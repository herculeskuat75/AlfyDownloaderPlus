# AlfyDownloader+
Push this folder to GitHub; the workflow in `.github/workflows/build.yml` builds a debug APK (Actions → artifact).
