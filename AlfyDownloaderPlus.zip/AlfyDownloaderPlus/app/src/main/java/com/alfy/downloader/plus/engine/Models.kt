package com.alfy.downloader.plus.engine

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList

enum class Status { QUEUED, DOWNLOADING, PAUSED, COMPLETED, FAILED }

data class FoundMedia(val url: String, val headers: Map<String, String>, val label: String, val info: String)

data class DownloadItem(
    val id: String,
    val url: String,
    var title: String,
    val headers: Map<String, String>,
    var dir: String,
    var audioOnly: Boolean,
    var convert: Boolean,
    var status: Status = Status.QUEUED,
    var downloaded: Long = 0,
    var total: Long = -1,
    var path: String = "",
    var error: String = ""
) {
    fun percent(): Int = if (total > 0) ((downloaded * 100) / total).toInt().coerceIn(0, 100) else 0
}

object Repo {
    val items = CopyOnWriteArrayList<DownloadItem>()
    val found = CopyOnWriteArrayList<FoundMedia>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    private var file: File? = null
    private var inited = false

    fun init(c: Context) {
        if (inited) return
        inited = true
        file = File(c.filesDir, "items.json")
        try {
            val a = JSONArray(file!!.readText())
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val h = o.getJSONObject("h")
                val hm = h.keys().asSequence().associateWith { k -> h.getString(k) }
                var st = Status.valueOf(o.getString("st"))
                if (st == Status.DOWNLOADING || st == Status.QUEUED) st = Status.PAUSED
                items.add(DownloadItem(o.getString("id"), o.getString("url"), o.getString("title"), hm,
                    o.getString("dir"), o.getBoolean("audio"), o.getBoolean("conv"), st,
                    o.getLong("done"), o.getLong("total"), o.getString("path")))
            }
        } catch (_: Exception) { }
    }

    fun save() {
        try {
            val a = JSONArray()
            items.forEach {
                a.put(JSONObject().put("id", it.id).put("url", it.url).put("title", it.title)
                    .put("h", JSONObject(it.headers)).put("dir", it.dir).put("audio", it.audioOnly)
                    .put("conv", it.convert).put("st", it.status.name).put("done", it.downloaded)
                    .put("total", it.total).put("path", it.path))
            }
            file?.writeText(a.toString())
        } catch (_: Exception) { }
    }

    fun changed() { main.post { listeners.forEach { it() } } }
    fun listen(l: () -> Unit) { listeners.add(l) }
    fun unlisten(l: () -> Unit) { listeners.remove(l) }
    fun addFound(m: FoundMedia) { found.add(m); changed() }
    fun removeFound(m: FoundMedia) { found.remove(m); changed() }
    fun clearFound() { found.clear(); changed() }
}
