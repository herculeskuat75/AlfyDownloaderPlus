package com.alfy.downloader.plus.ui

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import com.alfy.downloader.plus.engine.*
import java.util.UUID

class DownloadDialogActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(this)
        val url = intent.getStringExtra("url") ?: run { finish(); return }
        val headers = Repo.found.firstOrNull { it.url == url }?.headers ?: Sniffer.headersFor(url, null)
        val isAudioSrc = url.substringBefore('?').lowercase().let { it.endsWith(".mp3") || it.endsWith(".m4a") }

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(16), dp(20), dp(8)) }
        col.addView(TextView(this).apply { text = "Download settings"; textSize = 20f })
        val name = EditText(this).apply {
            setText(Uri.parse(url).lastPathSegment?.substringBeforeLast('.') ?: "media"); hint = "File name"; setSingleLine()
        }
        col.addView(name)
        val rg = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val rbV = RadioButton(this).apply { text = "Video (MP4)"; id = 1; isEnabled = !isAudioSrc }
        val rbA = RadioButton(this).apply { text = "Audio (M4A / MP3)"; id = 2 }
        rg.addView(rbV); rg.addView(rbA); rg.check(if (isAudioSrc) 2 else 1)
        col.addView(rg)
        val path = EditText(this).apply { setText(Prefs.dir(this@DownloadDialogActivity)); hint = "Storage path"; setSingleLine() }
        col.addView(path)
        val cbConv = CheckBox(this).apply { text = "Auto-convert / remux to MP4"; isChecked = true }
        col.addView(cbConv)

        fun make(): DownloadItem {
            Prefs.setDir(this, path.text.toString())
            val it = DownloadItem(UUID.randomUUID().toString(), url, name.text.toString().ifBlank { "media" }, headers,
                path.text.toString(), rg.checkedRadioButtonId == 2, cbConv.isChecked)
            Repo.items.add(0, it)
            return it
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(t: String, a: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { a() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        row.addView(btn("Cancel") { finish() })
        row.addView(btn("Add") { make().status = Status.PAUSED; Repo.save(); Repo.changed(); finish() })
        row.addView(btn("Start") { DownloadEngine.start(this, make()); finish() })
        col.addView(row)
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
