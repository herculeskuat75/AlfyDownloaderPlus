package com.alfy.downloader.plus.ui

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StrictMode
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.alfy.downloader.plus.engine.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var listBox: LinearLayout
    private lateinit var gearBadge: TextView
    private lateinit var drawer: LinearLayout
    private val tabNames = listOf("All", "Downloading", "Paused", "Completed")
    private val tabViews = mutableListOf<TextView>()
    private var tab = 0
    private var rootOk: Boolean? = null
    private val cb: () -> Unit = { render() }

    private val dark get() = Prefs.dark(this)
    private val bg get() = if (dark) 0xFF121212.toInt() else 0xFFF4F5F7.toInt()
    private val card get() = if (dark) 0xFF1E1F24.toInt() else 0xFFFFFFFF.toInt()
    private val fg get() = if (dark) 0xFFEDEDED.toInt() else 0xFF111111.toInt()
    private val accent = 0xFF3D7BFF.toInt()

    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(this)
        StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().build())
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        buildUi()
        Repo.listen(cb)
        if (intent?.action == Intent.ACTION_SEND) intent.getStringExtra(Intent.EXTRA_TEXT)?.let { Sniffer.handleText(this, it) }
    }

    override fun onDestroy() { Repo.unlisten(cb); super.onDestroy() }

    override fun onResume() {
        super.onResume()
        updateGear()
        Thread { val ok = RootShell.available(); runOnUiThread { rootOk = ok; updateGear() } }.start()
        if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, FloatingService::class.java))
        render()
    }

    private fun hasStorage() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun updateGear() {
        val missing = !hasStorage() || !Settings.canDrawOverlays(this) || rootOk != true
        gearBadge.visibility = if (missing) View.VISIBLE else View.GONE
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(bg) }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(36), dp(12), 0) }

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "≡"; textSize = 26f; setTextColor(fg); setPadding(dp(8), 0, dp(14), 0)
            setOnClickListener { toggleDrawer() }
        })
        header.addView(TextView(this).apply { text = "AlfyDownloader+"; textSize = 20f; setTextColor(fg) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val gear = FrameLayout(this)
        gear.addView(TextView(this).apply { text = "⚙"; textSize = 26f; setTextColor(fg); setPadding(dp(10), dp(4), dp(10), dp(4)) })
        gearBadge = TextView(this).apply {
            text = "!"; textSize = 11f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFE53935.toInt()) }
        }
        gear.addView(gearBadge, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.TOP or Gravity.END))
        gear.setOnClickListener { showPermissions() }
        header.addView(gear)
        content.addView(header)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabNames.forEachIndexed { i, n ->
            val t = TextView(this).apply {
                text = n; gravity = Gravity.CENTER; textSize = 13f; setPadding(0, dp(12), 0, dp(12))
                setOnClickListener { tab = i; render() }
            }
            tabViews.add(t); tabs.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        content.addView(tabs)

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(90)) }
        content.addView(ScrollView(this).apply { addView(listBox) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(content)

        root.addView(TextView(this).apply {
            text = "+"; textSize = 30f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(accent) }
            elevation = dp(6).toFloat(); setOnClickListener { addUrlDialog() }
        }, FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(20), dp(24)) })

        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(card); setPadding(dp(16), dp(48), dp(16), dp(16))
            elevation = dp(16).toFloat(); translationX = -dp(290).toFloat()
        }
        drawer.addView(TextView(this).apply { text = "Storage location"; setTextColor(fg); textSize = 15f })
        val dirEt = EditText(this).apply { setText(Prefs.dir(this@MainActivity)); setTextColor(fg); textSize = 13f }
        drawer.addView(dirEt)
        drawer.addView(Button(this).apply { text = "Save path"; setOnClickListener { Prefs.setDir(this@MainActivity, dirEt.text.toString()); toast("Saved") } })
        drawer.addView(TextView(this).apply { text = "Theme"; setTextColor(fg); textSize = 15f; setPadding(0, dp(20), 0, 0) })
        drawer.addView(Switch(this).apply {
            text = "Dark mode"; setTextColor(fg); isChecked = dark
            setOnCheckedChangeListener { _, v -> Prefs.setDark(this@MainActivity, v); recreate() }
        })
        root.addView(drawer, FrameLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
    }

    private var drawerOpen = false
    private fun toggleDrawer() {
        drawerOpen = !drawerOpen
        drawer.animate().translationX(if (drawerOpen) 0f else -dp(290).toFloat()).setDuration(200).start()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun addUrlDialog() {
        val et = EditText(this).apply { hint = "Paste media or page URL"; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Add download").setView(et)
            .setPositiveButton("Next") { _, _ ->
                val u = et.text.toString().trim()
                if (u.isEmpty()) return@setPositiveButton
                if (Sniffer.isMedia(u)) startActivity(Intent(this, DownloadDialogActivity::class.java).putExtra("url", u))
                else { toast("Scanning page…"); Sniffer.handleText(this, u) }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showPermissions() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), 0) }
        fun row(name: String, ok: Boolean?, grant: () -> Unit) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            r.addView(TextView(this).apply { text = (if (ok == true) "✅ " else "❗ ") + name; textSize = 15f },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (ok != true) r.addView(Button(this).apply { text = "Grant"; setOnClickListener { grant() } })
            col.addView(r)
        }
        row("Root access (su)", rootOk) {
            Thread { val ok = RootShell.available(); runOnUiThread { rootOk = ok; updateGear(); toast(if (ok) "Root granted" else "Root denied/unavailable") } }.start()
        }
        row("Storage access", hasStorage()) {
            if (Build.VERSION.SDK_INT >= 30)
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            else requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 2)
        }
        row("Floating bubble (overlay)", Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        AlertDialog.Builder(this).setTitle("Permissions").setView(col).setPositiveButton("Close", null).show()
    }

    private fun render() {
        if (!::listBox.isInitialized) return
        tabViews.forEachIndexed { i, t ->
            t.setTextColor(if (i == tab) accent else fg)
            t.setBackgroundColor(if (i == tab) (if (dark) 0xFF1E2A44.toInt() else 0xFFE3ECFF.toInt()) else 0)
        }
        listBox.removeAllViews()
        val shown = Repo.items.filter {
            when (tab) {
                1 -> it.status == Status.DOWNLOADING || it.status == Status.QUEUED
                2 -> it.status == Status.PAUSED || it.status == Status.FAILED
                3 -> it.status == Status.COMPLETED
                else -> true
            }
        }
        if (shown.isEmpty()) listBox.addView(TextView(this).apply {
            text = "Nothing here yet. Tap + or use the floating bubble."; setTextColor(fg); alpha = 0.6f; gravity = Gravity.CENTER; setPadding(0, dp(60), 0, 0)
        })
        shown.forEach { listBox.addView(itemView(it)) }
    }

    private fun itemView(it: DownloadItem): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(10)); background = round(card, 14)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(5), 0, dp(5)) }
        }
        c.addView(TextView(this).apply { text = it.title; setTextColor(fg); textSize = 15f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
        c.addView(TextView(this).apply {
            text = "${it.status.name.lowercase().replaceFirstChar { ch -> ch.uppercase() }} • ${it.percent()}%" +
                (if (it.error.isNotEmpty()) " • ${it.error}" else "")
            setTextColor(fg); alpha = 0.65f; textSize = 12f
        })
        c.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = it.percent() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(10)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        fun b(t: String, a: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(accent); textSize = 14f; setPadding(dp(14), dp(10), dp(6), dp(4)); setOnClickListener { a() }
        }
        when (it.status) {
            Status.DOWNLOADING, Status.QUEUED -> row.addView(b("Pause") { DownloadEngine.pause(it) })
            Status.PAUSED, Status.FAILED -> row.addView(b(if (it.status == Status.FAILED) "Retry" else "Resume") { DownloadEngine.start(this, it) })
            Status.COMPLETED -> row.addView(b("Open") { openFile(it) })
        }
        row.addView(b("Delete") { DownloadEngine.delete(it) })
        c.addView(row)
        return c
    }

    private fun openFile(it: DownloadItem) {
        val f = File(it.path)
        if (!f.exists()) { toast("File not found"); return }
        val mime = if (f.extension in listOf("m4a", "mp3")) "audio/*" else "video/*"
        try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.fromFile(f), mime)) }
        catch (e: Exception) { toast("No app to open this file") }
    }
}
