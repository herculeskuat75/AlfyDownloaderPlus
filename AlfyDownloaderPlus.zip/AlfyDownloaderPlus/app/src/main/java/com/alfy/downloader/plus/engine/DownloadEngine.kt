package com.alfy.downloader.plus.engine

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

object DownloadEngine {
    private val pool = Executors.newFixedThreadPool(3)
    private val stops = ConcurrentHashMap<String, AtomicBoolean>()

    fun start(ctx: Context, item: DownloadItem) {
        if (stops.containsKey(item.id)) return
        val stop = AtomicBoolean(false)
        stops[item.id] = stop
        item.status = Status.DOWNLOADING; item.error = ""
        Repo.save(); Repo.changed()
        val app = ctx.applicationContext
        pool.execute {
            try {
                val finished = run(app, item, stop)
                item.status = if (finished) Status.COMPLETED else Status.PAUSED
            } catch (e: Exception) {
                item.status = if (stop.get()) Status.PAUSED else Status.FAILED
                if (item.status == Status.FAILED) item.error = e.message ?: "error"
            } finally {
                stops.remove(item.id)
                Repo.save(); Repo.changed()
            }
        }
    }

    fun pause(item: DownloadItem) { stops[item.id]?.set(true) }

    fun delete(item: DownloadItem) {
        pause(item)
        Repo.items.remove(item)
        try { File(item.path).delete(); File(item.path.substringBeforeLast('.') + ".part").delete() } catch (_: Exception) { }
        Repo.save(); Repo.changed()
    }

    private fun safe(s: String) = s.replace(Regex("[^\\w\\- .]"), "_").take(80).ifBlank { "media" }

    private fun run(ctx: Context, item: DownloadItem, stop: AtomicBoolean): Boolean {
        val dir = File(item.dir); dir.mkdirs()
        val isHls = item.url.substringBefore('?').endsWith(".m3u8", true)
        val srcExt = if (isHls) "ts" else item.url.substringBefore('?').substringAfterLast('.', "mp4").lowercase().take(4)
        val base = safe(item.title)
        val file = if (item.path.isNotEmpty() && File(item.path).parentFile == dir) File(item.path) else File(dir, "$base.$srcExt")
        item.path = file.absolutePath
        val ok = if (isHls) hls(item, file, stop) else direct(item, file, stop)
        if (!ok) return false

        val ext = file.extension.lowercase()
        val audioDone = ext == "m4a" || ext == "mp3"
        val wantAudio = item.audioOnly && !audioDone
        val wantMp4 = !item.audioOnly && (isHls || (item.convert && (ext == "ts" || ext == "mkv")))
        if (wantAudio || wantMp4) {
            val out = File(dir, "$base." + if (wantAudio) "m4a" else "mp4")
            if (Converter.convert(ctx, file, out, wantAudio)) {
                file.delete(); item.path = out.absolutePath
            } else item.error = "Conversion failed, original kept"
        }
        return true
    }

    private fun direct(item: DownloadItem, file: File, stop: AtomicBoolean): Boolean {
        var from = if (file.exists()) file.length() else 0L
        Http.client.newCall(Http.req(item.url, item.headers, from)).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val resumed = r.code == 206
            if (!resumed) from = 0
            val len = r.body!!.contentLength()
            item.total = if (len > 0) len + from else -1
            item.downloaded = from
            FileOutputStream(file, resumed).use { out ->
                val buf = ByteArray(64 * 1024)
                val src = r.body!!.byteStream()
                var last = 0L
                while (true) {
                    if (stop.get()) return false
                    val n = src.read(buf); if (n < 0) break
                    out.write(buf, 0, n); item.downloaded += n
                    val now = System.currentTimeMillis()
                    if (now - last > 300) { last = now; Repo.changed() }
                }
            }
        }
        return true
    }

    private fun pickVariant(master: String, base: String): String {
        val lines = master.lines(); var best: String? = null; var bestBw = -1L
        for (i in lines.indices) {
            val l = lines[i]
            if (!l.startsWith("#EXT-X-STREAM-INF")) continue
            val bw = Regex("BANDWIDTH=(\\d+)").find(l)?.groupValues?.get(1)?.toLong() ?: 0L
            val side = Regex("RESOLUTION=(\\d+)x(\\d+)").find(l)?.let { minOf(it.groupValues[1].toInt(), it.groupValues[2].toInt()) } ?: 1080
            if (side in 240..1080 && bw > bestBw) {
                val next = lines.drop(i + 1).firstOrNull { it.isNotBlank() && !it.startsWith("#") }
                if (next != null) { best = Http.resolve(base, next.trim()); bestBw = bw }
            }
        }
        return best ?: throw IOException("No 240p-1080p variant")
    }

    private fun hls(item: DownloadItem, tmp: File, stop: AtomicBoolean): Boolean {
        var base = item.url
        var pl = Http.get(base, item.headers)
        if (pl.contains("#EXT-X-STREAM-INF")) { base = pickVariant(pl, base); pl = Http.get(base, item.headers) }
        if (pl.lines().any { it.startsWith("#EXT-X-KEY") && !it.contains("METHOD=NONE") })
            throw IOException("Encrypted HLS is not supported")
        val segs = pl.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }.map { Http.resolve(base, it) }
        if (segs.isEmpty()) throw IOException("Empty playlist")
        item.total = segs.size.toLong()
        if (item.downloaded == 0L) tmp.delete()
        FileOutputStream(tmp, true).use { out ->
            for (i in item.downloaded.toInt() until segs.size) {
                if (stop.get()) return false
                Http.client.newCall(Http.req(segs[i], item.headers)).execute().use { r ->
                    if (!r.isSuccessful) throw IOException("Segment HTTP ${r.code}")
                    r.body!!.byteStream().copyTo(out)
                }
                item.downloaded = (i + 1).toLong(); Repo.changed()
            }
        }
        return true
    }
}
