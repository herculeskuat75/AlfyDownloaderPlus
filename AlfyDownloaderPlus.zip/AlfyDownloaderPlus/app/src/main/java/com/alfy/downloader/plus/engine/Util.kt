package com.alfy.downloader.plus.engine

import android.content.Context
import android.os.Environment
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.net.URI
import java.util.concurrent.TimeUnit

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("alfy", Context.MODE_PRIVATE)
    fun dir(c: Context): String = sp(c).getString("dir", null)
        ?: File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AlfyDownloader").absolutePath
    fun setDir(c: Context, v: String) = sp(c).edit().putString("dir", v).apply()
    fun dark(c: Context) = sp(c).getBoolean("dark", true)
    fun setDark(c: Context, v: Boolean) = sp(c).edit().putBoolean("dark", v).apply()
}

object Http {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true).followSslRedirects(true).build()

    fun req(url: String, h: Map<String, String>, rangeFrom: Long = 0): Request {
        val b = Request.Builder().url(url)
        h.forEach { (k, v) -> b.header(k, v) }
        if (rangeFrom > 0) b.header("Range", "bytes=$rangeFrom-")
        return b.build()
    }

    fun get(url: String, h: Map<String, String>): String =
        client.newCall(req(url, h)).execute().use {
            if (!it.isSuccessful) throw IOException("HTTP ${it.code}")
            it.body!!.string()
        }

    fun resolve(base: String, ref: String): String = URI(base).resolve(ref).toString()
}
