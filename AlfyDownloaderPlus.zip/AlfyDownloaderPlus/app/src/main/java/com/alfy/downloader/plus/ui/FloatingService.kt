package com.alfy.downloader.plus.ui

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.alfy.downloader.plus.engine.*
import kotlin.math.abs

class SwipeRow(ctx: Context, private val onDismiss: () -> Unit) : LinearLayout(ctx) {
    private var dx0 = 0f; private var dy0 = 0f; private var swiping = false
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dx0 = e.rawX; dy0 = e.rawY; swiping = false }
            MotionEvent.ACTION_MOVE -> if (!swiping && abs(e.rawX - dx0) > context.dp(16) && abs(e.rawX - dx0) > abs(e.rawY - dy0)) {
                swiping = true; parent?.requestDisallowInterceptTouchEvent(true)
            }
        }
        return swiping
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dx0 = e.rawX; dy0 = e.rawY }
            MotionEvent.ACTION_MOVE -> { translationX = e.rawX - dx0; alpha = (1f - abs(translationX) / width).coerceIn(0.2f, 1f) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (abs(translationX) > width * 0.4f) onDismiss() else animate().translationX(0f).alpha(1f).start()
                swiping = false
            }
        }
        return true
    }
}

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: FrameLayout? = null
    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private lateinit var badge: TextView
    private var listBox: LinearLayout? = null
    private val players = mutableListOf<ExoPlayer>()
    private var lastSig = -1
    private val cb: () -> Unit = { refresh() }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        Repo.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("alfy", "AlfyDownloader+", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "alfy").setContentTitle("AlfyDownloader+ is running")
            .setSmallIcon(android.R.drawable.stat_sys_download).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(1, n)
        addBubble()
        Repo.listen(cb)
    }

    override fun onDestroy() {
        Repo.unlisten(cb); releasePlayers()
        bubble?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    private val overlayType get() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun circle(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
    private fun round(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun addBubble() {
        val lp = WindowManager.LayoutParams(dp(60), dp(60), overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 0; y = dp(200)
        }
        val fl = FrameLayout(this)
        fl.addView(TextView(this).apply {
            text = "⬇"; textSize = 24f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
            background = circle(0xDD3D7BFF.toInt())
        }, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
        badge = TextView(this).apply {
            textSize = 11f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER; background = circle(0xFFE53935.toInt()); text = "0"
        }
        fl.addView(badge, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP or Gravity.END))
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        fl.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) > dp(8) || abs(e.rawY - sy) > dp(8)) moved = true
                    if (moved) { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(fl, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        bubble = fl; wm.addView(fl, lp); refresh()
    }

    private fun togglePanel() {
        if (panel != null) { releasePlayers(); runCatching { wm.removeView(panel) }; panel = null; listBox = null; return }
        val lp = WindowManager.LayoutParams(dp(330), dp(450), overlayType, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(110)
            if (Build.VERSION.SDK_INT >= 31) { flags = flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND; blurBehindRadius = 40 }
        }
        panelLp = lp
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(6))
            background = round(0xCC14171F.toInt(), 20).apply { setStroke(dp(1), 0x33FFFFFF) }
        }
        fun btn(t: String, w: Float = 1f, a: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER; textSize = 13f
            setPadding(dp(8), dp(9), dp(8), dp(9)); background = round(0x33FFFFFF, 12)
            layoutParams = LinearLayout.LayoutParams(if (w > 0) 0 else ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, w).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
            setOnClickListener { a() }
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(btn("≡", 0f) { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) })
        val title = TextView(this).apply { text = "AlfyDownloader+"; setTextColor(0xFFFFFFFF.toInt()); textSize = 15f; gravity = Gravity.CENTER }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        title.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(root, lp) }
            }
            true
        }
        top.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(btn("✕", 0f) { togglePanel() })
        root.addView(top)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(btn("Screen Scan") { Sniffer.screenScan(this); Sniffer.toast(this, "Scanning screen…") })
        actions.addView(btn("Paste") { startActivity(Intent(this, PasteActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) })
        actions.addView(btn("Clear All") { releasePlayers(); Repo.clearFound() })
        root.addView(actions)

        val lb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listBox = lb
        root.addView(ScrollView(this).apply { addView(lb) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val handle = TextView(this).apply { text = "◢"; setTextColor(0x99FFFFFF.toInt()); gravity = Gravity.END; textSize = 16f }
        var rx = 0f; var ry = 0f; var rw = 0; var rh = 0
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { rx = e.rawX; ry = e.rawY; rw = lp.width; rh = lp.height }
                MotionEvent.ACTION_MOVE -> {
                    lp.width = (rw + (e.rawX - rx)).toInt().coerceAtLeast(dp(240))
                    lp.height = (rh + (e.rawY - ry)).toInt().coerceAtLeast(dp(260)); wm.updateViewLayout(root, lp)
                }
            }
            true
        }
        root.addView(handle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)))
        panel = root; wm.addView(root, lp); lastSig = -1; refresh()
    }

    private fun releasePlayers() { players.forEach { runCatching { it.release() } }; players.clear() }

    private fun refresh() {
        if (::badge.isInitialized) badge.text = Repo.found.size.toString()
        val lb = listBox ?: return
        val sig = Repo.found.map { it.url }.hashCode()
        if (sig == lastSig) return
        lastSig = sig
        releasePlayers(); lb.removeAllViews()
        if (Repo.found.isEmpty()) {
            lb.addView(TextView(this).apply {
                text = "No media yet.\nPlay a video in any app, then tap Screen Scan, or copy a link and tap Paste."
                setTextColor(0xAAFFFFFF.toInt()); setPadding(dp(8), dp(24), dp(8), dp(8)); gravity = Gravity.CENTER
            })
            return
        }
        Repo.found.forEach { lb.addView(row(it)) }
    }

    private fun row(m: FoundMedia): View {
        val row = SwipeRow(this) { Repo.removeFound(m) }.apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6)); background = round(0x22FFFFFF, 14)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(4), 0, dp(4)) }
        }
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        line.addView(TextView(this).apply {
            text = "${m.label}\n${m.info}"; setTextColor(0xFFFFFFFF.toInt()); textSize = 12f; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val holder = FrameLayout(this).apply { visibility = View.GONE }
        fun small(t: String, a: () -> Unit) = TextView(this).apply {
            text = t; textSize = 16f; setTextColor(0xFFFFFFFF.toInt()); setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { a() }
        }
        var player: ExoPlayer? = null
        line.addView(small("▶") {
            if (holder.visibility == View.VISIBLE) {
                player?.release(); players.remove(player); player = null; holder.removeAllViews(); holder.visibility = View.GONE
            } else {
                val tctx = ContextThemeWrapper(this, android.R.style.Theme_Material_Light)
                val ds = OkHttpDataSource.Factory(Http.client).setDefaultRequestProperties(m.headers)
                val p = ExoPlayer.Builder(tctx).setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build()
                val pv = PlayerView(tctx).apply { this.player = p; layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)) }
                holder.addView(pv); holder.visibility = View.VISIBLE
                p.setMediaItem(MediaItem.fromUri(m.url)); p.prepare(); p.playWhenReady = true
                player = p; players.add(p)
            }
        })
        line.addView(small("⬇") {
            startActivity(Intent(this, DownloadDialogActivity::class.java).putExtra("url", m.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        row.addView(line); row.addView(holder)
        return row
    }
}
