package com.alfy.downloader.plus.engine

import android.media.MediaMetadataRetriever

data class Check(val ok: Boolean, val info: String)

/** Filters: short side must be 240..1080 px; silent videos are rejected. Unverifiable media is kept. */
object MediaValidator {
    fun check(url: String, headers: Map<String, String>): Check = try {
        if (url.substringBefore('?').endsWith(".m3u8", true)) hls(url, headers) else probe(url, headers)
    } catch (e: Exception) { Check(true, "unverified") }

    private fun probe(url: String, headers: Map<String, String>): Check {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(url, headers)
            val hasVideo = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"
            val hasAudio = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
            if (!hasVideo) return Check(true, "audio")
            if (!hasAudio) return Check(false, "muted")
            if (h != null && w != null) {
                val side = minOf(h, w)
                if (side < 240 || side > 1080) return Check(false, "${side}p out of range")
                return Check(true, "${side}p")
            }
            return Check(true, "video")
        } finally { r.release() }
    }

    private fun hls(url: String, headers: Map<String, String>): Check {
        val pl = Http.get(url, headers)
        if (!pl.contains("#EXT-X-STREAM-INF")) return Check(true, "HLS")
        val sides = Regex("RESOLUTION=(\\d+)x(\\d+)").findAll(pl).map { minOf(it.groupValues[1].toInt(), it.groupValues[2].toInt()) }.toList()
        if (sides.isEmpty()) return Check(true, "HLS")
        val ok = sides.filter { it in 240..1080 }
        return if (ok.isEmpty()) Check(false, "no 240-1080p variant") else Check(true, "HLS up to ${ok.max()}p")
    }
}
