package com.alfy.downloader.plus.engine

object RootShell {
    fun run(cmd: String): String = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Exception) { "" }

    fun available(): Boolean = run("id").contains("uid=0")
}
