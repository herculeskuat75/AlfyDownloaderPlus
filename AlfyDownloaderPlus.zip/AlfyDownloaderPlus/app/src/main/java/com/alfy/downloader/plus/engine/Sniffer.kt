package com.alfy.downloader.plus.engine

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.net.URI
import java.util.concurrent.Executors

/** Root-assisted discovery: UI dump + logcat scan, clipboard text and homepage pre-fetching. */
object Sniffer {
    val exec = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())
    const val UA = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
    private val mediaRe = Regex("""https?://[^\s"'<>\\)]+?\.(?:mp4|mkv|ts|m3u8|m4a|mp3)(?:\?[^\s"'<>\\)]*)?""", RegexOption.IGNORE_CASE)
    private val urlRe = Regex("""https?://[^\s"'<>\\)]+""")
    private val ogRe = Regex("""property=["']og:video(?::url|:secure_url)?["']\s+content=["']([^"']+)["']""", RegexOption.IGNORE_CASE)

    fun isMedia(url: String) = mediaRe.matches(url)

    fun headersFor(url: String, referer: String?): Map<String, String> {
        val origin = try { URI(url).let { "${it.scheme}://${it.host}/" } } catch (e: Exception) { "" }
        return mapOf("User-Agent" to UA, "Referer" to (referer ?: origin))
    }

    private fun clean(t: String) = t.replace("\\/", "/").replace("\\u0026", "&").replace("&amp;", "&")

    fun toast(ctx: Context, msg: String) {
        val app = ctx.applicationContext
        main.post { Toast.makeText(app, msg, Toast.LENGTH_SHORT).show() }
    }

    fun handleText(ctx: Context, text: String) = exec.execute {
        val n = handleTextSync(text)
        toast(ctx, if (n > 0) "Found $n media link(s)" else "No media found")
    }

    fun handleTextSync(text: String): Int {
        val before = Repo.found.size
        val t = clean(text)
        mediaRe.findAll(t).map { it.value }.distinct().toList().takeLast(20).forEach { consider(it, null) }
        urlRe.findAll(t).map { it.value }.filter { !isMedia(it) }.distinct().take(3).forEach { prefetchPage(it) }
        return Repo.found.size - before
    }

    /** Auto pre-fetch: loads a page and extracts media URLs from HTML/JSON. */
    fun prefetchPage(pageUrl: String) {
        try {
            val body = Http.client.newCall(Http.req(pageUrl, headersFor(pageUrl, null))).execute().use {
                if (!it.isSuccessful) return
                clean(it.peekBody(2_000_000).string())
            }
            val urls = mediaRe.findAll(body).map { it.value }.toMutableList()
            ogRe.findAll(body).forEach { urls.add(it.groupValues[1]) }
            urls.distinct().take(15).forEach { consider(it, pageUrl) }
        } catch (_: Exception) { }
    }

    private fun consider(url: String, referer: String?) {
        if (Repo.found.any { it.url == url }) return
        val h = headersFor(url, referer)
        val c = MediaValidator.check(url, h)
        if (!c.ok) return
        val label = url.substringBefore('?').substringAfterLast('/').ifBlank { "media" }
        Repo.addFound(FoundMedia(url, h, label, c.info))
    }

    fun screenScan(ctx: Context) = exec.execute {
        if (!RootShell.available()) { toast(ctx, "Root (su) not available"); return@execute }
        val ui = RootShell.run("uiautomator dump /sdcard/alfy_ui.xml >/dev/null 2>&1; cat /sdcard/alfy_ui.xml; rm -f /sdcard/alfy_ui.xml")
        val log = RootShell.run("logcat -d -t 4000")
        val n = handleTextSync(ui + "\n" + log)
        toast(ctx, if (n > 0) "Found $n media link(s)" else "Nothing found on screen")
    }
}
