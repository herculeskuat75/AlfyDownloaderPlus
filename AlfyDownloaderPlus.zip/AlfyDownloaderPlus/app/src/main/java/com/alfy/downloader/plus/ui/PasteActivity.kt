package com.alfy.downloader.plus.ui

import android.app.Activity
import android.content.ClipboardManager
import com.alfy.downloader.plus.engine.Sniffer

/** Transparent activity: clipboard can only be read by a focused foreground window on Android 10+. */
class PasteActivity : Activity() {
    private var done = false
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !done) {
            done = true
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
            if (t.isBlank()) Sniffer.toast(this, "Clipboard is empty")
            else { Sniffer.toast(this, "Scanning clipboard…"); Sniffer.handleText(this, t) }
            finish()
        }
    }
}
