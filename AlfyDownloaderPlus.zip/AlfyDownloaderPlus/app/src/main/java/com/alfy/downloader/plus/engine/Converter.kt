package com.alfy.downloader.plus.engine

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Background remux (TS/MKV -> MP4) and audio extraction (-> M4A) using Media3 Transformer. */
object Converter {
    fun convert(ctx: Context, input: File, output: File, audioOnly: Boolean): Boolean {
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        val app = ctx.applicationContext
        Handler(Looper.getMainLooper()).post {
            try {
                output.delete()
                val t = Transformer.Builder(app).addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) { ok.set(true); latch.countDown() }
                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) { latch.countDown() }
                }).build()
                val edited = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(input))).setRemoveVideo(audioOnly).build()
                t.start(edited, output.absolutePath)
            } catch (e: Exception) { latch.countDown() }
        }
        latch.await(30, TimeUnit.MINUTES)
        return ok.get() && output.exists() && output.length() > 0
    }
}
