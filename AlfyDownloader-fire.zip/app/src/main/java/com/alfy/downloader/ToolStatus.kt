package com.alfy.downloader

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Status 4 tingkat per tool (SCAN/OK/GAGAL/NONAKTIF), teks Indonesia sederhana, laporan detail, dan scan ulang manual. */
object ToolStatus {
    enum class St { SCAN, OK, FAIL, OFF }

    const val TXT_OK = "Video/musik ditemukan"
    const val TXT_FAIL = "Tidak bisa mendapatkan video/musik pada situs ini"

    private val hist = ConcurrentHashMap<String, java.util.LinkedList<String>>()
    @Volatile private var lastRescanAt = 0L

    private fun now(): String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())

    /** Dicatat dari ToolLog.set/side (hanya saat tool benar-benar berjalan). */
    fun note(tool: String, s: String) {
        try {
            val q = hist.getOrPut(tool) { java.util.LinkedList() }
            synchronized(q) {
                if (q.peekLast()?.endsWith(" | $s") == true) return
                q.add(now() + " | " + s)
                while (q.size > 40) q.removeFirst()
            }
        } catch (e: Exception) { }
    }

    private fun noteAll(s: String) { for (n in ToolLog.chainAll + ToolLog.monAll) note(n, s) }

    fun state(n: String): St {
        if (!Tool.on(n)) return St.OFF
        val s = ToolLog.statusOf(n)
        if (n in svcTools) return if (s.startsWith("✓")) St.OK else if (s.startsWith("•")) St.SCAN else St.FAIL
        return when {
            s.startsWith("✓") -> St.OK
            s.startsWith("⏳") -> St.SCAN
            s.startsWith("✗") -> St.FAIL
            s.contains("dimatikan") || s.contains("lewati") || s.startsWith("•") -> St.OFF
            else -> {
                val x = s.lowercase()
                if (s.startsWith("–") || listOf("gagal", "error", "mati", "berhenti", "belum", "tidak").any { it in x }) St.FAIL
                else if ("memuat" in x || "menunggu" in x || "memindai" in x) St.SCAN
                else St.OFF
            }
        }
    }

    private fun offText(n: String): String {
        if (!Tool.on(n)) return "Nonaktif"
        val s = ToolLog.statusOf(n)
        return when {
            s.contains("dimatikan") -> "Nonaktif"
            s.contains("lewati") -> "Dilewati (video sudah ditemukan tool lain)"
            s.startsWith("•") -> "Menunggu"
            else -> "Nonaktif"
        }
    }

    /** Teks status ramah. [spin] = penanda untuk status SCAN (di panel berupa ◐◓◑◒, di dialog kosong karena ada ProgressBar). */
    private val svcTools = setOf("Aksesibilitas", "ffmpeg")
    fun label(n: String, spin: String = ""): String = if (n in svcTools && Tool.on(n)) when (state(n)) {
        St.OK -> "✓ Aktif"
        St.SCAN -> "• Memuat…"
        else -> "✗ Tidak aktif"
    } else when (state(n)) {
        St.SCAN -> (if (spin.isEmpty()) "" else "$spin ") + "Sedang scan…"
        St.OK -> "✓ $TXT_OK"
        St.FAIL -> "✗ $TXT_FAIL"
        St.OFF -> "– " + offText(n)
    }

    fun color(s: St): Int = when (s) {
        St.OK -> 0xFFA5D6A7.toInt()
        St.FAIL -> 0xFFEF5350.toInt()
        St.SCAN -> 0xFFFFE082.toInt()
        St.OFF -> 0xFF9E9E9E.toInt()
    }

    fun panelLines(): List<String> {
        val fr = "◐◓◑◒"[((System.currentTimeMillis() / 1000) % 4).toInt()].toString()
        return (ToolLog.chainAll + ToolLog.monAll).mapIndexed { i, n -> "${i + 1}. $n  " + label(n, fr) }
    }

    // ---------- laporan detail ----------
    fun detail(ctx: Context, n: String): String {
        val sb = StringBuilder()
        val df = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val raw = ToolLog.statusOf(n)
        val st = state(n)
        sb.append("=== LAPORAN DETAIL TOOL — AlfyDownloader+ ===\n\n[RINGKASAN]\n")
        sb.append("Tool        : ").append(n).append('\n')
        sb.append("Waktu       : ").append(df.format(Date())).append('\n')
        sb.append("Status      : ").append(st.name).append(" — ").append(label(n).trim()).append('\n')
        sb.append("Status mentah: ").append(raw).append('\n')
        sb.append("Tool aktif  : ").append(if (Tool.on(n)) "ya" else "tidak").append('\n')
        sb.append("Scan otomatis: ").append(Scan.modeText()).append("\n\n[PERANGKAT]\n")
        sb.append("Android     : ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
        sb.append("Perangkat   : ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
        try {
            val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
            sb.append("Versi app   : ").append(pi.versionName ?: "-").append('\n')
        } catch (e: Exception) { }
        sb.append("\n[SITUS / APLIKASI]\n")
        sb.append("Aplikasi di depan: ").append(AlfyAccessibilityService.fgPkg.ifEmpty { "-" }).append('\n')
        sb.append("Halaman terakhir : ").append(Resolver.lastPage.ifEmpty { "-" }).append('\n')
        sb.append("Halaman utama    : ").append(Resolver.mainPage.ifEmpty { "-" }).append('\n')
        sb.append("Tautan terdeteksi: ").append(Repo.detected.value.size).append('\n')
        sb.append("Diagnosa app     : ").append(Resolver.diag.ifEmpty { "-" }).append('\n')
        if (ToolLog.winner.isNotEmpty()) sb.append("Tool pemenang    : ").append(ToolLog.winner).append('\n')
        sb.append("\n[TUGAS TOOL]\n").append(ScanReport.ROLE[n] ?: "-").append('\n')
        sb.append("\n[KEMUNGKINAN PENYEBAB]\n").append(ScanReport.cause(n, raw)).append('\n')
        sb.append("\n[LANGKAH YANG DICOBA (terbaru di bawah)]\n")
        val q = hist[n]
        val steps = if (q == null) emptyList() else synchronized(q) { q.toList() }
        if (steps.isEmpty()) sb.append("(belum ada langkah tercatat sejak app dibuka)\n") else steps.forEach { sb.append("- ").append(it).append('\n') }
        val rj = try { Resolver.rejects.toList() } catch (e: Exception) { emptyList() }
        sb.append("\n[PENOLAKAN LINK TERAKHIR]\n")
        if (rj.isEmpty()) sb.append("(tidak ada)\n") else rj.forEach { sb.append("- ").append(it).append('\n') }
        sb.append("\n[SISTEM]\n").append(RootGate.status).append('\n').append(NetSniffer.status).append('\n').append(VpnTool.status).append('\n')
        sb.append("Mesin unduh: ").append(if (Engine.ready) "siap" else (Engine.error ?: "memuat…")).append('\n')
        if (NetSniffer.lastHit.isNotEmpty()) sb.append("Link terakhir (logcat): ").append(NetSniffer.lastHit).append('\n')
        if (Resolver.captchaPage.isNotEmpty()) sb.append("Butuh CAPTCHA di: ").append(Resolver.captchaPage).append('\n')
        sb.append("\n[STATUS SEMUA TOOL]\n")
        for (t in ToolLog.chainAll + ToolLog.monAll) sb.append("- ").append(t).append(": ").append(ToolLog.statusOf(t).replace("\n", " ")).append('\n')
        return sb.toString()
    }

    fun copyDetail(ctx: Context, n: String) {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("laporan $n", detail(ctx, n)))
            Toast.makeText(ctx, "Laporan detail $n disalin", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, "Gagal menyalin laporan", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- scan ulang manual (hanya saat ditekan; tidak menyalakan scan otomatis, tidak mengubah mode) ----------
    fun rescanOnce(ctx: Context) {
        val t = System.currentTimeMillis()
        if (t - lastRescanAt < 4000L) { Toast.makeText(ctx, "Scan ulang masih berjalan…", Toast.LENGTH_SHORT).show(); return }
        lastRescanAt = t
        val pages = listOf(Resolver.lastPage, Resolver.mainPage).filter { it.startsWith("http") }.distinct()
        noteAll("Scan ulang manual ditekan; halaman: " + pages.joinToString().ifEmpty { "-" })
        val acc = AlfyAccessibilityService.inst
        try { acc?.scanNow() } catch (e: Exception) { }
        for (pg in pages) {
            try { Resolver.rescan(pg, null, "Manual 🔄 scan ulang"); Resolver.sniff(pg, true) } catch (e: Exception) { }
        }
        Toast.makeText(ctx, if (pages.isEmpty() && acc == null) "Tidak ada situs terbuka. Buka situs atau aktifkan aksesibilitas (📖)" else "Memindai ulang…", Toast.LENGTH_SHORT).show()
    }
}
