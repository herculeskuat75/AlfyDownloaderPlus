#!/usr/bin/env python3
import os, re, shutil, sys

DEFAULT_NS = "com.alfyd.plus"
root = os.getcwd()
app = os.path.join(root, "app")
kts = os.path.join(app, "build.gradle.kts")
grv = os.path.join(app, "build.gradle")
gradle_file = kts if os.path.exists(kts) else (grv if os.path.exists(grv) else None)
if not gradle_file:
    sys.exit("app/build.gradle(.kts) not found")

txt = open(gradle_file, encoding="utf-8").read()
m = re.search(r'namespace\s*=?\s*["\']([\w.]+)["\']', txt) or re.search(r'applicationId\s*=?\s*["\']([\w.]+)["\']', txt)
ns = m.group(1) if m else DEFAULT_NS

src_root = os.path.join(app, "src", "main", "java")
old_dir = os.path.join(src_root, *DEFAULT_NS.split("."), "part3")
if ns != DEFAULT_NS and os.path.isdir(old_dir):
    new_dir = os.path.join(src_root, *ns.split("."), "part3")
    os.makedirs(os.path.dirname(new_dir), exist_ok=True)
    if os.path.exists(new_dir):
        shutil.rmtree(new_dir)
    shutil.move(old_dir, new_dir)
    for dp, _, fs in os.walk(new_dir):
        for f in fs:
            p = os.path.join(dp, f)
            s = open(p, encoding="utf-8").read().replace(DEFAULT_NS, ns)
            open(p, "w", encoding="utf-8").write(s)

if "part3-dependencies" not in txt:
    with open(gradle_file, "a", encoding="utf-8") as fh:
        if gradle_file.endswith(".kts"):
            fh.write('\napply(from = "part3-dependencies.gradle.kts")\n')
        else:
            fh.write("\napply from: 'part3-dependencies.gradle'\n")

mf = os.path.join(app, "src", "main", "AndroidManifest.xml")
x = open(mf, encoding="utf-8").read()
if "ALFYD_PART3" not in x:
    perms = [
        "android.permission.INTERNET",
        "android.permission.ACCESS_NETWORK_STATE",
        "android.permission.FOREGROUND_SERVICE",
        "android.permission.FOREGROUND_SERVICE_DATA_SYNC",
        "android.permission.POST_NOTIFICATIONS",
    ]
    lines = ["    <!-- ALFYD_PART3 -->"]
    for p in perms:
        if f'android:name="{p}"' not in x:
            lines.append(f'    <uses-permission android:name="{p}"/>')
    if 'android.permission.WRITE_EXTERNAL_STORAGE' not in x:
        lines.append('    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28"/>')
    block = "\n".join(lines) + "\n"
    x = re.sub(r'<application\b', lambda mm: block + "    <application", x, count=1)

    comps = []
    def add(name, xml):
        if name not in x:
            comps.append(xml)
    add(f"{ns}.part3.download.DownloadService",
        f'        <service android:name="{ns}.part3.download.DownloadService" android:exported="false" android:foregroundServiceType="dataSync"/>')
    add(f"{ns}.part3.scan.AutoScanService",
        f'''        <service android:name="{ns}.part3.scan.AutoScanService" android:exported="false"
            android:foregroundServiceType="dataSync" android:permission="android.permission.BIND_VPN_SERVICE">
            <intent-filter><action android:name="android.net.VpnService"/></intent-filter>
        </service>''')
    add(f"{ns}.part3.ui.DownloadManagerActivity",
        f'        <activity android:name="{ns}.part3.ui.DownloadManagerActivity" android:exported="false"/>')
    add(f"{ns}.part3.player.PreviewPlayerActivity",
        f'''        <activity android:name="{ns}.part3.player.PreviewPlayerActivity" android:exported="false"
            android:theme="@android:style/Theme.DeviceDefault.Dialog.NoActionBar"
            android:configChanges="orientation|screenSize|keyboardHidden"/>''')
    x = x.replace("</application>", "\n".join(comps) + "\n    </application>", 1)
    if "usesCleartextTraffic" not in x:
        x = re.sub(r'<application\b', '<application android:usesCleartextTraffic="true"', x, count=1)
    open(mf, "w", encoding="utf-8").write(x)

print("Part 3 patched. namespace =", ns)
