package com.alfy.downloader.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.alfy.downloader.AppConfig
import com.alfy.downloader.databinding.ActivityMainBinding
import com.alfy.downloader.permissions.AppPermission
import com.alfy.downloader.permissions.PermissionRequester
import com.alfy.downloader.permissions.RootChecker
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val requester = PermissionRequester(this)
    private val prefs by lazy { getSharedPreferences(AppConfig.PREFS, Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val openSettings = { startActivity(Intent(this, SettingsActivity::class.java)) }
        binding.btnSettings.setOnClickListener { openSettings() }
        binding.btnFixPermissions.setOnClickListener { openSettings() }

        if (!prefs.getBoolean(KEY_STARTUP_DONE, false)) {
            runStartupFlow()
        } else {
            lifecycleScope.launch {
                RootChecker.check()
                refreshBadge()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshBadge()
    }

    /** First launch: ask Storage -> Overlay -> Battery -> Root, one after another. */
    private fun runStartupFlow() {
        val queue = ArrayDeque(AppPermission.startupOrder.filter { !it.isGranted(this) })
        fun next() {
            val permission = queue.removeFirstOrNull()
            if (permission == null) {
                prefs.edit().putBoolean(KEY_STARTUP_DONE, true).apply()
                refreshBadge()
                return
            }
            requester.request(permission) {
                refreshBadge()
                next()
            }
        }
        next()
    }

    private fun refreshBadge() {
        val anyMissing = !AppPermission.allGranted(this)
        binding.badgeSettings.isVisible = anyMissing
        binding.warningBar.isVisible = anyMissing
    }

    private companion object {
        const val KEY_STARTUP_DONE = "startup_done"
    }
}
