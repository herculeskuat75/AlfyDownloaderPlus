# AlfyDownloader+

Open-source Android downloader (Kotlin, minSdk 24, targetSdk 34).

## Bagian 1 (Grup A)
- Tanpa AccessibilityService sama sekali.
- Izin wajib saat pertama dibuka: Root, Penyimpanan, Tampil di Atas Aplikasi Lain, Abaikan Optimasi Baterai.
- Ikon gear -> Pengaturan: tanda seru merah (!) tampil di samping setiap izin yang belum diberikan.
- Dependensi: AndroidX Media3 (ExoPlayer), FFmpegKit (build komunitas), OkHttp, NanoHTTPD.

## Build
Push ke GitHub; workflow `.github/workflows/build.yaml` menghasilkan APK debug (artifact `AlfyDownloader-debug`).
Lokal: buka di Android Studio, atau `gradle assembleDebug` (Gradle 8.7, JDK 17).
