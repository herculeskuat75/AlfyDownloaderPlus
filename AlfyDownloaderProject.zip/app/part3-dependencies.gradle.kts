dependencies {
    add("implementation", "androidx.media3:media3-exoplayer:1.3.1")
    add("implementation", "androidx.media3:media3-exoplayer-hls:1.3.1")
    add("implementation", "androidx.media3:media3-ui:1.3.1")
    add("implementation", "androidx.media3:media3-datasource:1.3.1")
    add("implementation", "androidx.media3:media3-datasource-okhttp:1.3.1")
    add("implementation", "com.squareup.okhttp3:okhttp:4.12.0")
    add("implementation", "org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    add("implementation", "androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    add("implementation", "androidx.activity:activity-ktx:1.9.1")
    add("implementation", "androidx.recyclerview:recyclerview:1.3.2")
    add("implementation", "com.moizhassan.ffmpeg:ffmpeg-kit-16kb:6.1.1")
}
