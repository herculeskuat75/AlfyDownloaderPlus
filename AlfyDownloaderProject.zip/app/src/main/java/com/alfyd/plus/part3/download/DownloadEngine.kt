package com.alfyd.plus.part3.download

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.alfyd.plus.part3.convert.FfmpegConverter
import com.alfyd.plus.part3.core.Category
import com.alfyd.plus.part3.core.Http
import com.alfyd.plus.part3.core.MediaCandidate
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.Call
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object DownloadEngine {
    private lateinit var app: Context
    @Volatile private var ready = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = ConcurrentHashMap<String, Job>()
    private val tokens = ConcurrentHashMap<String, Any>()
    private val calls = ConcurrentHashMap<String, Call>()
    private val ffSessions = ConcurrentHashMap<String, Long>()
    private val gate = Semaphore(3)
    private val remuxExt = setOf("ts", "m2ts", "mts", "m3u8")

    @Synchronized
    fun init(ctx: Context) { if (!ready) { app = ctx.applicationContext; ready = true } }

    private fun newId() = UUID.randomUUID().toString().replace("-", "").take(12)

    fun enqueue(c: MediaCandidate, name: String?): String {
        val id = newId()
        val title = StorageHelper.sanitize(name?.takeIf { it.isNotBlank() } ?: c.title)
        val ext = if (c.isHls) "mp4" else c.ext
        DownloadStore.add(
            DownloadItem(
                id = id, url = c.url, title = title, category = c.category, referer = c.referer,
                userAgent = c.userAgent, isHls = c.isHls, hlsProgram = c.hlsProgram, status = Status.QUEUED,
                downloaded = 0, total = c.sizeBytes.coerceAtLeast(0), speedBps = 0, etaSec = -1,
                durationSec = c.durationSec, tmpPath = File(StorageHelper.tmpDir(app), "$id.part").absolutePath,
                ext = ext, finalUri = null, error = null, createdAt = System.currentTimeMillis()
            )
        )
        start(id)
        return id
    }

    fun start(id: String) {
        if (jobs[id]?.isActive == true) return
        DownloadStore.get(id) ?: return
        DownloadStore.update(id) { it.copy(status = Status.QUEUED, error = null, speedBps = 0, etaSec = -1) }
        val t = Any()
        tokens[id] = t
        jobs[id] = scope.launch { gate.withPermit { run(id, t) } }
    }

    private fun stopWork(id: String) {
        tokens.remove(id)
        calls.remove(id)?.cancel()
        ffSessions.remove(id)?.let { FFmpegKit.cancel(it) }
        jobs.remove(id)?.cancel()
    }

    fun pause(id: String) {
        val it = DownloadStore.get(id) ?: return
        if (it.status == Status.DONE || it.status == Status.FAILED) return
        stopWork(id)
        DownloadStore.update(id) { d -> d.copy(status = Status.PAUSED, speedBps = 0, etaSec = -1) }
    }

    fun cancel(id: String) {
        stopWork(id)
        DownloadStore.get(id)?.let { File(it.tmpPath).delete() }
        DownloadStore.update(id) { it.copy(status = Status.FAILED, error = "Dibatalkan", downloaded = 0, speedBps = 0, etaSec = -1) }
    }

    fun retry(id: String) = start(id)

    fun delete(id: String) {
        val it = DownloadStore.get(id)
        stopWork(id)
        if (it != null) {
            File(it.tmpPath).delete()
            if (it.status == Status.DONE) StorageHelper.deleteFinal(app, it.finalUri)
        }
        DownloadStore.remove(id)
    }

    fun rename(id: String, newName: String) {
        val clean = StorageHelper.sanitize(newName)
        val it = DownloadStore.get(id) ?: return
        DownloadStore.update(id) { d -> d.copy(title = clean) }
        if (it.status == Status.DONE) StorageHelper.renameFinal(app, it.finalUri, "$clean.${it.ext}")
    }

    fun pauseAll() = DownloadStore.items.value
        .filter { it.status == Status.DOWNLOADING || it.status == Status.QUEUED }.forEach { pause(it.id) }

    fun resumeAll() = DownloadStore.items.value
        .filter { it.status == Status.PAUSED }.forEach { start(it.id) }

    fun clearFinished() {
        DownloadStore.removeWhere { it.status == Status.DONE }
    }

    private suspend fun run(id: String, t: Any) {
        val item = DownloadStore.get(id) ?: return
        DownloadStore.update(id) { it.copy(status = Status.DOWNLOADING, error = null) }
        try {
            val f = if (item.isHls) downloadHls(item, t) else downloadProgressive(item, t)
            finish(id, f, t)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (tokens[id] !== t) return
            DownloadStore.update(id) {
                it.copy(status = Status.FAILED, error = e.message ?: e.javaClass.simpleName, speedBps = 0, etaSec = -1)
            }
        }
    }

    private suspend fun downloadProgressive(item: DownloadItem, t: Any): File {
        val tmp = File(item.tmpPath)
        var offset = if (tmp.exists()) tmp.length() else 0L
        val rb = Request.Builder().url(item.url)
        Http.headersFor(item.userAgent, item.referer).forEach { (k, v) -> rb.header(k, v) }
        rb.header("Accept", "*/*")
        if (offset > 0) rb.header("Range", "bytes=$offset-")
        val call = Http.client.newCall(rb.build())
        calls[item.id] = call
        return try {
            call.execute().use { resp ->
                if (resp.code == 416 && offset > 0) return@use tmp
                if (!resp.isSuccessful) {
                    throw IOException("HTTP ${resp.code}" + if (resp.code == 403) " — akses ditolak / link kedaluwarsa" else "")
                }
                val ct = resp.header("Content-Type")?.lowercase().orEmpty()
                if (ct.startsWith("text/html")) throw IOException("Server mengirim halaman web, bukan berkas media")
                val append = resp.code == 206 && offset > 0
                if (!append) offset = 0
                val body = resp.body ?: throw IOException("Respons kosong")
                val len = body.contentLength()
                val total = if (len > 0) offset + len else 0L
                var downloaded = offset
                FileOutputStream(tmp, append).use { out ->
                    val src = body.byteStream()
                    val buf = ByteArray(64 * 1024)
                    var lastT = System.nanoTime()
                    var lastB = downloaded
                    var speed = 0.0
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = src.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        downloaded += n
                        val now = System.nanoTime()
                        if (now - lastT >= 500_000_000L) {
                            val inst = (downloaded - lastB) * 1e9 / (now - lastT)
                            speed = if (speed == 0.0) inst else speed * 0.6 + inst * 0.4
                            lastT = now
                            lastB = downloaded
                            val eta = if (total > 0 && speed > 1) ((total - downloaded) / speed).toLong() else -1L
                            if (tokens[item.id] === t) {
                                val d = downloaded
                                DownloadStore.update(item.id, persist = false) {
                                    it.copy(downloaded = d, total = total, speedBps = speed.toLong(), etaSec = eta)
                                }
                            }
                        }
                    }
                    out.flush()
                }
                val d = downloaded
                DownloadStore.update(item.id) { it.copy(downloaded = d, total = if (total > 0) total else d, speedBps = 0, etaSec = 0) }
                tmp
            }
        } finally {
            calls.remove(item.id)
        }
    }

    private suspend fun downloadHls(item: DownloadItem, t: Any): File = suspendCancellableCoroutine { cont ->
        val out = File(item.tmpPath)
        out.delete()
        val hs = Http.ffHeaderString(Http.headersFor(item.userAgent, item.referer))
        val a = ArrayList<String>()
        a += listOf("-y", "-user_agent", item.userAgent)
        if (hs.isNotEmpty()) a += listOf("-headers", hs)
        a += listOf("-allowed_extensions", "ALL", "-protocol_whitelist", "file,http,https,tcp,tls,crypto,data", "-i", item.url)
        if (item.hlsProgram >= 0) a += listOf("-map", "0:p:${item.hlsProgram}")
        else a += listOf("-map", "0:v:0?", "-map", "0:a:0?")
        a += listOf("-c", "copy", "-f", "mp4", "-movflags", "+faststart", out.absolutePath)

        var lastT = System.nanoTime()
        var lastSize = 0L
        var speed = 0.0
        val session = FFmpegKit.executeWithArgumentsAsync(
            a.toTypedArray(),
            { s ->
                ffSessions.remove(item.id)
                if (cont.isActive) {
                    when {
                        ReturnCode.isSuccess(s.returnCode) -> cont.resume(out)
                        ReturnCode.isCancel(s.returnCode) -> cont.resumeWithException(CancellationException("dibatalkan"))
                        else -> cont.resumeWithException(
                            IOException("FFmpeg gagal (kode ${s.returnCode}) — ${s.allLogsAsString?.takeLast(160) ?: ""}")
                        )
                    }
                }
            },
            { },
            { st ->
                if (tokens[item.id] === t) {
                    val now = System.nanoTime()
                    if (now - lastT >= 500_000_000L) {
                        val size = st.size
                        val sec = st.time / 1000.0
                        val inst = (size - lastSize) * 1e9 / (now - lastT)
                        speed = if (speed == 0.0) inst else speed * 0.6 + inst * 0.4
                        val dur = item.durationSec
                        val pct = if (dur > 0) (sec / dur).coerceIn(0.0, 1.0) else 0.0
                        val total = if (pct > 0.02) (size / pct).toLong() else 0L
                        val eta = if (dur > 0 && st.speed > 0.01) ((dur - sec) / st.speed).toLong() else -1L
                        lastT = now
                        lastSize = size
                        DownloadStore.update(item.id, persist = false) {
                            it.copy(downloaded = size, total = total, speedBps = speed.toLong(), etaSec = eta)
                        }
                    }
                }
            }
        )
        ffSessions[item.id] = session.sessionId
        cont.invokeOnCancellation { FFmpegKit.cancel(session.sessionId) }
    }

    private suspend fun finish(id: String, file: File, t: Any) {
        val item = DownloadStore.get(id) ?: return
        var f = file
        var ext = item.ext
        if (item.category == Category.VIDEO && !item.isHls && ext.lowercase() in remuxExt) {
            DownloadStore.update(id) { it.copy(status = Status.CONVERTING, speedBps = 0, etaSec = -1) }
            val out = File(file.parentFile, "$id.mp4.part")
            val ok = FfmpegConverter.remuxToMp4(file, out) { frac ->
                if (tokens[id] === t) {
                    val total = 1000L
                    DownloadStore.update(id, persist = false) { it.copy(downloaded = (frac * total).toLong(), total = total) }
                }
            }
            if (!ok) throw IOException("Konversi TS/M3U8 → MP4 gagal")
            file.delete()
            f = out
            ext = "mp4"
        } else if (!FfmpegConverter.verify(f)) {
            throw IOException("Berkas hasil unduhan rusak / tidak terbaca")
        }
        val name = (DownloadStore.get(id)?.title ?: item.title) + "." + ext
        val size = f.length()
        val uri = StorageHelper.publish(app, f, name, item.category)
        f.delete()
        if (tokens[id] !== t) return
        DownloadStore.update(id) {
            it.copy(status = Status.DONE, ext = ext, finalUri = uri, downloaded = size, total = size, speedBps = 0, etaSec = 0, error = null)
        }
    }

    /** Local converter (main page): any picked file -> MP4 (remux) or MP3. */
    fun convertLocal(uri: Uri, toMp3: Boolean) {
        val id = newId()
        val display = queryName(uri) ?: "media"
        val base = StorageHelper.sanitize(display.substringBeforeLast('.', display))
        val ext = if (toMp3) "mp3" else "mp4"
        val cat = if (toMp3) Category.MUSIC else Category.VIDEO
        DownloadStore.add(
            DownloadItem(
                id = id, url = "local://$display", title = base, category = cat, referer = null,
                userAgent = Http.UA, isHls = false, hlsProgram = -1, status = Status.CONVERTING,
                downloaded = 0, total = 1000, speedBps = 0, etaSec = -1, durationSec = 0.0,
                tmpPath = File(StorageHelper.tmpDir(app), "$id.out").absolutePath, ext = ext,
                finalUri = null, error = null, createdAt = System.currentTimeMillis()
            )
        )
        val t = Any()
        tokens[id] = t
        jobs[id] = scope.launch {
            val inp = File(StorageHelper.tmpDir(app), "$id.in")
            val out = File(StorageHelper.tmpDir(app), "$id.out")
            try {
                app.contentResolver.openInputStream(uri)?.use { i -> inp.outputStream().use { o -> i.copyTo(o) } }
                    ?: throw IOException("Tidak bisa membuka berkas")
                val onP: (Float) -> Unit = { frac ->
                    DownloadStore.update(id, persist = false) { it.copy(downloaded = (frac * 1000).toLong(), total = 1000) }
                }
                val ok = if (toMp3) FfmpegConverter.toMp3(inp, out, onP) else FfmpegConverter.remuxToMp4(inp, out, onP)
                if (!ok) throw IOException("Konversi gagal")
                val size = out.length()
                val u = StorageHelper.publish(app, out, "$base.$ext", cat)
                DownloadStore.update(id) {
                    it.copy(status = Status.DONE, finalUri = u, downloaded = size, total = size, error = null)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                DownloadStore.update(id) { it.copy(status = Status.FAILED, error = e.message ?: "Konversi gagal") }
            } finally {
                inp.delete(); out.delete()
            }
        }
    }

    private fun queryName(uri: Uri): String? = try {
        app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (e: Exception) { null }
}
