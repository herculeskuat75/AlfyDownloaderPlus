package com.alfyd.plus.part3.download

import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.alfyd.plus.part3.Part3
import com.alfyd.plus.part3.core.MediaCandidate
import com.alfyd.plus.part3.util.Fmt
import com.alfyd.plus.part3.util.Notifs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONObject

class DownloadService : Service() {
    companion object {
        const val ENQUEUE = "alfyd.dl.ENQUEUE"
        const val PAUSE = "alfyd.dl.PAUSE"
        const val RESUME = "alfyd.dl.RESUME"
        const val CANCEL = "alfyd.dl.CANCEL"
        const val RETRY = "alfyd.dl.RETRY"
        const val DELETE = "alfyd.dl.DELETE"
        const val PAUSE_ALL = "alfyd.dl.PAUSE_ALL"
        const val RESUME_ALL = "alfyd.dl.RESUME_ALL"
        private const val CH = "alfyd_dl"
        private const val NID = 4701
        private val ACTIVE = setOf(Status.DOWNLOADING, Status.QUEUED, Status.CONVERTING)

        fun send(ctx: Context, action: String, id: String? = null, json: String? = null, name: String? = null) {
            val i = Intent(ctx, DownloadService::class.java).setAction(action)
                .putExtra("id", id).putExtra("json", json).putExtra("name", name)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun enqueue(ctx: Context, c: MediaCandidate, name: String? = null) =
            send(ctx, ENQUEUE, json = c.toJson().toString(), name = name)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watcher: Job? = null

    private fun fg(text: String) {
        val n = Notifs.build(this, CH, "AlfyD+ Download", text)
        if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(NID, n)
    }

    override fun onCreate() {
        super.onCreate()
        Part3.init(this)
        fg("Menyiapkan unduhan…")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        fg("Memproses…")
        val id = intent?.getStringExtra("id")
        when (intent?.action) {
            ENQUEUE -> intent.getStringExtra("json")?.let {
                runCatching { MediaCandidate.fromJson(JSONObject(it)) }.getOrNull()
            }?.let { DownloadEngine.enqueue(it, intent.getStringExtra("name")) }
            PAUSE -> id?.let { DownloadEngine.pause(it) }
            RESUME, RETRY -> id?.let { DownloadEngine.start(it) }
            CANCEL -> id?.let { DownloadEngine.cancel(it) }
            DELETE -> id?.let { DownloadEngine.delete(it) }
            PAUSE_ALL -> DownloadEngine.pauseAll()
            RESUME_ALL -> DownloadEngine.resumeAll()
        }
        if (watcher == null) {
            watcher = scope.launch {
                DownloadStore.items.collect { list ->
                    val active = list.filter { it.status in ACTIVE }
                    if (active.isEmpty()) {
                        stopForeground(true)
                        stopSelf()
                    } else {
                        val speed = active.sumOf { it.speedBps }
                        val text = "${active.size} unduhan • ${Fmt.speed(speed)}"
                        getSystemService(NotificationManager::class.java)
                            .notify(NID, Notifs.build(this@DownloadService, CH, "AlfyD+ Download", text))
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        watcher?.cancel()
        scope.cancel()
        super.onDestroy()
    }
}
