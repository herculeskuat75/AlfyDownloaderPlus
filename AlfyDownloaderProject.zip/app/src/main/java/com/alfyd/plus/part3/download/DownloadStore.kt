package com.alfyd.plus.part3.download

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray

object DownloadStore {
    private const val PREFS = "alfyd_p3_downloads"
    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()
    @Volatile private var prefs: SharedPreferences? = null

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        val arr = try { JSONArray(p.getString("items", "[]")) } catch (e: Exception) { JSONArray() }
        val active = setOf(Status.DOWNLOADING, Status.QUEUED, Status.CONVERTING)
        _items.value = (0 until arr.length()).mapNotNull {
            runCatching { DownloadItem.fromJson(arr.getJSONObject(it)) }.getOrNull()
        }.map { if (it.status in active) it.copy(status = Status.PAUSED) else it }
    }

    fun get(id: String): DownloadItem? = _items.value.firstOrNull { it.id == id }

    fun add(item: DownloadItem) { _items.update { listOf(item) + it }; persist() }

    fun update(id: String, persist: Boolean = true, f: (DownloadItem) -> DownloadItem) {
        _items.update { l -> l.map { if (it.id == id) f(it) else it } }
        if (persist) persist()
    }

    fun remove(id: String) { _items.update { l -> l.filterNot { it.id == id } }; persist() }

    fun removeWhere(pred: (DownloadItem) -> Boolean) { _items.update { l -> l.filterNot(pred) }; persist() }

    @Synchronized
    private fun persist() {
        val p = prefs ?: return
        val arr = JSONArray()
        _items.value.forEach { arr.put(it.toJson()) }
        p.edit().putString("items", arr.toString()).apply()
    }
}
