package com.alfyd.plus.part3.scan

import com.alfyd.plus.part3.core.CaptureHub
import com.alfyd.plus.part3.core.Source
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.TimeUnit

object Shell {
    fun su(cmd: String, timeoutSec: Long = 8): Boolean = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        Thread { try { p.inputStream.readBytes() } catch (_: Exception) { } }.start()
        if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) { p.destroy(); false } else p.exitValue() == 0
    } catch (e: Exception) { false }
}

/**
 * Used when another VPN (Dark Tunnel / HTTP Custom ...) already owns the VPN slot.
 * Root iptables NAT redirects local plain-HTTP traffic of other apps to a loopback relay,
 * which logs request URLs and transparently forwards the connection.
 */
class IptablesSniffer(private val uid: Int, private val port: Int = 8089) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var server: ServerSocket? = null

    private fun rule(op: String) =
        "iptables -t nat $op OUTPUT -p tcp --dport 80 -m owner ! --uid-owner $uid -j REDIRECT --to-ports $port"

    fun start(): Boolean {
        if (!Shell.su("id")) return false
        // remove stale rules from a previous crash
        repeat(3) { Shell.su(rule("-D")) }
        server = try { ServerSocket(port, 64, InetAddress.getByName("127.0.0.1")) } catch (e: Exception) { return false }
        if (!Shell.su(rule("-I").replace("OUTPUT", "OUTPUT 1"))) { stop(); return false }
        scope.launch { acceptLoop() }
        return true
    }

    fun stop() {
        Shell.su(rule("-D"))
        try { server?.close() } catch (_: Exception) { }
        server = null
        scope.cancel()
    }

    private fun acceptLoop() {
        val s = server ?: return
        while (!s.isClosed) {
            val c = try { s.accept() } catch (e: Exception) { break }
            Thread { handle(c) }.start()
        }
    }

    private fun readHead(inp: InputStream): ByteArray? {
        val bos = ByteArrayOutputStream()
        var state = 0
        while (bos.size() < 16384) {
            val b = inp.read()
            if (b < 0) return if (bos.size() > 0) bos.toByteArray() else null
            bos.write(b)
            state = when {
                b == '\r'.code && (state == 0 || state == 2) -> state + 1
                b == '\n'.code && (state == 1 || state == 3) -> state + 1
                else -> 0
            }
            if (state == 4) break
        }
        return bos.toByteArray()
    }

    private fun handle(c: Socket) {
        var up: Socket? = null
        try {
            c.soTimeout = 30000
            val cin = c.getInputStream()
            val head = readHead(cin) ?: run { c.close(); return }
            val text = String(head, Charsets.ISO_8859_1)
            val lines = text.split("\r\n")
            val req = lines[0].split(" ")
            fun h(name: String) = lines.firstOrNull { it.startsWith("$name:", true) }?.substringAfter(':')?.trim()
            val hostHdr = h("Host")
            if (req.size < 3 || hostHdr == null) { c.close(); return }
            val hostName = hostHdr.substringBefore(':')
            val hostPort = hostHdr.substringAfter(':', "80").toIntOrNull() ?: 80

            if (req[0].equals("GET", true)) {
                val url = "http://$hostHdr${req[1]}"
                val wantsHtml = h("Accept")?.contains("text/html", true) == true
                CaptureHub.submit(url, Source.NETWORK, h("Referer"), h("User-Agent"))
                if (wantsHtml) HostWatcher.onHost(hostName)
            }

            up = Socket()
            up.connect(InetSocketAddress(hostName, hostPort), 10000)
            up.soTimeout = 60000
            val uout = up.getOutputStream()
            uout.write(head); uout.flush()
            val upRef = up
            val t = Thread { pipe(upRef.getInputStream(), c.getOutputStream()); closeQuiet(c); closeQuiet(upRef) }
            t.start()
            pipe(cin, uout)
            closeQuiet(upRef); closeQuiet(c)
        } catch (e: Exception) {
            closeQuiet(c); up?.let { closeQuiet(it) }
        }
    }

    private fun pipe(i: InputStream, o: java.io.OutputStream) {
        val buf = ByteArray(16384)
        try {
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n); o.flush()
            }
        } catch (_: Exception) { }
    }

    private fun closeQuiet(s: Socket) { try { s.close() } catch (_: Exception) { } }
}
