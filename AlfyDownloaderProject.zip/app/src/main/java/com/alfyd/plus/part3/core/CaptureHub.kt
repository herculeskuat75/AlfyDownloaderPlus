package com.alfyd.plus.part3.core

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.Request
import java.util.concurrent.ConcurrentHashMap

/**
 * Single entry point for EVERY capture method (clipboard, browser, OCR, share, network sniffer).
 * Part 1/2 detectors should call CaptureHub.submit(...) / submitText(...).
 */
object CaptureHub {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val gate = Semaphore(3)
    private val _candidates = MutableStateFlow<List<MediaCandidate>>(emptyList())
    val candidates: StateFlow<List<MediaCandidate>> = _candidates.asStateFlow()
    private val _pending = MutableStateFlow(0)
    /** Value for the red badge on the floating menu. */
    val pendingCount: StateFlow<Int> = _pending.asStateFlow()

    private val urlRegex = Regex("https?://[^\\s<>\"'`\\\\^{}|]+", RegexOption.IGNORE_CASE)
    private val pageTtl = ConcurrentHashMap<String, Long>()

    fun init(ctx: Context) = UrlRegistry.init(ctx)

    fun submitText(text: String?, source: Source, referer: String? = null): Int {
        if (text.isNullOrBlank()) return 0
        var n = 0
        urlRegex.findAll(text).forEach { if (submit(it.value, source, referer)) n++ }
        return n
    }

    fun submit(
        raw: String?, source: Source, referer: String? = null,
        userAgent: String? = null, titleHint: String? = null
    ): Boolean {
        val url = UrlRegistry.validate(raw) ?: return false
        val kind = UrlKind.kind(url)
        if (kind == UrlKind.Kind.OTHER) return false
        if (source == Source.NETWORK && UrlKind.isSegment(url)) return false
        val key = UrlRegistry.keyOf(url)
        if (!UrlRegistry.tryClaim(key)) return false
        launchProcess(url, key, kind, source, referer, userAgent, titleHint)
        return true
    }

    /** Re-scan a homepage periodically without permanently claiming it (new videos appear over time). */
    fun prefetchPage(raw: String?, source: Source, ttlMs: Long = 30 * 60_000L) {
        val url = UrlRegistry.validate(raw) ?: return
        if (UrlKind.kind(url) != UrlKind.Kind.PAGE) return
        val now = System.currentTimeMillis()
        val last = pageTtl[url]
        if (last != null && now - last < ttlMs) return
        pageTtl[url] = now
        if (pageTtl.size > 500) pageTtl.clear()
        launchProcess(url, UrlRegistry.keyOf(url), UrlKind.Kind.PAGE, source, null, null, null)
    }

    fun remove(key: String) {
        _candidates.update { l -> l.filterNot { it.key == key } }
        _pending.value = _candidates.value.size
    }

    fun clearCandidates() { _candidates.value = emptyList(); _pending.value = 0 }

    private fun launchProcess(
        url: String, key: String, kind: UrlKind.Kind, source: Source,
        referer: String?, ua: String?, titleHint: String?
    ) {
        scope.launch {
            try {
                gate.withPermit {
                    if (kind == UrlKind.Kind.PAGE) processPage(url, source, referer, ua)
                    else processMedia(url, key, source, referer, ua, titleHint)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                // never crash the host app because of a bad candidate
            }
        }
    }

    private suspend fun processPage(url: String, source: Source, referer: String?, ua: String?) {
        val meta = MetadataPrefetcher.fetch(url, referer)
        meta.mediaUrls.forEach { m -> submit(m, source, url, ua, meta.title) }
    }

    private suspend fun processMedia(
        url: String, key: String, source: Source, referer: String?, uaIn: String?, titleHint: String?
    ) {
        val ua = uaIn ?: Http.UA
        val hdr = Http.headersFor(ua, referer)
        val hls = url.contains(".m3u8", true)
        var program = -1
        var fw = 0
        var fh = 0
        if (hls) {
            when (val sel = HlsMaster.select(url, hdr)) {
                is HlsMaster.Selection.Picked -> { program = sel.program; fw = sel.width; fh = sel.height }
                HlsMaster.Selection.Media -> Unit
                HlsMaster.Selection.OutOfRange, HlsMaster.Selection.Failed -> return
            }
        }
        val p = MediaProbe.probe(url, hdr, hls)
        val category = QualityFilter.decide(p, fw, fh) ?: return
        val ext = if (hls) "mp4" else UrlKind.extOf(url).ifEmpty { if (category == Category.MUSIC) "mp3" else "mp4" }
        var size = p.sizeBytes
        if (size <= 0 && !hls) size = headSize(url, hdr)
        val cand = MediaCandidate(
            url = url, key = key,
            title = titleHint?.takeIf { it.isNotBlank() } ?: UrlKind.nameOf(url),
            category = category, referer = referer, userAgent = ua,
            width = if (fw > 0) fw else p.width, height = if (fh > 0) fh else p.height,
            durationSec = p.durationSec, sizeBytes = size, isHls = hls, hlsProgram = program,
            ext = ext, source = source
        )
        _candidates.update { it + cand }
        _pending.value = _candidates.value.size
    }

    private fun headSize(url: String, hdr: Map<String, String>): Long = try {
        val rb = Request.Builder().url(url).head()
        hdr.forEach { (k, v) -> rb.header(k, v) }
        Http.client.newCall(rb.build()).execute().use {
            if (it.isSuccessful) it.header("Content-Length")?.toLongOrNull() ?: -1L else -1L
        }
    } catch (e: Exception) { -1L }
}
