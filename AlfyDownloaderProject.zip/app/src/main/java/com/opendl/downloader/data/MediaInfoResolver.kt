package com.opendl.downloader.data

import android.media.MediaMetadataRetriever
import com.opendl.downloader.util.qualityFromHeight
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

data class Resolved(
    val reachable: Boolean,
    val directMedia: Boolean,
    val title: String?,
    val sizeBytes: Long,
    val durationMs: Long,
    val heightPx: Int
) { val quality get() = qualityFromHeight(heightPx) }

/**
 * Lightweight resolver: HEAD request + MediaMetadataRetriever for direct media files.
 * For page links (YouTube, etc.) it only confirms reachability; a stream extractor
 * (later part) should replace/extend [resolve] to return real formats.
 */
object MediaInfoResolver {
    private const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36"
    private val MEDIA_EXT = Regex("""\.(mp4|mkv|webm|mov|m4v|3gp|mp3|m4a|aac|ogg|opus|flac|wav|ts|m3u8)(\?.*)?$""", RegexOption.IGNORE_CASE)

    suspend fun resolve(url: String): Resolved = withContext(Dispatchers.IO) {
        var size = -1L
        var type: String? = null
        var reachable = false
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "HEAD"
            c.connectTimeout = 8000; c.readTimeout = 8000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", UA)
            reachable = c.responseCode in 200..399
            size = c.contentLengthLong
            type = c.contentType
            c.disconnect()
        } catch (_: Exception) { }

        val direct = type?.startsWith("video/") == true || type?.startsWith("audio/") == true ||
            MEDIA_EXT.containsMatchIn(url)

        var dur = -1L; var h = 0; var title: String? = null
        if (direct) {
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(url, HashMap<String, String>().apply { put("User-Agent", UA) })
                dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: -1L
                h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            } catch (_: Exception) {
            } finally {
                try { mmr.release() } catch (_: Exception) { }
            }
        }
        Resolved(reachable || direct, direct, title, size, dur, h)
    }
}
