package com.opendl.downloader.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.opendl.downloader.R

object Notifs {
    const val ID_OVERLAY = 2001
    const val ID_CAPTURE = 2002
    private const val CHANNEL = "overlay_service"

    fun build(ctx: Context, text: String): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, ctx.getString(R.string.ov_channel), NotificationManager.IMPORTANCE_MIN)
                )
            }
        }
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CHANNEL) else Notification.Builder(ctx)
        return b.setSmallIcon(R.drawable.ic_download)
            .setContentTitle(ctx.getString(R.string.ov_notif_title))
            .setContentText(text)
            .setOngoing(true)
            .build()
    }
}
