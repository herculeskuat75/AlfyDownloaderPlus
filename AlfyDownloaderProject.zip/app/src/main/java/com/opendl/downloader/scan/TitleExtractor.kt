package com.opendl.downloader.scan

import android.graphics.Rect
import com.google.mlkit.vision.text.Text
import com.opendl.downloader.model.ScanCandidate
import com.opendl.downloader.model.ScanOutcome
import kotlin.math.abs

/**
 * Heuristic: video titles are the largest "sentence-like" text on screen.
 * Channel names / view counts / durations / UI chrome are filtered out as noise,
 * and wrapped titles (up to 3 lines) are merged.
 */
object TitleExtractor {
    private class Ln(val text: String, val rect: Rect) { var used = false }

    private val NOISE = Regex(
        """(?i)(\bviews?\b|\bsubscribers?\b|\bsubscribe\b|\bago\b|\bcomments?\b|\bsponsored\b|^@|^https?://|•|·|""" +
            """^\d+([.,]\d+)?\s?[KMB]?$|^\d{1,2}:\d{2}(:\d{2})?$)"""
    )
    private val URL_RX = Regex("""(?i)\b(?:https?://)?(?:[a-z0-9-]+\.)+[a-z]{2,}/[^\s]+""")

    fun extract(text: Text, screenH: Int): ScanOutcome {
        val lines = text.textBlocks.flatMap { it.lines }
            .mapNotNull { l -> l.boundingBox?.let { Ln(l.text.trim(), it) } }
            .filter { it.text.isNotEmpty() && it.rect.top > screenH * 0.04 && it.rect.bottom < screenH * 0.97 }
            .sortedBy { it.rect.top }

        val merged = mutableListOf<Pair<String, Rect>>()
        for (start in lines) {
            if (start.used) continue
            start.used = true
            var cur = start; var combined = start.text; val box = Rect(start.rect); var n = 1
            while (n < 3) {
                val h = cur.rect.height()
                val next = lines.firstOrNull {
                    !it.used && abs(it.rect.height() - h) <= h * 0.2 &&
                        (it.rect.top - cur.rect.bottom) in (-h * 0.2).toInt()..(h * 0.7).toInt() &&
                        abs(it.rect.left - cur.rect.left) <= h
                } ?: break
                next.used = true; combined += " " + next.text; box.union(next.rect); cur = next; n++
            }
            merged += combined to Rect(box.left, box.top, box.right, box.bottom).also {
                it.bottom = it.top + start.rect.height() // keep first-line height as "font size"
            }
        }

        val candidates = merged.filter { (t, _) ->
            val letters = t.count { it.isLetter() }
            t.length >= 10 && letters >= t.length * 0.5 && !NOISE.containsMatchIn(t)
        }
        if (candidates.isEmpty()) return ScanOutcome(emptyList())

        val maxH = candidates.maxOf { it.second.height() }
        val titles = candidates.filter { it.second.height() >= maxH * 0.8 }
            .sortedBy { it.second.top }
            .map { it.first }
            .distinct()
            .take(8)

        val urls = URL_RX.findAll(lines.joinToString("\n") { it.text }).map { m ->
            m.value.let { if (it.startsWith("http", true)) it else "https://$it" }
        }.distinct().toList()

        val pairedUrl = if (titles.size == 1 && urls.size == 1) urls[0] else null
        return ScanOutcome(titles.map { ScanCandidate(it, pairedUrl) })
    }
}
