package com.opendl.downloader.scan

import android.app.Activity
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.opendl.downloader.R
import com.opendl.downloader.data.ScanBus
import com.opendl.downloader.model.ScanOutcome
import com.opendl.downloader.util.Notifs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Grabs ONE frame of the screen via MediaProjection, runs on-device OCR, emits titles on [ScanBus]. */
class ScreenCaptureService : Service() {

    companion object {
        private const val EXTRA_CODE = "code"
        private const val EXTRA_DATA = "data"
        fun intent(ctx: Context, code: Int, data: Intent) =
            Intent(ctx, ScreenCaptureService::class.java).putExtra(EXTRA_CODE, code).putExtra(EXTRA_DATA, data)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = Notifs.build(this, getString(R.string.ov_scanning))
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(Notifs.ID_CAPTURE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(Notifs.ID_CAPTURE, n)

        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java) else intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null || code != Activity.RESULT_OK) {
            finish(ScanOutcome(emptyList(), "Screen capture permission was not granted"))
            return START_NOT_STICKY
        }
        scope.launch {
            try { capture(code, data) }
            catch (e: Exception) { finish(ScanOutcome(emptyList(), "Scan failed: ${e.message}")) }
        }
        return START_NOT_STICKY
    }

    private suspend fun capture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val projection = mpm.getMediaProjection(code, data)
        // Android 14+: a callback MUST be registered before createVirtualDisplay.
        projection.registerCallback(object : MediaProjection.Callback() {}, handler)

        val (w, h) = screenSize()
        val dpi = resources.displayMetrics.densityDpi
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val display = projection.createVirtualDisplay(
            "dl-scan", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, handler
        )
        var shot: Bitmap? = null
        try {
            delay(600) // let the consent dialog / our hidden overlay disappear from the frame
            var tries = 0
            while (shot == null && tries++ < 12) {
                reader.acquireLatestImage()?.let { img -> shot = try { toBitmap(img, w, h) } finally { img.close() } }
                if (shot == null) delay(150)
            }
        } finally {
            display.release(); reader.close(); projection.stop()
        }
        val bmp = shot ?: run { finish(ScanOutcome(emptyList(), "Could not capture the screen")); return }
        val text = recognize(bmp)
        finish(TitleExtractor.extract(text, bmp.height))
    }

    private fun toBitmap(img: Image, w: Int, h: Int): Bitmap {
        val p = img.planes[0]
        val pad = p.rowStride - p.pixelStride * w
        val full = Bitmap.createBitmap(w + pad / p.pixelStride, h, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(p.buffer)
        return Bitmap.createBitmap(full, 0, 0, w, h)
    }

    private suspend fun recognize(b: Bitmap): Text = suspendCancellableCoroutine { c ->
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(InputImage.fromBitmap(b, 0))
            .addOnSuccessListener { c.resume(it) }
            .addOnFailureListener { c.resumeWithException(it) }
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= 30) wm.maximumWindowMetrics.bounds.let { it.width() to it.height() }
        else android.util.DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }.let { it.widthPixels to it.heightPixels }
    }

    private fun finish(o: ScanOutcome) {
        ScanBus.outcomes.tryEmit(o)
        stopForeground(true)
        stopSelf()
    }
}
