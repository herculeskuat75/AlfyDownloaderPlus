package com.opendl.downloader.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.opendl.downloader.R
import com.opendl.downloader.model.DownloadItem
import com.opendl.downloader.model.DownloadItem.Status
import com.opendl.downloader.util.formatDuration
import com.opendl.downloader.util.formatSize

class DownloadAdapter(
    private val onCopyUrl: (DownloadItem) -> Unit
) : ListAdapter<DownloadItem, DownloadAdapter.VH>(Diff) {

    object Diff : DiffUtil.ItemCallback<DownloadItem>() {
        override fun areItemsTheSame(a: DownloadItem, b: DownloadItem) = a.id == b.id
        override fun areContentsTheSame(a: DownloadItem, b: DownloadItem) = a == b
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.tvItemTitle)
        val quality: TextView = v.findViewById(R.id.tvQuality)
        val size: TextView = v.findViewById(R.id.tvSize)
        val duration: TextView = v.findViewById(R.id.tvDuration)
        val status: TextView = v.findViewById(R.id.tvStatus)
        val url: TextView = v.findViewById(R.id.tvUrl)
        val copy: Button = v.findViewById(R.id.btnCopyUrl)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_download, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val it = getItem(position)
        val ctx = h.itemView.context
        val resolving = it.status == Status.RESOLVING
        h.title.text = it.title
        h.quality.text = it.quality
        h.size.text = if (resolving) "…" else formatSize(it.sizeBytes)
        h.duration.text = if (resolving) "…" else formatDuration(it.durationMs)
        h.status.setText(
            when (it.status) {
                Status.RESOLVING -> R.string.ov_status_resolving
                Status.DIRECT_FILE -> R.string.ov_status_direct
                Status.PAGE_LINK -> R.string.ov_status_page
                Status.NO_URL -> R.string.ov_status_no_url
                Status.FAILED -> R.string.ov_status_failed
            }
        )
        val hasUrl = it.url.isNotEmpty()
        h.url.text = if (hasUrl) it.url else ctx.getString(R.string.ov_url_missing)
        h.copy.isEnabled = hasUrl
        h.copy.alpha = if (hasUrl) 1f else 0.4f
        h.copy.setOnClickListener { _ -> onCopyUrl(it) }
    }
}
