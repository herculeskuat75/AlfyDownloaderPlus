package com.opendl.downloader.util

import android.net.Uri
import android.util.Patterns

object UrlValidator {
    private val HTTP = Regex("""https?://[^\s<>"']+""", RegexOption.IGNORE_CASE)

    /** Returns a clean, valid http(s) URL found in [raw], or null. */
    fun extract(raw: String?): String? {
        val s = raw?.trim().orEmpty()
        if (s.isEmpty()) return null
        val candidate = HTTP.find(s)?.value
            ?: s.takeIf { !it.contains(' ') && Patterns.WEB_URL.matcher(it).matches() }?.let { "https://$it" }
            ?: return null
        val c = candidate.trimEnd('.', ',', ')', ';')
        val host = Uri.parse(c).host
        return if (host.isNullOrBlank() || !host.contains('.')) null else c
    }
}
