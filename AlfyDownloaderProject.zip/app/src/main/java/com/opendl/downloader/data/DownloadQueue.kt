package com.opendl.downloader.data

import android.net.Uri
import com.opendl.downloader.model.DownloadItem
import com.opendl.downloader.model.DownloadItem.Status
import com.opendl.downloader.model.ScanCandidate
import com.opendl.downloader.model.ScanOutcome
import com.opendl.downloader.util.qualityHint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicLong

/** Process-wide queue shared by the overlay UI and (later) the download engine. */
object DownloadQueue {
    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val ids = AtomicLong(1)

    /** @return false if the URL is already queued. */
    @Synchronized
    fun addUrl(url: String): Boolean {
        if (_items.value.any { it.url.equals(url, true) }) return false
        val item = DownloadItem(
            id = ids.getAndIncrement(), title = titleFromUrl(url), url = url,
            quality = qualityHint(url), titleDerived = true
        )
        _items.update { it + item }
        resolve(item)
        return true
    }

    @Synchronized
    fun addScanned(candidates: List<ScanCandidate>): Int {
        var added = 0
        for (c in candidates) {
            val exists = _items.value.any {
                it.title.equals(c.title, true) || (c.url != null && it.url.equals(c.url, true))
            }
            if (exists) continue
            val item = DownloadItem(
                id = ids.getAndIncrement(), title = c.title, url = c.url.orEmpty(),
                quality = qualityHint(c.title + " " + c.url),
                status = if (c.url == null) Status.NO_URL else Status.RESOLVING
            )
            _items.update { it + item }
            if (c.url != null) resolve(item)
            added++
        }
        return added
    }

    fun clear() { _items.value = emptyList() }

    private fun resolve(item: DownloadItem) {
        scope.launch {
            val r = MediaInfoResolver.resolve(item.url)
            patch(item.id) {
                it.copy(
                    title = if (it.titleDerived && !r.title.isNullOrBlank()) r.title else it.title,
                    quality = if (r.heightPx > 0) r.quality else it.quality,
                    sizeBytes = r.sizeBytes,
                    durationMs = r.durationMs,
                    status = when {
                        r.directMedia -> Status.DIRECT_FILE
                        r.reachable -> Status.PAGE_LINK
                        else -> Status.FAILED
                    }
                )
            }
        }
    }

    private fun patch(id: Long, f: (DownloadItem) -> DownloadItem) {
        _items.update { list -> list.map { if (it.id == id) f(it) else it } }
    }

    private fun titleFromUrl(url: String): String {
        val uri = Uri.parse(url)
        val seg = uri.lastPathSegment
        return if (seg != null && seg.contains('.') && seg.length > 3) seg
        else uri.host?.removePrefix("www.") ?: url
    }
}

/** Result channel from the screen-scan service back to the overlay. */
object ScanBus {
    val outcomes = MutableSharedFlow<ScanOutcome>(extraBufferCapacity = 4)
}
