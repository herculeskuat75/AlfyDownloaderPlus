package com.opendl.downloader.overlay

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
import android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
import android.view.WindowManager.LayoutParams.WRAP_CONTENT
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.opendl.downloader.R
import com.opendl.downloader.data.DownloadQueue
import com.opendl.downloader.data.ScanBus
import com.opendl.downloader.model.DownloadItem
import com.opendl.downloader.model.ScanOutcome
import com.opendl.downloader.scan.ProjectionRequestActivity
import com.opendl.downloader.ui.DownloadAdapter
import com.opendl.downloader.util.Notifs
import com.opendl.downloader.util.UrlValidator
import com.opendl.downloader.util.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max

private const val EDGE_L = 1
private const val EDGE_T = 2
private const val EDGE_R = 4
private const val EDGE_B = 8

/**
 * Owns two overlay windows: the draggable bubble (with badge) and the glass panel
 * (resizable from all 4 edges + 4 corners).
 */
class OverlayService : Service() {

    companion object {
        fun start(ctx: Context) =
            ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java))
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, OverlayService::class.java)) }
    }

    private lateinit var wm: WindowManager
    private lateinit var ui: Context
    private lateinit var prefs: SharedPreferences
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var bubble: View
    private lateinit var badge: TextView
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private var bubbleAttached = false

    private lateinit var panel: View
    private lateinit var panelLp: WindowManager.LayoutParams
    private lateinit var rv: RecyclerView
    private lateinit var tvCount: TextView
    private lateinit var tvEmpty: View
    private lateinit var adapter: DownloadAdapter
    private var panelAttached = false
    private var scanning = false

    private val minW get() = dp(240)
    private val minH get() = dp(240)

    override fun onBind(intent: Intent?) = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        val n = Notifs.build(this, getString(R.string.ov_notif_text))
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(Notifs.ID_OVERLAY, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(Notifs.ID_OVERLAY, n)

        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        ui = ContextThemeWrapper(this, R.style.Theme_OverlayUI)
        prefs = getSharedPreferences("overlay_ui", MODE_PRIVATE)

        buildBubble()
        buildPanel()
        scope.launch { DownloadQueue.items.collect { render(it) } }
        scope.launch { ScanBus.outcomes.collect { onScanOutcome(it) } }
    }

    override fun onDestroy() {
        scope.cancel()
        if (::bubble.isInitialized) {
            if (bubbleAttached) wm.removeView(bubble)
            if (panelAttached) wm.removeView(panel)
        }
        super.onDestroy()
    }

    // ───────────────────────── Bubble ─────────────────────────

    @SuppressLint("ClickableViewAccessibility")
    private fun buildBubble() {
        bubble = LayoutInflater.from(ui).inflate(R.layout.overlay_bubble, null)
        badge = bubble.findViewById(R.id.tvBadge)
        bubbleLp = baseParams(WRAP_CONTENT, WRAP_CONTENT).apply {
            x = prefs.getInt("bx", 0); y = prefs.getInt("by", dp(220))
        }
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = bubbleLp.x; sy = bubbleLp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        bubbleLp.x = (sx + dx).toInt(); bubbleLp.y = (sy + dy).toInt()
                        wm.updateViewLayout(bubble, bubbleLp)
                    }
                }
                MotionEvent.ACTION_UP -> if (moved) snapBubbleToEdge() else togglePanel()
            }
            true
        }
        wm.addView(bubble, bubbleLp); bubbleAttached = true
    }

    private fun snapBubbleToEdge() {
        val (sw, sh) = screenSize()
        val w = bubble.width
        val targetX = if (bubbleLp.x + w / 2 < sw / 2) 0 else sw - w
        val targetY = bubbleLp.y.coerceIn(0, max(0, sh - bubble.height))
        ValueAnimator.ofInt(bubbleLp.x, targetX).apply {
            duration = 180
            addUpdateListener {
                bubbleLp.x = it.animatedValue as Int; bubbleLp.y = targetY
                if (bubbleAttached) wm.updateViewLayout(bubble, bubbleLp)
            }
            start()
        }
        prefs.edit().putInt("bx", targetX).putInt("by", targetY).apply()
    }

    // ───────────────────────── Panel ─────────────────────────

    @SuppressLint("ClickableViewAccessibility")
    private fun buildPanel() {
        panel = LayoutInflater.from(ui).inflate(R.layout.overlay_panel, null)
        rv = panel.findViewById(R.id.rvList)
        tvCount = panel.findViewById(R.id.tvCount)
        tvEmpty = panel.findViewById(R.id.tvEmpty)

        adapter = DownloadAdapter { copyUrl(it) }
        rv.layoutManager = LinearLayoutManager(ui)
        rv.adapter = adapter
        rv.itemAnimator = null

        val (sw, sh) = screenSize()
        val w = prefs.getInt("pw", minOf((sw * 0.92).toInt(), dp(360)))
        val h = prefs.getInt("ph", minOf((sh * 0.6).toInt(), dp(520)))
        panelLp = baseParams(w, h)
        if (Build.VERSION.SDK_INT >= 31 && wm.isCrossWindowBlurEnabled) {
            panelLp.flags = panelLp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            panelLp.blurBehindRadius = dp(18)
        }

        panel.findViewById<View>(R.id.btnScan).setOnClickListener { startScan() }
        panel.findViewById<View>(R.id.btnPaste).setOnClickListener { pasteFromClipboard() }
        panel.findViewById<View>(R.id.btnClear).setOnClickListener { DownloadQueue.clear() }

        attachPanelDrag(panel.findViewById(R.id.dragHeader))
        attachResize(panel.findViewById(R.id.hLeft), EDGE_L)
        attachResize(panel.findViewById(R.id.hTop), EDGE_T)
        attachResize(panel.findViewById(R.id.hRight), EDGE_R)
        attachResize(panel.findViewById(R.id.hBottom), EDGE_B)
        attachResize(panel.findViewById(R.id.hTL), EDGE_T or EDGE_L)
        attachResize(panel.findViewById(R.id.hTR), EDGE_T or EDGE_R)
        attachResize(panel.findViewById(R.id.hBL), EDGE_B or EDGE_L)
        attachResize(panel.findViewById(R.id.hBR), EDGE_B or EDGE_R)
    }

    private fun togglePanel() {
        if (panelAttached) {
            wm.removeView(panel); panelAttached = false
        } else {
            placePanelNearBubble()
            wm.addView(panel, panelLp); panelAttached = true
            // Keep the bubble above the panel in z-order.
            bubble.post { if (bubbleAttached) { wm.removeView(bubble); wm.addView(bubble, bubbleLp) } }
        }
    }

    private fun placePanelNearBubble() {
        val (sw, sh) = screenSize()
        panelLp.width = panelLp.width.coerceIn(minW, max(minW, sw))
        panelLp.height = panelLp.height.coerceIn(minH, max(minH, sh))
        val w = panelLp.width; val h = panelLp.height
        panelLp.x = (bubbleLp.x + bubble.width / 2 - w / 2).coerceIn(0, max(0, sw - w))
        var y = bubbleLp.y + bubble.height + dp(8)
        if (y + h > sh) y = bubbleLp.y - h - dp(8)
        panelLp.y = y.coerceIn(0, max(0, sh - h))
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachPanelDrag(handle: View) {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = panelLp.x; sy = panelLp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    val (sw, sh) = screenSize()
                    panelLp.x = (sx + (e.rawX - tx)).toInt().coerceIn(0, max(0, sw - panelLp.width))
                    panelLp.y = (sy + (e.rawY - ty)).toInt().coerceIn(0, max(0, sh - panelLp.height))
                    if (panelAttached) wm.updateViewLayout(panel, panelLp)
                }
            }
            true
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachResize(handle: View, edges: Int) {
        var sx = 0; var sy = 0; var sw = 0; var sh = 0; var tx = 0f; var ty = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = panelLp.x; sy = panelLp.y; sw = panelLp.width; sh = panelLp.height
                    tx = e.rawX; ty = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    val (scrW, scrH) = screenSize()
                    var nx = sx; var ny = sy; var nw = sw; var nh = sh
                    if ((edges and EDGE_R) != 0) nw = (sw + dx).coerceIn(minW, max(minW, scrW - sx))
                    if ((edges and EDGE_L) != 0) { nw = (sw - dx).coerceIn(minW, max(minW, sx + sw)); nx = sx + sw - nw }
                    if ((edges and EDGE_B) != 0) nh = (sh + dy).coerceIn(minH, max(minH, scrH - sy))
                    if ((edges and EDGE_T) != 0) { nh = (sh - dy).coerceIn(minH, max(minH, sy + sh)); ny = sy + sh - nh }
                    panelLp.x = nx; panelLp.y = ny; panelLp.width = nw; panelLp.height = nh
                    if (panelAttached) wm.updateViewLayout(panel, panelLp)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    prefs.edit().putInt("pw", panelLp.width).putInt("ph", panelLp.height).apply()
            }
            true
        }
    }

    // ───────────────────────── List rendering ─────────────────────────

    private fun render(list: List<DownloadItem>) {
        val grew = list.size > adapter.itemCount
        adapter.submitList(list) { if (grew && list.isNotEmpty()) rv.scrollToPosition(list.size - 1) }
        tvCount.text = list.size.toString()
        tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        badge.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        badge.text = if (list.size > 99) "99+" else list.size.toString()
    }

    private fun copyUrl(item: DownloadItem) {
        if (item.url.isEmpty()) return
        getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText("url", item.url))
        toast(R.string.ov_copied)
    }

    // ───────────────────────── Paste ─────────────────────────

    /**
     * Android 10+ only lets the app with input focus read the clipboard, and overlay
     * windows are normally NOT_FOCUSABLE. We make the panel focusable for a split second.
     */
    private fun pasteFromClipboard() {
        if (!panelAttached) return
        setPanelFocusable(true)
        var attempts = 0
        fun tryRead() {
            attempts++
            val txt = readClipboard()
            if (txt == null && attempts < 4) { panel.postDelayed({ tryRead() }, 150); return }
            setPanelFocusable(false)
            val url = UrlValidator.extract(txt)
            when {
                url == null -> toast(R.string.ov_paste_invalid)
                DownloadQueue.addUrl(url) -> toast(R.string.ov_paste_added)
                else -> toast(R.string.ov_paste_duplicate)
            }
        }
        panel.postDelayed({ tryRead() }, 150)
    }

    private fun readClipboard(): String? {
        val clip = getSystemService(ClipboardManager::class.java).primaryClip ?: return null
        return if (clip.itemCount > 0) clip.getItemAt(0).coerceToText(this)?.toString() else null
    }

    private fun setPanelFocusable(focusable: Boolean) {
        panelLp.flags = if (focusable) panelLp.flags and FLAG_NOT_FOCUSABLE.inv()
        else panelLp.flags or FLAG_NOT_FOCUSABLE
        if (panelAttached) wm.updateViewLayout(panel, panelLp)
    }

    // ───────────────────────── Screen scan ─────────────────────────

    private fun startScan() {
        if (scanning) return
        scanning = true
        // Start the consent activity while our overlay is still visible (background-start exemption),
        // then hide the overlay so it isn't captured by OCR.
        startActivity(
            Intent(this, ProjectionRequestActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        )
        setOverlayVisible(false)
    }

    private fun setOverlayVisible(visible: Boolean) {
        val v = if (visible) View.VISIBLE else View.INVISIBLE
        bubble.visibility = v
        panel.visibility = v
    }

    private fun onScanOutcome(o: ScanOutcome) {
        scanning = false
        setOverlayVisible(true)
        when {
            o.error != null -> Toast.makeText(this, o.error, Toast.LENGTH_LONG).show()
            o.candidates.isEmpty() -> toast(R.string.ov_scan_none)
            else -> {
                val n = DownloadQueue.addScanned(o.candidates)
                Toast.makeText(this, getString(R.string.ov_scan_added, n), Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ───────────────────────── Helpers ─────────────────────────

    @Suppress("DEPRECATION")
    private fun baseParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE,
        FLAG_NOT_FOCUSABLE or FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) wm.maximumWindowMetrics.bounds.let { it.width() to it.height() }
        else DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }.let { it.widthPixels to it.heightPixels }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()
}
