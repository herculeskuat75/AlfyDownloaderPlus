# Part 2 – Group B: Floating UI & Layout

Package assumed: `com.opendl.downloader` (rename in all files + `R` imports if Part 1 used another).

## Install
1. Unzip into your project root (merges into `app/src/main/...`).
2. Merge `INTEGRATION/AndroidManifest.part2.xml` and `INTEGRATION/build.gradle.part2.txt`.
3. After the overlay permission is granted in the Part 1 flow, call `OverlayService.start(this)`.

## Files
- `overlay/OverlayService.kt` – bubble (drag, edge-snap, red badge), glass panel (move, 4-edge + 4-corner resize, remembered size), Paste / Clear / Scan wiring
- `scan/*` – Screen Scan pipeline
- `data/DownloadQueue.kt` – shared queue (StateFlow), `MediaInfoResolver.kt` – size/duration/quality for direct files
- `ui/DownloadAdapter.kt`, `res/layout/*` – IDM-style item rows

## Known limits (please read)
- **Screen Scan uses OCR, not the view hierarchy.** Reading another app's view tree requires an Accessibility Service (or root/ADB), which Part 1 excludes. This build captures one frame through MediaProjection and extracts the largest sentence-like text blocks with ML Kit. It is heuristic: it can miss titles or pick subtitles. Android 14+ shows the capture consent dialog on every scan.
- OCR cannot see a video's real URL, so scanned items normally show "URL not detected"; use Paste for the link.
- Resolution/size/duration are real only for direct media files (HEAD + MediaMetadataRetriever). For page links (YouTube etc.) the row shows the quality as `Auto` until a stream extractor is added.
- Not compiled or run on a device in this environment; expect to fix small compile errors on first build.
