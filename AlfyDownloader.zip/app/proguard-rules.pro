# FFmpegKit calls back into these classes from native code (JNI) - must not be renamed/removed.
-keep class com.arthenica.ffmpegkit.** { *; }
-keep class com.arthenica.smartexception.** { *; }
-dontwarn com.arthenica.**

# OkHttp / Okio optional platform classes
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# Media3 / ML Kit ship their own consumer rules; silence optional references only.
-dontwarn androidx.media3.**
-dontwarn com.google.mlkit.**

# yt-dlp runtime (reflection / Jackson)
-keep class com.yausername.** { *; }
-dontwarn com.yausername.**
-keep class com.fasterxml.jackson.** { *; }
-dontwarn com.fasterxml.jackson.**
-dontwarn org.apache.commons.**
