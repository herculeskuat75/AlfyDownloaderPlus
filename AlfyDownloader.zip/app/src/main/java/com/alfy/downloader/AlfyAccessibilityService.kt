package com.alfy.downloader

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

class AlfyAccessibilityService : AccessibilityService() {
    private val skip = listOf("subscription", "live", "tren", "beranda", "notifikasi", "anda", "shorts", "disulih", "bagikan",
        "simpan", "remix", "suka", "komentar", "like", "share", "comment", "subscribe", "telusuri", "search", "lainnya",
        "kembali", "back", "more", "home", "library", "trending", "explore", "jelajahi", "buat", "create", "iklan", "sponsor")

    private val urlRe = Regex("https?://[^\\s\"'<>)]+")
    // alamat tanpa "https://" yang sering tampil di layar aplikasi lain (mis. "tiktok.com/@x/video/123")
    private val bareRe = Regex("(?<![\\w/.@-])(?:www\\.|m\\.|vm\\.|vt\\.)?(?:youtube\\.com|youtu\\.be|tiktok\\.com|instagram\\.com|facebook\\.com|fb\\.watch|x\\.com|twitter\\.com|vimeo\\.com|dailymotion\\.com|reddit\\.com|twitch\\.tv|soundcloud\\.com|bilibili\\.com|threads\\.net)/[^\\s\\\"'<>)]+", RegexOption.IGNORE_CASE)
    private val durRe = Regex("\\d+\\s*(menit|detik|jam|minute|second|hour|min|sec)", RegexOption.IGNORE_CASE)
    private val thumbDone = HashSet<String>()
    private var thumbAt = 0L
    private var thumbWin = 0L
    private var thumbCount = 0
    private val hostRe = Regex("^[\\w.-]+\\.[a-zA-Z]{2,}(/\\S*)?$")
    private val barIds = listOf(
        "url_bar", "url_field", "location_bar_edit_text", "mozac_browser_toolbar_url_view",
        "url_bar_title", "omnibarTextInput", "toolbar_url", "search_box_text", "url_edit_text"
    )

    private val ht = android.os.HandlerThread("alfy-scan").also { it.start() }
    private val bg = android.os.Handler(ht.looper)
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    @Volatile private var busy = false
    private var last = 0L
    private var lastFull = 0L
    private var candQ = ""
    private var doneQ = ""
    private var lastPkg = ""
    @Volatile private var titleClickAt = 0L

    companion object {
        @Volatile var inst: AlfyAccessibilityService? = null
        /** v1.12: aplikasi yang sedang di depan (dipakai kunci mode YouTube: hanya deteksi layar). */
        @Volatile var fgPkg: String = ""
    }

    // v1.12: nama channel dari keterangan thumbnail / baris channel ("Buka saluran X", "X • 1,2 jt subscriber")
    private val chanRe = Regex("(?i)^(?:buka|kunjungi|lihat|go to|open|view)\\s+(?:saluran|channel)\\s+(.+)$")
    private val subRe = Regex("(?i)^(.{2,60}?)\\s*[•·,]\\s*[\\d.,]+\\s*(?:[km]|rb|jt|ribu|juta)?\\s*(?:subscribers?|pelanggan)")
    private val statRe = Regex("(?i)\\d.*(ditonton|views?|subscribers?|pelanggan|x tayang)")
    private fun channelFrom(t: String): String? {
        for (p in t.split(" - ", " – ", " • ", "\n")) {
            chanRe.find(p.trim())?.let { m -> val c = m.groupValues[1].trim().trimEnd('.', ',').take(60); if (c.length >= 2) return c }
        }
        subRe.find(t.trim())?.let { m -> val c = m.groupValues[1].trim(); if (c.length >= 2) return c }
        return null
    }
    private class YQ(val first: String, val second: Boolean, val chan: String)
    private fun vis(n: AccessibilityNodeInfo): Boolean = try { n.isVisibleToUser } catch (e: Exception) { true }

    private val cmgr by lazy { getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager }
    private var lastClipTxt = ""
    private var evMask = 0
    private var clipOn = false
    /** Scan/tool OFF => sistem berhenti mengirim event, listener clipboard dilepas, handler dibersihkan. */
    fun applyState() {
        val s = Scan.enabled()
        val full = s && Tool.on("Aksesibilitas")
        val fgOnly = s && !full && Tool.on("Logcat root")   // hanya untuk fgPkg (kunci mode YouTube)
        val mask = if (full) evMask else if (fgOnly) AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED else 0
        try { val i = serviceInfo; if (i != null && i.eventTypes != mask) { i.eventTypes = mask; serviceInfo = i } } catch (e: Exception) { }
        if (full && !clipOn) { clipOn = true; try { cmgr.addPrimaryClipChangedListener(clipL) } catch (e: Exception) { } }
        if (!full) {
            if (clipOn) { clipOn = false; try { cmgr.removePrimaryClipChangedListener(clipL) } catch (e: Exception) { } }
            bg.removeCallbacksAndMessages(null); main.removeCallbacksAndMessages(null); busy = false
        }
    }
    private val clipL = android.content.ClipboardManager.OnPrimaryClipChangedListener {
        // layanan aksesibilitas boleh membaca clipboard di latar belakang -> otomatis, tanpa paste
        if (Scan.enabled()) main.post { if (!readClipDirect()) FloatingService.inst?.pullClip() ?: NetSniffer.readClipRootOnce() }
    }

    /** Baca clipboard langsung dari layanan aksesibilitas. true bila ada tautan yang ditemukan. */
    fun readClipDirect(): Boolean {
        return try {
            val t = cmgr.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: return false
            if (t.isBlank()) return false
            val urls = urlRe.findAll(t).map { it.value.trimEnd('.', ',', ';', ')') }.toList()
            if (urls.isEmpty()) return t.isNotBlank()
            urls.forEach { Resolver.rescan(it, null, "Clipboard (aksesibilitas)") }
            lastClipTxt = t
            Resolver.diag = "Clipboard: memindai ${urls.size} tautan…"
            true
        } catch (e: Exception) { false }
    }

    override fun onServiceConnected() {
        super.onServiceConnected(); inst = this
        goForeground()
        try {
            val i = serviceInfo
            if (i != null) {
                i.eventTypes = i.eventTypes or AccessibilityEvent.TYPE_VIEW_CLICKED or AccessibilityEvent.TYPE_VIEW_LONG_CLICKED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
                i.notificationTimeout = 50
                evMask = i.eventTypes
                serviceInfo = i
            }
        } catch (e: Exception) { }
        applyState()
    }

    /** Jalankan sebagai Foreground Service (notifikasi persisten) agar tidak dimatikan sistem (mis. MIUI/Xiaomi). */
    private fun goForeground() {
        try {
            startForeground(3, makeNotif(this, "Layanan aksesibilitas aktif", icon = android.R.drawable.stat_sys_download_done, channel = "alfy_access"))
        } catch (e: Exception) { }
    }

    fun keyboardShown(): Boolean = try { windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD } } catch (e: Exception) { false }

    /** Ambil jendela aplikasi yang sedang dibuka (bukan jendela AlfyDownloader sendiri). */
    private fun appRoot(): AccessibilityNodeInfo? {
        try {
            val r = rootInActiveWindow
            if (r != null && r.packageName?.toString() != packageName) return r
        } catch (e: Exception) { }
        try {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val x = w.root ?: continue
                if (x.packageName?.toString() != packageName) return x
            }
        } catch (e: Exception) { }
        return null
    }

    /** Pindai layar yang sedang terbuka (tombol 🔍): langsung, tanpa menunggu. */
    fun scanNow(fresh: Boolean = false) {
        // v1.61: scan baru = ambil aplikasi yang sedang di depan, buang cache lama, hanya layar aplikasi itu yang dibaca
        val fg = (try { appRoot()?.packageName?.toString() } catch (e: Exception) { null }) ?: fgPkg
        if (fg.isNotEmpty() && fg != packageName && (fresh || fg != Resolver.activePkg)) Resolver.beginScope(fg)
        // v77: tombol 🔍 = Force Re-scan: buang cache 'sudah discan' & jeda gagal agar link yang baru dihapus dari daftar masuk lagi
        if (fresh) Resolver.forgetForManual()
        bg.post {
            var roots = scopedRoots()
            for (i in 0 until 4) {
                if (roots.isNotEmpty()) break
                try { Thread.sleep(200) } catch (e: Exception) { }
                roots = scopedRoots()
            }
            if (roots.isEmpty()) { Resolver.diag = "Layar belum terbaca, coba lagi"; return@post }
            Resolver.diag = "Memindai layar…"
            var found = 0
            for (root in roots) try { found += process(root, root.packageName?.toString() ?: "", true, false) } catch (e: Exception) { }
            // Visual Scan universal: tidak ada URL -> teks paling menonjol jadi kata kunci ytsearch5 (yt-dlp)
            val fgp = roots.firstOrNull()?.packageName?.toString() ?: ""
            val ytApp = fgp.contains("youtube", true) && !Block.youtube()
            if (found == 0 && !ytApp) {
                val q = try { prominentText(roots) } catch (e: Exception) { null }
                if (q != null) { found = 1; Resolver.searchYoutube(q, false, true, "") }
            }
            if (found == 0 && Resolver.diag == "Memindai layar…") Resolver.diag = "Layar dipindai: tidak ada tautan/teks judul terbaca"
            // hemat RAM: hentikan pemindaian lanjutan setelah hasil dikirim
            if (found > 0) bg.removeCallbacksAndMessages(null)
        }
    }

    private val junkRe = Regex("(?i)^(follow|following|followed|ikuti|mengikuti|like|liked|likes|comment|comments|komentar|play|pause|putar|jeda|shuffle|acak|repeat|ulangi|next|previous|selanjutnya|sebelumnya|skip|lewati|ad|ads|iklan|advertisement|premium|upgrade|download|unduh|share|bagikan|save|simpan|add|tambah|close|tutup|menu|search|cari|home|beranda|your library|library|koleksi|now playing|sedang diputar|lyrics|lirik|queue|antrean|cast|more|lainnya|back|kembali|settings|pengaturan|reply|balas|send|kirim|new|baru|live|story|stories|reels|explore|jelajahi|profile|profil)$")
    private val timeRe = Regex("^[-+]?\\d{1,2}(:\\d{2}){1,2}$|^\\d+\\s*[kKmMbB]?$|^[\\d.,]+\\s*(rb|jt|k|m|ribu|juta)?\\s*(likes?|suka|views?|komentar|comments?|followers?|pengikut)?$")

    /** Teks judul paling menonjol di layar (node terlihat, tinggi/atas terbesar), setelah membuang teks sampah. */
    private fun prominentText(roots: List<AccessibilityNodeInfo>): String? {
        class C(val t: String, val top: Int, val h: Int)
        val list = ArrayList<C>()
        val seen = HashSet<String>()
        val cnt = IntArray(1)
        val screenH = resources.displayMetrics.heightPixels
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || d > 30 || cnt[0]++ > 1500) return
            if (!vis(n)) return
            for (s0 in listOf(n.text?.toString(), n.contentDescription?.toString())) {
                val t = s0?.trim()?.replace(Regex("\\s+"), " ") ?: continue
                if (t.length !in 3..120 || !seen.add(t.lowercase())) continue
                if (junkRe.matches(t) || timeRe.matches(t) || durRe.matches(t) || isNavText(t) || statRe.containsMatchIn(t)) continue
                if (t.startsWith("http") || t.all { !it.isLetter() }) continue
                val r = android.graphics.Rect(); try { n.getBoundsInScreen(r) } catch (e: Exception) { continue }
                if (r.top < screenH * 0.06 || r.top > screenH * 0.85) continue   // abaikan status/toolbar atas & bar bawah
                list.add(C(t, r.top, r.height()))
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        for (r in roots) walk(r, 0)
        if (list.isEmpty()) return null
        val best = list.maxByOrNull { it.h * 2 + minOf(it.t.length, 60) } ?: return null
        // judul pendek (mis. Spotify: lagu + artis berdekatan) -> gabungkan teks terdekat di bawahnya
        if (best.t.length < 30) {
            val sub = list.filter { it !== best && it.top >= best.top && it.top - best.top < 260 && it.t.length < 50 }.minByOrNull { it.top - best.top }
            if (sub != null) return (best.t + " " + sub.t).take(120)
        }
        return best.t
    }

    private fun clipSoon() {
        for (d in longArrayOf(300, 1200)) main.postDelayed({
            if (readClipDirect()) return@postDelayed
            val f = FloatingService.inst
            if (f != null) f.pullClip() else NetSniffer.readClipRootOnce()
        }, d)
    }

    /** Semua jendela aplikasi (bukan AlfyDownloader) — termasuk popup/bottom sheet. */
    private fun scopedRoots(): List<AccessibilityNodeInfo> {
        val a = Resolver.activePkg
        val l = allRoots()
        return if (a.isEmpty()) l else l.filter { it.packageName?.toString() == a }
    }

    private fun allRoots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION && w.type != AccessibilityWindowInfo.TYPE_SYSTEM) continue
                val x = w.root ?: continue
                if (x.packageName?.toString() != packageName) out.add(x)
            }
        } catch (e: Exception) { }
        if (out.isEmpty()) appRoot()?.let { out.add(it) }
        return out
    }

    private fun isNavText(t: String): Boolean { val l = t.lowercase().trim(); return skip.any { l == it || l.startsWith("$it ") } }

    /** Teks keterangan thumbnail YouTube: "Judul - 5 menit - Buka saluran X - 1 jt x ditonton ..." -> ambil judul. */
    private fun titleFromDesc(d: String): String? {
        val parts = d.split(" - ", " – ", " • ").map { it.trim() }.filter { it.isNotEmpty() }
        val t = parts.firstOrNull() ?: return null
        if (t.length < 4 || isNavText(t)) return null
        return t.take(120)
    }

    /** Setelah klik video/tautan: pindai layar di latar belakang (tunggu layar baru muncul). */
    private fun burst(pkg: String) {
        for (d in longArrayOf(1500, 3500)) bg.postDelayed({
            try {
                val r = appRoot() ?: return@postDelayed
                process(r, r.packageName?.toString() ?: pkg, false, true)
            } catch (ex: Exception) { }
        }, d)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || !Scan.enabled()) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) {
            // v1.61: browser Alfy di depan = scope aplikasi sendiri
            if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && e.className?.toString()?.endsWith("BrowserActivity") == true && Resolver.activePkg != packageName) Resolver.beginScope(packageName)
            return
        }
        if (!Scan.enabled()) return   // v1.11: scan otomatis dimatikan lewat ⚙ di panel
        val type = e.eventType
        if (type != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED && !pkg.contains("systemui") && !pkg.contains("inputmethod") && !pkg.contains("keyboard")) fgPkg = pkg
        // v1.61: pindah aplikasi di depan -> buang semua link/cache aplikasi sebelumnya
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg == fgPkg && pkg != Resolver.activePkg) Resolver.beginScope(pkg)
        if (!Tool.on("Aksesibilitas")) return   // v1.12: tool dimatikan lewat ⚙ (tombol 🔍 manual tetap jalan)
        val txt = (e.text?.joinToString(" ") ?: "") + " " + (e.contentDescription ?: "")
        val low = txt.lowercase()

        // Klik / tahan video atau tautan -> langsung pindai di latar belakang
        if (type == AccessibilityEvent.TYPE_VIEW_CLICKED || type == AccessibilityEvent.TYPE_VIEW_LONG_CLICKED) {
            val sb = StringBuilder(txt)
            try {
                var n: AccessibilityNodeInfo? = e.source
                var d = 0
                while (n != null && d < 4) {
                    sb.append(' ').append(n.text ?: "").append(' ').append(n.contentDescription ?: "")
                    n = n.parent; d++
                }
            } catch (ex: Exception) { }
            val all = sb.toString()
            urlRe.findAll(all).forEach { Resolver.submit(it.value.trimEnd('.', ',', ';', ')'), null, true, "Aksesibilitas (klik)") }
            if (pkg.contains("youtube", true)) {
                // thumbnail yang diklik: judulnya ada di deskripsi -> langsung cari video itu
                val cds = ArrayList<String>()
                try {
                    var n: AccessibilityNodeInfo? = e.source; var d = 0
                    while (n != null && d < 5) { n.contentDescription?.toString()?.let { cds.add(it) }; n.text?.toString()?.let { cds.add(it) }; n = n.parent; d++ }
                } catch (ex: Exception) { }
                cds.add(txt)
                val best = cds.filter { it.length > 12 && !isNavText(it) }.maxByOrNull { it.length }
                val t = best?.let { titleFromDesc(it) }
                val chC = cds.firstNotNullOfOrNull { channelFrom(it) } ?: ""
                if (t != null) { titleClickAt = SystemClock.uptimeMillis(); candQ = t; doneQ = t; Resolver.latestYt = t; Resolver.searchYoutube(t, false, true, chC) }
            }
            val l = all.lowercase()
            if (l.contains("salin") || l.contains("copy") || l.contains("copied")) clipSoon()
            burst(pkg)
            return
        }

        // Toast "tautan disalin" / pratinjau clipboard sistem -> baca clipboard terbaru
        if (type == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED || pkg.contains("systemui")) {
            if (low.contains("disalin") || low.contains("copied") || low.contains("salin") || low.contains("clipboard") ||
                low.contains("papan klip") || low.contains("tautan") || low.contains("link")) clipSoon()
            if (pkg == Resolver.activePkg) urlRe.findAll(txt).forEach { Resolver.submit(it.value, null, false, "Aksesibilitas (notifikasi)") }   // v1.61: notifikasi aplikasi latar diabaikan
            if (type == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) return
        }
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != lastPkg) { lastPkg = pkg; burst(pkg) }
        if (type == AccessibilityEvent.TYPE_VIEW_SCROLLED || type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) xTick()
        if (busy) return
        val now = SystemClock.uptimeMillis()
        if (now - last < 200) return
        last = now
        busy = true
        bg.post {
            try {
                val root = rootInActiveWindow ?: return@post
                process(root, pkg, false, false)
            } catch (ex: Exception) { } finally { busy = false }
        }
    }

    override fun onDestroy() { inst = null; try { stopForeground(true) } catch (e: Exception) { }; bg.removeCallbacksAndMessages(null); main.removeCallbacksAndMessages(null); try { cmgr.removePrimaryClipChangedListener(clipL) } catch (e: Exception) { }; try { ht.quitSafely() } catch (e: Exception) { }; super.onDestroy() }

    @Volatile private var curPkg = ""

    private fun process(root: AccessibilityNodeInfo, pkg: String, manual: Boolean, click: Boolean): Int {
        if (Resolver.activePkg.isNotEmpty() && pkg != Resolver.activePkg) return 0   // v1.61: hanya aplikasi aktif
        var found = 0
        curPkg = pkg
        for (n in barIds) {
            root.findAccessibilityNodeInfosByViewId("$pkg:id/$n")?.forEach { v ->
                v.text?.toString()?.let { handleBar(it) }
            }
        }
        val yt = pkg.contains("youtube", true) && !Block.youtube()
        if (yt) {
            if (manual) {
                val q = ytQuery(root)   // v1.12: judul + handle + NAMA CHANNEL dibaca dari layar
                if (q == null) Resolver.diag = "YouTube: teks video di layar tidak terbaca"
                else { candQ = q.first; doneQ = q.first; Resolver.searchYoutube(q.first, q.second, true, q.chan) }
            } else if (click) {
                if (SystemClock.uptimeMillis() - titleClickAt > 6000 && onPlayer(root)) {
                    val q = ytQuery(root, true)
                    if (q != null && q.first != doneQ) { candQ = q.first; doneQ = q.first; Resolver.latestYt = q.first; Resolver.searchYoutube(q.first, q.second, true, q.chan) }
                }
            } else if (onPlayer(root)) {
                ytAuto(root)
            } else if (Scan.enabled() && Repo.prefs().getBoolean("autoThumb", true) && SystemClock.uptimeMillis() - titleClickAt > 15_000) {
                // v1.11: HANYA mode agresif: cari video dari judul thumbnail yang cuma DILIHAT. Mode normal = hanya video yang sudah dibuka.
                thumbScan(root)
            }
        }
        if (!yt && !manual) autoPlay(root, pkg)
        // Pindai semua teks layar untuk alamat http(s) (otomatis, dibatasi agar ringan)
        val now = SystemClock.uptimeMillis()
        if (manual || click || now - lastFull > 800) {
            lastFull = now
            found += scan(root, 0, IntArray(1), manual || click, if (manual) "Aksesibilitas (🔍 manual)" else if (click) "Aksesibilitas (klik)" else "Aksesibilitas (layar)")
        }
        return found
    }

    /** Otomatis saat daftar/hasil pencarian YouTube hanya DILIHAT (belum diklik): cari video dari judul thumbnail. Dibatasi agar IP tidak ditandai bot. */
    private fun thumbScan(root: AccessibilityNodeInfo) {
        if (!Repo.prefs().getBoolean("autoThumb", true)) return
        val now = SystemClock.uptimeMillis()
        if (now - thumbWin > 600_000) { thumbWin = now; thumbCount = 0 }
        if (now - thumbAt < 3000 || thumbCount >= 20) return
        val cnt = IntArray(1)
        var pick: String? = null
        var pickCh = ""
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || pick != null || d > 25 || cnt[0]++ > 600) return
            if (!vis(n)) return   // v1.12: hanya thumbnail yang benar-benar terlihat di layar
            val cd = n.contentDescription?.toString()
            if (cd != null && cd.length > 15 && cd.contains(" - ") && durRe.containsMatchIn(cd)) {
                val t = titleFromDesc(cd)
                if (t != null && t !in thumbDone) { pick = t; pickCh = channelFrom(cd) ?: ""; return }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(root, 0)
        val t = pick ?: return
        thumbDone.add(t); thumbAt = now; thumbCount++
        Resolver.searchYoutube(t, false, false, pickCh)
    }

    /** Teks YouTube di layar: handle channel + keterangan video. Mengembalikan (query, apakah Shorts). */
    private fun ytQuery(root: AccessibilityNodeInfo, visOnly: Boolean = false): YQ? {
        val texts = LinkedHashSet<String>()
        val tops = HashMap<String, Int>()
        val screenH = resources.displayMetrics.heightPixels
        fun add(s: String?, n: AccessibilityNodeInfo) {
            val t = s?.trim() ?: return
            if (t.isEmpty()) return
            if (texts.add(t) && visOnly) { val r = android.graphics.Rect(); try { n.getBoundsInScreen(r) } catch (e: Exception) { }; tops[t] = r.top }
        }
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || d > 25 || texts.size > 150) return
            if (visOnly && !vis(n)) return   // v1.12 mode otomatis: node yang tidak terlihat di layar diabaikan
            add(n.text?.toString(), n); add(n.contentDescription?.toString(), n)
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(root, 0)
        val handleRe = Regex("@[A-Za-z0-9._-]{3,}")
        val handle = texts.firstNotNullOfOrNull { handleRe.find(it)?.value }
        val chan = texts.firstNotNullOfOrNull { channelFrom(it) } ?: ""
        val shorts = texts.any { it.equals("shorts", true) }
        val cap = texts.filter { t ->
            t.length in 6..140 && !t.matches(Regex("[\\d.,: KkMmRrbBtT]+")) && t != handle &&
                (handle == null || !t.contains(handle)) && skip.none { t.lowercase().startsWith(it) } &&
                !statRe.containsMatchIn(t) && !chanRe.containsMatchIn(t) && !t.equals(chan, true) &&
                // otomatis: abaikan keterangan thumbnail rekomendasi & teks di bagian bawah layar (bukan judul video yang diputar)
                (!visOnly || shorts || ((tops[t] ?: 0) < screenH * 0.65 && !(durRe.containsMatchIn(t) && t.contains(" - "))))
        }.maxByOrNull { it.length }
        if (handle == null && cap == null) return null
        return YQ(((handle ?: "") + " " + (cap ?: "")).trim(), shorts, chan)
    }

    /** Otomatis: tunggu layar stabil sebentar (geser Shorts), baru cari video yang sedang tampil. */
    private fun ytAuto(root: AccessibilityNodeInfo) {
        val r = ytQuery(root, true) ?: return
        val q = r.first
        if (q == candQ) return
        candQ = q
        if (q == doneQ) return
        bg.postDelayed({
            if (candQ == q && doneQ != q) { doneQ = q; Resolver.latestYt = q; Resolver.searchYoutube(q, r.second, false, r.chan) }
        }, 800)
    }

    /** Layar pemutar YouTube (Shorts / halaman tonton) = ada tombol bagikan + aksi suka/simpan/remix. */
    private fun onPlayer(root: AccessibilityNodeInfo): Boolean {
        // v1.12: hanya tombol aksi yang TERLIHAT (diawali kata tombolnya) dan keduanya harus ada; judul video di feed yang
        // kebetulan memuat kata "like/save/suka" tidak lagi dianggap layar pemutar (penyebab video acak)
        var share = false; var act = false; var n = 0
        fun walk(x: AccessibilityNodeInfo?, d: Int) {
            if (x == null || d > 25 || n++ > 400 || (share && act)) return
            if (!vis(x)) return
            for (s in listOf(x.text?.toString(), x.contentDescription?.toString())) {
                val t = s?.trim()?.lowercase() ?: continue
                if (t.isEmpty() || (t.contains(" - ") && durRe.containsMatchIn(t))) continue
                if (t.startsWith("bagikan") || t.startsWith("share")) share = true
                if (t.startsWith("remix") || t.startsWith("simpan") || t.startsWith("save") || t.startsWith("suka") || t.startsWith("like")) act = true
            }
            for (i in 0 until x.childCount) walk(x.getChild(i), d + 1)
        }
        walk(root, 0)
        return share && act
    }

    // ---------- v1.9: tekan tombol PLAY otomatis di situs stream (jwplyr.com, vidoy.asia, dll) ----------
    private val playRe = Regex("^(?:tombol )?(?:play|putar|mainkan|tonton|watch|mulai)(?: ?(?:video|button|now|sekarang|tombol|media|film|di ?sini))?$")
    private val streamHostRe = Regex("(jwplyr\\.com|vidoy\\.(asia|com)|vldey\\.mom|overfetch\\.video|dood\\w*\\.|streamtape\\.|mixdrop\\.|filemoon\\.|streamwish\\.|vidhide\\.|voe\\.sx|upstream\\.)", RegexOption.IGNORE_CASE)
    private var playAt = 0L
    private var playClicks = 0
    private var playPage = ""

    /** Bila halaman stream terbuka dan ada tombol play yang TERLIHAT di layar: tekan otomatis, lalu semua alat memindai link video. */
    private fun autoPlay(root: AccessibilityNodeInfo, pkg: String) {
        if (!Repo.prefs().getBoolean("autoPlay", true)) return
        val pg = Resolver.lastPage
        if (pg.isEmpty() || System.currentTimeMillis() - Resolver.lastPageAt > 600_000L || !streamHostRe.containsMatchIn(pg)) return
        val now = SystemClock.uptimeMillis()
        if (now - playAt < 3000) return
        if (pg != playPage) { playPage = pg; playClicks = 0 }
        if (playClicks >= 4) return
        var target: AccessibilityNodeInfo? = null
        val cnt = IntArray(1)
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || target != null || d > 30 || cnt[0]++ > 1500) return
            try {
                if (n.isVisibleToUser) {
                    for (t0 in listOf(n.contentDescription?.toString(), n.text?.toString())) {
                        val t = t0?.trim()?.lowercase() ?: continue
                        if (t.length in 3..28 && playRe.matches(t)) { target = n; return }
                    }
                }
            } catch (e: Exception) { }
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(root, 0)
        val tg = target ?: return
        playAt = now; playClicks++
        var done = false
        try {
            var c: AccessibilityNodeInfo? = tg; var d = 0
            while (c != null && d < 5 && !done) { if (c.isClickable) done = c.performAction(AccessibilityNodeInfo.ACTION_CLICK); c = c.parent; d++ }
        } catch (e: Exception) { }
        if (!done) try {
            val r = android.graphics.Rect(); tg.getBoundsInScreen(r)
            val path = android.graphics.Path(); path.moveTo(r.exactCenterX(), r.exactCenterY())
            val g = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 60)).build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) { }
        val host = try { android.net.Uri.parse(pg).host ?: "web" } catch (e: Exception) { "web" }
        Resolver.diag = "Situs video: tombol play ditekan otomatis, memindai link…"
        if (SiteSettings.scanHost(host)) AutoScan.onPlay("web:$host", true)
    }

    // v1.10: saat x.com (dan subdomain) dibuka/di-scroll di browser, pindai ulang halaman tiap ~10 dtk
    private val xRe = Regex("^https?://(?:[\\w-]+\\.)?(?:x|twitter)\\.com(?:/|$)", RegexOption.IGNORE_CASE)
    private var xAt = 0L
    private fun xTick() {
        val pg = Resolver.lastPage
        if (pg.isEmpty() || !xRe.containsMatchIn(pg) || Resolver.xStatusId(pg) == null || System.currentTimeMillis() - Resolver.lastPageAt > 600_000L) return
        val now = SystemClock.uptimeMillis()
        if (now - xAt < 10_000) return
        xAt = now
        Resolver.rescan(pg, null, "Aksesibilitas (halaman X)")
    }

    private fun handleBar(t: String) {
        var s = t.trim()
        if (s.contains(' ')) return
        if (!s.startsWith("http")) {
            if (hostRe.matches(s)) s = "https://$s" else return
        }
        // v1.61: pindah situs di browser (alamat host berubah) -> buang cache situs lama
        val hh = try { android.net.Uri.parse(s).host ?: "" } catch (e: Exception) { "" }
        if (hh.isNotEmpty() && Resolver.siteKey(hh) != Resolver.siteKey(Resolver.activeHost)) {
            if (Resolver.activeHost.isNotEmpty()) Resolver.beginScope(Resolver.activePkg.ifEmpty { fgPkg }, hh) else Resolver.activeHost = hh
        }
        Resolver.lastPage = s
        Resolver.diag = "Sedang scan: " + Resolver.shortAddr(s)
        Resolver.submit(s, null, false, "Aksesibilitas (bar alamat)")
        Resolver.sniff(s)
    }

    private fun scan(n: AccessibilityNodeInfo?, d: Int, cnt: IntArray, force: Boolean, src: String): Int {
        if (n == null || d > 30 || cnt[0]++ > 1200) return 0
        var f = 0
        // v1.11: di aplikasi YouTube (mode normal) tautan YouTube lain di layar (komentar, deskripsi, rekomendasi) TIDAK dipindai otomatis:
        // fokus hanya pada video yang sudah dibuka. Mode agresif / tombol manual tetap memindai semuanya.
        val ytOnly = curPkg.contains("youtube", true) && !Scan.aggr() && !force
        if (ytOnly) return 0   // v1.12: di aplikasi YouTube (otomatis, mode normal) tautan di layar tidak dipindai sama sekali
        // v1.3: bar alamat browser mana pun (id berisi url/address/omnibox), mis. browser 1DM+, Kiwi, Via, dll
        val vid = n.viewIdResourceName?.lowercase()
        if (vid != null && (vid.contains("url") || vid.contains("address") || vid.contains("omnibox") || vid.contains("location_bar") || vid.contains("search_box_text") || vid.contains("toolbar_text"))) n.text?.toString()?.let { handleBar(it) }
        for (t in listOf(n.text?.toString(), n.contentDescription?.toString())) {
            if (t != null && t.contains("http")) {
                urlRe.findAll(t).forEach { m -> val x = m.value.trimEnd('.', ',', ';', ')'); if (ytOnly && Resolver.ytRe.containsMatchIn(x)) return@forEach; f++; Resolver.submit(x, null, force, src) }
            }
        }
        for (t in listOf(n.text?.toString(), n.contentDescription?.toString())) {
            if (t != null && !t.contains("http") && t.length > 8) {
                bareRe.findAll(t).forEach { m -> val x = "https://" + m.value.trimEnd('.', ',', ';', ')'); if (ytOnly && Resolver.ytRe.containsMatchIn(x)) return@forEach; f++; Resolver.submit(x, null, force, src) }
            }
        }
        for (i in 0 until n.childCount) f += scan(n.getChild(i), d + 1, cnt, force, src)
        return f
    }

    override fun onInterrupt() {}

    /** Service terlepas sementara (VPN/root/sistem): hanya kosongkan referensi; izin di Settings tetap dianggap aktif. */
    override fun onUnbind(intent: android.content.Intent?): Boolean {
        inst = null
        try { stopForeground(true) } catch (e: Exception) { }
        return super.onUnbind(intent)
    }
}
