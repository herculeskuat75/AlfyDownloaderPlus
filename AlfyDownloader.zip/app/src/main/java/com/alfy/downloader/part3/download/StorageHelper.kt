package com.alfy.downloader.part3.download

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.alfy.downloader.AppConfig
import com.alfy.downloader.part3.core.Category
import java.io.File
import java.io.IOException

object StorageHelper {
    private const val SETTINGS = "alfyd_settings"
    private const val KEY_FOLDER = "save_folder"
    const val DEFAULT_FOLDER = AppConfig.DEFAULT_FOLDER

    fun folderName(ctx: Context): String =
        ctx.getSharedPreferences(SETTINGS, Context.MODE_PRIVATE).getString(KEY_FOLDER, DEFAULT_FOLDER)
            ?.takeIf { it.isNotBlank() } ?: DEFAULT_FOLDER

    fun tmpDir(ctx: Context): File =
        File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "tmp").apply { mkdirs() }

    fun sanitize(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().trim('.').take(120).ifBlank { "media" }

    fun mimeOf(ext: String, cat: Category): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase())
            ?: when (ext.lowercase()) {
                "mkv" -> "video/x-matroska"; "ts" -> "video/mp2t"; "m4a" -> "audio/mp4"; "aac" -> "audio/aac"
                else -> if (cat == Category.MUSIC) "audio/mpeg" else "video/mp4"
            }

    /** Copies [src] into Downloads/<folder>/<video|music>/ and returns the final uri (content:// or file path). */
    fun publish(ctx: Context, src: File, displayName: String, cat: Category): String {
        val sub = if (cat == Category.MUSIC) AppConfig.SUBFOLDER_MUSIC else AppConfig.SUBFOLDER_VIDEO
        val rel = "${folderName(ctx)}/$sub"
        val ext = displayName.substringAfterLast('.', "")
        val mime = mimeOf(ext, cat)
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$rel")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val cr = ctx.contentResolver
            val uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: throw IOException("Gagal membuat berkas di Download")
            try {
                cr.openOutputStream(uri)?.use { o -> src.inputStream().use { it.copyTo(o) } } ?: throw IOException("Gagal menulis berkas")
                cr.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) {
                cr.delete(uri, null, null)
                throw e
            }
            return uri.toString()
        }
        @Suppress("DEPRECATION")
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), rel).apply { mkdirs() }
        var out = File(dir, displayName)
        var n = 1
        while (out.exists()) {
            out = File(dir, displayName.substringBeforeLast('.') + " ($n)." + ext); n++
        }
        src.copyTo(out, overwrite = false)
        MediaScannerConnection.scanFile(ctx, arrayOf(out.absolutePath), arrayOf(mime), null)
        return out.absolutePath
    }

    fun deleteFinal(ctx: Context, uri: String?) {
        if (uri == null) return
        try {
            if (uri.startsWith("content://")) ctx.contentResolver.delete(android.net.Uri.parse(uri), null, null)
            else File(uri).delete()
        } catch (_: Exception) { }
    }

    fun renameFinal(ctx: Context, uri: String?, newName: String) {
        if (uri == null) return
        try {
            if (uri.startsWith("content://")) {
                ctx.contentResolver.update(
                    android.net.Uri.parse(uri),
                    ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, newName) }, null, null
                )
            }
        } catch (_: Exception) { }
    }
}
