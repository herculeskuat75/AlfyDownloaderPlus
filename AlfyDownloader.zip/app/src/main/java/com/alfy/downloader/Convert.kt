package com.alfy.downloader

import java.io.File

/** v1.9: konversi format aneh (ts, flv, mkv, avi, ...) ke MP4 memakai ffmpeg dari pustaka youtubedl-android. */
object Convert {
    private val odd = setOf("ts", "m2ts", "mts", "flv", "mkv", "avi", "mov", "3gp", "mpg", "mpeg", "wmv", "ogv", "f4v", "webm", "m4v")

    fun isOdd(url: String): Boolean = Resolver.extOf(url) in odd

    private fun ffmpegBin(): File? {
        val app = Repo.app
        val cands = ArrayList<File>()
        cands.add(File(app.applicationInfo.nativeLibraryDir, "libffmpeg.so"))
        try {
            File(app.noBackupFilesDir, "youtubedl-android").walkTopDown().maxDepth(7)
                .filter { it.isFile && (it.name == "libffmpeg.so" || it.name == "ffmpeg") }.forEach { cands.add(it) }
        } catch (e: Exception) { }
        return cands.firstOrNull { it.exists() && it.length() > 100_000 }
    }

    /** Mengembalikan file hasil (.mp4) atau file asli bila konversi gagal. */
    fun toMp4(src: File): File {
        try {
            val bin = ffmpegBin() ?: return src
            val out = File(src.parentFile, src.nameWithoutExtension + ".conv.mp4")
            val pb = ProcessBuilder(bin.path, "-y", "-i", src.path, "-c", "copy", "-movflags", "+faststart", out.path).redirectErrorStream(true)
            val libs = ArrayList<String>()
            libs.add(Repo.app.applicationInfo.nativeLibraryDir)
            try {
                File(Repo.app.noBackupFilesDir, "youtubedl-android").walkTopDown().maxDepth(7)
                    .filter { it.isDirectory && it.name == "lib" }.forEach { libs.add(it.path) }
            } catch (e: Exception) { }
            pb.environment()["LD_LIBRARY_PATH"] = libs.joinToString(":")
            val p = pb.start()
            p.inputStream.readBytes()
            val code = p.waitFor()
            if (code == 0 && out.exists() && out.length() > 1000) {
                val dest = File(src.parentFile, src.nameWithoutExtension.removeSuffix(".conv") + ".mp4")
                src.delete()
                if (dest.exists() && dest != out) dest.delete()
                out.renameTo(dest)
                return dest
            }
            out.delete()
        } catch (e: Throwable) { }
        return src
    }
}
