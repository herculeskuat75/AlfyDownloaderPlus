package com.alfy.downloader.model

data class DownloadItem(
    val id: Long,
    val title: String,
    val url: String,
    val quality: String = "Auto",
    val sizeBytes: Long = -1,
    val durationMs: Long = -1,
    val status: Status = Status.RESOLVING,
    val titleDerived: Boolean = false,
    /** Key of the matching Part 3 MediaCandidate (set when the item was detected/probed and can be downloaded). */
    val candKey: String? = null
) {
    enum class Status { RESOLVING, DIRECT_FILE, PAGE_LINK, NO_URL, FAILED }
}

data class ScanCandidate(val title: String, val url: String?)

data class ScanOutcome(val candidates: List<ScanCandidate>, val error: String? = null)
