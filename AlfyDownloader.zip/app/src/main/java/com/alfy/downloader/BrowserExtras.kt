package com.alfy.downloader

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** v1.14: pemblokir iklan Browser Alfy (pop-up/redirect + domain iklan). */
object AdBlock {
    private val DEFAULT = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com", "2mdn.net",
        "adnxs.com", "adsrvr.org", "adform.net", "criteo.com", "pubmatic.com", "rubiconproject.com", "openx.net",
        "smartadserver.com", "yieldmo.com", "moatads.com", "amazon-adsystem.com", "zedo.com",
        "taboola.com", "outbrain.com", "revcontent.com", "mgid.com", "adskeeper.com",
        "popads.net", "popcash.net", "propellerads.com", "onclickads.net", "onclkds.com", "clickadu.com",
        "hilltopads.net", "adcash.com", "a-ads.com", "bidvertiser.com", "admaven.com", "ad-maven.com",
        "adsterra.com", "highperformanceformat.com", "popmyads.com", "trafficstars.com", "tsyndicate.com",
        "exoclick.com", "exosrv.com", "realsrv.com", "magsrv.com", "juicyads.com", "trafficjunky.com",
        "ero-advertising.com", "adspyglass.com", "acscdn.com", "adsco.re", "jads.co"
    )
    @Volatile private var cache: List<String>? = null
    @Volatile private var set: HashSet<String>? = null

    fun popupOn() = Repo.prefs().getBoolean("blockPopup", true)
    fun adOn() = Repo.prefs().getBoolean("blockAds", true)
    fun setPopup(v: Boolean) { Repo.prefs().edit().putBoolean("blockPopup", v).apply() }
    fun setAd(v: Boolean) { Repo.prefs().edit().putBoolean("blockAds", v).apply() }

    fun list(): List<String> = cache ?: run {
        val s = Repo.prefs().getString("adList", null)
        val l = if (s == null) DEFAULT else s.lines().map { host(it) }.filter { it.isNotEmpty() }.distinct()
        cache = l; set = l.toHashSet(); l
    }

    private fun host(s: String): String = Block.norm(s).substringBefore('/').substringBefore(':')

    private fun save(l: List<String>) {
        cache = l; set = l.toHashSet()
        Repo.prefs().edit().putString("adList", l.joinToString("\n")).apply()
    }
    fun add(s: String): Boolean {
        val h = host(s)
        if (h.length < 3 || !h.contains('.')) return false
        val l = list(); if (h !in l) save(l + h); return true
    }
    fun remove(s: String) { save(list().filter { it != s }) }
    fun reset() { cache = null; set = null; Repo.prefs().edit().remove("adList").apply() }

    fun isAd(url: String): Boolean {
        if (!adOn()) return false
        list()
        val hs = set ?: return false
        val h = (try { android.net.Uri.parse(url).host } catch (e: Exception) { null } ?: return false).lowercase()
        var x = h
        while (true) {
            if (x in hs) return true
            val i = x.indexOf('.')
            if (i < 0) return false
            x = x.substring(i + 1)
        }
    }
}


/** v1.15: blokir elemen halaman per situs (host). Aturan = pemilih CSS, disimpan di prefs sebagai JSON {host:[selector]}. */
object ElementBlock {
    private val main = Handler(Looper.getMainLooper())
    fun post(r: Runnable) { main.post(r) }

    private fun readAll(): JSONObject = try { JSONObject(Repo.prefs().getString("elemRules", null) ?: "{}") } catch (e: Exception) { JSONObject() }
    private fun writeAll(o: JSONObject) { Repo.prefs().edit().putString("elemRules", o.toString()).apply() }

    fun host(url: String?): String {
        val h = try { Uri.parse(url ?: "").host } catch (e: Exception) { null } ?: return ""
        return h.lowercase().removePrefix("www.")
    }

    @Synchronized fun hosts(): List<String> {
        val o = readAll(); val out = ArrayList<String>()
        val it = o.keys()
        while (it.hasNext()) { val k = it.next(); if ((o.optJSONArray(k)?.length() ?: 0) > 0) out.add(k) }
        out.sort(); return out
    }
    @Synchronized fun rules(host: String): List<String> {
        val a = readAll().optJSONArray(host) ?: return emptyList()
        val out = ArrayList<String>()
        for (i in 0 until a.length()) { val v = a.optString(i); if (v.isNotBlank()) out.add(v) }
        return out
    }
    @Synchronized fun add(host: String, sel: String): Boolean {
        if (host.isEmpty() || sel.isBlank()) return false
        val l = rules(host)
        if (sel in l) return true
        val o = readAll(); val a = JSONArray(); l.forEach { a.put(it) }; a.put(sel)
        o.put(host, a); writeAll(o); return true
    }
    @Synchronized fun remove(host: String, sel: String) {
        val o = readAll(); val a = JSONArray()
        rules(host).filter { it != sel }.forEach { a.put(it) }
        if (a.length() == 0) o.remove(host) else o.put(host, a)
        writeAll(o)
    }
    @Synchronized fun removeHost(host: String) { val o = readAll(); o.remove(host); writeAll(o) }

    private fun offSet(): Set<String> = HashSet(Repo.prefs().getStringSet("elemOff", emptySet()) ?: emptySet())
    fun isOn(host: String): Boolean = host !in offSet()
    fun setOn(host: String, on: Boolean) {
        if (host.isEmpty()) return
        val s = HashSet(offSet()); if (on) s.remove(host) else s.add(host)
        Repo.prefs().edit().putStringSet("elemOff", s).apply()
    }

    private const val OFF = "window.__alfyOff&&window.__alfyOff();"

    // Menerapkan aturan: <style> display:none + MutationObserver (elemen yang muncul belakangan ikut disembunyikan).
    private const val PRELUDE = """(function(){
if(window.__alfyOff)window.__alfyOff();
window.__alfyApply=function(sels){
 if(!document.documentElement)return;
 window.__alfyRules=sels;
 function ensure(){
  var c=window.__alfyRules.map(function(s){return s+'{display:none!important}'}).join('\n');
  var st=document.getElementById('__alfy_style');
  if(!st){st=document.createElement('style');st.id='__alfy_style';(document.head||document.documentElement).appendChild(st);}
  if(st.textContent!==c)st.textContent=c;
 }
 function hide(){
  window.__alfyRules.forEach(function(s){
   try{[].forEach.call(document.querySelectorAll(s),function(e){e.setAttribute('data-alfy-h','1');e.style.setProperty('display','none','important');});}catch(x){}
  });
 }
 ensure();hide();
 if(!window.__alfyMO){
  var t=null;
  window.__alfyMO=new MutationObserver(function(){
   if(t)return;
   t=setTimeout(function(){t=null;ensure();hide();},100);
  });
  window.__alfyMO.observe(document.documentElement,{childList:true,subtree:true});
 }
};
window.__alfyOff=function(){
 try{if(window.__alfyMO){window.__alfyMO.disconnect();window.__alfyMO=null;}}catch(x){}
 try{var st=document.getElementById('__alfy_style');if(st)st.remove();}catch(x){}
 try{[].forEach.call(document.querySelectorAll('[data-alfy-h]'),function(e){e.style.removeProperty('display');e.removeAttribute('data-alfy-h');});}catch(x){}
 window.__alfyRules=[];
};
})();"""

    // Mode pilih: sentuhan tidak membuka tautan, hanya menyorot elemen lalu melaporkan pemilih CSS ke Kotlin (AlfyBlock.onPick).
    private const val PICK = """(function(){
if(window.__alfyPickStop)window.__alfyPickStop();
var hl=document.createElement('div');hl.id='__alfy_hl';
hl.style.cssText='position:fixed;z-index:2147483647;pointer-events:none;border:2px solid #ff5252;background:rgba(255,82,82,.25);display:none;box-sizing:border-box';
document.documentElement.appendChild(hl);
var moved=false;
function sel(el){
 if(el.id){var s='#'+CSS.escape(el.id);try{if(document.querySelectorAll(s).length===1)return s;}catch(e){}}
 var parts=[],cur=el;
 while(cur&&cur.nodeType===1&&cur!==document.documentElement){
  var p=cur.tagName.toLowerCase();
  if(cur===document.body){parts.unshift('body');break;}
  if(cur.id){var s2='#'+CSS.escape(cur.id);try{if(document.querySelectorAll(s2).length===1){parts.unshift(s2);break;}}catch(e){}}
  var cl=[].slice.call(cur.classList).filter(function(c){return c.length<40&&/^[A-Za-z_]/.test(c)&&c.replace(/[A-Za-z0-9_-]/g,'')==='';}).slice(0,2);
  if(cl.length)p+='.'+cl.join('.');
  var par=cur.parentElement;
  if(par){
   var same=[].filter.call(par.children,function(c){try{return c.matches(p);}catch(e){return false;}});
   if(same.length>1)p+=':nth-child('+([].indexOf.call(par.children,cur)+1)+')';
  }
  parts.unshift(p);
  var cand=parts.join(' > ');
  try{if(document.querySelectorAll(cand).length===1)return cand;}catch(e){}
  cur=par;
 }
 return parts.join(' > ');
}
function at(e){var t=(e.changedTouches&&e.changedTouches[0])||e;return document.elementFromPoint(t.clientX,t.clientY);}
function pick(e){
 var el=at(e);
 if(!el||el===hl||el===document.body||el===document.documentElement)return;
 var r=el.getBoundingClientRect();
 hl.style.display='block';hl.style.left=r.left+'px';hl.style.top=r.top+'px';hl.style.width=r.width+'px';hl.style.height=r.height+'px';
 try{AlfyBlock.onPick(sel(el),el.tagName.toLowerCase());}catch(x){}
}
function eat(e){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();}
var H={
 touchstart:function(){moved=false;},
 touchmove:function(){moved=true;},
 touchend:function(e){if(moved)return;eat(e);pick(e);},
 click:function(e){eat(e);if(e.pointerType==='mouse'||!('ontouchstart' in window))pick(e);},
 mousedown:function(e){e.stopPropagation();},
 mouseup:function(e){e.stopPropagation();},
 pointerdown:function(e){e.stopPropagation();},
 pointerup:function(e){e.stopPropagation();},
 contextmenu:function(e){eat(e);}
};
var o={capture:true,passive:false};
Object.keys(H).forEach(function(k){document.addEventListener(k,H[k],o);});
window.__alfyPickStop=function(){
 Object.keys(H).forEach(function(k){document.removeEventListener(k,H[k],o);});
 if(hl.parentNode)hl.parentNode.removeChild(hl);
 window.__alfyPickStop=null;
};
})();"""

    /** Terapkan aturan situs ini ke halaman. force=true: juga membersihkan bila tidak ada aturan / sakelar mati. Panggil di thread utama. */
    fun apply(w: WebView, url: String?, force: Boolean = false) {
        val h = host(url); if (h.isEmpty()) return
        val l = if (isOn(h)) rules(h) else emptyList()
        if (l.isEmpty() && !force) return
        val js = if (l.isEmpty()) OFF else PRELUDE + "window.__alfyApply(" + JSONArray(l).toString() + ");"
        try { w.evaluateJavascript(js, null) } catch (e: Exception) { }
    }
    fun startPick(w: WebView) { try { w.evaluateJavascript(PICK, null) } catch (e: Exception) { } }
    fun stopPick(w: WebView) { try { w.evaluateJavascript("window.__alfyPickStop&&window.__alfyPickStop();", null) } catch (e: Exception) { } }
}

/** Jembatan JS -> Kotlin untuk mode pilih elemen (satu per tab). */
class PickBridge(private val t: BrowserTab) {
    @JavascriptInterface fun onPick(sel: String?, tag: String?) {
        if (sel.isNullOrBlank() || sel.length > 600) return
        ElementBlock.post(Runnable {
            if (BrowserTabs.pickTab === t) { t.pendingSel = sel; BrowserTabs.ui?.pickUpdate() }
        })
    }
}

class PageItem(val title: String, val url: String, val time: Long)

/** v1.14: history & bookmark Browser Alfy, disimpan sebagai file JSON di filesDir (sama seperti downloads.json). */
object BrowserData {
    private val hist = mutableListOf<PageItem>()   // terbaru di indeks 0
    private val bms = mutableListOf<PageItem>()
    private var loaded = false
    private val io = Executors.newSingleThreadExecutor()
    private fun hFile() = File(Repo.app.filesDir, "history.json")
    private fun bFile() = File(Repo.app.filesDir, "bookmarks.json")

    @Synchronized private fun load() {
        if (loaded) return
        loaded = true
        read(hFile(), hist); read(bFile(), bms)
    }

    private fun read(f: File, out: MutableList<PageItem>) {
        try {
            if (!f.exists()) return
            val a = JSONArray(f.readText())
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(PageItem(o.optString("t"), o.optString("u"), o.optLong("w")))
            }
        } catch (e: Exception) { }
    }

    private fun write(f: File, l: List<PageItem>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("t", it.title).put("u", it.url).put("w", it.time)) }
        val s = a.toString()
        io.execute { try { f.writeText(s) } catch (e: Exception) { } }
    }

    @Synchronized fun addHistory(title: String?, url: String?) {
        if (url.isNullOrBlank() || !(url.startsWith("http://") || url.startsWith("https://"))) return
        load()
        val now = System.currentTimeMillis()
        val top = hist.firstOrNull()
        if (top != null && top.url == url && now - top.time < 30000) return
        hist.add(0, PageItem(if (title.isNullOrBlank()) url else title, url, now))
        while (hist.size > 1000) hist.removeAt(hist.size - 1)
        write(hFile(), hist)
    }
    @Synchronized fun history(): List<PageItem> { load(); return hist.toList() }
    @Synchronized fun removeHistory(p: PageItem) { load(); hist.remove(p); write(hFile(), hist) }
    @Synchronized fun clearHistory() { load(); hist.clear(); write(hFile(), hist) }

    @Synchronized fun bookmarks(): List<PageItem> { load(); return bms.toList() }
    @Synchronized fun isBookmarked(url: String?): Boolean { load(); return url != null && bms.any { it.url == url } }
    /** @return true bila baru disimpan, false bila sudah ada / URL tidak valid */
    @Synchronized fun addBookmark(title: String?, url: String?): Boolean {
        if (url.isNullOrBlank() || !(url.startsWith("http://") || url.startsWith("https://"))) return false
        load()
        if (bms.any { it.url == url }) return false
        bms.add(0, PageItem(if (title.isNullOrBlank()) url else title, url, System.currentTimeMillis()))
        write(bFile(), bms)
        return true
    }
    @Synchronized fun removeBookmark(p: PageItem) { load(); bms.remove(p); write(bFile(), bms) }
}

/** v1.14: layar History, Bookmark, dan pengaturan blokir iklan (mode: history | bookmark | adblock). */
class BrowserDataActivity : Activity() {
    private lateinit var listBox: LinearLayout
    private lateinit var mode: String
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private val fmt = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault())

    private fun tv(t: String, sp: Float, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sp; setTextColor(c) }
    private fun action(t: String, onClick: () -> Unit) = tv(t, 13f, 0xFF80CBC4.toInt()).apply {
        setTypeface(null, android.graphics.Typeface.BOLD); setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { onClick() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        mode = intent.getStringExtra("mode") ?: "history"
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF212121.toInt()); setPadding(dp(16), dp(14), dp(16), dp(10)) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = when (mode) { "bookmark" -> "★ Bookmark"; "adblock" -> "🛡 Blokir iklan & pop-up"; "elemblock" -> "🧱 Aturan blokir elemen"; else -> "🕘 History" }
        head.addView(tv(title, 18f).apply { setTypeface(null, android.graphics.Typeface.BOLD) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (mode == "history") head.addView(action("HAPUS SEMUA") {
            android.app.AlertDialog.Builder(this).setMessage("Hapus semua history?")
                .setPositiveButton("Hapus") { _, _ -> BrowserData.clearHistory(); render() }.setNegativeButton("Batal", null).show()
        })
        head.addView(action("TUTUP") { finish() })
        root.addView(head)
        if (mode == "elemblock") {
            val cur = intent.getStringExtra("host") ?: ""
            if (cur.isNotEmpty()) root.addView(Switch(this).apply {
                text = "Blokir elemen di situs ini ($cur)"; isChecked = ElementBlock.isOn(cur); setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(8))
                setOnCheckedChangeListener { _, v -> ElementBlock.setOn(cur, v); render() }
            })
        }
        if (mode == "adblock") {
            fun sw(t: String, on: Boolean, set: (Boolean) -> Unit) = Switch(this).apply {
                text = t; isChecked = on; setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(8))
                setOnCheckedChangeListener { _, v -> set(v) }
            }
            root.addView(sw("Blokir pop-up & redirect otomatis", AdBlock.popupOn()) { AdBlock.setPopup(it) })
            root.addView(sw("Blokir domain iklan", AdBlock.adOn()) { AdBlock.setAd(it) })
            root.addView(tv("Daftar domain iklan (subdomain ikut diblokir):", 12f, 0xFFBDBDBD.toInt()).apply { setPadding(0, dp(8), 0, dp(4)) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val et = EditText(this).apply {
                hint = "contoh: iklan.com"; setHintTextColor(0xFF888888.toInt()); setTextColor(Color.WHITE); textSize = 14f
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI; setSingleLine(true)
            }
            fun doAdd() {
                if (et.text.isBlank()) return
                if (AdBlock.add(et.text.toString())) { et.setText(""); render() } else Toast.makeText(this, "Isi nama domain, mis. iklan.com", Toast.LENGTH_SHORT).show()
            }
            et.setOnEditorActionListener { _, _, _ -> doAdd(); true }
            row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(action("TAMBAH") { doAdd() })
            row.addView(action("RESET") { AdBlock.reset(); render() })
            root.addView(row)
        }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(listBox); setPadding(0, dp(8), 0, dp(8)) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        render()
    }

    private fun open(url: String) { setResult(RESULT_OK, Intent().putExtra("url", url)); finish() }

    private fun render() {
        listBox.removeAllViews()
        if (mode == "elemblock") {
            val hs = ElementBlock.hosts()
            if (hs.isEmpty()) listBox.addView(tv("Belum ada aturan blokir elemen. Pakai menu ⋮ → Blokir elemen.", 13f, 0xFFBDBDBD.toInt()))
            hs.forEach { h ->
                val hr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, 0) }
                hr.addView(tv(h + if (ElementBlock.isOn(h)) "" else " (mati)", 15f, 0xFF80CBC4.toInt()).apply { setTypeface(null, android.graphics.Typeface.BOLD) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                hr.addView(action("HAPUS SITUS") {
                    android.app.AlertDialog.Builder(this).setMessage("Hapus semua aturan untuk $h?")
                        .setPositiveButton("Hapus") { _, _ -> ElementBlock.removeHost(h); render() }.setNegativeButton("Batal", null).show()
                })
                listBox.addView(hr)
                ElementBlock.rules(h).forEach { sl ->
                    val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    r.addView(tv(sl, 12f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                    r.addView(tv("✕", 18f, 0xFFEF9A9A.toInt()).apply { setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { ElementBlock.remove(h, sl); render() } })
                    listBox.addView(r)
                }
            }
            return
        }
        if (mode == "adblock") {
            AdBlock.list().forEach { d ->
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                r.addView(tv(d, 14f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                r.addView(tv("✕", 18f, 0xFFEF9A9A.toInt()).apply { setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { AdBlock.remove(d); render() } })
                listBox.addView(r)
            }
            return
        }
        val items = if (mode == "bookmark") BrowserData.bookmarks() else BrowserData.history()
        if (items.isEmpty()) listBox.addView(tv(if (mode == "bookmark") "Belum ada bookmark." else "History kosong.", 13f, 0xFFBDBDBD.toInt()))
        items.forEach { p ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setOnClickListener { open(p.url) } }
            col.addView(tv(p.title, 15f).apply { setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END })
            col.addView(tv(p.url, 11f, 0xFF80CBC4.toInt()).apply { setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END })
            if (mode == "history") col.addView(tv(fmt.format(Date(p.time)), 11f, 0xFF9E9E9E.toInt()))
            r.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(tv("✕", 18f, 0xFFEF9A9A.toInt()).apply {
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setOnClickListener { if (mode == "bookmark") BrowserData.removeBookmark(p) else BrowserData.removeHistory(p); render() }
            })
            listBox.addView(r)
        }
    }
}
