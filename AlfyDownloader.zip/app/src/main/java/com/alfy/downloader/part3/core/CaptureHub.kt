package com.alfy.downloader.part3.core

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import com.alfy.downloader.part3.scan.ForegroundWatcher
import com.alfy.downloader.part3.scan.MediaSessionResolver
import com.alfy.downloader.part3.ytdlp.YtDlpResolver
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.Request
import java.util.concurrent.ConcurrentHashMap

/**
 * Single entry point for EVERY capture method (clipboard, browser, OCR, share, network sniffer).
 * Part 1/2 detectors should call CaptureHub.submit(...) / submitText(...).
 */
object CaptureHub {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val gate = Semaphore(3)
    private val _candidates = MutableStateFlow<List<MediaCandidate>>(emptyList())
    val candidates: StateFlow<List<MediaCandidate>> = _candidates.asStateFlow()
    private val _pending = MutableStateFlow(0)
    /** Value for the red badge on the floating menu. */
    val pendingCount: StateFlow<Int> = _pending.asStateFlow()

    private val urlRegex = Regex("https?://[^\\s<>\"'`\\\\^{}|]+", RegexOption.IGNORE_CASE)
    private val pageTtl = ConcurrentHashMap<String, Long>()

    private val _hints = MutableSharedFlow<String>(extraBufferCapacity = 4)
    /** Short user-facing messages (e.g. "YouTube stream detected"). */
    val hints: SharedFlow<String> = _hints.asSharedFlow()
    fun hint(msg: String) { _hints.tryEmit(msg) }

    private val _fallback = MutableSharedFlow<String>(extraBufferCapacity = 4)
    /** Emitted when an encrypted (HTTPS/SNI-only) stream is seen: UI should offer Paste / Screen Scan right away. */
    val fallbackRequests: SharedFlow<String> = _fallback.asSharedFlow()

    /**
     * Encrypted streams (YouTube etc.) cannot be read raw. Root mode tries to identify the playing media through
     * the system media session + yt-dlp; in every mode the UI is asked to offer paste / share / screen-scan ingestion.
     */
    fun onEncryptedStream(label: String) {
        if (throttled) return
        _fallback.tryEmit(label)
        MediaSessionResolver.onEncryptedStream(label)
    }

    fun addResolved(list: List<MediaCandidate>) {
        if (list.isEmpty()) return
        _candidates.update { cur ->
            var l = cur
            list.forEach { c -> if (l.none { it.key == c.key }) l = addWithPriority(l, c) }
            l
        }
        _pending.value = _candidates.value.size
    }

    /** Battery saver: while true (screen off) every capture entry point is ignored. */
    @Volatile var throttled: Boolean = false
        private set
    fun setThrottled(v: Boolean) { throttled = v }

    fun init(ctx: Context) = UrlRegistry.init(ctx)

    fun submitText(text: String?, source: Source, referer: String? = null): Int {
        if (text.isNullOrBlank()) return 0
        var n = 0
        urlRegex.findAll(text).forEach { if (submit(it.value, source, referer)) n++ }
        return n
    }

    fun submit(
        raw: String?, source: Source, referer: String? = null,
        userAgent: String? = null, titleHint: String? = null, forceMedia: Boolean = false
    ): Boolean {
        if (throttled) return false
        val valid = UrlRegistry.validate(raw) ?: return false
        val url = AppHeuristics.normalize(valid)
        val verdict = AppHeuristics.accept(ForegroundWatcher.current, url)
        if (verdict == false) return false
        var kind = UrlKind.kind(url)
        val userIntent = source != Source.NETWORK
        if (verdict == true || forceMedia) kind = UrlKind.Kind.MEDIA
        // Clipboard / share / OCR / manual links: ANY http(s) page is handed to yt-dlp (universal extraction).
        if (kind == UrlKind.Kind.OTHER) {
            if (!userIntent) return false
            kind = UrlKind.Kind.PAGE
        }
        if (source == Source.NETWORK && UrlKind.isSegment(url)) return false
        val key = UrlRegistry.keyOf(url)
        if (UrlRegistry.debounce(key)) return false
        if (!UrlRegistry.tryClaim(key)) return false
        launchProcess(url, key, kind, source, referer, userAgent, titleHint)
        return true
    }

    /** Re-scan a homepage periodically without permanently claiming it (new videos appear over time). */
    fun prefetchPage(raw: String?, source: Source, ttlMs: Long = 30 * 60_000L) {
        if (throttled) return
        val url = UrlRegistry.validate(raw) ?: return
        if (UrlKind.kind(url) != UrlKind.Kind.PAGE) return
        val now = System.currentTimeMillis()
        val last = pageTtl[url]
        if (last != null && now - last < ttlMs) return
        pageTtl[url] = now
        if (pageTtl.size > 500) pageTtl.clear()
        launchProcess(url, UrlRegistry.keyOf(url), UrlKind.Kind.PAGE, source, null, null, null, claimed = false)
    }

    fun remove(key: String) {
        _candidates.update { l -> l.filterNot { it.key == key } }
        _pending.value = _candidates.value.size
    }

    fun clearCandidates() { _candidates.value = emptyList(); _pending.value = 0 }

    private fun launchProcess(
        url: String, key: String, kind: UrlKind.Kind, source: Source,
        referer: String?, ua: String?, titleHint: String?, claimed: Boolean = true
    ) {
        scope.launch {
            try {
                gate.withPermit {
                    if (kind == UrlKind.Kind.PAGE) processPage(url, if (claimed) key else null, source, referer, ua)
                    else processMedia(url, key, source, referer, ua, titleHint)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                // never crash the host app because of a bad candidate
            }
        }
    }

    private suspend fun processPage(url: String, claimKey: String?, source: Source, referer: String?, ua: String?) {
        // 1) yt-dlp first for anything the user hands us (paste / share / OCR / manual / browser).
        if (source != Source.NETWORK && claimKey != null) {
            when (val r = YtDlpResolver.resolve(url, claimKey, source, referer, ua)) {
                is YtDlpResolver.Result.Ok -> { addResolved(r.candidates); return }
                is YtDlpResolver.Result.Fail -> {
                    // 2) lightweight fallback: og:video / <video> / JSON-LD / raw media URLs in the HTML.
                    val meta = MetadataPrefetcher.fetch(url, referer)
                    if (meta.mediaUrls.isNotEmpty()) {
                        meta.mediaUrls.forEach { m -> submit(m, source, url, ua, meta.title) }
                    } else {
                        UrlRegistry.release(claimKey) // let the user retry the same link later
                        hint("yt-dlp: ${r.reason}")
                    }
                    return
                }
            }
        }
        val meta = MetadataPrefetcher.fetch(url, referer)
        meta.mediaUrls.forEach { m -> submit(m, source, url, ua, meta.title) }
    }

    private suspend fun processMedia(
        url: String, key: String, source: Source, referer: String?, uaIn: String?, titleHint: String?
    ) {
        val ua = uaIn ?: Http.UA
        val hdr = Http.headersFor(ua, referer)
        val hls = url.contains(".m3u8", true)
        var program = -1
        var fw = 0
        var fh = 0
        if (hls) {
            when (val sel = HlsMaster.select(url, hdr)) {
                is HlsMaster.Selection.Picked -> { program = sel.program; fw = sel.width; fh = sel.height }
                HlsMaster.Selection.Media -> Unit
                HlsMaster.Selection.OutOfRange, HlsMaster.Selection.Failed -> return
            }
        }
        val p = MediaProbe.probe(url, hdr, hls)
        val category = QualityFilter.decide(p, fw, fh) ?: return
        val urlExt = UrlKind.extOf(url)
        val ext = when {
            hls -> "mp4"
            UrlKind.isMediaExt(urlExt) -> urlExt
            category == Category.MUSIC -> "m4a"
            else -> "mp4"
        }
        var size = p.sizeBytes
        if (size <= 0 && !hls) size = headSize(url, hdr)
        val cand = MediaCandidate(
            url = url, key = key,
            title = titleHint?.takeIf { it.isNotBlank() } ?: UrlKind.nameOf(url),
            category = category, referer = referer, userAgent = ua,
            width = if (fw > 0) fw else p.width, height = if (fh > 0) fh else p.height,
            durationSec = p.durationSec, sizeBytes = size, isHls = hls, hlsProgram = program,
            ext = ext, source = source
        )
        _candidates.update { l -> addWithPriority(l, cand) }
        _pending.value = _candidates.value.size
    }

    private fun stemOf(url: String) = url.substringBefore('?').substringBeforeLast('.')

    /** Audio: when both an M4A and an MP3 of the same file are found, M4A wins. */
    private fun addWithPriority(list: List<MediaCandidate>, c: MediaCandidate): List<MediaCandidate> {
        if (c.category != Category.MUSIC || (c.ext != "m4a" && c.ext != "mp3")) return list + c
        val stem = stemOf(c.url)
        val twin = list.firstOrNull {
            it.category == Category.MUSIC && it.ext != c.ext && (it.ext == "m4a" || it.ext == "mp3") && stemOf(it.url) == stem
        } ?: return list + c
        return if (c.ext == "m4a" && twin.ext == "mp3") list.filter { it.key != twin.key } + c else list
    }

    private fun headSize(url: String, hdr: Map<String, String>): Long = try {
        val rb = Request.Builder().url(url).head()
        hdr.forEach { (k, v) -> rb.header(k, v) }
        Http.client.newCall(rb.build()).execute().use {
            if (it.isSuccessful) it.header("Content-Length")?.toLongOrNull() ?: -1L else -1L
        }
    } catch (e: Exception) { -1L }
}
