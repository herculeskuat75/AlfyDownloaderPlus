package com.alfy.downloader.extras

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import org.jsoup.Jsoup

/** Pencari kandidat link media dari HTML (Jsoup) dan JSON (kotlinx.serialization). Hasilnya hanya kandidat; uji tetap lewat Resolver. */
object LinkExtract {
    private val mediaRe = Regex("(?i)\\.(?:mp4|m3u8|mpd|webm|m4a|mp3|flv|mov)(?:[?#&]|$)|videoplayback|mime=(?:video|audio)")

    fun fromHtml(html: String, baseUrl: String): List<String> {
        val out = LinkedHashSet<String>()
        try {
            val doc = Jsoup.parse(html, baseUrl)
            for (e in doc.select("video[src], source[src], audio[src], iframe[src]")) {
                val u = e.absUrl("src")
                if (u.startsWith("http")) out.add(u)
            }
            for (e in doc.select("meta[property^=og:video], meta[property^=og:audio], meta[name=twitter:player:stream]")) {
                val u = e.attr("content")
                if (u.startsWith("http")) out.add(u)
            }
        } catch (e: Throwable) { }
        return out.toList()
    }

    fun fromJson(json: String): List<String> {
        val out = LinkedHashSet<String>()
        try { walk(Json.parseToJsonElement(json), out) } catch (e: Throwable) { }
        return out.toList()
    }

    private fun walk(el: JsonElement, out: MutableSet<String>) {
        when (el) {
            is JsonObject -> for (v in el.values) walk(v, out)
            is JsonArray -> for (v in el) walk(v, out)
            is JsonPrimitive -> if (el.isString) {
                val s = el.content
                if (s.startsWith("http") && mediaRe.containsMatchIn(s)) out.add(s)
            }
        }
    }
}
