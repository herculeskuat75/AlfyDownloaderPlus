package com.alfy.downloader

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Status 4 tingkat per tool (SCAN/OK/GAGAL/NONAKTIF), teks Indonesia sederhana, laporan detail, dan scan ulang manual. */
object ToolStatus {
    enum class St { SCAN, OK, FAIL, OFF }

    const val TXT_OK = "Video/musik ditemukan"
    const val TXT_FAIL = "Tidak bisa mendapatkan video/musik pada situs ini"

    private val hist = ConcurrentHashMap<String, java.util.LinkedList<String>>()
    @Volatile private var lastRescanAt = 0L

    private fun now(): String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())

    /** Dicatat dari ToolLog.set/side (hanya saat tool benar-benar berjalan). */
    fun note(tool: String, s: String) {
        try {
            val q = hist.getOrPut(tool) { java.util.LinkedList() }
            synchronized(q) {
                if (q.peekLast()?.endsWith(" | $s") == true) return
                q.add(now() + " | " + s)
                while (q.size > 40) q.removeFirst()
            }
        } catch (e: Exception) { }
    }

    private fun noteAll(s: String) { for (n in ToolLog.chainAll + ToolLog.monAll) if (Tool.on(n)) note(n, s) }

    fun state(n: String): St {
        if (!Tool.on(n)) return St.OFF
        val s = ToolLog.statusOf(n)
        if (n in svcTools) return if (s.startsWith("✓")) St.OK else if (s.startsWith("•")) St.SCAN else St.FAIL
        return when {
            s.startsWith("✓") -> St.OK
            s.startsWith("⏳") -> St.SCAN
            s.startsWith("✗") -> St.FAIL
            s.contains("dimatikan") || s.contains("lewati") || s.startsWith("•") -> St.OFF
            else -> {
                val x = s.lowercase()
                if (s.startsWith("–") || listOf("gagal", "error", "mati", "berhenti", "belum", "tidak").any { it in x }) St.FAIL
                else if ("memuat" in x || "menunggu" in x || "memindai" in x) St.SCAN
                else St.OFF
            }
        }
    }

    /** Teks jujur untuk tool yang di-skip (Early Exit): bukan "memindai"/"siaga". */
    fun skipText(s: String): String = if (s.contains("tier")) "Diabaikan (Tier bawah)" else "Di-skip (Sudah dapat link)"

    private fun offText(n: String): String {
        if (!Tool.on(n)) return if (Tool.excludedByProfile(n)) "Nonaktif (Bukan Profil)" else "Nonaktif"
        val s = ToolLog.statusOf(n)
        return when {
            s.contains("dimatikan") -> "Nonaktif"
            s.contains("lewati") -> skipText(s)
            s.startsWith("•") -> "Menunggu"
            else -> "Nonaktif"
        }
    }

    /** Kategori tool untuk log/laporan, mis. [Khusus X.com], [Khusus Vidlyx], [Khusus YouTube/IG], [Pembantu: Paste, FFmpeg]. */
    fun category(n: String): String = when (n) {
        "fxtwitter", "Syndication" -> "[Khusus X.com]"
        "JWPlayer" -> "[Khusus Vidlyx]"
        "yt-dlp", "yt-dlp+cookies", "NewPipe", "ytFast", "Piped/Invidious", "InnerTube" -> "[Khusus YouTube/IG]"
        "WebView", "WebView Pro", "HTML", "OpenGraph", "Iframe", "Redirect", "HLS Sniffer", "Advanced HLS" -> "[Umum: Situs Web]"
        "xGetter" -> "[Cadangan Tier 3: Situs Sulit]"
        "Clipboard root" -> "[Pembantu: Paste]"
        "ffmpeg" -> "[Pembantu: FFmpeg]"
        "Logcat root", "tcpdump", "Media session", "Notifikasi", "Aksesibilitas", "Hook pemutar", "Dexterceptor" -> "[Pembantu: Pemantau Sistem]"
        else -> "[Umum]"
    }

    /** Teks status ramah. [spin] = penanda untuk status SCAN (di panel berupa ◐◓◑◒, di dialog kosong karena ada ProgressBar). */
    private val svcTools = setOf("Aksesibilitas", "ffmpeg")
    fun label(n: String, spin: String = ""): String = if (n in svcTools && Tool.on(n)) when (state(n)) {
        St.OK -> "✓ Aktif"
        St.SCAN -> "• Memuat…"
        else -> "✗ Tidak aktif"
    } else when (state(n)) {
        St.SCAN -> (if (spin.isEmpty()) "" else "$spin ") + "Sedang scan…"
        St.OK -> "✓ $TXT_OK"
        St.FAIL -> "✗ $TXT_FAIL"
        St.OFF -> "– " + offText(n)
    }

    fun color(s: St): Int = when (s) {
        St.OK -> 0xFFA5D6A7.toInt()
        St.FAIL -> 0xFFEF5350.toInt()
        St.SCAN -> 0xFFFFE082.toInt()
        St.OFF -> 0xFF9E9E9E.toInt()
    }

    fun panelLines(): List<String> {
        val fr = "◐◓◑◒"[((System.currentTimeMillis() / 1000) % 4).toInt()].toString()
        return (ToolLog.chainAll + ToolLog.monAll).mapIndexed { i, n -> "${i + 1}. $n ${category(n)}  " + label(n, fr) }
    }

    /** v1.59: log kolaborasi antar tool, mis. "yt-dlp Berhasil via Paste", "NewPipe Menunggu Play". */
    fun collabLines(max: Int = 6): List<String> {
        val via = ToolLog.via
        val ok = ArrayList<String>(); val wait = ArrayList<String>(); val fail = ArrayList<String>()
        for (n in ToolLog.chainAll) {
            if (!Tool.on(n)) continue
            val s = ToolLog.statusOf(n)
            when (state(n)) {
                St.OK -> ok.add(if (n == ToolLog.winner) 0 else ok.size, "$n Berhasil via " + via.ifEmpty { "Scan" })
                St.SCAN -> if (s.contains("menunggu giliran") || s.contains("berjalan")) wait.add("$n Menunggu " + (if (via.isEmpty()) "Play" else "hasil ($via)"))
                St.FAIL -> { val h = ScanReport.hintFor(n); fail.add("$n Gagal" + (if (h != null) " → " + h.solution else "")) }
                else -> {}
            }
        }
        return (ok + wait + fail).take(max)
    }

    // ---------- laporan detail ----------
    /** Riwayat langkah satu tool (untuk laporan AI). */
    fun history(n: String): List<String> {
        val q = hist[n] ?: return emptyList()
        return synchronized(q) { q.toList() }
    }

    /** v1.50: laporan satu tool disusun oleh ScanReport.build (prompt lengkap untuk AI + konteks + semua tool). */
    fun detail(ctx: Context, n: String): String = ScanReport.build(false, n)

    fun copyDetail(ctx: Context, n: String) {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("laporan $n", detail(ctx, n)))
            Toast.makeText(ctx, "Laporan $n (untuk AI) disalin", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, "Gagal menyalin laporan", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- scan ulang manual (hanya saat ditekan; tidak menyalakan scan otomatis, tidak mengubah mode) ----------
    fun rescanOnce(ctx: Context) {
        val t = System.currentTimeMillis()
        if (t - lastRescanAt < 4000L) { Toast.makeText(ctx, "Scan ulang masih berjalan…", Toast.LENGTH_SHORT).show(); return }
        lastRescanAt = t
        val pages = listOf(Resolver.lastPage, Resolver.mainPage).filter { it.startsWith("http") }.distinct().ifEmpty { listOfNotNull(AutoScan.tabPage()) }   // v1.134: fallback tab Browser Alfy
        noteAll("Scan ulang manual ditekan; halaman: " + pages.joinToString().ifEmpty { "-" })
        val acc = AlfyAccessibilityService.inst
        try { acc?.scanNow() } catch (e: Exception) { }
        for (pg in pages) {
            try { Resolver.rescan(pg, null, "Manual 🔄 scan ulang"); Resolver.sniff(pg, true) } catch (e: Exception) { }
        }
        Toast.makeText(ctx, if (pages.isEmpty() && acc == null) "Tidak ada situs terbuka. Buka situs atau aktifkan aksesibilitas (📖)" else "Memindai ulang…", Toast.LENGTH_SHORT).show()
    }
}
