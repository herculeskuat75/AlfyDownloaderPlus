package com.alfy.downloader.accessibility

import java.util.Locale

/**
 * Pure-Kotlin helpers (no Android classes, so they are easy to unit-test):
 *  - find an 11-char YouTube video ID inside any text / contentDescription,
 *  - clean a UI title and score how well a search result matches it.
 */
object YouTubeIdExtractor {

    private const val ID = "[A-Za-z0-9_-]{11}"
    private const val END = "(?![A-Za-z0-9_-])"

    // youtube.com/watch?v=ID (v= may not be the first param), /shorts/ID, /live/ID, /embed/ID, /v/ID, youtu.be/ID
    private val URL_RX = Regex(
        "(?:(?:https?://)?(?:[a-z0-9-]+\\.)?(?:youtube\\.com|youtube-nocookie\\.com)/" +
            "(?:watch\\?(?:[^\\s#\"'<>]*?[&;])?v=|shorts/|live/|embed/|v/)($ID)$END)" +
            "|(?:(?:https?://)?youtu\\.be/($ID)$END)",
        RegexOption.IGNORE_CASE
    )

    /** Returns the first video ID found in [text], or null. */
    fun findId(text: CharSequence?): String? {
        if (text.isNullOrEmpty() || text.length < 11) return null
        val m = URL_RX.find(text) ?: return null
        return m.groups[1]?.value ?: m.groups[2]?.value
    }

    fun watchUrl(id: String) = "https://www.youtube.com/watch?v=$id"

    // ───────────────────────── Title helpers ─────────────────────────

    private val SUFFIX_RX = Regex("""\s*[-–—|]\s*(YouTube( Music)?|Putar video|play video)\s*$""", RegexOption.IGNORE_CASE)
    private val DURATION_RX = Regex(
        """^\d+\s*(hours?|hrs?|jam|minutes?|mins?|menit|seconds?|secs?|detik)\b.*""",
        RegexOption.IGNORE_CASE
    )
    private val CHANNEL_MARK_RX = Regex(
        """^(go to channel|buka channel|lihat channel|kunjungi channel|\d[\d.,]*\s*[KMBjt]?\s*(views?|x ditonton|tayangan)).*""",
        RegexOption.IGNORE_CASE
    )

    /**
     * YouTube list / player nodes often describe a video as
     * "Title - 3 minutes, 20 seconds - Go to channel - Channel - 1.2M views - 2 years ago - play video".
     * Returns just the title part (everything before the first duration / "Go to channel" segment).
     */
    fun titleFromDescription(desc: String?): String? {
        if (desc.isNullOrBlank()) return null
        val parts = desc.split(" - ")
        val keep = ArrayList<String>()
        for (p in parts) {
            val t = p.trim()
            if (keep.isNotEmpty() && (DURATION_RX.matches(t) || CHANNEL_MARK_RX.matches(t))) break
            keep += t
        }
        return cleanTitle(keep.joinToString(" - "))
    }

    fun cleanTitle(raw: String?): String? {
        if (raw == null) return null
        var t = raw.replace(' ', ' ').trim()
        t = SUFFIX_RX.replace(t, "").trim().trimEnd('…', '.').trim()
        return t.takeIf { it.length in 3..300 }
    }

    private val TOKEN_RX = Regex("""[\p{L}\p{N}]+""")

    private fun tokens(s: String): Set<String> =
        TOKEN_RX.findAll(s.lowercase(Locale.ROOT)).map { it.value }.toSet()

    /**
     * 0..1 similarity between the title seen on screen and a search-result title. Handles titles that were
     * truncated with "…" by the UI (containment of the shorter token set counts almost like a full match).
     */
    fun similarity(seen: String, candidate: String): Double {
        val a = tokens(seen)
        val b = tokens(candidate)
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val inter = a.intersect(b).size.toDouble()
        val jaccard = inter / (a.size + b.size - inter)
        val small = minOf(a.size, b.size)
        val containment = if (small >= 3) inter / small * 0.95 else 0.0
        return maxOf(jaccard, containment)
    }

    fun sameChannel(a: String?, b: String?): Boolean {
        if (a.isNullOrBlank() || b.isNullOrBlank()) return false
        val x = tokens(a); val y = tokens(b)
        if (x.isEmpty() || y.isEmpty()) return false
        return x.containsAll(y) || y.containsAll(x)
    }
}
