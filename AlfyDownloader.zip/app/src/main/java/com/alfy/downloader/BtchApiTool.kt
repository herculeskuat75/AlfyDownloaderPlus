package com.alfy.downloader

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Tool cadangan Tier 3: btch-downloader API universal (TikTok, SnackVideo, Likee, Instagram, Facebook, Twitter/X, Pinterest). */
object BtchApiTool {
    private val BASE: String get() = AppPreferences.btchApiUrl

    private fun hostOf(page: String): String = try { android.net.Uri.parse(page).host?.lowercase() ?: "" } catch (e: Exception) { "" }

    /** Nama endpoint API untuk alamat ini, atau null bila situs tidak didukung. */
    private fun endpointOrNull(page: String): String? {
        val h = hostOf(page)
        return when {
            h.endsWith("tiktok.com") -> "tiktok"
            h.endsWith("snackvideo.com") -> "snackvideo"
            h.endsWith("likee.video") -> "likee"
            h.endsWith("instagram.com") || h.endsWith("instagr.am") -> "instagram"
            h.endsWith("facebook.com") || h.endsWith("fb.watch") || h.endsWith("fb.com") -> "facebook"
            h.endsWith("twitter.com") || h == "x.com" || h.endsWith(".x.com") -> "twitter"
            h.endsWith("pinterest.com") || h.contains(".pinterest.") || h.startsWith("pinterest.") || h.endsWith("pin.it") -> "pinterest"
            else -> null
        }
    }

    fun matches(page: String): Boolean = endpointOrNull(page) != null

    /** Nama platform untuk status/log. */
    fun platformOf(page: String): String = endpointOrNull(page) ?: "-"

    private fun httpGet(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "GET"; c.connectTimeout = 8000; c.readTimeout = 9000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            c.setRequestProperty("Accept", "application/json")
            val code = c.responseCode
            if (code >= 400) throw RuntimeException("HTTP $code")
            return c.inputStream.bufferedReader().readText()
        } finally { try { c.disconnect() } catch (e: Throwable) { } }
    }

    private val imgExt = setOf("jpg", "jpeg", "png", "webp", "gif")
    private val vidExt = setOf("mp4", "webm", "mov", "m4v", "mkv", "m3u8")
    private val audExt = setOf("mp3", "m4a", "aac", "ogg", "opus")
    private val thumbKey = Regex("thumb|cover|avatar|profile|icon|poster|preview|origin_cover|dynamic", RegexOption.IGNORE_CASE)
    private val audKey = Regex("audio|music|sound", RegexOption.IGNORE_CASE)
    private val vidKey = Regex("video|nowm|no_watermark|wmplay|play|hd|sd|normal|download|url|link|src", RegexOption.IGNORE_CASE)
    private val imgKey = Regex("image|img|photo|picture|pic", RegexOption.IGNORE_CASE)

    private class Found {
        val vids = LinkedHashMap<String, String>()   // url -> label
        val imgs = LinkedHashSet<String>()
        val auds = LinkedHashSet<String>()
        var thumb = ""
        var title = ""
        var dur = 0L
    }

    private fun clean(s: String) = s.replace("\\u0026", "&").replace("&amp;", "&").trim()

    private fun labelOf(key: String): String {
        val k = key.lowercase()
        return when {
            k.contains("hd") -> "HD"
            k.contains("sd") -> "SD"
            k.contains("nowm") || k.contains("no_watermark") -> "tanpa watermark"
            else -> "video"
        }
    }

    /** Telusuri seluruh JSON; kelompokkan link menjadi video / gambar / audio / thumbnail berdasarkan ekstensi dan nama kunci. */
    private fun collect(x: Any?, key: String, f: Found, depth: Int) {
        if (depth > 6) return
        when (x) {
            is org.json.JSONObject -> {
                if (f.title.isEmpty()) for (k in listOf("title", "desc", "description", "caption", "text")) {
                    val t = x.optString(k, ""); if (t.isNotBlank() && !t.startsWith("http")) { f.title = t.take(120); break }
                }
                if (f.dur == 0L) f.dur = x.optLong("duration", 0L).let { if (it > 100000) it / 1000 else it }
                val ks = x.keys()
                while (ks.hasNext()) { val k = ks.next(); collect(x.opt(k), k, f, depth + 1) }
            }
            is org.json.JSONArray -> for (i in 0 until minOf(x.length(), 40)) collect(x.opt(i), key, f, depth + 1)
            is String -> {
                val u = clean(x)
                if (!u.startsWith("http")) return
                val ext = Resolver.extOf(u)
                when {
                    thumbKey.containsMatchIn(key) -> { if (f.thumb.isEmpty() && (ext in imgExt || ext.isEmpty())) f.thumb = u }
                    ext in audExt || audKey.containsMatchIn(key) -> f.auds.add(u)
                    ext in vidExt -> f.vids.putIfAbsent(u, labelOf(key))
                    ext in imgExt || imgKey.containsMatchIn(key) -> f.imgs.add(u)
                    vidKey.containsMatchIn(key) -> f.vids.putIfAbsent(u, labelOf(key))
                }
            }
        }
    }

    /** null = berhasil, selain itu alasan gagal. */
    fun fetch(page: String): String? {
        val ep = endpointOrNull(page) ?: return "situs tidak didukung"
        return fetchEp(page, listOf(ep), "BTCH")
    }

    /** Dipakai juga oleh ModernApiTool: coba tiap endpoint berurutan sampai ada JSON berisi media. null = berhasil. */
    internal fun fetchEp(page: String, eps: List<String>, tag: String): String? {
        var err = "tanpa link video/gambar"
        var root: Any? = null
        val f = Found()
        for (ep in eps) {
            val api = BASE + ep + "?url=" + URLEncoder.encode(page, "UTF-8")
            val raw = try { httpGet(api).trim() } catch (e: Exception) { err = "API $ep: " + (e.message ?: "gagal").take(40); continue }
            val r: Any = try { if (raw.startsWith("[")) org.json.JSONArray(raw) else org.json.JSONObject(raw) } catch (e: Exception) { err = "API $ep: respons bukan JSON"; continue }
            if (r is org.json.JSONObject) {
                val em = r.optString("error", "").ifBlank { if (r.has("status") && !r.optBoolean("status", true)) r.optString("message", "API menolak") else "" }
                if (em.isNotBlank()) { err = "API $ep: " + em.take(50); continue }
            }
            collect(r, "", f, 0)
            if (f.vids.isNotEmpty() || f.imgs.isNotEmpty()) { root = r; break }
            err = "API $ep: tanpa link media"
        }
        if (root == null) return err
        val title = f.title.ifBlank { if (f.vids.isNotEmpty()) "Video" else "Gambar" }
        val out = ArrayList<Candidate>()
        for ((vu, lb) in f.vids.entries.take(6))
            out.add(Candidate(key = tag + vu.take(150), url = vu, title = title, kind = if (Resolver.extOf(vu) == "m3u8") Kind.HLS else Kind.DIRECT,
                isAudio = false, ext = if (Resolver.extOf(vu) == "m3u8") "mp4" else Resolver.extOf(vu).ifEmpty { "mp4" },
                size = -1, quality = lb, duration = f.dur, formatSel = null, previewUrl = vu, referer = page, img = f.thumb))
        if (f.vids.isEmpty()) for (iu in f.imgs.take(10))
            out.add(Candidate(key = tag + iu.take(150), url = iu, title = title, kind = Kind.DIRECT, isAudio = false,
                ext = Resolver.extOf(iu).ifEmpty { "jpg" }, size = -1, quality = "gambar", duration = 0, formatSel = null,
                previewUrl = iu, referer = page, img = iu))
        f.auds.firstOrNull()?.let { au ->
            out.add(Candidate(key = tag + au.take(150), url = au, title = title, kind = Kind.DIRECT, isAudio = true,
                ext = Resolver.extOf(au).ifEmpty { "mp3" }, size = -1, quality = "audio", duration = f.dur, formatSel = null,
                previewUrl = au, referer = page, audioUrl = au, img = f.thumb))
        }
        if (out.isEmpty()) return "tanpa link video/gambar"
        Repo.addCandidates(out)
        return null
    }
}
