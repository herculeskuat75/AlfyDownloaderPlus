package com.alfy.downloader

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

/**
 * v1.41: satu layar "Blokir & Filter" berisi 4 bagian dengan urutan tetap:
 * (1) Link yang di-scan, (2) Blokir iklan, (3) Blokir elemen, (4) Blokir situs.
 * Hanya tampilan: semua data & logika tetap lewat LinkBlock, AdBlock, ElementBlock, Block (tidak diubah).
 * Extra "section" (0..3) = bagian yang langsung digulir ke atas layar.
 */
class BlockHubActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(BlockHubPanel(this, intent.getIntExtra("section", 0)) { finish() }.build())
    }
}

class BlockHubPanel(a: Activity, private val section: Int, private val onClose: () -> Unit) : android.content.ContextWrapper(a) {
    private val lists = arrayOfNulls<LinearLayout>(4)
    private val tops = arrayOfNulls<View>(4)
    private val queries = arrayOf("", "", "", "")
    private fun match(q: String, vararg v: String) = q.isBlank() || v.any { it.contains(q.trim(), ignoreCase = true) }
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, sp: Float, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sp; setTextColor(c) }
    private fun bg(c: Int, r: Int = 10, stroke: Int = 0) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun action(t: String, onClick: () -> Unit) = tv(t, 13f, 0xFF80CBC4.toInt()).apply {
        setTypeface(null, android.graphics.Typeface.BOLD); setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { onClick() }
    }
    private fun btn(t: String, onClick: () -> Unit) = tv(t, 13f, 0xFF212121.toInt()).apply {
        setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER
        background = bg(0xFF80CBC4.toInt(), 8); setPadding(dp(14), dp(10), dp(14), dp(10)); setOnClickListener { onClick() }
    }
    private fun field(h: String) = EditText(this).apply {
        hint = h; setHintTextColor(0xFF888888.toInt()); setTextColor(Color.WHITE); textSize = 14f
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI; setSingleLine(true)
        background = bg(0xFF2C2C2C.toInt(), 8, 0xFF555555.toInt()); setPadding(dp(12), dp(10), dp(12), dp(10))
    }
    private fun empty(t: String) = tv(t, 13f, 0xFFBDBDBD.toInt()).apply { setPadding(0, dp(4), 0, dp(4)) }
    private fun delRow(label: String, size: Float, onDel: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        background = bg(0xFF2C2C2C.toInt()); setPadding(dp(14), dp(4), dp(4), dp(4))
        addView(tv(label, size), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(tv("✕", 18f, 0xFFEF9A9A.toInt()).apply { setPadding(dp(14), dp(10), dp(14), dp(10)); setOnClickListener { onDel() } })
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) }
    }

    /** Pola seragam tiap bagian: judul, keterangan, (kontrol tambahan), isian + tombol TAMBAH, daftar (diisi render()). */
    private fun addSection(idx: Int, title: String, hintText: String, extra: View?, fields: List<EditText>,
                           err: String, headAction: Pair<String, () -> Unit>?, onAdd: (List<String>) -> Boolean) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tops[idx] = box
        if (idx > 0) box.addView(View(this).apply { setBackgroundColor(0xFF424242.toInt()) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply { topMargin = dp(16); bottomMargin = dp(12) })
        val hd = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        hd.addView(tv(title, 15f, 0xFF80CBC4.toInt()).apply { setTypeface(null, android.graphics.Typeface.BOLD) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (headAction != null) hd.addView(action(headAction.first, headAction.second))
        box.addView(hd)
        box.addView(tv(hintText, 12f, 0xFFBDBDBD.toInt()).apply { setPadding(0, dp(2), 0, dp(8)) })
        if (extra != null) box.addView(extra, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })

        fun doAdd() {
            val vals = fields.map { it.text.toString() }
            if (vals.all { it.isBlank() }) return
            if (onAdd(vals)) { fields.forEach { it.setText("") }; render() }
            else Toast.makeText(this, err, Toast.LENGTH_SHORT).show()
        }
        val inputs = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fields.forEachIndexed { i, f ->
            inputs.addView(f, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { if (i > 0) topMargin = dp(6) })
        }
        fields.last().setOnEditorActionListener { _, _, _ -> doAdd(); true }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(inputs, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(btn("TAMBAH") { doAdd() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        box.addView(row)

        val sf = field("🔍 Cari di daftar...").apply { inputType = InputType.TYPE_CLASS_TEXT
            addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(e: android.text.Editable?) { queries[idx] = e?.toString() ?: ""; render() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            }) }
        box.addView(sf, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        val lb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, 0) }
        lists[idx] = lb
        box.addView(lb)
        content.addView(box)
    }

    /** Blokir host manual (ad_hosts.txt): hanya on/off. */
    private fun addNetSection() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(tv("0 · BLOKIR HOST MANUAL", 15f, 0xFF80CBC4.toInt()).apply { setTypeface(null, android.graphics.Typeface.BOLD) })
        box.addView(tv("Request ke host iklan (daftar bawaan aplikasi) diblokir sebelum dimuat.", 12f, 0xFFBDBDBD.toInt()).apply { setPadding(0, dp(2), 0, dp(6)) })
        val st = tv(NetAdblock.status(), 12f, 0xFFFFE082.toInt()); box.addView(st)
        box.addView(Switch(this).apply {
            text = "Aktifkan blokir host manual"; isChecked = NetFilterStore.enabled(); setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, v -> NetFilterStore.setEnabled(v); st.text = NetAdblock.status() }
        })
        box.addView(View(this).apply { setBackgroundColor(0xFF424242.toInt()) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply { topMargin = dp(8); bottomMargin = dp(12) })
        content.addView(box)
    }

    fun build(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF212121.toInt()); setPadding(dp(16), dp(14), dp(16), dp(10)) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("🚫 Blokir & Filter", 18f).apply { setTypeface(null, android.graphics.Typeface.BOLD) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(action("TUTUP") { onClose() })
        root.addView(head)
        root.addView(View(this).apply { setBackgroundColor(0xFF424242.toInt()) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply { topMargin = dp(8); bottomMargin = dp(10) })

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(content); setPadding(0, 0, 0, dp(8)) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        addNetSection()

        // (4) Blokir situs
        addSection(3, "1 · BLOKIR SITUS",
            "Situs di daftar ini tidak discan. Tidak ada di daftar = discan seperti biasa. youtube.com juga mencakup youtu.be/googlevideo; x.com juga twitter.com.",
            null, listOf(field("contoh: youtube.com")),
            "Isi nama situs, mis. youtube.com", null) { Block.add(it[0]) }

        // (1) Link yang di-scan
        addSection(0, "2 · LINK YANG DI-SCAN",
            "Link persis di daftar ini diblokir: tidak discan dan tidak bisa dibuka. Bisa juga ditambah lewat tekan lama link di browser.",
            null, listOf(field("contoh: situs.com/halaman/video")),
            "Isi link yang valid, mis. situs.com/video", null) { LinkBlock.add(it[0]) }

        // (3) Blokir elemen
        addSection(2, "3 · BLOKIR ELEMEN",
            "Elemen halaman yang disembunyikan per situs (pemilih CSS). Cara mudah: menu ⋮ browser → Blokir elemen, lalu sentuh elemennya.",
            null, listOf(field("situs, mis. contoh.com"), field("pemilih CSS, mis. .banner-iklan")),
            "Isi situs dan pemilih CSS", null) { v ->
            val h = Block.norm(v[0]).substringBefore('/').substringBefore(':')
            val ok = h.contains('.') && ElementBlock.add(h, v[1].trim())
            if (ok) ElementBlock.setOn(h, true)
            ok
        }

        // (2) Blokir iklan
        fun sw(t: String, on: Boolean, set: (Boolean) -> Unit) = Switch(this).apply {
            text = t; isChecked = on; setTextColor(Color.WHITE); setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, v -> set(v) }
        }
        val swBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(0xFF2C2C2C.toInt()); setPadding(dp(14), dp(4), dp(14), dp(4))
            addView(sw("Blokir pop-up (jendela baru)", AdBlock.popupOn()) { AdBlock.setPopup(it) })
            addView(sw("Blokir redirect otomatis", AdBlock.redirectOn()) { AdBlock.setRedirect(it) })
            addView(sw("Blokir domain iklan", AdBlock.adOn()) { AdBlock.setAd(it) })
            addView(sw("Cosmetic Filtering (sembunyikan iklan)", AdBlock.cosmeticOn()) { AdBlock.setCosmeticOn(it) })
        }
        addSection(1, "4 · BLOKIR IKLAN",
            "Sakelar iklan & pop-up browser, lalu daftar domain iklan. Subdomain ikut diblokir.",
            swBox, listOf(field("contoh: iklan.com")),
            "Isi nama domain, mis. iklan.com", Pair<String, () -> Unit>("RESET", { AdBlock.reset(); render() })) { AdBlock.add(it[0]) }

        render()
        val sec = section
        if (sec in 1..3) scroll.post { tops[sec]?.let { scroll.scrollTo(0, it.top) } }
        return root
    }

    private fun render() {
        lists.forEach { it?.removeAllViews() }
        // (1)
        val lb0 = lists[0]!!
        val ll = LinkBlock.list().filter { match(queries[0], it) }
        if (ll.isEmpty()) lb0.addView(empty("Belum ada link yang diblokir."))
        ll.forEach { e -> lb0.addView(delRow(e, 13f) { LinkBlock.remove(e); render() }) }
        // (2)
        val lb1 = lists[1]!!
        val al = AdBlock.list().filter { match(queries[1], it) }
        if (al.isEmpty()) lb1.addView(empty("Daftar domain iklan kosong."))
        al.forEach { d -> lb1.addView(delRow(d, 14f) { AdBlock.remove(d); render() }) }
        // (3)
        val lb2 = lists[2]!!
        val hs = ElementBlock.hosts().filter { h -> match(queries[2], h) || ElementBlock.rules(h).any { match(queries[2], it) } }
        if (hs.isEmpty()) lb2.addView(empty("Belum ada aturan blokir elemen."))
        hs.forEach { h ->
            val hr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, dp(2)) }
            hr.addView(tv(h + if (ElementBlock.isOn(h)) "" else " (mati)", 14f, 0xFF80CBC4.toInt()).apply { setTypeface(null, android.graphics.Typeface.BOLD) },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            hr.addView(action("HAPUS SITUS") {
                android.app.AlertDialog.Builder(this).setMessage("Hapus semua aturan untuk $h?")
                    .setPositiveButton("Hapus") { _, _ -> ElementBlock.removeHost(h); render() }.setNegativeButton("Batal", null).show()
            })
            lb2.addView(hr)
            ElementBlock.rules(h).filter { match(queries[2], h, it) }.forEach { sl -> lb2.addView(delRow(sl, 12f) { ElementBlock.remove(h, sl); render() }) }
        }
        // (4)
        val lb3 = lists[3]!!
        val sl = Block.list().filter { match(queries[3], it) }
        if (sl.isEmpty()) lb3.addView(empty("Daftar kosong: semua situs discan."))
        sl.forEachIndexed { i, e -> lb3.addView(delRow("${i + 1}. $e", 14f) { Block.remove(e); render() }) }
    }
}
