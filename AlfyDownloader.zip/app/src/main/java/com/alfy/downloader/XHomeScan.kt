package com.alfy.downloader

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.JavascriptInterface
import android.webkit.WebView
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * v1.59: X.com auto-scan beranda/timeline (seperti IDM+).
 * JS di halaman x.com memantau <video> yang SEDANG TERLIHAT (IntersectionObserver) + respons api.x.com/graphql (fetch/XHR).
 * Tweet berlabel iklan (promoted/placementTracking/"Ad"), serta URL /ads/, /promoted/, pbs.twimg.com/static/money/ dibuang di JS maupun Kotlin.
 * Hasil: ID tweet (-> Resolver.submit status) dan URL mp4/m3u8 video.twimg.com langsung (-> Resolver.submitXHome), tanpa perlu /status/.
 */
object XHomeScan {
    private val h = Handler(Looper.getMainLooper())
    private val idRe = Regex("^\\d{5,25}$")
    private val doneId = ConcurrentHashMap.newKeySet<String>()
    private val queue = ConcurrentLinkedQueue<String>()
    @Volatile private var pumping = false
    private var winAt = 0L
    private var winCount = 0

    private val JS = """(function(){
if(window.__alfyX)return;window.__alfyX=1;var dead=false,iv=null,mo2=null;window.__alfyXStop=function(){dead=true;try{io.disconnect();}catch(x){}try{mo2&&mo2.disconnect();}catch(x){}if(iv)clearInterval(iv);if(tF)clearTimeout(tF);vs=[];window.__alfyX=0;};
var seenId={},seenU={},n=0;
function adArt(a){try{
  if(!a)return true;
  if(a.querySelector('[data-testid="placementTracking"]'))return true;
  var sp=a.querySelectorAll('span');
  for(var i=0;i<sp.length&&i<80;i++){var t=(sp[i].textContent||'').trim();if(t==='Ad'||t==='Promoted'||t==='Iklan'||t==='Dipromosikan'||t==='Bersponsor'||t==='Promosi')return true;}
  if(a.querySelector('a[href*="/i/ads"],a[href*="ads.x.com"],a[href*="ads.twitter.com"]'))return true;
  var im=a.querySelectorAll('img,video');
  for(var j=0;j<im.length&&j<12;j++){var s=im[j].src||im[j].poster||'';if(s.indexOf('/static/money/')>=0||s.indexOf('/promoted')>=0||s.indexOf('/ads/')>=0)return true;}
}catch(e){}return false;}
function badU(u){return !u||u.indexOf('/static/money/')>=0||u.indexOf('/ads/')>=0||u.indexOf('/promoted')>=0||/[?&]promoted/.test(u);}
function sendId(id){if(!id||seenId[id]||n>300)return;seenId[id]=1;n++;try{AlfyX.tweet(id);}catch(e){}}
function sendU(u,id){if(badU(u)||seenU[u]||n>300)return;seenU[u]=1;n++;try{AlfyX.media(u,id||'');}catch(e){}}
function idOfArt(a){var l=a.querySelectorAll('a[href*="/status/"]');
  for(var i=0;i<l.length;i++){var m=/\/status\/(\d{5,25})/.exec(l[i].getAttribute('href')||'');if(m)return m[1];}return null;}
function visVideo(v){
  var a=v.closest&&v.closest('article');if(!a||adArt(a))return;
  var id=idOfArt(a);if(id)sendId(id);
  var u=v.currentSrc||v.src||'';if(u&&u.indexOf('http')===0&&/video\.twimg\.com/.test(u))sendU(u,id);
}
var vs=[],tF=null;
var io=new IntersectionObserver(function(es){
  for(var i=0;i<es.length;i++){var e=es[i].target;
    if(es[i].isIntersecting){if(vs.indexOf(e)<0)vs.push(e);}else{var k=vs.indexOf(e);if(k>=0)vs.splice(k,1);}}
  if(tF)clearTimeout(tF);tF=setTimeout(function(){tF=null;if(document.hidden)return;for(var i=0;i<vs.length&&i<8;i++)visVideo(vs[i]);},700);
},{threshold:0.5});
function watch(e){if(e.__ax)return;e.__ax=1;io.observe(e);}
function scanAll(){if(dead)return;try{var q=document.querySelectorAll('article video');for(var i=0;i<q.length&&i<60;i++)watch(q[i]);}catch(e){}}
var tM=null;
mo2=new MutationObserver(function(){if(dead)return;if(!tM)tM=setTimeout(function(){tM=null;scanAll();},400);});mo2.observe(document.documentElement,{childList:true,subtree:true});
scanAll();iv=setInterval(scanAll,3000);
function walk(o,ad,d){
  if(!o||typeof o!=='object'||d>40)return;
  if(Array.isArray(o)){for(var i=0;i<o.length&&i<200;i++)walk(o[i],ad,d+1);return;}
  if(o.promotedMetadata||o.promoted_content||o.adMetadataContainer||(typeof o.entryId==='string'&&o.entryId.indexOf('promoted')===0))ad=true;
  if(!ad&&o.rest_id&&o.legacy&&o.legacy.extended_entities&&o.legacy.extended_entities.media){
    var ms=o.legacy.extended_entities.media;
    for(var i=0;i<ms.length;i++){var vi=ms[i].video_info;if(!vi||!vi.variants)continue;
      var best=null,hls=null;
      for(var j=0;j<vi.variants.length;j++){var v=vi.variants[j];
        if(v.content_type==='video/mp4'){if(!best||(v.bitrate||0)>(best.bitrate||0))best=v;}
        else if(v.content_type==='application/x-mpegURL')hls=v;}
      var pick=best||hls;if(pick&&pick.url)sendU(pick.url,o.rest_id);}
  }
  for(var k in o){if(k==='legacy'&&o.legacy&&!o.rest_id){continue;}try{walk(o[k],ad,d+1);}catch(e){}}
}
function parse(t){try{if(t&&t.length<4000000)walk(JSON.parse(t),false,0);}catch(e){}}
function isApi(u){return typeof u==='string'&&/(?:api\.)?(?:x|twitter)\.com\/i?\/?(?:api\/)?graphql\//.test(u)&&!/\/ads\/|promoted/.test(u);}
try{var f=window.fetch;if(f)window.fetch=function(i){var u=typeof i==='string'?i:(i&&i.url);var p=f.apply(this,arguments);
  try{if(isApi(u))p.then(function(r){try{r.clone().text().then(parse);}catch(e){}});}catch(e){}return p;};}catch(e){}
try{var xo=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(m,u){var self=this;
  try{if(isApi(String(u)))this.addEventListener('load',function(){try{if(!self.responseType||self.responseType==='text')parse(self.responseText);}catch(e){}});}catch(e){}
  return xo.apply(this,arguments);};}catch(e){}
})();"""

    private fun host(u: String?): String = (try { Uri.parse(u ?: "").host } catch (e: Exception) { null } ?: "").lowercase()

    fun isX(u: String?): Boolean { val x = host(u); return x == "x.com" || x.endsWith(".x.com") || x == "twitter.com" || x.endsWith(".twitter.com") }

    fun enabled(url: String?): Boolean =
        Scan.enabled() && Repo.prefs().getBoolean("autoXHome", true) && isX(url) && SiteSettings.scan(url)

    /** Aman dipanggil berulang (skrip menjaga dirinya sendiri). */
    fun inject(wv: WebView, url: String?) {
        if (!enabled(url)) return
        try { wv.evaluateJavascript(JS, null) } catch (e: Throwable) { }
    }

    fun stop() {
        queue.clear(); doneId.clear(); pumping = false
        h.removeCallbacksAndMessages(null)
        val js = "try{window.__alfyXStop&&window.__alfyXStop();}catch(e){}"
        h.post { try { for (t in BrowserTabs.tabs.toList()) { try { t.wv.evaluateJavascript(js, null) } catch (e: Throwable) { } } } catch (e: Throwable) { } }
    }

    class Bridge(private val t: BrowserTab) {
        private fun ok() = BrowserTabs.current() === t && enabled(t.url)

        @JavascriptInterface fun tweet(id: String?) {
            if (id == null || !ok() || !idRe.matches(id) || !doneId.add(id)) return
            if (queue.size < 40) queue.add(id)
            h.post { pump() }
        }

        @JavascriptInterface fun media(u: String?, id: String?) {
            if (u == null || u.length > 1500 || !ok()) return
            if (!u.startsWith("http") || !u.contains("video.twimg.com", true) || Resolver.isXAd(u) || u.contains("/static/money/")) return
            Resolver.submitXHome(u, t.url)
        }
    }

    private fun pump() {
        if (pumping) return
        pumping = true
        h.postDelayed({ tick() }, 500)
    }

    private fun tick() {
        val now = SystemClock.elapsedRealtime()
        if (now - winAt > 600_000L) { winAt = now; winCount = 0 }
        if (!Scan.enabled()) { queue.clear(); pumping = false; return }
        if (queue.isEmpty()) { pumping = false; return }
        if (winCount < 30 && Chain.runningCount() < 2) {
            val id = queue.poll()
            if (id != null) {
                winCount++
                Resolver.submit("https://x.com/i/status/$id", null, true, "Browser Alfy (auto-scan X)")
            }
        }
        h.postDelayed({ tick() }, 3000)
    }
}
