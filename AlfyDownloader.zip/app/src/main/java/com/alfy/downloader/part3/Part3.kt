package com.alfy.downloader.part3

import android.content.Context
import android.content.Intent
import com.alfy.downloader.part3.core.CaptureHub
import com.alfy.downloader.part3.core.Http
import com.alfy.downloader.part3.download.DownloadEngine
import com.alfy.downloader.part3.download.DownloadStore
import com.alfy.downloader.part3.player.PreviewPlayerActivity
import com.alfy.downloader.part3.ui.DownloadManagerActivity
import com.alfy.downloader.part3.ytdlp.YtDlp

object Part3 {
    fun init(ctx: Context) {
        val a = ctx.applicationContext
        CaptureHub.init(a)
        DownloadStore.init(a)
        DownloadEngine.init(a)
        YtDlp.init(a)
        if (!cleaned) {
            cleaned = true
            try { DownloadEngine.autoCleanup() } catch (e: Exception) { }
        }
    }

    @Volatile private var cleaned = false

    fun openManager(ctx: Context) {
        init(ctx)
        ctx.startActivity(Intent(ctx, DownloadManagerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun preview(
        ctx: Context, url: String, referer: String?, userAgent: String = Http.UA,
        title: String? = null, audioOnly: Boolean = false
    ) {
        ctx.startActivity(
            PreviewPlayerActivity.intent(ctx, url, referer, userAgent, title, audioOnly)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
