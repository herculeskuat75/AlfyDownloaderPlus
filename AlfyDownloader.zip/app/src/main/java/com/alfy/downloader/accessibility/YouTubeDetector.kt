package com.alfy.downloader.accessibility

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.util.Log
import com.alfy.downloader.AppConfig
import com.alfy.downloader.part3.core.CaptureHub
import com.alfy.downloader.part3.core.Source
import com.alfy.downloader.part3.ytdlp.YtDlp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * Brain behind [YouTubeAccessibilityService]. The service only reports what it SEES on screen;
 * this object turns it into a standard YouTube URL and hands it to [CaptureHub] (→ yt-dlp → floating list).
 *
 *  1. A video ID found directly in the UI (URL text, share sheet, description link, browser address bar…)
 *     → standard watch URL immediately.
 *  2. Otherwise (the YouTube app does not show the ID on its player screen): title + channel read from the
 *     player → fast yt-dlp flat search → best verified match → standard watch URL.
 */
object YouTubeDetector {
    private const val TAG = "AlfyA11y"
    const val K_ENABLED = "a11y_autodetect"
    const val K_DEBUG = "a11y_debug"
    private const val MIN_SIMILARITY = 0.6

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _detected = MutableSharedFlow<String>(extraBufferCapacity = 8)
    /** Emits the standard watch URL every time a NEW video is detected (used to pulse the floating bubble). */
    val detected: SharedFlow<String> = _detected.asSharedFlow()

    private val titleCache = ConcurrentHashMap<String, String>() // signature → videoId
    private val submitted = java.util.Collections.synchronizedSet(LinkedHashSet<String>())
    @Volatile private var lastId: String? = null
    @Volatile private var lastSig: String? = null

    fun enabled(ctx: Context) = prefs(ctx).getBoolean(K_ENABLED, true)
    fun setEnabled(ctx: Context, v: Boolean) { prefs(ctx).edit().putBoolean(K_ENABLED, v).apply() }
    fun debug(ctx: Context) = prefs(ctx).getBoolean(K_DEBUG, false)
    fun setDebug(ctx: Context, v: Boolean) { prefs(ctx).edit().putBoolean(K_DEBUG, v).apply() }

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(AppConfig.PREFS, Context.MODE_PRIVATE)

    /** True when the user switched the service on in Android's Accessibility settings. */
    fun isServiceEnabled(ctx: Context): Boolean {
        val me = ComponentName(ctx, YouTubeAccessibilityService::class.java)
        val list = try {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        } catch (e: Exception) { null } ?: return false
        return list.split(':').any {
            val c = ComponentName.unflattenFromString(it)
            c != null && c == me
        }
    }

    /** A video ID was read straight from the UI. */
    fun onVideoId(ctx: Context, id: String) {
        if (id == lastId) return
        lastId = id
        publish(ctx, id, null)
    }

    /** Only title (+ channel) is visible: resolve it to an ID with a quick yt-dlp search. */
    fun onTitle(ctx: Context, title: String, channel: String?) {
        val sig = (title + "|" + (channel ?: "")).lowercase()
        if (sig == lastSig) return
        lastSig = sig
        val cached = titleCache[sig]
        if (cached != null) { lastId = cached; publish(ctx, cached, title); return }
        val app = ctx.applicationContext
        scope.launch {
            try {
                if (!YtDlp.await()) return@launch
                val q = if (channel.isNullOrBlank()) title else "$title $channel"
                val results = YtDlp.searchFlat(q, 5)
                var bestId: String? = null
                var best = 0.0
                for (r in results) {
                    val id = r.optString("id")
                    if (id.length != 11) continue
                    var score = YouTubeIdExtractor.similarity(title, r.optString("title"))
                    val ch = r.optString("channel").ifEmpty { r.optString("uploader") }
                    if (YouTubeIdExtractor.sameChannel(channel, ch)) score += 0.2
                    if (score > best) { best = score; bestId = id }
                }
                if (bestId == null || best < MIN_SIMILARITY) {
                    if (debug(app)) Log.d(TAG, "no verified match for '$title' (best=$best)")
                    return@launch
                }
                if (titleCache.size > 100) titleCache.clear()
                titleCache[sig] = bestId
                // The screen may already show another video by now; only publish when it is still the same one.
                if (lastSig == sig) { lastId = bestId; publish(app, bestId, title) }
            } catch (e: Throwable) {
                if (debug(app)) Log.d(TAG, "search failed: ${e.message}")
            }
        }
    }

    private fun publish(ctx: Context, id: String, titleHint: String?) {
        val url = YouTubeIdExtractor.watchUrl(id)
        if (debug(ctx)) Log.d(TAG, "detected $url (title=$titleHint)")
        if (submitted.size > 500) submitted.clear()
        val fresh = submitted.add(id)
        // CaptureHub itself dedups (UrlRegistry) and throttles while the screen is off.
        val accepted = CaptureHub.submit(url, Source.ACCESSIBILITY, titleHint = titleHint, forceMedia = false)
        if (accepted || fresh) _detected.tryEmit(url)
    }

    /** Forget the "last seen" state, e.g. when the user leaves the player screen. */
    fun resetCurrent() { lastId = null; lastSig = null }
}
