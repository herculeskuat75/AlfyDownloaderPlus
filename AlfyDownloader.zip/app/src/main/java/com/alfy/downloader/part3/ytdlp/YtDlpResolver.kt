package com.alfy.downloader.part3.ytdlp

import com.alfy.downloader.part3.core.Category
import com.alfy.downloader.part3.core.ENGINE_YTDLP
import com.alfy.downloader.part3.core.Http
import com.alfy.downloader.part3.core.MediaCandidate
import com.alfy.downloader.part3.core.Source
import com.alfy.downloader.part3.core.UrlRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Turns ANY page / share / search URL into download candidates using yt-dlp's extractors. */
object YtDlpResolver {
    private const val MAX_HEIGHT = 1080

    sealed class Result {
        data class Ok(val candidates: List<MediaCandidate>) : Result()
        data class Fail(val reason: String) : Result()
    }

    private class Fmt(
        val id: String, val h: Int, val w: Int, val vcodec: String, val acodec: String,
        val ext: String, val size: Long, val abr: Double, val tbr: Double
    ) {
        val hasVideo get() = vcodec != "none" && vcodec.isNotEmpty() && (h > 0 || w > 0)
        val hasAudio get() = acodec != "none" && acodec.isNotEmpty()
        val isMp4Friendly get() = ext == "mp4" || vcodec.startsWith("avc") || vcodec.startsWith("h264")
    }

    private fun fmtOf(o: JSONObject): Fmt? {
        val id = o.optString("format_id").ifEmpty { return null }
        val ext = o.optString("ext").lowercase(Locale.ROOT)
        if (ext == "mhtml" || o.optString("format_note").contains("storyboard", true)) return null
        val v = o.optString("vcodec", "none").ifEmpty { "none" }
        val a = o.optString("acodec", "none").ifEmpty { "none" }
        if (v == "none" && a == "none") return null
        val size = o.optLong("filesize", 0L).takeIf { it > 0 } ?: o.optLong("filesize_approx", 0L)
        return Fmt(
            id, o.optInt("height", 0), o.optInt("width", 0), v, a, ext, size,
            o.optDouble("abr", 0.0).let { if (it.isNaN()) 0.0 else it },
            o.optDouble("tbr", 0.0).let { if (it.isNaN()) 0.0 else it }
        )
    }

    /** [target] = page URL or a "ytsearch1:query" string. [claimKey] = key already claimed in UrlRegistry. */
    suspend fun resolve(
        target: String, claimKey: String?, source: Source, referer: String?, userAgent: String?, titleHint: String? = null
    ): Result = withContext(Dispatchers.IO) {
        if (!YtDlp.await()) return@withContext Result.Fail("Mesin yt-dlp belum siap: ${YtDlp.initError ?: "memuat…"}")
        val root = try {
            YtDlp.dumpJson(target, referer, null)
        } catch (e: Throwable) {
            return@withContext Result.Fail(shortError(e))
        } ?: return@withContext Result.Fail("Tidak ada data media")

        val entries = ArrayList<JSONObject>()
        val arr: JSONArray? = root.optJSONArray("entries")
        if (arr != null) {
            for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { entries += it }
        } else entries += root
        if (entries.isEmpty()) return@withContext Result.Fail("Tidak ada media di halaman ini")

        val out = ArrayList<MediaCandidate>()
        var first = true
        for (e in entries) {
            if (e.optBoolean("is_live", false) || e.optString("live_status") == "is_live") continue
            val page = e.optString("webpage_url").ifEmpty { e.optString("original_url") }
                .ifEmpty { if (target.startsWith("http")) target else "" }
            if (page.isEmpty()) continue
            val key = if (claimKey != null && first) claimKey else {
                val k = UrlRegistry.keyOf(page)
                if (k != claimKey && !UrlRegistry.tryClaim(k)) { first = false; continue }
                k
            }
            first = false
            out += candidatesOf(e, page, key, source, referer, userAgent, titleHint)
        }
        if (out.isEmpty()) Result.Fail("Tidak ada media yang bisa diunduh (live / terproteksi)") else Result.Ok(out)
    }

    private fun candidatesOf(
        e: JSONObject, page: String, key: String, source: Source,
        referer: String?, ua: String?, titleHint: String?
    ): List<MediaCandidate> {
        val title = e.optString("title").ifBlank { titleHint ?: e.optString("id", "media") }
        val dur = e.optDouble("duration", 0.0).let { if (it.isNaN()) 0.0 else it }
        val fmts = ArrayList<Fmt>()
        e.optJSONArray("formats")?.let { fa ->
            for (i in 0 until fa.length()) fa.optJSONObject(i)?.let { o -> fmtOf(o)?.let { fmts += it } }
        }
        val agent = ua ?: Http.UA
        val res = ArrayList<MediaCandidate>()

        // No format list (generic / direct extractors): let yt-dlp pick "best".
        if (fmts.isEmpty()) {
            val h = e.optInt("height", 0)
            val w = e.optInt("width", 0)
            val vc = e.optString("vcodec", "")
            val audioOnly = vc == "none" || (h == 0 && e.optString("ext") in setOf("mp3", "m4a", "opus", "aac"))
            val size = e.optLong("filesize", 0L).takeIf { it > 0 } ?: e.optLong("filesize_approx", 0L)
            res += cand(
                page, key, title, if (audioOnly) Category.MUSIC else Category.VIDEO, referer, agent, w, h, dur, size,
                if (audioOnly) "m4a" else "mp4", source, "b"
            )
            return res
        }

        val videos = fmts.filter { it.hasVideo }
        if (videos.isNotEmpty()) {
            val capped = videos.filter { maxOf(it.h, 0) <= MAX_HEIGHT || it.h == 0 }.ifEmpty { listOf(videos.minByOrNull { it.h }!!) }
            val bestH = capped.maxOf { it.h }
            val best = capped.filter { it.h == bestH }
                .sortedWith(compareByDescending<Fmt> { it.isMp4Friendly }.thenByDescending { it.tbr })
                .first()
            var plan = best.id
            var size = best.size
            if (!best.hasAudio) {
                val audios = fmts.filter { !it.hasVideo && it.hasAudio }
                val a = audios.sortedWith(
                    compareByDescending<Fmt> { it.ext == "m4a" && best.isMp4Friendly }.thenByDescending { it.abr }
                ).firstOrNull()
                if (a != null) { plan = "${best.id},${a.id}"; size += a.size }
            }
            res += cand(page, key, title, Category.VIDEO, referer, agent, best.w, best.h, dur, size, "mp4", source, plan)
        }

        val audios = fmts.filter { it.hasAudio && !it.hasVideo }
        val aBest = audios.sortedWith(compareByDescending<Fmt> { it.ext == "m4a" }.thenByDescending { it.abr }).firstOrNull()
        val aKey = if (videos.isEmpty()) key else "$key#a"
        res += cand(
            page, aKey, title, Category.MUSIC, referer, agent, 0, 0, dur, aBest?.size ?: 0L, "m4a", source, "ba[ext=m4a]/ba/b"
        )
        return res
    }

    private fun cand(
        page: String, key: String, title: String, cat: Category, referer: String?, ua: String,
        w: Int, h: Int, dur: Double, size: Long, ext: String, source: Source, plan: String
    ) = MediaCandidate(
        url = page, key = key, title = title, category = cat, referer = referer, userAgent = ua,
        width = w, height = h, durationSec = dur, sizeBytes = size, isHls = false, hlsProgram = -1,
        ext = ext, source = source, engine = ENGINE_YTDLP, fmtPlan = plan
    )

    private fun shortError(e: Throwable): String {
        val m = (e.message ?: e.javaClass.simpleName).lines().lastOrNull { it.isNotBlank() } ?: "gagal"
        return m.removePrefix("ERROR:").trim().take(140)
    }
}
