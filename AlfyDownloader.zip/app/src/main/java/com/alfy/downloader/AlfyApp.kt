package com.alfy.downloader

import android.app.Application
import com.alfy.downloader.part3.Part3
import com.alfy.downloader.permissions.RootChecker

class AlfyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        RootChecker.init(this)
        Part3.init(this)
    }
}
