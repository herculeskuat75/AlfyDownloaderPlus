package com.alfy.downloader.permissions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import com.alfy.downloader.R

enum class AppPermission(@StringRes val titleRes: Int, @StringRes val descRes: Int) {
    ROOT(R.string.perm_root_title, R.string.perm_root_desc),
    STORAGE(R.string.perm_storage_title, R.string.perm_storage_desc),
    OVERLAY(R.string.perm_overlay_title, R.string.perm_overlay_desc),
    BATTERY(R.string.perm_battery_title, R.string.perm_battery_desc);

    fun isGranted(context: Context): Boolean = when (this) {
        ROOT -> RootChecker.isGranted
        STORAGE -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }
        OVERLAY -> Settings.canDrawOverlays(context)
        BATTERY -> (context.getSystemService(Context.POWER_SERVICE) as PowerManager)
            .isIgnoringBatteryOptimizations(context.packageName)
    }

    companion object {
        /** Order in which permissions are requested on first launch. */
        val startupOrder = listOf(STORAGE, OVERLAY, BATTERY, ROOT)

        fun missing(context: Context): List<AppPermission> =
            values().filter { !it.isGranted(context) }

        fun allGranted(context: Context): Boolean = missing(context).isEmpty()
    }
}
