package com.alfy.downloader

import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * v1.8: izin root diminta SATU KALI di awal aplikasi (su -c id). Setelah diizinkan di Magisk (pilih "Selamanya"),
 * semua alat berbasis root (logcat, tcpdump, media_session, clipboard, pengaturan izin) memakai izin yang sama
 * dan baru dijalankan SESUDAH izin keluar, jadi tidak ada permintaan ganda.
 */
object RootGate {
    /** 0 = belum diminta, 1 = menunggu jawaban, 2 = diizinkan, 3 = ditolak/tidak ada root */
    @Volatile var state = 0
    @Volatile var status = "Root: belum diminta"
    private val lock = Any()
    val granted: Boolean get() = state == 2

    /** Blok sampai ada jawaban. force = tanya ulang (tombol pengguna / pemantau otomatis). */
    fun ensure(force: Boolean = false): Boolean = synchronized(lock) {
        if (state == 2) return@synchronized true
        if (state == 3 && !force) return@synchronized false
        state = 1; status = "Root: meminta izin (cek jendela Magisk/KernelSU)…"
        val ok = try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor(); out.contains("uid=0")
        } catch (e: Exception) { false }
        markGranted(ok)
        ok
    }

    @Volatile private var watching = false

    /**
     * v1.9: bila izin belum diberikan (jendela Magisk terlewat / baru diizinkan lewat tab Superuser), cek ulang otomatis
     * di latar belakang. Begitu root aktif, semua pemantau dinyalakan sendiri (tanpa paksa-berhenti / restart aplikasi).
     */
    @Synchronized fun watch() {
        if (watching || state == 2) return
        watching = true
        Thread {
            var n = 0
            try {
                while (state != 2) {
                    if (ensure(true)) { NetSniffer.enable(Repo.app.packageName, false); break }
                    n++
                    try { Thread.sleep(if (n < 20) 3000L else 30000L) } catch (e: Exception) { }
                }
            } finally { watching = false }
        }.apply { isDaemon = true }.start()
    }

    fun markGranted(ok: Boolean) {
        state = if (ok) 2 else 3
        status = if (ok) "Root: ✓ diizinkan 1x (berlaku untuk semua alat)" else "Root: ✗ ditolak / tidak ada"
    }
}

/** Sniffer lalu lintas jaringan (butuh root): logcat semua aplikasi + tcpdump (jika tersedia). */
object NetSniffer {
    @Volatile private var running = false
    @Volatile var status = "Sniffer: memulai…"
    // v1.8: status & penghitung per alat root, tampil di panel mengambang
    @Volatile var logStat = "• menunggu izin root"
    @Volatile var dumpStat = "• menunggu izin root"
    @Volatile var mediaStat = "• menunggu izin root"
    @Volatile var clipStat = "• menunggu izin root"
    @Volatile var logLines = 0L
    @Volatile var logHits = 0
    @Volatile var hookHits = 0
    @Volatile var dumpHits = 0
    @Volatile var lastHit = ""
    private val procs = mutableListOf<Process>()
    private val urlRe = Regex("https?://[^\\s\"'<>\\\\)]+")

    /** Tombol AKTIFKAN: minta root, beri izin, nyalakan (ulang) pemantau. */
    fun enable(pkg: String, restart: Boolean = true) { Thread { enableSync(pkg, restart) }.start() }

    /** v1.9: versi sinkron (dipakai MainActivity: root diminta PERTAMA sebelum izin lain). */
    fun enableSync(pkg: String, restart: Boolean = true): Boolean {
        run {
            status = "Meminta akses root…"
            val ok = try {
                val me = "$pkg/$pkg.AlfyAccessibilityService"
                val d = "\$"
                val cmd = "appops set $pkg SYSTEM_ALERT_WINDOW allow; pm grant $pkg android.permission.READ_LOGS; pm grant $pkg android.permission.POST_NOTIFICATIONS; pm grant $pkg android.permission.READ_EXTERNAL_STORAGE; pm grant $pkg android.permission.WRITE_EXTERNAL_STORAGE; dumpsys deviceidle whitelist +$pkg; " +
                    "cmd notification allow_listener $pkg/$pkg.AlfyNotifService 2>/dev/null; " +
                    "cur=${d}(settings get secure enabled_accessibility_services); " +
                    "case \"${d}cur\" in *$me*) ;; *) settings put secure enabled_accessibility_services \"${d}{cur#null}:$me\" ;; esac; " +
                    "settings put secure accessibility_enabled 1; id"
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                val out = p.inputStream.bufferedReader().readText()
                p.waitFor(); out.contains("uid=0")
            } catch (e: Exception) { false }
            RootGate.markGranted(ok)
            if (!ok) { status = "Root DITOLAK/tidak ada. Izinkan di Magisk (cek otomatis tiap beberapa detik)."; RootGate.watch(); return false }
            if (restart) stop()   // restart=false: jangan matikan pemantau yang sedang menunggu izin (hindari ganda)
            start()
        }
        return true
    }

    /** Coba pasang tcpdump lewat Termux (jika Termux terpasang). */
    fun installTcpdump() {
        Thread {
            val tp = "/data/data/com.termux/files/usr"
            status = "Memasang tcpdump via Termux… (butuh internet)"
            try {
                val cmd = "[ -x $tp/bin/pkg ] || exit 7; export PREFIX=$tp HOME=$tp/../home PATH=$tp/bin LD_LIBRARY_PATH=$tp/lib; " +
                    "yes | $tp/bin/pkg install -y tcpdump 2>&1 | tail -3; [ -x $tp/bin/tcpdump ]"
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                p.inputStream.readBytes(); val code = p.waitFor()
                status = if (code == 0) "tcpdump terpasang ✓" else if (code == 7) "Termux belum terpasang. Pasang Termux dulu (F-Droid)." else "Pasang tcpdump gagal. Buka Termux lalu ketik: pkg install tcpdump"
                if (code == 0) { stop(); start() }
            } catch (e: Exception) { status = "Pasang tcpdump gagal: ${e.message}" }
        }.start()
    }

    @Synchronized fun start() {
        if (running) return
        running = true
        status = "Memulai pemantau…"
        Thread {
            // v1.8: izin root diminta dulu SEKALI; semua pemantau root jalan sesudahnya (tcpdump ikut, tanpa menunggu opsi pantau semua)
            if (!RootGate.ensure()) {
                status = "Root DITOLAK/tidak ada. Izinkan di Magisk lalu tekan tombol Akses root di 📖."
                logStat = "✗ root ditolak"; dumpStat = "✗ root ditolak"; mediaStat = "✗ root ditolak"; clipStat = "✗ root ditolak"
                running = false
                return@Thread
            }
            if (!running) return@Thread
            Thread { logcat() }.apply { isDaemon = true }.start()
            Thread { dump() }.apply { isDaemon = true }.start()
            Thread { media() }.apply { isDaemon = true }.start()
            Thread { clip() }.apply { isDaemon = true }.start()
        }.apply { isDaemon = true }.start()
    }

    @Synchronized fun stop() {
        running = false
        procs.forEach { try { it.destroy() } catch (e: Exception) { } }
        procs.clear()
    }

    private fun su(cmd: String): Process? = try {
        Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).also { synchronized(this) { procs.add(it) } }
    } catch (e: Exception) { null }

    // v1.8: alamat/ID tweet di log aplikasi X -> fxtwitter langsung (cepat), tidak menunggu video mulai diputar
    private val tweetRe = Regex("(?:(?:x|twitter)\\.com/(?:[\\w.]+/)*status(?:es)?/|twitter://status\\?id=|x://status\\?id=)(\\d{8,25})")

    private fun feed(line: String, src: String = "Logcat root") {
        if (!Scan.enabled()) return   // v1.11: scan otomatis dimatikan lewat ⚙
        if (line.startsWith("AlfyHook|")) {   // v1.29: link dari modul LSPosed "Hook pemutar"
            if (!Tool.on("Hook pemutar")) return
            val parts = line.split('|')
            val hu = parts.getOrNull(1) ?: return
            if (!hu.startsWith("http")) return
            hookHits++
            Resolver.submitMedia(hu, parts.getOrNull(2)?.takeIf { it.startsWith("http") }, "Hook pemutar")
            return
        }
        if (!Tool.on(src)) return     // v1.12: tool "Logcat root" / "tcpdump" dimatikan lewat ⚙
        if (line.contains("status")) tweetRe.findAll(line).forEach { Resolver.submitTweet(it.groupValues[1]) }
        if (!line.contains("http")) return
        val all = Repo.prefs().getBoolean("sniffAll", false) || Scan.aggr()   // v1.11: mode agresif = semua URL
        urlRe.findAll(line).forEach {
            val u = it.value.trimEnd('.', ',', ';').replace("\\u0026", "&")
            // mode normal: hanya link media asli (googlevideo/videoplayback, mp4, m3u8, mp3, ...)
            if (all || Resolver.isMedia(u)) {
                logHits++; lastHit = u.substringAfter("://").substringBefore('?').takeLast(40)
                // v1.8: media X/Twitter masuk daftar LANGSUNG (tanpa HEAD/uji) supaya tidak lambat
                if (u.contains("twimg.com") && Resolver.isMedia(u)) Resolver.submitFast(u) else Resolver.submit(u, null, false, src)
            }
        }
    }

    /** URL yang dicatat pemutar media/aplikasi di logcat. */
    private fun logcat() {
        val p = su("pm grant com.alfy.downloader android.permission.READ_LOGS; logcat -b all -v raw -T 1 *:V")
        if (p == null) { status = "Root: tidak tersedia"; logStat = "✗ root tidak tersedia"; return }
        status = "Root: aktif • pemantau link aktif"
        logStat = "✓ aktif"
        try {
            BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8), 65536).use { r ->
                while (running) { val l = r.readLine() ?: break; logLines++; feed(l) }
            }
        } catch (e: Exception) { }
        if (running) logStat = "✗ berhenti (logcat putus)"
    }

    /** Paket HTTP polos (port 80 / 8080) via tcpdump bila ada di HP. */
    private fun dump() {
        dumpStat = "⏳ mencari tcpdump…"
        val which = su("which tcpdump; ls /system/xbin/tcpdump /system/bin/tcpdump /data/local/tmp/tcpdump /data/adb/modules/*/system/*bin/tcpdump /data/data/com.termux/files/usr/bin/tcpdump 2>/dev/null")
            ?: return
        val bin = try {
            which.inputStream.bufferedReader().readLines().firstOrNull { it.contains("tcpdump") }?.trim()
        } catch (e: Exception) { null }
        if (bin == null) { dumpStat = "✗ tidak ada di HP (📖 → pasang tcpdump)"; return }
        dumpStat = "✓ aktif • HTTP polos"
        val p = su("LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib:\$LD_LIBRARY_PATH $bin -i any -l -A -s 1500 'tcp and (port 80 or port 8080)'") ?: return
        var path: String? = null
        try {
            BufferedReader(InputStreamReader(p.inputStream)).use { r ->
                while (running) {
                    val l = r.readLine() ?: break
                    Regex("(?:GET|HEAD) (\\S+) HTTP").find(l)?.let { path = it.groupValues[1] }
                    Regex("Host: (\\S+)").find(l)?.let { m ->
                        val pa = path
                        if (pa != null && Tool.on("tcpdump") && Scan.enabled()) {
                            dumpHits++
                            Resolver.submit(if (pa.startsWith("http")) pa else "http://${m.groupValues[1]}$pa", null, false, "tcpdump")
                            path = null
                        }
                    }
                    feed(l, "tcpdump")
                }
            }
        } catch (e: Exception) { }
        if (running) dumpStat = "✗ berhenti"
    }

    /** Deteksi aplikasi YouTube: baca judul video yang sedang diputar (media session) lalu cari URL-nya.
     *  v1.7: aplikasi LAIN (browser, X, dll) yang mulai memutar media memicu AutoScan (semua alat jalan sendiri di belakang). */
    private fun media() {
        val p = su("while true; do dumpsys media_session 2>/dev/null | grep -E 'package=|metadata:|state=PlaybackState'; echo ---; sleep 1; done")
        if (p == null) { mediaStat = "✗ root tidak tersedia"; return }
        mediaStat = "✓ aktif • belum ada media diputar"
        var pkg = ""
        var last = ""
        val playing = HashSet<String>()
        var seenNow = HashSet<String>()
        try {
            BufferedReader(InputStreamReader(p.inputStream)).use { r ->
                while (running) {
                    val l = (r.readLine() ?: break).trim()
                    if (l.startsWith("package=")) pkg = l.substringAfter("package=").trim()
                    else if (l == "---") {
                        pkg = ""
                        playing.retainAll(seenNow)
                        seenNow = HashSet()
                    }
                    else if (l.startsWith("state=PlaybackState") && pkg.isNotEmpty()) {
                        val st = Regex("state=(\\d+)").find(l)?.groupValues?.get(1)?.toIntOrNull() ?: -1
                        if (st == 3) {
                            seenNow.add(pkg)
                            if (playing.add(pkg)) { mediaStat = "✓ aktif • memutar: " + pkg.substringAfterLast('.'); if (Tool.on("Media session")) AutoScan.onPlay(pkg) }
                        }
                    }
                    else if (l.startsWith("metadata:") && pkg.contains("youtube", true)) {
                        val d = l.substringAfter("description=", "").trim()
                            .removeSuffix(", null").removeSuffix(", null").trim()
                        if (d.length > 3 && d != last && d != "null" && Tool.on("Media session")) {
                            last = d
                            Resolver.searchYoutube(d)
                        }
                    }
                }
            }
        } catch (e: Exception) { }
    }

    // ---------- Clipboard via root (tanpa mencuri fokus layar, jadi tidak mengganggu saat mengetik) ----------
    @Volatile var clipRoot = false
    @Volatile private var clipCmd: String? = null
    @Volatile private var lastClip = ""
    private val clipUrlRe = Regex("https?://[^\\s\\u0000-\\u001F\\\"<>]+")

    private fun clipVariants(): List<String> {
        val sdk = android.os.Build.VERSION.SDK_INT
        val args = listOf("s16 %s i32 0", "s16 %s s16 null i32 0", "s16 %s s16 null i32 0 i32 0")
        val order = when { sdk <= 30 -> listOf(0, 1, 2); sdk <= 34 -> listOf(1, 2, 0); else -> listOf(2, 1, 0) }
        val out = ArrayList<String>()
        for (i in order) for (pkg in listOf("android", "root", "com.android.shell")) out.add("service call clipboard 3 " + args[i].format(pkg))
        for (i in order) out.add("su 2000 -c 'service call clipboard 3 " + args[i].format("com.android.shell") + "'")
        return out
    }

    private fun parseParcel(out: String): Pair<Boolean, String>? {
        val i = out.indexOf("Parcel(")
        if (i < 0) return null
        val body = out.substring(i + 7).replace(Regex("'[^']*'"), " ").replace(Regex("0x[0-9a-fA-F]+:"), " ")
        val words = Regex("\\b[0-9a-fA-F]{8}\\b").findAll(body).map { it.value }.toList()
        if (words.isEmpty()) return null
        val bytes = ByteArray(words.size * 4)
        words.forEachIndexed { k, w ->
            val v = w.toLong(16)
            for (b in 0..3) bytes[k * 4 + b] = ((v shr (8 * b)) and 0xFF).toByte()
        }
        return Pair(words[0] == "00000000", String(bytes, Charsets.UTF_16LE))
    }

    private fun runSu(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        val o = p.inputStream.bufferedReader().readText(); p.waitFor(); o
    } catch (e: Exception) { "" }

    private fun urlsIn(t: String): List<String> =
        clipUrlRe.findAll(t).map { it.value.trimEnd('.', ',', ';', ')') }.filter { it.length > 10 }.distinct().toList()

    /** Baca clipboard sekali (dipanggil saat ada tanda tautan disalin). */
    fun readClipRootOnce() {
        Thread {
            val c = clipCmd ?: return@Thread
            val r = parseParcel(runSu(c)) ?: return@Thread
            lastClip = r.second
            if (Tool.on("Clipboard root")) urlsIn(r.second).forEach { Resolver.rescan(it, null, "Clipboard root") }
        }.start()
    }

    private fun clip() {
        while (running) {
            var c = clipCmd
            if (c == null) {
                clipStat = "⏳ mencari cara baca clipboard…"
                for (v in clipVariants()) { val r = parseParcel(runSu(v)); if (r != null && r.first) { c = v; break } }
                if (c == null) { clipRoot = false; clipStat = "✗ HP ini tidak mendukung (akan dicoba lagi)"; try { Thread.sleep(20000) } catch (e: Exception) { }; continue }
                clipCmd = c; clipRoot = true; clipStat = "✓ aktif"
            }
            val p = su("while true; do $c; echo ---; sleep 1; done") ?: return
            var first = true
            try {
                BufferedReader(InputStreamReader(p.inputStream)).use { r ->
                    val sb = StringBuilder()
                    while (running) {
                        val l = r.readLine() ?: break
                        if (l.trim() == "---") {
                            val res = parseParcel(sb.toString()); sb.setLength(0)
                            if (res != null) {
                                val t = res.second
                                if (first) { first = false; lastClip = t }
                                else if (t != lastClip) { lastClip = t; if (Tool.on("Clipboard root")) urlsIn(t).forEach { Resolver.rescan(it, null, "Clipboard root") } }
                            }
                        } else sb.append(l).append('\n')
                    }
                }
            } catch (e: Exception) { }
            if (!running) return
            try { Thread.sleep(3000) } catch (e: Exception) { }
        }
    }
}
