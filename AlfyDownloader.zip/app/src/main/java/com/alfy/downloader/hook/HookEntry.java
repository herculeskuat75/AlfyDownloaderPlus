package com.alfy.downloader.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * v1.29: modul LSPosed "Hook pemutar". Aktifkan di LSPosed, pilih aplikasi (TikTok, Instagram, Facebook, X, dll.), lalu mulai ulang aplikasinya.
 * Memasang pengait pada pemutar/jaringan (MediaPlayer, ExoPlayer/Media3, OkHttp, TTVideoEngine, Uri.parse, URL) dan menulis link media
 * ke logcat dengan format "AlfyHook|url|ref|paket"; pemantau Logcat root di AlfyDownloader membacanya.
 */
public class HookEntry implements IXposedHookLoadPackage {
    private static final String SELF = "com.alfy.downloader";
    private static final Pattern GOOD = Pattern.compile(
        "(?i)\\.(?:mp4|m3u8|mpd|webm|m4a|mp3|flv|aac|mov)(?:[?#&]|$)|mime_type=(?:video|audio)|mime=(?:video|audio)|/video/tos/|bytevc|/aweme/v\\d+/play|videoplayback");
    private static final Pattern BAD = Pattern.compile("(?i)doubleclick|googlesyndication|googleads|imasdk|adservice|pubads|/vast|\\.(?:png|jpe?g|gif|webp|js|css|ts|m4s)(?:[?#]|$)");
    private static final Pattern VID = Pattern.compile("(?:[?&]v=|youtu\\.be/|/shorts/|/live/|videoId[\"=:\\s]{1,4}\"?)([\\w-]{11})(?![\\w-])");
    private static volatile String lastVid = "";
    private static final Set<String> SENT = Collections.synchronizedSet(new HashSet<String>());

    static void noteVid(String u) {
        try {
            if (u == null || u.length() > 2000 || (!u.contains("youtu") && !u.contains("videoId"))) return;
            if (u.contains("googlevideo.com")) return;
            java.util.regex.Matcher m = VID.matcher(u);
            if (m.find()) lastVid = m.group(1);
        } catch (Throwable ignored) { }
    }

    static void report(String u, String pkg) {
        try {
            noteVid(u);
            if (u == null || u.length() < 12 || u.length() > 1800 || !u.startsWith("http")) return;
            if (!GOOD.matcher(u).find() || BAD.matcher(u).find()) return;
            int q = u.indexOf('?');
            String key = q > 0 ? u.substring(0, q) : u;
            String vid = "";
            if (u.contains("googlevideo.com") && u.contains("videoplayback")) {
                vid = lastVid;
                if (vid.length() == 11) key = "gv|" + vid;
            }
            if (SENT.size() > 800) SENT.clear();
            if (!SENT.add(key)) return;
            android.util.Log.i("AlfyHook", "AlfyHook|" + u + "||" + pkg + "|" + vid);
        } catch (Throwable ignored) { }
    }

    static void scan(Object[] args, String pkg) {
        if (args == null) return;
        for (Object a : args) {
            if (a == null) continue;
            if (a instanceof String) { noteVid((String) a); report((String) a, pkg); }
            else if (a instanceof android.net.Uri || a instanceof java.net.URL || a.getClass().getName().endsWith("HttpUrl")) { noteVid(a.toString()); report(a.toString(), pkg); }
        }
    }

    private static XC_MethodHook cb(final String pkg) {
        return new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam param) { scan(param.args, pkg); }
        };
    }

    private static void all(Class<?> c, String m, XC_MethodHook h) {
        try { if (c != null) XposedBridge.hookAllMethods(c, m, h); } catch (Throwable ignored) { }
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        if (lp == null) return;
        if (SELF.equals(lp.packageName)) {   // tandai modul aktif di proses AlfyDownloader (dibaca HookStatus)
            try {
                Class<?> hs = Class.forName("com.alfy.downloader.HookStatus", true, lp.classLoader);
                hs.getField("hooked").setBoolean(null, true);
            } catch (Throwable ignored) { }
            return;
        }
        if ("android".equals(lp.packageName)) return;
        final String pkg = lp.packageName;
        ClassLoader cl = lp.classLoader;
        XC_MethodHook h = cb(pkg);
        // hasil Uri.parse dibaca setelah dipanggil (argumen string), umum dipakai semua pemutar
        try { XposedBridge.hookAllMethods(android.net.Uri.class, "parse", h); } catch (Throwable ignored) { }
        try { XposedBridge.hookAllConstructors(java.net.URL.class, h); } catch (Throwable ignored) { }
        all(android.media.MediaPlayer.class, "setDataSource", h);
        // ExoPlayer lama & Media3
        for (String n : new String[]{"com.google.android.exoplayer2.MediaItem$Builder", "androidx.media3.common.MediaItem$Builder"}) {
            try { all(XposedHelpers.findClassIfExists(n, cl), "setUri", h); } catch (Throwable ignored) { }
        }
        for (String n : new String[]{"com.google.android.exoplayer2.MediaItem", "androidx.media3.common.MediaItem"}) {
            try { all(XposedHelpers.findClassIfExists(n, cl), "fromUri", h); } catch (Throwable ignored) { }
        }
        // OkHttp (bila tidak diacak oleh aplikasi)
        try { all(XposedHelpers.findClassIfExists("okhttp3.Request$Builder", cl), "url", h); } catch (Throwable ignored) { }
        // ByteDance (TikTok)
        try {
            Class<?> tt = XposedHelpers.findClassIfExists("com.ss.ttvideoengine.TTVideoEngine", cl);
            all(tt, "setDirectURL", h);
            all(tt, "setDirectUrlUseDataLoader", h);
            all(tt, "setLocalURL", h);
        } catch (Throwable ignored) { }
    }
}
