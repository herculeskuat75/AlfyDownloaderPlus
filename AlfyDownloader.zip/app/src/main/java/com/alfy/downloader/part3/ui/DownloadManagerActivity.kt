package com.alfy.downloader.part3.ui

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.alfy.downloader.part3.Part3
import com.alfy.downloader.part3.core.CaptureHub
import com.alfy.downloader.part3.core.Category
import com.alfy.downloader.part3.download.DownloadEngine
import com.alfy.downloader.part3.download.DownloadItem
import com.alfy.downloader.part3.download.DownloadService
import com.alfy.downloader.part3.download.DownloadStore
import com.alfy.downloader.part3.download.Status
import com.alfy.downloader.part3.scan.AutoScanService
import com.alfy.downloader.part3.util.Fmt
import kotlinx.coroutines.launch

/** Main app menu + IDM-Plus style download manager (tabs, live progress, speed, ETA, full controls). */
class DownloadManagerActivity : ComponentActivity() {

    private enum class Tab(val label: String) {
        ALL("Semua"), VIDEO("Video"), MUSIC("Musik"), ACTIVE("Berjalan"), DONE("Selesai"), FAILED("Gagal")
    }

    private val BG = Color.parseColor("#12141C")
    private val CARD = Color.parseColor("#1C2030")
    private val ACCENT = Color.parseColor("#29B6F6")
    private val MUTED = Color.parseColor("#9AA3B5")

    private var tab = Tab.ALL
    private var latest: List<DownloadItem> = emptyList()
    private lateinit var adapter: Adapter
    private lateinit var summary: TextView
    private lateinit var foundBtn: TextView
    private lateinit var scanBtn: TextView
    private val tabViews = ArrayList<TextView>()

    private val vpnLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) AutoScanService.start(this)
    }
    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) askConvert(uri)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Part3.init(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 71)

        window.statusBarColor = BG
        setContentView(buildUi())

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { DownloadStore.items.collect { latest = it; render() } }
                launch { CaptureHub.pendingCount.collect { foundBtn.text = "🔎 $it" } }
                launch { AutoScanService.state.collect { scanBtn.text = if (it) "📡 ON" else "📡 OFF" } }
            }
        }
    }

    // ---------------- UI construction ----------------

    private fun rainbow(text: String): CharSequence {
        val cols = listOf("#FF5252", "#FFB300", "#66BB6A", "#29B6F6", "#AB47BC", "#EC407A").map { Color.parseColor(it) }
        val s = SpannableString(text)
        text.indices.forEach { s.setSpan(ForegroundColorSpan(cols[it % cols.size]), it, it + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) }
        return s
    }

    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(12), dp(7), dp(12), dp(7))
        background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(CARD) }
        setOnClickListener { onClick() }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(10), dp(6))
        }
        header.addView(TextView(this).apply {
            text = rainbow("AlfyD+"); textSize = 24f; typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        foundBtn = chip("🔎 0") { showCandidates() }
        scanBtn = chip("📡 OFF") { toggleScan() }
        val conv = chip("🔁") { pickFile.launch(arrayOf("video/*", "audio/*", "application/octet-stream", "application/x-mpegURL")) }
        val clear = chip("🧹") { DownloadEngine.clearFinished() }
        listOf(foundBtn, scanBtn, conv, clear).forEach {
            header.addView(it, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(6) })
        }
        root.addView(header)

        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), 0, dp(8), dp(6)) }
        Tab.values().forEach { t ->
            val tv = TextView(this).apply {
                text = t.label; textSize = 14f; gravity = Gravity.CENTER
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnClickListener { tab = t; refreshTabs(); render() }
            }
            tabViews += tv
            tabRow.addView(tv, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { rightMargin = dp(4) })
        }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(tabRow) })
        refreshTabs()

        adapter = Adapter()
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@DownloadManagerActivity)
            adapter = this@DownloadManagerActivity.adapter
            itemAnimator = null
            clipToPadding = false
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        root.addView(rv, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(CARD); setPadding(dp(12), dp(8), dp(8), dp(8))
        }
        summary = TextView(this).apply { textSize = 12f; setTextColor(MUTED) }
        bottom.addView(summary, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        bottom.addView(chip("⏸ Semua") { DownloadService.send(this, DownloadService.PAUSE_ALL) })
        bottom.addView(chip("▶ Semua") { DownloadService.send(this, DownloadService.RESUME_ALL) },
            LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(6) })
        root.addView(bottom, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        return root
    }

    private fun refreshTabs() {
        Tab.values().forEachIndexed { i, t ->
            val sel = t == tab
            tabViews[i].setTextColor(if (sel) Color.WHITE else MUTED)
            tabViews[i].typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            tabViews[i].background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat(); setColor(if (sel) ACCENT else Color.TRANSPARENT)
            }
        }
    }

    private fun render() {
        val running = setOf(Status.QUEUED, Status.DOWNLOADING, Status.CONVERTING, Status.PAUSED)
        val list = latest.filter {
            when (tab) {
                Tab.ALL -> true
                Tab.VIDEO -> it.category == Category.VIDEO
                Tab.MUSIC -> it.category == Category.MUSIC
                Tab.ACTIVE -> it.status in running
                Tab.DONE -> it.status == Status.DONE
                Tab.FAILED -> it.status == Status.FAILED
            }
        }
        adapter.submitList(list)
        val act = latest.filter { it.status == Status.DOWNLOADING }
        summary.text = "${act.size} aktif • ${Fmt.speed(act.sumOf { it.speedBps })} • ${latest.count { it.status == Status.DONE }} selesai"
    }

    // ---------------- actions ----------------

    private fun toggleScan() {
        if (AutoScanService.state.value) { AutoScanService.stop(this); return }
        if (AutoScanService.otherVpnActive(this)) { AutoScanService.start(this); return }
        val p = VpnService.prepare(this)
        if (p != null) vpnLauncher.launch(p) else AutoScanService.start(this)
    }

    private fun showCandidates() {
        val list = CaptureHub.candidates.value
        if (list.isEmpty()) { Toast.makeText(this, "Belum ada temuan", Toast.LENGTH_SHORT).show(); return }
        val labels = list.map { "${it.title}\n${it.qualityLabel} • ${Fmt.size(it.sizeBytes)} • ${Fmt.duration(it.durationSec)}" }.toTypedArray()
        val checked = BooleanArray(list.size) { true }
        AlertDialog.Builder(this)
            .setTitle("Temuan (${list.size})")
            .setMultiChoiceItems(labels, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Unduh") { _, _ ->
                list.filterIndexed { i, _ -> checked[i] }.forEach {
                    DownloadService.enqueue(this, it)
                    CaptureHub.remove(it.key)
                }
            }
            .setNeutralButton("Pratinjau") { _, _ ->
                list.filterIndexed { i, _ -> checked[i] }.firstOrNull()?.let {
                    Part3.preview(this, it.url, it.referer, it.userAgent, it.title)
                }
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun askConvert(uri: Uri) {
        AlertDialog.Builder(this).setTitle("Konversi")
            .setItems(arrayOf("Ke MP4 (remux TS/M3U8, tanpa kehilangan kualitas)", "Ke MP3 (ekstrak audio)")) { _, which ->
                DownloadEngine.convertLocal(uri, which == 1)
                
            }.show()
    }

    private fun send(action: String, id: String) = DownloadService.send(this, action, id)

    private fun preview(it: DownloadItem) {
        val target = if (it.status == Status.DONE && it.finalUri != null) it.finalUri else it.url
        if (target.startsWith("local://")) return
        Part3.preview(this, target, it.referer, it.userAgent, it.title)
    }

    private fun rename(it: DownloadItem) {
        val et = EditText(this).apply { setText(it.title); inputType = InputType.TYPE_CLASS_TEXT; setSelection(it.title.length) }
        AlertDialog.Builder(this).setTitle("Ganti nama").setView(et)
            .setPositiveButton("Simpan") { _, _ -> DownloadEngine.rename(it.id, et.text.toString()) }
            .setNegativeButton("Batal", null).show()
    }

    private fun confirmDelete(it: DownloadItem) {
        AlertDialog.Builder(this).setTitle("Hapus?").setMessage(it.title)
            .setPositiveButton("Hapus") { _, _ -> DownloadEngine.delete(it.id) }
            .setNegativeButton("Batal", null).show()
    }

    private fun detail(it: DownloadItem) {
        val msg = "Error: ${it.error ?: "-"}\n\nURL:\n${it.url}\n\nReferer: ${it.referer ?: "-"}\n" +
            "Terunduh: ${Fmt.size(it.downloaded)} / ${Fmt.size(it.total)}"
        AlertDialog.Builder(this).setTitle("Detail kegagalan").setMessage(msg)
            .setPositiveButton("Lanjutkan") { _, _ -> send(DownloadService.RETRY, it.id) }
            .setNegativeButton("Tutup", null).show()
    }

    private fun actionsFor(it: DownloadItem): List<Pair<String, () -> Unit>> = when (it.status) {
        Status.DOWNLOADING, Status.QUEUED -> listOf(
            "⏸ Jeda" to { send(DownloadService.PAUSE, it.id) },
            "⏹ Batal" to { send(DownloadService.CANCEL, it.id) },
            "👁 Pratinjau" to { preview(it) }
        )
        Status.PAUSED -> listOf(
            "▶ Lanjut" to { send(DownloadService.RESUME, it.id) },
            "⏹ Batal" to { send(DownloadService.CANCEL, it.id) },
            "✎ Nama" to { rename(it) },
            "🗑" to { confirmDelete(it) }
        )
        Status.CONVERTING -> listOf("⏹ Batal" to { send(DownloadService.CANCEL, it.id) })
        Status.FAILED -> listOf(
            "↻ Ulangi" to { send(DownloadService.RETRY, it.id) },
            "ℹ Detail" to { detail(it) },
            "🗑" to { confirmDelete(it) }
        )
        Status.DONE -> listOf(
            "▶ Putar" to { preview(it) },
            "✎ Nama" to { rename(it) },
            "🗑" to { confirmDelete(it) }
        )
    }

    // ---------------- list ----------------

    private inner class VH(
        val card: LinearLayout, val title: TextView, val meta: TextView,
        val bar: ProgressBar, val stat: TextView, val btns: LinearLayout
    ) : RecyclerView.ViewHolder(card)

    private inner class Adapter : ListAdapter<DownloadItem, VH>(object : DiffUtil.ItemCallback<DownloadItem>() {
        override fun areItemsTheSame(a: DownloadItem, b: DownloadItem) = a.id == b.id
        override fun areContentsTheSame(a: DownloadItem, b: DownloadItem) = a == b
    }) {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val card = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(10))
                background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(CARD) }
                layoutParams = RecyclerView.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(0, dp(4), 0, dp(4)) }
            }
            val title = TextView(parent.context).apply { textSize = 15f; setTextColor(Color.WHITE); maxLines = 2; typeface = Typeface.DEFAULT_BOLD }
            val meta = TextView(parent.context).apply { textSize = 11f; setTextColor(MUTED) }
            val bar = ProgressBar(parent.context, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
            val stat = TextView(parent.context).apply { textSize = 12f; setTextColor(Color.parseColor("#CFD8E6")) }
            val btns = LinearLayout(parent.context).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, 0) }
            card.addView(title); card.addView(meta)
            card.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, dp(10)).apply { topMargin = dp(8); bottomMargin = dp(4) })
            card.addView(stat); card.addView(btns)
            return VH(card, title, meta, bar, stat, btns)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val it = getItem(position)
            h.title.text = it.title
            val st = when (it.status) {
                Status.QUEUED -> "Antre"; Status.DOWNLOADING -> "Mengunduh"; Status.PAUSED -> "Dijeda"
                Status.CONVERTING -> "Mengonversi"; Status.DONE -> "Selesai"; Status.FAILED -> "Gagal"
            }
            h.meta.text = "${if (it.category == Category.VIDEO) "Video" else "Musik"} • ${it.ext.uppercase()} • $st"
            val indeterminate = it.status == Status.QUEUED || (it.status == Status.DOWNLOADING && it.total <= 0 && it.downloaded <= 0)
            h.bar.isIndeterminate = indeterminate
            if (!indeterminate) h.bar.progress = if (it.total > 0) ((it.downloaded * 1000) / it.total).toInt().coerceIn(0, 1000) else 0
            h.stat.text = when (it.status) {
                Status.DOWNLOADING -> "${it.pct}% • ${Fmt.speed(it.speedBps)} • sisa ${Fmt.time(it.etaSec)} • ${Fmt.size(it.downloaded)}/${Fmt.size(it.total)}"
                Status.CONVERTING -> "Konversi ${it.pct}%"
                Status.PAUSED -> "Dijeda • ${it.pct}% • ${Fmt.size(it.downloaded)}/${Fmt.size(it.total)}"
                Status.QUEUED -> "Menunggu giliran…"
                Status.DONE -> "Tersimpan • ${Fmt.size(it.total)}"
                Status.FAILED -> it.error ?: "Gagal"
            }
            h.btns.removeAllViews()
            actionsFor(it).forEach { (label, act) ->
                h.btns.addView(TextView(h.card.context).apply {
                    text = label; textSize = 13f; setTextColor(Color.WHITE)
                    setPadding(dp(10), dp(6), dp(10), dp(6))
                    background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#2A3046")) }
                    setOnClickListener { act() }
                }, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { rightMargin = dp(6) })
            }
        }
    }
}
