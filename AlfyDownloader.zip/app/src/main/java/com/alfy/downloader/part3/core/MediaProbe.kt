package com.alfy.downloader.part3.core

import com.arthenica.ffmpegkit.FFprobeKit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONObject
import java.net.URI

data class ProbeResult(
    val ok: Boolean,
    val hasVideo: Boolean,
    val hasAudio: Boolean,
    val width: Int,
    val height: Int,
    val durationSec: Double,
    val sizeBytes: Long
) {
    companion object { val FAIL = ProbeResult(false, false, false, 0, 0, 0.0, 0) }
}

object QualityFilter {
    const val MIN_SIDE = 240
    const val MAX_SIDE = 1080
    private const val TOL = 8

    fun inRange(w: Int, h: Int): Boolean {
        val s = if (w > 0 && h > 0) minOf(w, h) else h
        return s >= MIN_SIDE - TOL && s <= MAX_SIDE + TOL
    }

    /** Returns the category, or null when the stream must be discarded (out of range / mute / unreadable). */
    fun decide(p: ProbeResult, forcedW: Int, forcedH: Int): Category? {
        if (!p.ok) return null
        if (p.hasVideo) {
            if (!p.hasAudio) return null
            val w = if (forcedW > 0) forcedW else p.width
            val h = if (forcedH > 0) forcedH else p.height
            return if (inRange(w, h)) Category.VIDEO else null
        }
        return if (p.hasAudio) Category.MUSIC else null
    }
}

object HlsMaster {
    sealed class Selection {
        object Media : Selection()
        object OutOfRange : Selection()
        object Failed : Selection()
        data class Picked(val program: Int, val width: Int, val height: Int) : Selection()
    }

    private val resRe = Regex("RESOLUTION=(\\d+)x(\\d+)", RegexOption.IGNORE_CASE)
    private val bwRe = Regex("BANDWIDTH=(\\d+)", RegexOption.IGNORE_CASE)

    fun select(url: String, headers: Map<String, String>): Selection {
        val text = try {
            val rb = Request.Builder().url(url)
            headers.forEach { (k, v) -> rb.header(k, v) }
            Http.client.newCall(rb.build()).execute().use { r ->
                if (!r.isSuccessful) return Selection.Failed
                val src = r.body?.source() ?: return Selection.Failed
                src.request(524_288L)
                src.buffer.clone().readUtf8()
            }
        } catch (e: Exception) { return Selection.Failed }

        if (!text.contains("#EXT-X-STREAM-INF")) return Selection.Media

        data class V(val idx: Int, val w: Int, val h: Int, val bw: Long)
        val vs = ArrayList<V>()
        var idx = 0
        var pending: String? = null
        for (line in text.lines()) {
            val l = line.trim()
            if (l.startsWith("#EXT-X-STREAM-INF:")) { pending = l; continue }
            if (pending != null && l.isNotEmpty() && !l.startsWith("#")) {
                val m = resRe.find(pending)
                val w = m?.groupValues?.get(1)?.toIntOrNull() ?: 0
                val h = m?.groupValues?.get(2)?.toIntOrNull() ?: 0
                val bw = bwRe.find(pending)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                vs += V(idx++, w, h, bw)
                pending = null
            }
        }
        if (vs.isEmpty()) return Selection.Media
        if (vs.none { it.w > 0 && it.h > 0 }) return Selection.Media
        val best = vs.filter { it.w > 0 && QualityFilter.inRange(it.w, it.h) }
            .sortedWith(compareByDescending<V> { minOf(it.w, it.h) }.thenByDescending { it.bw })
            .firstOrNull() ?: return Selection.OutOfRange
        return Selection.Picked(best.idx, best.w, best.h)
    }
}

object MediaProbe {
    private val coverCodecs = setOf("mjpeg", "png", "bmp", "gif", "webp")

    suspend fun probe(url: String, headers: Map<String, String>, hls: Boolean): ProbeResult =
        withContext(Dispatchers.IO) {
            try {
                val args = ArrayList<String>()
                args += listOf("-v", "error", "-hide_banner", "-user_agent", headers["User-Agent"] ?: Http.UA)
                val hs = Http.ffHeaderString(headers)
                if (hs.isNotEmpty()) args += listOf("-headers", hs)
                args += listOf("-rw_timeout", "15000000")
                if (hls) args += listOf("-allowed_extensions", "ALL")
                args += listOf("-print_format", "json", "-show_format", "-show_streams", "-i", url)

                val session = FFprobeKit.executeWithArguments(args.toTypedArray())
                val out = session.output ?: return@withContext ProbeResult.FAIL
                val i0 = out.indexOf('{')
                val i1 = out.lastIndexOf('}')
                if (i0 < 0 || i1 <= i0) return@withContext ProbeResult.FAIL
                val root = JSONObject(out.substring(i0, i1 + 1))

                var hasV = false
                var hasA = false
                var w = 0
                var h = 0
                val streams = root.optJSONArray("streams")
                if (streams != null) {
                    for (i in 0 until streams.length()) {
                        val s = streams.optJSONObject(i) ?: continue
                        val type = s.optString("codec_type")
                        if (type == "video") {
                            val codec = s.optString("codec_name").lowercase()
                            if (codec in coverCodecs) continue
                            hasV = true
                            if (w == 0) {
                                w = s.optInt("width", 0)
                                h = s.optInt("height", 0)
                            }
                        } else if (type == "audio") {
                            hasA = true
                        }
                    }
                }
                val fmt = root.optJSONObject("format")
                ProbeResult(
                    ok = hasV || hasA, hasVideo = hasV, hasAudio = hasA, width = w, height = h,
                    durationSec = fmt?.optString("duration")?.toDoubleOrNull() ?: 0.0,
                    sizeBytes = fmt?.optString("size")?.toLongOrNull() ?: 0L
                )
            } catch (e: Exception) {
                ProbeResult.FAIL
            }
        }
}

fun resolveUrl(base: String, ref: String): String? = try {
    URI(base).resolve(ref.trim()).toString()
} catch (e: Exception) { null }
