package com.alfy.downloader.scan

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.core.content.ContextCompat
import com.alfy.downloader.data.ScanBus
import com.alfy.downloader.model.ScanOutcome

/** Transparent activity whose only job is to show the system screen-capture consent dialog. */
class ProjectionRequestActivity : Activity() {
    private val reqCode = 4711

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCode && resultCode == RESULT_OK && data != null) {
            ContextCompat.startForegroundService(this, ScreenCaptureService.intent(this, resultCode, data))
        } else {
            ScanBus.outcomes.tryEmit(ScanOutcome(emptyList(), "Screen capture permission was not granted"))
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
