package com.alfy.downloader

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color

@Composable
fun AlfyTheme(content: @Composable () -> Unit) {
    val tick = Wallpaper.colorTick.value
    val bg = remember(tick) { Color(Wallpaper.uiColor()) }
    val sf = remember(tick) { Color(Wallpaper.uiColor2()) }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF80CBC4), background = bg, surface = sf,
            onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}
