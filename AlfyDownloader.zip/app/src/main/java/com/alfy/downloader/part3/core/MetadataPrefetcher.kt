package com.alfy.downloader.part3.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

data class PageMeta(val title: String?, val mediaUrls: List<String>)

object MetadataPrefetcher {
    private val ogRe1 = Regex("<meta[^>]+(?:property|name)=[\"']og:(?:video|video:url|video:secure_url|audio|audio:url)[\"'][^>]*content=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
    private val ogRe2 = Regex("<meta[^>]+content=[\"']([^\"']+)[\"'][^>]*(?:property|name)=[\"']og:(?:video|video:url|video:secure_url|audio|audio:url)[\"']", RegexOption.IGNORE_CASE)
    private val tagRe = Regex("<(?:video|audio|source)[^>]+src=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
    private val rawRe = Regex("https?://[^\\s\"'<>\\\\)]+?\\.(?:m3u8|mp4|webm|mkv|mp3|m4a|mov)(?:\\?[^\\s\"'<>\\\\)]*)?", RegexOption.IGNORE_CASE)
    private val ldRe = Regex("<script[^>]+application/ld\\+json[^>]*>(.*?)</script>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val titleOg = Regex("<meta[^>]+property=[\"']og:title[\"'][^>]*content=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
    private val titleTag = Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

    suspend fun fetch(pageUrl: String, referer: String?): PageMeta = withContext(Dispatchers.IO) {
        try {
            val rb = Request.Builder().url(pageUrl)
                .header("User-Agent", Http.UA)
                .header("Accept", "text/html,application/json;q=0.9,*/*;q=0.8")
            if (!referer.isNullOrBlank()) rb.header("Referer", referer)
            Http.client.newCall(rb.build()).execute().use { r ->
                if (!r.isSuccessful) return@use PageMeta(null, emptyList())
                val ct = r.header("Content-Type")?.lowercase().orEmpty()
                if (ct.isNotEmpty() && !(ct.contains("html") || ct.contains("json") || ct.contains("xml") || ct.contains("text")))
                    return@use PageMeta(null, emptyList())
                val src = r.body?.source() ?: return@use PageMeta(null, emptyList())
                src.request(1_500_000L)
                val raw = src.buffer.clone().readUtf8()
                parse(pageUrl, raw)
            }
        } catch (e: Exception) {
            PageMeta(null, emptyList())
        }
    }

    private fun unescape(s: String) = s.replace("\\/", "/").replace("\\u0026", "&").replace("&amp;", "&").replace("\\u003d", "=")

    private fun parse(base: String, raw: String): PageMeta {
        val text = unescape(raw)
        val out = LinkedHashSet<String>()
        var title = titleOg.find(text)?.groupValues?.get(1)

        fun add(ref: String?) {
            if (ref.isNullOrBlank()) return
            val abs = if (ref.startsWith("//")) "https:$ref" else resolveUrl(base, ref) ?: return
            out += abs
        }

        ogRe1.findAll(text).forEach { add(it.groupValues[1]) }
        ogRe2.findAll(text).forEach { add(it.groupValues[1]) }
        tagRe.findAll(text).forEach { add(it.groupValues[1]) }

        ldRe.findAll(raw).forEach { m ->
            try {
                val body = m.groupValues[1].trim()
                val node: Any = if (body.startsWith("[")) JSONArray(body) else JSONObject(body)
                walk(node) { k, v ->
                    if (k == "contentUrl") add(v)
                    if (k == "name" && title == null) title = v
                }
            } catch (ignored: Exception) { }
        }

        rawRe.findAll(text).forEach { add(it.value) }

        if (title == null) title = titleTag.find(text)?.groupValues?.get(1)?.trim()?.take(120)
        val filtered = out.filter { UrlKind.kind(it) == UrlKind.Kind.MEDIA }.take(12)
        return PageMeta(title?.let { android.text.Html.fromHtml(it, android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim() }, filtered)
    }

    private fun walk(node: Any?, f: (String, String) -> Unit) {
        when (node) {
            is JSONObject -> node.keys().forEach { k ->
                val v = node.opt(k)
                if (v is String) f(k, v) else walk(v, f)
            }
            is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i), f)
        }
    }
}
