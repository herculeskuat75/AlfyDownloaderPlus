package com.alfy.downloader

/** Ikon yang bisa diganti pengguna (emoji/teks apa saja). Disimpan di prefs dengan kunci "ic_<key>". */
object Icons {
    val defs = listOf(
        Triple("home", "Browser: tombol beranda", "🏠"),
        Triple("back", "Browser: kembali", "◀"),
        Triple("fwd", "Browser: maju", "▶"),
        Triple("reload", "Browser: muat ulang", "⟳"),
        Triple("stop", "Browser: berhenti memuat", "✕"),
        Triple("star", "Browser: bookmark (belum)", "☆"),
        Triple("starOn", "Browser: bookmark (tersimpan)", "★"),
        Triple("menu", "Browser: tombol menu", "⋮"),
        Triple("gear", "Menu: pengaturan beranda", "⚙"),
        Triple("mainmenu", "Menu: menu utama", "☷"),
        Triple("m_new", "Menu: Tab Baru", "＋"),
        Triple("m_pin", "Menu: Tambah ke layar utama", "🏠"),
        Triple("m_hist", "Menu: Riwayat", "🕘"),
        Triple("m_bm", "Menu: Bookmark", "★"),
        Triple("m_find", "Menu: Cari di Halaman", "🔍"),
        Triple("m_ad", "Menu: Blokir Iklan", "🚫"),
        Triple("m_desk", "Menu: Situs desktop", "🖥"),
        Triple("m_elem", "Menu: Blokir elemen/situs", "▣"),
        Triple("m_set", "Menu: Pengaturan situs", "⚙"),
        Triple("m_filter", "Menu: Blokir & Filter", "🛡"),
        Triple("bm_item", "Bookmark: ikon item", "🌐"),
        Triple("bm_fav", "Bookmark: ikon favorit", "★"),
        Triple("bm_head", "Bookmark: ikon judul", "☆"),
        Triple("main_web", "Utama: browser", "🌐"),
        Triple("main_guide", "Utama: panduan/pemantau", "📖"),
        Triple("main_set", "Utama: izin/pengaturan", "⚙"),
        Triple("main_warn", "Utama: peringatan izin", "⚠️"),
        Triple("bubble", "Tombol mengambang (teks)", "⬇")
    )
    fun def(k: String) = defs.firstOrNull { it.first == k }?.third ?: ""
    fun get(k: String): String = Repo.prefs().getString("ic_$k", null)?.takeIf { it.isNotEmpty() } ?: def(k)
    fun set(k: String, v: String) { Repo.prefs().edit().putString("ic_$k", v.trim()).apply() }
    fun reset(k: String) { Repo.prefs().edit().remove("ic_$k").apply() }
    fun resetAll() { val e = Repo.prefs().edit(); defs.forEach { e.remove("ic_" + it.first) }; e.remove("ic_bubbleImg"); e.apply() }
}
