package com.alfy.downloader.part3.scan

import com.alfy.downloader.part3.core.CaptureHub
import com.alfy.downloader.part3.core.Source
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

object Shell {
    fun su(cmd: String, timeoutSec: Long = 8): Boolean = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        Thread { try { p.inputStream.readBytes() } catch (ignored: Exception) { } }.start()
        if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) { p.destroy(); false } else p.exitValue() == 0
    } catch (e: Exception) { false }

    /** Runs [cmd] as root and returns its output, or null when su is unavailable / timed out. */
    fun suOut(cmd: String, timeoutSec: Long = 5): String? = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        var text = ""
        val reader = Thread { try { text = p.inputStream.bufferedReader().readText() } catch (ignored: Exception) { } }
        reader.start()
        if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) { p.destroy(); null } else { reader.join(1000); text }
    } catch (e: Exception) { null }
}

/**
 * Root transparent proxy (used when another VPN such as Dark Tunnel / HTTP Custom owns the VPN slot,
 * and as DPI engine in local-VPN mode).
 *  - Plain HTTP (port 80) of every other app is redirected to a loopback relay that logs request URLs.
 *  - HTTPS (port 443) of the streaming/browser apps in [tlsUids] is redirected to a TLS relay that reads
 *    only the ClientHello SNI (no decryption) and forwards the bytes untouched. QUIC (UDP 443) of those
 *    apps is rejected so they fall back to TCP, where SNI is visible.
 *  - [pause]/[resume] remove/insert the rules (screen off = zero overhead).
 */
class IptablesSniffer(
    private val uid: Int,
    private val tlsUids: List<Int> = emptyList(),
    /** UIDs of VPN / tunnel apps (HTTP Custom, Dark Tunnel, ...): their sockets are NEVER redirected. */
    private val vpnUids: List<Int> = emptyList(),
    private val port: Int = 8089,
    private val tlsPort: Int = 8090
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val pool = Executors.newCachedThreadPool()
    private var server: ServerSocket? = null
    private var tlsServer: ServerSocket? = null
    @Volatile private var active = false
    @Volatile private var paused = false

    /** Normal user apps only (uid 10000-19999). System daemons, root and the VPN apps are left untouched. */
    private val appRange = "10000-19999"

    /** -w waits for the xtables lock (VPN apps edit iptables too); old iptables without -w falls back. */
    private fun ipt(args: String) = Shell.su("iptables -w 3 $args || iptables $args")

    private fun httpArgs(op: String) =
        "-t nat $op OUTPUT -p tcp --dport 80 -m owner --uid-owner $appRange -j REDIRECT --to-ports $port"

    private fun legacyHttpArgs(op: String) =
        "-t nat $op OUTPUT -p tcp --dport 80 -m owner ! --uid-owner $uid -j REDIRECT --to-ports $port"

    private fun tlsArgs(op: String, u: Int) =
        "-t nat $op OUTPUT -p tcp --dport 443 -m owner --uid-owner $u -j REDIRECT --to-ports $tlsPort"

    private fun quicArgs(op: String, u: Int) =
        "$op OUTPUT -p udp --dport 443 -m owner --uid-owner $u -j REJECT"

    private fun skipArgs(op: String, u: Int) =
        "-t nat $op OUTPUT -p tcp -m owner --uid-owner $u -j RETURN"

    private fun first(args: String) = args.replace("OUTPUT", "OUTPUT 1")

    private fun skipUids(): List<Int> = (listOf(uid) + vpnUids).distinct()

    private fun removeRules() {
        repeat(3) { ipt(httpArgs("-D")); ipt(legacyHttpArgs("-D")) }
        skipUids().forEach { repeat(2) { _ -> ipt(skipArgs("-D", it)) } }
        tlsUids.forEach { u ->
            ipt(tlsArgs("-D", u))
            ipt(quicArgs("-D", u))
        }
    }

    private fun installRules(): Boolean {
        if (!ipt(first(httpArgs("-I")))) return false
        if (tlsServer != null) {
            tlsUids.forEach { u ->
                if (u in vpnUids || u == uid) return@forEach
                ipt(first(tlsArgs("-I", u)))
                ipt(first(quicArgs("-I", u)))
            }
        }
        // Inserted last at position 1 => evaluated first: own app + every VPN app bypass all redirects.
        skipUids().forEach { ipt(first(skipArgs("-I", it))) }
        return true
    }

    fun start(): Boolean {
        if (!Shell.su("id")) return false
        removeRules() // stale rules from a previous crash
        server = try { ServerSocket(port, 64, InetAddress.getByName("127.0.0.1")) } catch (e: Exception) { return false }
        tlsServer = if (tlsUids.isEmpty()) null else try {
            ServerSocket(tlsPort, 64, InetAddress.getByName("127.0.0.1"))
        } catch (e: Exception) { null }
        if (!installRules()) { stop(); return false }
        active = true
        val http = server
        val tls = tlsServer
        if (http != null) scope.launch { acceptLoop(http, false) }
        if (tls != null) scope.launch { acceptLoop(tls, true) }
        return true
    }

    fun pause() {
        if (!active || paused) return
        paused = true
        removeRules()
    }

    fun resume() {
        if (!active || !paused) return
        paused = false
        installRules()
    }

    fun stop() {
        active = false
        removeRules()
        try { server?.close() } catch (ignored: Exception) { }
        try { tlsServer?.close() } catch (ignored: Exception) { }
        server = null
        tlsServer = null
        scope.cancel()
        pool.shutdownNow()
    }

    private fun acceptLoop(s: ServerSocket, tls: Boolean) {
        while (!s.isClosed) {
            val c = try { s.accept() } catch (e: Exception) { break }
            try {
                pool.execute { if (tls) handleTls(c) else handle(c) }
            } catch (e: Exception) { closeQuiet(c) }
        }
    }

    /** Reads the first TLS record (ClientHello) completely. Non-TLS data returns only the 5 header bytes. */
    private fun readFirstRecord(inp: InputStream): ByteArray? {
        val hdr = ByteArray(5)
        var r = 0
        while (r < 5) {
            val n = inp.read(hdr, r, 5 - r)
            if (n < 0) return null
            r += n
        }
        if (hdr[0].toInt() != 0x16) return hdr
        val len = ((hdr[3].toInt() and 0xFF) shl 8) or (hdr[4].toInt() and 0xFF)
        val body = ByteArray(minOf(len, 16384))
        var b = 0
        while (b < body.size) {
            val n = inp.read(body, b, body.size - b)
            if (n < 0) break
            b += n
        }
        return hdr + body.copyOf(b)
    }

    private fun handleTls(c: Socket) {
        var up: Socket? = null
        try {
            c.soTimeout = 30000
            val cin = c.getInputStream()
            val first = readFirstRecord(cin)
            val sni = if (first == null) null else SniParser.parse(first, first.size)
            if (first == null || sni == null) { closeQuiet(c); return }
            HostWatcher.onSni(sni)

            up = Socket()
            up.connect(InetSocketAddress(sni, 443), 10000)
            up.soTimeout = 60000
            val uout = up.getOutputStream()
            uout.write(first); uout.flush()
            val upRef = up
            pool.execute { pipe(upRef.getInputStream(), c.getOutputStream()); closeQuiet(c); closeQuiet(upRef) }
            pipe(cin, uout)
            closeQuiet(upRef); closeQuiet(c)
        } catch (e: Exception) {
            closeQuiet(c); up?.let { closeQuiet(it) }
        }
    }

    private fun readHead(inp: InputStream): ByteArray? {
        val bos = ByteArrayOutputStream()
        var state = 0
        while (bos.size() < 16384) {
            val b = inp.read()
            if (b < 0) return if (bos.size() > 0) bos.toByteArray() else null
            bos.write(b)
            state = when {
                b == '\r'.code && (state == 0 || state == 2) -> state + 1
                b == '\n'.code && (state == 1 || state == 3) -> state + 1
                else -> 0
            }
            if (state == 4) break
        }
        return bos.toByteArray()
    }

    private fun handle(c: Socket) {
        var up: Socket? = null
        try {
            c.soTimeout = 30000
            val cin = c.getInputStream()
            val head = readHead(cin) ?: run { c.close(); return }
            val text = String(head, Charsets.ISO_8859_1)
            val lines = text.split("\r\n")
            val req = lines[0].split(" ")
            fun h(name: String) = lines.firstOrNull { it.startsWith("$name:", true) }?.substringAfter(':')?.trim()
            val hostHdr = h("Host")
            if (req.size < 3 || hostHdr == null) { c.close(); return }
            val hostName = hostHdr.substringBefore(':')
            val hostPort = hostHdr.substringAfter(':', "80").toIntOrNull() ?: 80

            if (req[0].equals("GET", true)) {
                val url = "http://$hostHdr${req[1]}"
                val wantsHtml = h("Accept")?.contains("text/html", true) == true
                CaptureHub.submit(url, Source.NETWORK, h("Referer"), h("User-Agent"))
                if (wantsHtml) HostWatcher.onHost(hostName)
            }

            up = Socket()
            up.connect(InetSocketAddress(hostName, hostPort), 10000)
            up.soTimeout = 60000
            val uout = up.getOutputStream()
            uout.write(head); uout.flush()
            val upRef = up
            pool.execute { pipe(upRef.getInputStream(), c.getOutputStream()); closeQuiet(c); closeQuiet(upRef) }
            pipe(cin, uout)
            closeQuiet(upRef); closeQuiet(c)
        } catch (e: Exception) {
            closeQuiet(c); up?.let { closeQuiet(it) }
        }
    }

    private fun pipe(i: InputStream, o: java.io.OutputStream) {
        val buf = ByteArray(16384)
        try {
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n); o.flush()
            }
        } catch (ignored: Exception) { }
    }

    private fun closeQuiet(s: Socket) { try { s.close() } catch (ignored: Exception) { } }
}
