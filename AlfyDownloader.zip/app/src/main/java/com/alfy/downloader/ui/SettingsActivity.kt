package com.alfy.downloader.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.alfy.downloader.R
import com.alfy.downloader.databinding.ActivitySettingsBinding
import com.alfy.downloader.databinding.ItemPermissionBinding
import com.alfy.downloader.permissions.AppPermission
import com.alfy.downloader.permissions.PermissionRequester
import com.alfy.downloader.permissions.RootChecker
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val requester = PermissionRequester(this)
    private val rows = LinkedHashMap<AppPermission, ItemPermissionBinding>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnBack.setOnClickListener { finish() }

        AppPermission.values().forEach { permission ->
            val row = ItemPermissionBinding.inflate(layoutInflater, binding.container, false)
            row.title.setText(permission.titleRes)
            row.desc.setText(permission.descRes)
            row.root.setOnClickListener {
                if (!permission.isGranted(this)) requester.request(permission) { render() }
            }
            binding.container.addView(row.root)
            rows[permission] = row
        }

        render()
        lifecycleScope.launch {
            RootChecker.check()
            render()
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** Red "!" next to every permission that is not granted. */
    private fun render() {
        rows.forEach { (permission, row) ->
            val granted = permission.isGranted(this)
            row.warn.isVisible = !granted
            row.status.setText(if (granted) R.string.status_granted else R.string.status_missing)
            row.status.setTextColor(
                ContextCompat.getColor(this, if (granted) R.color.ok_green else R.color.warn_red)
            )
        }
    }
}
