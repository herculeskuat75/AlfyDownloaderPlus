package com.alfy.downloader.ui

import android.content.Intent
import android.graphics.Typeface
import android.provider.Settings
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.SwitchCompat
import com.alfy.downloader.accessibility.YouTubeDetector
import com.alfy.downloader.part3.scan.AutoScanService
import com.alfy.downloader.part3.scan.SniffPref
import com.alfy.downloader.part3.scan.SniffSettings
import com.alfy.downloader.part3.ytdlp.YtDlp
import com.alfy.downloader.AppConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.alfy.downloader.R
import com.alfy.downloader.databinding.ActivitySettingsBinding
import com.alfy.downloader.databinding.ItemPermissionBinding
import com.alfy.downloader.permissions.AppPermission
import com.alfy.downloader.permissions.PermissionRequester
import com.alfy.downloader.permissions.RootChecker
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val requester = PermissionRequester(this)
    private val rows = LinkedHashMap<AppPermission, ItemPermissionBinding>()
    private var a11yStatus: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnBack.setOnClickListener { finish() }

        addModeSection()

        AppPermission.values().forEach { permission ->
            val row = ItemPermissionBinding.inflate(layoutInflater, binding.container, false)
            row.title.setText(permission.titleRes)
            row.desc.setText(permission.descRes)
            row.root.setOnClickListener {
                if (!permission.isGranted(this)) requester.request(permission) { render() }
            }
            binding.container.addView(row.root)
            rows[permission] = row
        }

        render()
        lifecycleScope.launch {
            RootChecker.check()
            render()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun header(t: String) = TextView(this).apply {
        text = t; textSize = 13f; setTypeface(null, Typeface.BOLD)
        setPadding(dp(16), dp(16), dp(16), dp(4))
    }

    private fun note(t: String) = TextView(this).apply {
        text = t; textSize = 12f; alpha = 0.7f
        setPadding(dp(16), 0, dp(16), dp(8))
    }

    private fun toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = SwitchCompat(this).apply {
        text = label; isChecked = checked
        setPadding(dp(16), dp(8), dp(16), dp(8))
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    /** Mode toggle: Root (real-time background sniffing) vs Non-root (manual paste / share / screen scan). */
    private fun addModeSection() {
        val c = binding.container
        var idx = 0
        fun put(v: View) { c.addView(v, idx++, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)) }

        put(header("MODE SNIFFING"))
        val rg = RadioGroup(this).apply { setPadding(dp(16), 0, dp(16), 0) }
        val ids = LinkedHashMap<SniffPref, Int>()
        listOf(
            SniffPref.AUTO to "Otomatis — Root jika tersedia, kalau tidak manual",
            SniffPref.ROOT to "Root — sniffing real-time otomatis (tanpa salin-tempel)",
            SniffPref.MANUAL to "Non-root — manual: Paste / Bagikan (Share) / Scan Layar"
        ).forEach { (pref, label) ->
            val rb = RadioButton(this).apply { text = label; id = View.generateViewId() }
            ids[pref] = rb.id
            rg.addView(rb)
        }
        rg.check(ids[SniffSettings.pref(this)]!!)
        rg.setOnCheckedChangeListener { _, checked ->
            val pref = ids.entries.first { it.value == checked }.key
            SniffSettings.setPref(this, pref)
            AutoScanService.stop(this)
            lifecycleScope.launch {
                if (pref != SniffPref.MANUAL) RootChecker.check()
                delay(500)
                SniffSettings.autoStartIfNeeded(this@SettingsActivity)
                render()
            }
        }
        put(rg)
        put(note("Stream HTTPS (YouTube dll.) terenkripsi: mode root mencoba mengenali video yang diputar lewat media session + yt-dlp; jika gagal, Paste / Bagikan / Scan Layar tetap tersedia."))
        put(toggle("Mulai sniffing otomatis saat aplikasi dibuka (mode root)", SniffSettings.autoStart(this)) {
            SniffSettings.setAutoStart(this, it)
        })
        put(toggle("VPN DNS lokal (non-root, opsional)", SniffSettings.localVpn(this)) {
            SniffSettings.setLocalVpn(this, it)
        })
        put(note("Menempati slot VPN Android. Biarkan MATI bila memakai HTTP Custom, Dark Tunnel atau VPN lain."))

        put(header("MESIN UNDUH (yt-dlp + FFmpegKit)"))
        val prefs = getSharedPreferences(AppConfig.PREFS, MODE_PRIVATE)
        put(toggle("Perbarui extractor yt-dlp otomatis (tiap 12 jam)", prefs.getBoolean(YtDlp.KEY_AUTO_UPDATE, true)) {
            prefs.edit().putBoolean(YtDlp.KEY_AUTO_UPDATE, it).apply()
        })
        put(Button(this).apply {
            text = "Perbarui yt-dlp sekarang"
            transformationMethod = null
            setOnClickListener {
                isEnabled = false
                lifecycleScope.launch {
                    val ok = YtDlp.await() && withContext(Dispatchers.IO) { YtDlp.updateNow(this@SettingsActivity) }
                    Toast.makeText(
                        this@SettingsActivity,
                        if (ok) "Extractor yt-dlp diperbarui" else "Gagal memperbarui (periksa koneksi / VPN)",
                        Toast.LENGTH_SHORT
                    ).show()
                    isEnabled = true
                }
            }
        })

        put(header("DETEKSI YOUTUBE OTOMATIS (AKSESIBILITAS)"))
        put(note("Membaca layar YouTube / YouTube Music (hanya baca, tanpa ketikan) lalu mengirim link video yang sedang diputar ke menu mengambang secara real-time, tanpa salin-tempel. Hanya aktif untuk YouTube, YouTube Music, dan bilah alamat browser."))
        a11yStatus = TextView(this).apply {
            textSize = 13f; setTypeface(null, Typeface.BOLD)
            setPadding(dp(16), dp(4), dp(16), dp(4))
        }
        put(a11yStatus!!)
        put(Button(this).apply {
            text = "Buka pengaturan Aksesibilitas"
            transformationMethod = null
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    Toast.makeText(this@SettingsActivity, "Buka Pengaturan > Aksesibilitas secara manual", Toast.LENGTH_LONG).show()
                }
            }
        })
        put(toggle("Deteksi otomatis aktif", YouTubeDetector.enabled(this)) { YouTubeDetector.setEnabled(this, it) })
        put(toggle("Log debug (adb logcat -s AlfyA11y)", YouTubeDetector.debug(this)) { YouTubeDetector.setDebug(this, it) })
        put(note("Android 13+: bila tombol aktifkan abu-abu, buka Info Aplikasi > menu titik tiga > Izinkan setelan terbatas, lalu aktifkan kembali."))

        put(header("IZIN"))
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** Red "!" next to every permission that is not granted. */
    private fun render() {
        a11yStatus?.let { tv ->
            val on = YouTubeDetector.isServiceEnabled(this)
            tv.text = if (on) "Layanan: AKTIF" else "! Layanan: BELUM DIAKTIFKAN (opsional)"
            tv.setTextColor(ContextCompat.getColor(this, if (on) R.color.ok_green else R.color.warn_red))
        }
        rows.forEach { (permission, row) ->
            val granted = permission.isGranted(this)
            row.warn.isVisible = !granted
            row.status.setText(if (granted) R.string.status_granted else R.string.status_missing)
            row.status.setTextColor(
                ContextCompat.getColor(this, if (granted) R.color.ok_green else R.color.warn_red)
            )
        }
    }
}
