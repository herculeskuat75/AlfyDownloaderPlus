package com.alfy.downloader.permissions

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import com.alfy.downloader.AppConfig
import kotlinx.coroutines.launch

/**
 * Requests one permission at a time. Must be created as a property of the activity
 * (before it reaches STARTED) because it registers activity-result launchers.
 */
class PermissionRequester(private val activity: ComponentActivity) {

    private var onDone: (() -> Unit)? = null

    private val runtimeLauncher = activity.registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { complete() }

    private val intentLauncher = activity.registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { complete() }

    private fun complete() {
        val callback = onDone
        onDone = null
        callback?.invoke()
    }

    fun request(permission: AppPermission, done: () -> Unit = {}) {
        onDone = done
        val pkg = Uri.parse("package:${activity.packageName}")
        when (permission) {
            AppPermission.ROOT -> activity.lifecycleScope.launch {
                RootChecker.check()
                complete()
            }
            AppPermission.STORAGE -> requestStorage(pkg)
            AppPermission.OVERLAY ->
                launchSettings(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg))
            AppPermission.BATTERY ->
                launchSettings(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg))
        }
    }

    private fun requestStorage(pkg: Uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            launchSettings(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkg))
            return
        }
        val perms = arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
        val prefs = activity.getSharedPreferences(AppConfig.PREFS, Context.MODE_PRIVATE)
        val askedBefore = prefs.getBoolean("storage_asked", false)
        val permanentlyDenied = askedBefore && perms.none {
            ActivityCompat.shouldShowRequestPermissionRationale(activity, it)
        }
        if (permanentlyDenied) {
            openAppDetails(pkg)
        } else {
            prefs.edit().putBoolean("storage_asked", true).apply()
            runtimeLauncher.launch(perms)
        }
    }

    private fun launchSettings(intent: Intent) {
        try {
            intentLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            openAppDetails(Uri.parse("package:${activity.packageName}"))
        }
    }

    private fun openAppDetails(pkg: Uri) {
        try {
            intentLauncher.launch(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
        } catch (e: ActivityNotFoundException) {
            complete()
        }
    }
}
