package com.alfy.downloader

import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Update binary yt-dlp dari GitHub Releases tanpa build ulang APK. */
object BinUpdater {
    private const val UA = "AlfyDownloader/1.0 (Android)"

    private fun open(u: String, accept: String): HttpURLConnection {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 60000; c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA); c.setRequestProperty("Accept", accept)
        return c
    }

    /** Dipanggil dari thread latar. Mengembalikan pesan hasil (sukses atau alasan gagal). */
    fun updateYtDlp(onStatus: (String) -> Unit): String {
        try {
            onStatus("Cek rilis terbaru…")
            val meta = open(AppPreferences.ytdlpReleaseUrl, "application/vnd.github+json").let { c ->
                try {
                    if (c.responseCode != 200) return "GitHub HTTP ${c.responseCode}"
                    c.inputStream.bufferedReader().readText()
                } finally { try { c.disconnect() } catch (e: Throwable) { } }
            }
            val j = org.json.JSONObject(meta)
            val tag = j.optString("tag_name", "?")
            val assets = j.optJSONArray("assets") ?: return "rilis tanpa file"
            var dl: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.optJSONObject(i) ?: continue
                if (a.optString("name") == "yt-dlp") { dl = a.optString("browser_download_url"); break }
            }
            if (dl.isNullOrEmpty()) return "file yt-dlp tidak ada di rilis $tag"
            onStatus("Mengunduh yt-dlp $tag…")
            val app = Repo.app
            val tmp = File(app.filesDir, "yt-dlp.tmp")
            val c = open(dl, "application/octet-stream")
            try {
                if (c.responseCode != 200) return "unduh HTTP ${c.responseCode}"
                c.inputStream.use { ins -> tmp.outputStream().use { ins.copyTo(it) } }
            } finally { try { c.disconnect() } catch (e: Throwable) { } }
            if (tmp.length() < 100_000L) { tmp.delete(); return "file unduhan tidak valid" }
            val dest = File(app.filesDir, "yt-dlp")
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) { tmp.copyTo(dest, true); tmp.delete() }
            chmodX(dest)
            // Timpa juga berkas yang dipakai mesin yt-dlp aplikasi agar versi baru langsung dipakai.
            try {
                val eng = File(app.noBackupFilesDir, "youtubedl-android/yt-dlp/yt-dlp")
                if (eng.parentFile?.exists() == true) { dest.copyTo(eng, true); chmodX(eng) }
            } catch (e: Throwable) { }
            Resolver.diag = "yt-dlp diperbarui ($tag)"
            return "yt-dlp $tag terpasang"
        } catch (e: Throwable) {
            return "gagal: " + (e.message ?: e.javaClass.simpleName).take(60)
        }
    }

    private fun chmodX(f: File) {
        try { Runtime.getRuntime().exec(arrayOf("chmod", "755", f.absolutePath)).waitFor() } catch (e: Throwable) { }
        try { f.setExecutable(true, false) } catch (e: Throwable) { }
    }
}
