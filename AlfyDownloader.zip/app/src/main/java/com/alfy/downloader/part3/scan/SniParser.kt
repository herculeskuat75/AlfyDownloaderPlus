package com.alfy.downloader.part3.scan

/** Extracts the SNI host name from a raw TLS ClientHello record. */
object SniParser {
    fun parse(b: ByteArray, len: Int): String? {
        try {
            if (len < 48 || b[0].toInt() != 0x16) return null
            var p = 5
            if (b[p].toInt() != 0x01) return null
            p += 4
            p += 2 + 32
            p += 1 + (b[p].toInt() and 0xFF)
            p += 2 + u16(b, p)
            p += 1 + (b[p].toInt() and 0xFF)
            if (p + 2 > len) return null
            val extEnd = p + 2 + u16(b, p)
            p += 2
            val end = minOf(extEnd, len)
            while (p + 4 <= end) {
                val type = u16(b, p)
                val l = u16(b, p + 2)
                p += 4
                if (type == 0 && p + 5 <= end) {
                    val nameLen = u16(b, p + 3)
                    val s = p + 5
                    return if (s + nameLen <= end) String(b, s, nameLen, Charsets.US_ASCII).lowercase() else null
                }
                p += l
            }
        } catch (e: Exception) {
            return null
        }
        return null
    }

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
}
