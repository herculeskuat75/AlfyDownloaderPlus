package com.alfy.downloader.ui

import android.content.Context
import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.alfy.downloader.AppConfig
import com.alfy.downloader.R
import com.alfy.downloader.databinding.ActivityMainBinding
import com.alfy.downloader.overlay.OverlayService
import com.alfy.downloader.part3.Part3
import com.alfy.downloader.permissions.AppPermission
import com.alfy.downloader.permissions.PermissionRequester
import com.alfy.downloader.permissions.RootChecker
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val requester = PermissionRequester(this)
    private val prefs by lazy { getSharedPreferences(AppConfig.PREFS, Context.MODE_PRIVATE) }
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val openSettings = { startActivity(Intent(this, SettingsActivity::class.java)) }
        binding.btnSettings.setOnClickListener { openSettings() }
        binding.btnFixPermissions.setOnClickListener { openSettings() }
        binding.btnOpenManager.setOnClickListener { Part3.openManager(this) }
        binding.btnToggleOverlay.setOnClickListener {
            val enable = !overlayEnabled()
            prefs.edit().putBoolean(KEY_OVERLAY, enable).apply()
            if (enable) ensureOverlay() else OverlayService.stop(this)
            refreshOverlayButton()
        }

        if (!prefs.getBoolean(KEY_STARTUP_DONE, false)) {
            runStartupFlow()
        } else {
            askNotifications()
            lifecycleScope.launch {
                RootChecker.check()
                refreshBadge()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshBadge()
        refreshOverlayButton()
        if (prefs.getBoolean(KEY_STARTUP_DONE, false)) ensureOverlay()
    }

    private fun askNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun overlayEnabled() = prefs.getBoolean(KEY_OVERLAY, true)

    /** Starts the floating bubble once the overlay permission is granted. */
    private fun ensureOverlay() {
        if (overlayEnabled() && Settings.canDrawOverlays(this)) OverlayService.start(this)
    }

    private fun refreshOverlayButton() {
        binding.btnToggleOverlay.setText(
            if (overlayEnabled()) R.string.overlay_toggle_off else R.string.overlay_toggle_on
        )
    }

    /** First launch: ask Storage -> Overlay -> Battery -> Root, one after another. */
    private fun runStartupFlow() {
        val queue = ArrayDeque(AppPermission.startupOrder.filter { !it.isGranted(this) })
        fun next() {
            val permission = queue.removeFirstOrNull()
            if (permission == null) {
                prefs.edit().putBoolean(KEY_STARTUP_DONE, true).apply()
                refreshBadge()
                ensureOverlay()
                askNotifications()
                return
            }
            requester.request(permission) {
                refreshBadge()
                next()
            }
        }
        next()
    }

    private fun refreshBadge() {
        val anyMissing = !AppPermission.allGranted(this)
        binding.badgeSettings.isVisible = anyMissing
        binding.warningBar.isVisible = anyMissing
    }

    private companion object {
        const val KEY_STARTUP_DONE = "startup_done"
        const val KEY_OVERLAY = "overlay_enabled"
    }
}
