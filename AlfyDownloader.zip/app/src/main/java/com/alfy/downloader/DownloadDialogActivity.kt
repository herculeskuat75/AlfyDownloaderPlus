package com.alfy.downloader

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID

class DownloadDialogActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val key = intent.getStringExtra("key") ?: ""
        val c = Repo.detected.value.firstOrNull { it.key == key }
        if (c == null) { finish(); return }
        setContent { AlfyTheme { DialogUI(c) { finish() } } }
    }
}

fun enqueue(ctx: Context, c: Candidate, name: String, dir: String, wifi: Boolean, retry: Boolean, start: Boolean) {
    val id = UUID.randomUUID().toString()
    Repo.add(DlItem(
        id = id, name = name, url = c.url, kind = c.kind, isAudio = c.isAudio, toMp3 = c.toMp3,
        formatSel = c.formatSel, referer = c.referer, dir = dir,
        status = if (start) Status.QUEUED else Status.PAUSED,
        total = c.size.coerceAtLeast(0), wifiOnly = wifi, retry = retry
    ))
    if (start) DownloadService.cmd(ctx, "start", id)
}

@Composable
fun DialogUI(c: Candidate, close: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val ext = when { c.kind == Kind.HLS -> "mp4"; c.toMp3 -> "mp3"; else -> c.ext }
    var name by remember { mutableStateOf(safeName(c.title)) }
    var auto by remember { mutableStateOf(true) }
    var path by remember { mutableStateOf(Paths.dirFor(c.isAudio).path) }
    var wifi by remember { mutableStateOf(false) }
    var retry by remember { mutableStateOf(true) }
    val autoPath = Paths.dirFor(c.isAudio).path

    fun go(start: Boolean) {
        enqueue(ctx, c, safeName(name) + "." + ext, if (auto) autoPath else path, wifi, retry, start)
        close()
    }

    Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
        Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFF424242), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState())) {
                Text("Unduh berkas!", fontSize = 22.sp, color = Color.White)
                Spacer(Modifier.height(8.dp))
                Text(c.url, fontSize = 12.sp, color = Color(0xFFBDBDBD), maxLines = 3, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                Text("Simpan sebagai:", color = Color(0xFFBDBDBD))
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true,
                    suffix = { Text(".$ext", color = Color(0xFFFF7043)) }, modifier = Modifier.fillMaxWidth()
                )
                Text("${c.quality} • ~${fmtSize(c.size)} • durasi ${fmtDur(c.duration)}", color = Color(0xFFBDBDBD), fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.clickable { auto = !auto }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = auto, onCheckedChange = { auto = it })
                    Text("Simpan otomatis sesuai kategori (video / music)")
                }
                if (auto) Text("Folder: $autoPath", fontSize = 12.sp, color = Color(0xFFFF7043))
                else OutlinedTextField(value = path, onValueChange = { path = it }, label = { Text("Folder tujuan") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = wifi, onCheckedChange = { wifi = it }); Text("Hanya wifi")
                    Spacer(Modifier.width(12.dp))
                    Checkbox(checked = retry, onCheckedChange = { retry = it }); Text("Coba lagi")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { go(false) }) { Text("TAMBAH") }
                    Row {
                        TextButton(onClick = close) { Text("BATAL") }
                        TextButton(onClick = { go(true) }) { Text("MULAI") }
                    }
                }
            }
        }
    }
}
