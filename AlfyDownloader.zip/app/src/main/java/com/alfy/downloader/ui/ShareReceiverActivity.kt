package com.alfy.downloader.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.alfy.downloader.overlay.OverlayService
import com.alfy.downloader.part3.Part3
import com.alfy.downloader.part3.core.CaptureHub
import com.alfy.downloader.part3.core.Source

/** Share-intent ingestion (non-root fallback): "Share > AlfyD+" from any app or browser. */
class ShareReceiverActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Part3.init(this)
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT) ?: intent?.dataString
        val n = CaptureHub.submitText(text, Source.SHARE)
        // Keep the process alive while yt-dlp resolves the link, and show the results bubble.
        if (Settings.canDrawOverlays(this)) OverlayService.start(this)
        Toast.makeText(
            this,
            if (n > 0) "Link diterima — memeriksa dengan yt-dlp…" else "Tidak ada link baru / valid pada teks yang dibagikan",
            Toast.LENGTH_SHORT
        ).show()
        finish()
    }
}
