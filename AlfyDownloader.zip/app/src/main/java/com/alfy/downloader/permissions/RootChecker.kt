package com.alfy.downloader.permissions

import android.content.Context
import com.alfy.downloader.AppConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.IOException

/** Checks / requests root access by running `su -c id` (triggers the Magisk/KernelSU prompt). */
object RootChecker {
    private const val KEY_ROOT = "root_granted"

    private lateinit var appContext: Context

    @Volatile
    var isGranted: Boolean = false
        private set

    fun init(context: Context) {
        appContext = context.applicationContext
        isGranted = appContext.getSharedPreferences(AppConfig.PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_ROOT, false)
    }

    suspend fun check(): Boolean {
        val result = withContext(Dispatchers.IO) { runSu() }
        isGranted = result
        appContext.getSharedPreferences(AppConfig.PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ROOT, result).apply()
        return result
    }

    private suspend fun runSu(): Boolean {
        val process = try {
            Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
        } catch (e: IOException) {
            return false
        }
        return try {
            val code = withTimeoutOrNull(15_000L) { runInterruptible { process.waitFor() } }
            if (code != 0) {
                false
            } else {
                process.inputStream.bufferedReader().use { it.readText() }.contains("uid=0")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            false
        } finally {
            process.destroy()
        }
    }
}
