package com.alfy.downloader

import android.net.Uri
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

object Resolver {
    const val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    internal val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    internal val seen = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    private val pageRe = Regex(
        "(jwplyr\\.com/\\w|vidoy\\.(asia|com)/\\w|youtube\\.com/(watch\\?|shorts/|live/|embed/|clip/)|youtu\\.be/\\w|(x|twitter)\\.com/\\w+/status/\\d+|" +
        "facebook\\.com/(watch|reel/|share/|.+/videos/|video\\.php|story\\.php)|fb\\.watch/|fb\\.gg/|instagram\\.com/(reel|reels|p|tv|stories)/|" +
        "tiktok\\.com/.+/video/|vm\\.tiktok\\.com/|vt\\.tiktok\\.com/|vimeo\\.com/\\d+|dailymotion\\.com/video/|dai\\.ly/|" +
        "reddit\\.com/r/.+/comments/|v\\.redd\\.it/|twitch\\.tv/(videos/|\\w+/clip/)|clips\\.twitch\\.tv/|bilibili\\.com/video/|b23\\.tv/|" +
        "likee\\.video/|snapchat\\.com/(spotlight|add)/|threads\\.net/.+/post/|pinterest\\.[a-z.]+/pin/|pin\\.it/|rumble\\.com/v|" +
        "streamable\\.com/\\w|ok\\.ru/video|vk\\.com/video|soundcloud\\.com/[^/]+/[^/]+|bandcamp\\.com/track|mixcloud\\.com/[^/]+/[^/]+|" +
        "9gag\\.com/gag/|t\\.me/\\w+/\\d+|ted\\.com/talks/|odysee\\.com/|kick\\.com/video|" +
        "(x|twitter)\\.com/i/(status|web/status)/|reddit\\.com/r/\\w+/s/|facebook\\.com/.+/posts/|tiktok\\.com/t/|tiktok\\.com/@[^/]+/photo/|" +
        "instagram\\.com/[^/]+/(reel|p)/|youtube\\.com/@[^/]+/(videos|shorts|live)|music\\.youtube\\.com/|tumblr\\.com/post/|weibo\\.com/tv/|" +
        "douyin\\.com/video/|v\\.douyin\\.com/|kuaishou\\.com/|bilibili\\.tv/|tv\\.naver\\.com/|vlive\\.tv/|imdb\\.com/video/|" +
        "dailymotion\\.com/|archive\\.org/details/|vidio\\.com/watch/|viu\\.com/|iq\\.com/play/|bitchute\\.com/video/|peertube|lbry\\.tv/|rutube\\.ru/video/)"
    )

    fun extOf(url: String): String {
        val p = url.substringBefore('#').substringBefore('?').substringAfterLast('/')
        return if ('.' in p) p.substringAfterLast('.').lowercase() else ""
    }

    private val gvRe = Regex("https?://[^/\\s]*googlevideo\\.com/videoplayback")
    fun isGv(url: String) = gvRe.containsMatchIn(url)
    // Host file video yang URL-nya sering TANPA ekstensi (mis. mp4-06.overfetch.video/xxxx?token=...)
    private val hostMediaRe = Regex("^https?://[^/]*overfetch\\.video/", RegexOption.IGNORE_CASE)
    private val notMediaExt = setOf("html", "htm", "php", "js", "css", "json", "txt", "xml", "png", "jpg", "jpeg", "gif", "webp", "svg", "ico")
    fun isMedia(url: String) = isGv(url) || extOf(url).let { it in VIDEO_EXT || it in AUDIO_EXT } ||
        (hostMediaRe.containsMatchIn(url) && extOf(url) !in notMediaExt)
    /** Referer bawaan untuk host yang menolak permintaan tanpa Referer. */
    internal fun defaultRef(u: String): String? = if (hostMediaRe.containsMatchIn(u)) "https://jwplyr.com/" else null

    // v1.4: situs "embed" ber-iklan (jwplyr.com, asal video vidoy.asia, file di *.overfetch.video)
    private val jwPageRe = Regex("^https?://[^/]*(jwplyr\\.com|overfetch\\.video|vidoy\\.(asia|com))(:\\d+)?(/|$)", RegexOption.IGNORE_CASE)
    private val jwMediaOkRe = Regex("^https?://[^/]*(overfetch\\.video|vidoy\\.(asia|com)|jwplyr\\.com|backblazeb2\\.com)(:\\d+)?(/|$)", RegexOption.IGNORE_CASE)
    /** Halaman situs embed ber-iklan? (di halaman seperti ini, video dari host lain dianggap IKLAN). */
    internal fun isJwPage(u: String?): Boolean = u != null && jwPageRe.containsMatchIn(u)
    /** Host file video milik situs itu sendiri (bukan iklan). */
    internal fun jwMediaOk(u: String): Boolean = jwMediaOkRe.containsMatchIn(u)
    /** Referer yang dicoba berurutan bila host file video menolak (403). */
    private val jwRefs = listOf("https://vidoy.asia/", "https://jwplyr.com/")
    /** Alasan penolakan terakhir (untuk log alat) - ditulis addMediaChecked. */
    internal val rejects = java.util.concurrent.ConcurrentLinkedQueue<String>()
    internal fun noteReject(s: String) { rejects.add(s); while (rejects.size > 12) rejects.poll() }
    /** Halaman yang butuh CAPTCHA (diisi alat bila gagal karena CAPTCHA); dibuka lewat tombol 🌐 di panel. */
    @Volatile var captchaPage: String = ""
    fun isPage(url: String) = pageRe.containsMatchIn(url)
    fun reset() = seen.clear()
    /** Pindai ulang paksa (misal tautan disalin lagi / diklik lagi). */
    private val lastRescan = java.util.concurrent.ConcurrentHashMap<String, Long>()
    fun rescan(url: String, referer: String? = null) {
        val u = url.trim()
        val now = System.currentTimeMillis()
        val prev = lastRescan[u]
        if (prev != null && now - prev < 4000) return
        lastRescan[u] = now
        seen.remove(u); submit(u, referer, true)
    }
    @Volatile var lastPage: String = ""
    private val sniffed = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val mediaRe = Regex("https?:(?:\\\\?/){2}[^\\s\"'<>\\\\]+?\\.(?:mp4|m3u8|webm|mkv|mp3|m4a|aac|ogg|wav|flac)(?:\\?[^\\s\"'<>\\\\]*)?")

    /** Cari paksa file media di dalam halaman web (HTML) secara online. */
    fun sniff(page: String, force: Boolean = false) {
        if (!page.startsWith("http") || isMedia(page)) return
        if (!sniffed.add(page) && !force) return
        scope.launch {
            try {
                val html = getText(page, null).take(2_000_000)
                mediaRe.findAll(html).map { it.value.replace("\\/", "/").replace("&amp;", "&") }
                    .distinct().take(15).forEach { submit(it, page) }
            } catch (e: Exception) { }
        }
    }

    /** Seperti sniff() tetapi menunggu hasil; mengembalikan jumlah media yang ditemukan di HTML halaman. */
    internal fun sniffSync(page: String): Int {
        if (!page.startsWith("http") || isMedia(page)) return 0
        val html = getText(page, null).take(2_000_000)
        val l = mediaRe.findAll(html).map { it.value.replace("\\/", "/").replace("&amp;", "&") }.distinct().take(15).toList()
        l.forEach { submit(it, page) }
        return l.size
    }

    internal class Probe(val ok: Boolean, val size: Long, val type: String, val code: Int, val html: Boolean)

    /** Cek cepat apakah alamat benar-benar file media (HEAD, lalu GET Range 0-0 bila HEAD ditolak). */
    internal fun probe(u: String, ref: String?): Probe {
        var code = 0; var size = -1L; var type = ""
        try {
            val c = open(u, ref, "HEAD"); c.connectTimeout = 6000; c.readTimeout = 6000
            code = c.responseCode; size = c.contentLengthLong; type = c.contentType ?: ""
            c.disconnect()
        } catch (e: Exception) { }
        if (code == 0 || code == 403 || code == 405 || code == 501) {
            try {
                val c = open(u, ref, "GET"); c.connectTimeout = 6000; c.readTimeout = 6000
                c.setRequestProperty("Range", "bytes=0-0")
                code = c.responseCode; type = c.contentType ?: ""
                size = c.getHeaderField("Content-Range")?.substringAfter('/')?.toLongOrNull() ?: c.contentLengthLong
                c.disconnect()
            } catch (e: Exception) { }
        }
        val t = type.lowercase()
        val html = t.startsWith("text/") || t.contains("html") || t.contains("json")
        val mediaType = t.startsWith("video/") || t.startsWith("audio/") || t.contains("mpegurl") || t.contains("octet-stream") ||
            t.contains("mp4") || t.contains("matroska")
        val okExt = t.isEmpty() && (extOf(u) in VIDEO_EXT || extOf(u) in AUDIO_EXT)
        return Probe(code in 200..299 && (mediaType || okExt), size, t, code, html)
    }

    /**
     * Periksa lalu tambahkan satu alamat media ke daftar (berjalan di thread pemanggil, jadi label sumber [alat] ikut benar).
     * trust = alamat ini benar-benar diminta pemutar halaman (bukan tebakan): tetap diterima walau pemeriksaan ditolak,
     * selama ekstensinya media. true = ada link yang masuk daftar.
     */
    internal fun addMediaChecked(u0: String, ref0: String?, title: String = "", trust: Boolean = false): Boolean {
        val u = u0.trim().replace("\\u0026", "&").replace("&amp;", "&")
        if (!u.startsWith("http")) return false
        var ref = ref0 ?: defaultRef(u)
        if (isGv(u)) { gv(u, ref); return true }
        var p = probe(u, ref)
        // v1.4: host file video sering menolak Referer yang salah -> coba Referer lain (vidoy.asia / jwplyr.com)
        if (!p.ok && hostMediaRe.containsMatchIn(u)) {
            for (r in jwRefs) {
                if (r == ref) continue
                val p2 = probe(u, r)
                if (p2.ok) { p = p2; ref = r; break }
            }
        }
        val extMedia = extOf(u) in VIDEO_EXT || extOf(u) in AUDIO_EXT
        if (!p.ok && !(trust && (extMedia || hostMediaRe.containsMatchIn(u)) && !p.html)) {
            noteReject("${p.code} ${(Uri.parse(u).host ?: "?").take(24)} ${p.type.substringBefore(';').take(16)}".trim())
            return false
        }
        if (extOf(u) == "m3u8" || p.type.contains("mpegurl")) return try { hls(u, ref) } catch (e: Exception) { false }
        val ext = extOf(u).ifEmpty { if (p.type.startsWith("audio/")) "mp3" else "mp4" }
        Repo.addCandidates(listOf(Candidate(
            key = "D" + key(u), url = u, title = title.ifBlank { nameOf(u) }, kind = Kind.DIRECT,
            isAudio = ext in AUDIO_EXT || p.type.startsWith("audio/"), ext = ext, size = p.size, quality = resOf(u),
            duration = 0, formatSel = null, previewUrl = u, referer = ref
        )))
        return true
    }

    /** Alamat media yang pasti media (dari pemutar di Browser Alfy / DownloadListener) walau tanpa ekstensi. */
    fun submitMedia(url: String, referer: String?) {
        val u = url.trim()
        if (!u.startsWith("http") || !seen.add(u)) return
        scope.launch { try { addMediaChecked(u, referer, "", true) } catch (e: Exception) { } }
    }

    fun submit(url: String, referer: String? = null, force: Boolean = false) {
        val u = url.trim()
        if (!u.startsWith("http")) return
        val media = isMedia(u)
        if (!media && !isPage(u) && !force) return
        if (!seen.add(u)) return
        scope.launch {
            try {
                when {
                    media && extOf(u) == "m3u8" -> hls(u, referer)
                    media -> direct(u, referer)
                    else -> ytdlp(u)
                }
            } catch (e: Exception) {
                diag = "Gagal baca link: " + (e.message ?: e.javaClass.simpleName).take(120)
                if (!media) seen.remove(u)
            }
        }
    }

    private fun open(u: String, ref: String?, method: String = "GET"): HttpURLConnection {
        val c = URL(u).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 10000; c.readTimeout = 10000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        (ref ?: defaultRef(u))?.let { c.setRequestProperty("Referer", it) }
        // cookies hasil lolos CAPTCHA di Browser Alfy (bukan untuk YouTube/Google)
        if (!u.contains("youtube.com") && !u.contains("googlevideo.com") && !u.contains("google.com")) try {
            android.webkit.CookieManager.getInstance().getCookie(u)?.let { if (it.isNotBlank()) c.setRequestProperty("Cookie", it) }
        } catch (e: Throwable) { }
        return c
    }

    private fun key(u: String): String = try { val x = Uri.parse(u); "${x.host}${x.path}" } catch (e: Exception) { u }
    private fun nameOf(u: String): String {
        val p = Uri.decode(u.substringBefore('#').substringBefore('?').substringAfterLast('/'))
        return p.substringBeforeLast('.').ifBlank { "file" }
    }
    private fun resOf(u: String): String {
        Regex("(\\d{3,4})x(\\d{3,4})").find(u)?.let { return it.value }
        Regex("(\\d{3,4})p").find(u)?.let { return it.value }
        return "-"
    }
    internal fun getText(u: String, ref: String?): String {
        val c = open(u, ref)
        try { return c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }
    private fun durOf(txt: String): Long =
        Regex("#EXTINF:([\\d.]+)").findAll(txt).sumOf { it.groupValues[1].toDouble() }.toLong()

    private fun direct(u: String, ref0: String?) {
        if (isGv(u)) { gv(u, ref0); return }
        val ref = ref0 ?: defaultRef(u)
        var size = -1L
        var type = ""
        try {
            val c = open(u, ref, "HEAD")
            size = c.contentLengthLong; type = c.contentType ?: ""
            c.disconnect()
        } catch (e: Exception) { }
        if (type.startsWith("text/")) return
        val ext = extOf(u).ifEmpty { if (type.startsWith("audio/")) "mp3" else "mp4" }
        Repo.addCandidates(listOf(Candidate(
            key = "D" + key(u), url = u, title = nameOf(u), kind = Kind.DIRECT,
            isAudio = ext in AUDIO_EXT, ext = ext, size = size, quality = resOf(u),
            duration = 0, formatSel = null, previewUrl = u, referer = ref
        )))
    }


    // ---------- Link asli YouTube: googlevideo.com/videoplayback ----------
    @Volatile var latestTitle: String = ""
    internal val titleById = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val gvAudio = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val gvAudioSize = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val gvPrev = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val gvPrevSize = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val gvMux = java.util.concurrent.ConcurrentHashMap<String, String>()
    // hanya video H.264 (avc) yang bisa diputar semua HP; AV1/VP9 dibuang
    private val avcVideo = setOf("133", "134", "135", "136", "137", "160", "264", "266", "298", "299")
    private val itagQ = mapOf(
        "18" to "360p", "22" to "720p", "37" to "1080p", "59" to "480p", "133" to "240p", "134" to "360p",
        "135" to "480p", "136" to "720p", "137" to "1080p", "160" to "144p", "298" to "720p", "299" to "1080p",
        "242" to "240p", "243" to "360p", "244" to "480p", "247" to "720p", "248" to "1080p", "278" to "144p"
    )
    private val itagA = mapOf("139" to "48k", "140" to "128k", "141" to "256k", "249" to "50k", "250" to "70k", "251" to "160k", "256" to "192k", "258" to "384k")
    private val muxedItags = setOf("17", "18", "22", "36", "37", "43", "59", "78")
    const val UA_IOS = "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"
    const val UA_VR = "com.google.android.apps.youtube.vr.oculus/1.62.27 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
    const val UA_AND = "com.google.android.youtube/19.44.38 (Linux; U; Android 14) gzip"

    internal fun qp(u: String, k: String): String = try { Uri.parse(u).getQueryParameter(k) ?: "" } catch (e: Exception) { "" }

    fun uaForGv(u: String): String = when (qp(u, "c").uppercase()) {
        "IOS" -> UA_IOS
        "ANDROID_VR" -> UA_VR
        "ANDROID" -> UA_AND
        else -> UA
    }

    /** Buang parameter potongan (range/rn/rbuf) supaya link bisa diunduh utuh. */
    private fun cleanGv(u: String): String = try {
        val x = Uri.parse(u)
        val b = x.buildUpon().clearQuery()
        for (n in x.queryParameterNames) {
            if (n == "range" || n == "rn" || n == "rbuf" || n == "alr") continue
            for (v in x.getQueryParameters(n)) b.appendQueryParameter(n, v)
        }
        b.build().toString()
    } catch (e: Exception) { u }

    fun gv(raw: String, ref: String?, titleHint: String = "") {
        val u = cleanGv(raw.replace("\\u0026", "&").replace("&amp;", "&"))
        val id = qp(u, "id").ifEmpty { qp(u, "ei") }
        if (id.isEmpty()) return
        val itag = qp(u, "itag")
        val mime = qp(u, "mime")
        val isAudio = mime.startsWith("audio")
        val muxed = !isAudio && itag in muxedItags
        val videoOnly = !isAudio && !muxed
        if (videoOnly && mime.contains("webm")) return   // webm tanpa suara tidak bisa digabung ke mp4
        val clen = qp(u, "clen").toLongOrNull() ?: -1L
        val dur = qp(u, "dur").toDoubleOrNull()?.toLong() ?: 0L
        val ext = when {
            mime.contains("webm") -> "webm"
            isAudio -> "m4a"
            else -> "mp4"
        }
        if (ext != "m4a" && ext != "mp4") return          // hanya m4a (suara) dan mp4 (video)
        if (videoOnly && itag !in avcVideo) return        // codec AV1/VP9 sering tidak bisa diputar
        val grp = id + "|" + qp(u, "c")
        if (muxed && ext == "mp4" && (gvMux[grp] == null || itag == "18")) gvMux[grp] = u
        if (titleHint.isNotBlank()) { titleById[id] = titleHint; latestTitle = titleHint }
        val title = titleById[id] ?: latestTitle.ifBlank { "YouTube video" }
        val ua = uaForGv(u)
        if (isAudio) {
            if (ext == "m4a" && (gvAudio[grp] == null || (clen > (gvAudioSize[grp] ?: 0L)))) {
                gvAudio[grp] = u; gvAudioSize[grp] = clen
                // pasangkan ke video-only yang sudah terdeteksi lebih dulu
                Repo.detected.update { l ->
                    l.map { c ->
                        if (c.key.startsWith("G$id|") && c.muted && !c.isAudio)
                            c.copy(audioUrl = u, formatSel = "UA:$ua\nMERGE:$u\nAUA:$ua\n",
                                size = if (c.size > 0 && clen > 0) c.size + clen else c.size)
                        else c
                    }
                }
            }
            Repo.addCandidates(listOf(Candidate(
                key = "G$id|$itag", url = u, title = title, kind = Kind.DIRECT, isAudio = true, ext = ext, size = clen,
                quality = "audio " + (itagA[itag] ?: "") + " " + ext.uppercase(), duration = dur, formatSel = "UA:$ua\n",
                previewUrl = u, referer = ref, audioUrl = u)))
            return
        }
        if (videoOnly && ext == "mp4" && clen > 0) {
            val cur = gvPrevSize[grp]
            if (cur == null || clen < cur) { gvPrev[grp] = u; gvPrevSize[grp] = clen }
        }
        val au = if (videoOnly && ext == "mp4") gvAudio[grp] else null
        val sel = if (au != null) "UA:$ua\nMERGE:$au\nAUA:$ua\n" else "UA:$ua\n"
        Repo.addCandidates(listOf(Candidate(
            key = "G$id|$itag", url = u, title = title, kind = Kind.DIRECT, isAudio = false, ext = ext,
            size = if (au != null && clen > 0) clen + (gvAudioSize[grp] ?: 0L) else clen,
            quality = itagQ[itag] ?: "video", duration = dur, formatSel = sel,
            previewUrl = u, referer = ref, audioUrl = au, muted = videoOnly)))
    }

    class PrevInfo(val url: String, val audio: String?, val muted: Boolean, val fallback: String? = null)

    /** Pratinjau memakai kualitas yang SAMA dengan item yang dipilih (bukan resolusi kecil). Cadangan dipakai bila gagal. */
    fun previewInfo(c: Candidate): PrevInfo {
        if (!isGv(c.url) || c.isAudio) return PrevInfo(c.previewUrl, c.audioUrl, c.muted, c.fallbackUrl)
        val grp = qp(c.url, "id") + "|" + qp(c.url, "c")
        if (qp(c.url, "itag") in muxedItags) return PrevInfo(c.url, null, false, null)
        val a = gvAudio[grp] ?: c.audioUrl
        val mux = gvMux[grp]
        if (a != null) return PrevInfo(c.url, a, true, mux ?: gvPrev[grp])
        return PrevInfo(mux ?: c.url, null, false, null)
    }

    internal fun probeOk(u: String, ua: String): Boolean = try {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 6000
        c.setRequestProperty("User-Agent", ua); c.setRequestProperty("Range", "bytes=0-0")
        val ok = c.responseCode in 200..299
        c.disconnect(); ok
    } catch (e: Exception) { false }

    /** Satu permintaan Range seperti pemutar. >0 = byte terbaca, <0 = kode HTTP error, 0 = gagal koneksi. 416 dianggap lolos. */
    private fun rangeProbe(u: String, off: Long): Int = try {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 5000; c.readTimeout = 6000
        c.setRequestProperty("User-Agent", uaForGv(u)); c.setRequestProperty("Range", "bytes=$off-${off + 16383}")
        val code = c.responseCode
        var n = 0
        if (code in 200..299) c.inputStream.use { s ->
            val b = ByteArray(4096)
            while (n < 8192) { val r = s.read(b); if (r < 0) break; n += r }
        }
        c.disconnect()
        if (code == 416) 1 else if (code in 200..299) n else -code
    } catch (e: Exception) { 0 }

    /**
     * v1.4: uji link googlevideo seperti pemutar sungguhan. Uji awal (byte 0) SAJA tidak cukup: link yang butuh PO Token
     * (klien iOS/Android) biasanya lolos di potongan pertama tetapi 403 di potongan berikutnya -> itu penyebab "loading lalu 403".
     * Karena itu diuji juga satu potongan di kedalaman ~6MB (atau tengah file).
     */
    internal fun probePlay(u: String): Boolean {
        if (rangeProbe(u, 0L) <= 0) return false
        val clen = qp(u, "clen").toLongOrNull() ?: -1L
        if (clen in 1..1_500_000L) return true
        val off = if (clen > 0) minOf(6_000_000L, clen / 2) else 6_000_000L
        return rangeProbe(u, off) > 0
    }

    /** Jalur cepat ala 1DM+/TubeMate: minta langsung ke API pemutar YouTube, hanya ambil link googlevideo asli. */
    internal fun ytFast(id: String, why: StringBuilder = StringBuilder()): Boolean {
        val clients = listOf(
            // v1.4: ANDROID_VR dulu (tidak butuh PO Token); IOS butuh PO Token untuk link https -> sering 403 di potongan ke-2
            Triple("ANDROID_VR", "1.62.27", "28"),
            Triple("IOS", "20.10.4", "5")
        )
        for ((name, ver, num) in clients) {
            try {
                val j = if (name == "IOS")
                    innertube(id, "IOS", ver, "\"deviceMake\":\"Apple\",\"deviceModel\":\"iPhone16,2\",\"osName\":\"iPhone\",\"osVersion\":\"18.3.2.22D82\",", UA_IOS, num)
                else
                    innertube(id, "ANDROID_VR", ver, "\"deviceMake\":\"Oculus\",\"deviceModel\":\"Quest 3\",\"osName\":\"Android\",\"osVersion\":\"12L\",\"androidSdkVersion\":32,", UA_VR, num)
                val pst = j.optJSONObject("playabilityStatus")?.optString("status", "OK") ?: "OK"
                if (pst != "OK") { why.append("$name:$pst "); continue }
                val title = j.optJSONObject("videoDetails")?.optString("title", "") ?: ""
                val sd = j.optJSONObject("streamingData") ?: run { why.append("$name:tanpa stream "); null } ?: continue
                val urls = ArrayList<String>()
                for (k in listOf("formats", "adaptiveFormats")) {
                    val arr = sd.optJSONArray(k) ?: continue
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        val u = o.optString("url", "")
                        if (isGv(u)) urls.add(u)
                    }
                }
                if (urls.isEmpty()) { why.append("$name:tanpa link "); continue }
                // v1.3: tiap link diuji dulu seperti pemutar (GET Range, UA sesuai klien); hanya yang lolos masuk daftar
                val good = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
                val ths = urls.take(14).map { u -> Thread { if (probePlay(u)) good.add(u) }.apply { isDaemon = true; start() } }
                ths.forEach { try { it.join(7000) } catch (e: Exception) { } }
                val okUrls = urls.filter { it in good }
                if (okUrls.isEmpty()) { why.append("$name:403 (0/${urls.size} lolos uji ${if (name == "IOS") "- butuh PO Token" else ""}) "); continue }
                if (title.isNotBlank()) { titleById[id] = title; latestTitle = title }
                // audio dulu supaya video-only langsung berpasangan
                okUrls.sortedBy { if (qp(it, "mime").startsWith("audio")) 0 else 1 }.forEach { gv(it, null, title) }
                return true
            } catch (e: Exception) { why.append("$name:${(e.message ?: e.javaClass.simpleName).take(40)} ") }
        }
        return false
    }

    private fun hls(u: String, ref: String?): Boolean {
        val txt = getText(u, ref)
        val out = mutableListOf<Candidate>()
        if ("#EXT-X-STREAM-INF" in txt) {
            val lines = txt.lines()
            var firstDur = -1L
            for (i in lines.indices) {
                val l = lines[i]
                if (!l.startsWith("#EXT-X-STREAM-INF")) continue
                val bw = Regex("BANDWIDTH=(\\d+)").find(l)?.groupValues?.get(1)?.toLong() ?: 0L
                val res = Regex("RESOLUTION=(\\d+x\\d+)").find(l)?.groupValues?.get(1)
                val hh = res?.substringAfter('x')?.toIntOrNull()
                if (hh != null && (hh < 200 || hh > 1100)) continue
                var j = i + 1
                while (j < lines.size && (lines[j].isBlank() || lines[j].startsWith("#"))) j++
                if (j >= lines.size) continue
                val vu = URI(u).resolve(lines[j].trim()).toString()
                if (firstDur < 0) firstDur = try { durOf(getText(vu, ref)) } catch (e: Exception) { 0L }
                out.add(Candidate(
                    key = "H" + key(vu), url = vu, title = nameOf(u), kind = Kind.HLS,
                    isAudio = false, ext = "mp4", size = bw * firstDur / 8,
                    quality = res ?: "${bw / 1000}kbps", duration = firstDur,
                    formatSel = null, previewUrl = vu, referer = ref
                ))
            }
        } else {
            out.add(Candidate(
                key = "H" + key(u), url = u, title = nameOf(u), kind = Kind.HLS, isAudio = false,
                ext = "mp4", size = -1, quality = "-", duration = durOf(txt),
                formatSel = null, previewUrl = u, referer = ref
            ))
        }
        Repo.addCandidates(out)
        return out.isNotEmpty()
    }

    @Volatile var diag: String = ""
    @Volatile var latestYt: String = ""

    private fun jtext(j: org.json.JSONObject?): String {
        if (j == null) return ""
        val s = j.optString("simpleText", "")
        if (s.isNotEmpty()) return s
        return j.optJSONArray("runs")?.optJSONObject(0)?.optString("text", "") ?: ""
    }

    private fun tokens(t: String): Set<String> =
        t.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 }.toSet()

    private fun lenSec(v: org.json.JSONObject): Int {
        val t = jtext(v.optJSONObject("lengthText"))
        if (t.isEmpty()) return 0
        return t.split(":").mapNotNull { it.toIntOrNull() }.fold(0) { a, x -> a * 60 + x }
    }

    /** Pencarian cepat lewat API web YouTube, lalu pilih hasil yang paling cocok dengan teks di layar. */
    private fun quickSearch(q: String, shorts: Boolean): Pair<String, String>? {
        val body = "{\"context\":{\"client\":{\"clientName\":\"WEB\",\"clientVersion\":\"2.20250101.00.00\",\"hl\":\"id\",\"gl\":\"ID\"}},\"query\":${org.json.JSONObject.quote(q)}}"
        val txt = post("https://www.youtube.com/youtubei/v1/search?prettyPrint=false", body,
            mapOf("User-Agent" to UA, "Origin" to "https://www.youtube.com"))
        class Hit(val id: String, val title: String, val blob: String, val short: Boolean)
        val found = mutableListOf<Hit>()
        fun walk(o: Any?) {
            if (found.size >= 20) return
            when (o) {
                is org.json.JSONObject -> {
                    for (k in o.keys()) {
                        val v = o.opt(k)
                        if ((k == "videoRenderer" || k == "reelItemRenderer") && v is org.json.JSONObject) {
                            val id = v.optString("videoId", "")
                            if (id.length == 11) {
                                val sec = if (k == "videoRenderer") lenSec(v) else 0
                                found.add(Hit(id, jtext(v.optJSONObject("title") ?: v.optJSONObject("headline")), v.toString().lowercase(),
                                    k == "reelItemRenderer" || (sec in 1..61)))
                            }
                        } else if (k == "shortsLockupViewModel" && v is org.json.JSONObject) {
                            // format baru hasil pencarian Shorts
                            val blob = v.toString()
                            val id = Regex("\"videoId\":\"([\\w-]{11})\"").find(blob)?.groupValues?.get(1)
                                ?: Regex("shorts-shelf-item-([\\w-]{11})").find(blob)?.groupValues?.get(1) ?: ""
                            if (id.length == 11) {
                                val t = v.optJSONObject("overlayMetadata")?.optJSONObject("primaryText")?.optString("content", "") ?: ""
                                found.add(Hit(id, t, blob.lowercase(), true))
                            }
                        } else walk(v)
                    }
                }
                is org.json.JSONArray -> for (i in 0 until o.length()) walk(o.opt(i))
            }
        }
        walk(org.json.JSONObject(txt))
        if (found.isEmpty()) return null
        val handle = Regex("@[A-Za-z0-9._-]{3,}").find(q)?.value?.lowercase()
        val cap = tokens(if (handle != null) q.replace(Regex("(?i)" + Regex.escape(handle)), " ") else q)
        var best: Hit? = null
        var bestScore = -1.0
        for (h in found) {
            var sc = 0.0
            if (handle != null && h.blob.contains(handle)) sc += 6.0
            if (cap.isNotEmpty()) sc += 5.0 * tokens(h.title).intersect(cap).size / cap.size
            if (shorts && h.short) sc += 1.5
            if (sc > bestScore) { bestScore = sc; best = h }
        }
        val pick = best ?: found.first()
        return Pair(pick.id, pick.title)
    }

    /** Cari URL YouTube dari teks yang terlihat/diputar di aplikasi YouTube. */
    fun searchYoutube(query: String, shorts: Boolean = false, manual: Boolean = false) {
        if (query.isBlank()) { diag = "YouTube: belum ada teks video terbaca"; return }
        diag = "YouTube: mencari \"${query.take(60)}\"…"
        scope.launch {
            try {
                var id: String? = null
                var title = ""
                try { quickSearch(query, shorts)?.let { id = it.first; title = it.second } } catch (e: Exception) { }
                if (id == null) {
                    Engine.await()
                    val req = YoutubeDLRequest("ytsearch5:$query")
                    req.addOption("--flat-playlist")
                    req.addOption("--no-warnings")
                    req.addOption("--print", "%(id)s|%(uploader_id)s|%(title)s")
                    val lines = YoutubeDL.getInstance().execute(req).out.trim().lines()
                        .map { it.trim() }.filter { Regex("^[\\w-]{11}\\|").containsMatchIn(it) }
                    val handle = Regex("@[A-Za-z0-9._-]{3,}").find(query)?.value?.lowercase()?.removePrefix("@")
                    val pick = (if (handle != null) lines.firstOrNull { it.lowercase().contains(handle) } else null)
                        ?: lines.firstOrNull()
                    if (pick != null) { id = pick.substring(0, 11); title = pick.substringAfterLast('|') }
                }
                val vid = id
                if (vid == null) { diag = "YouTube: pencarian tanpa hasil"; return@launch }
                val url = "https://www.youtube.com/watch?v=$vid"
                diag = "YouTube: ketemu $vid"
                if (title.isNotBlank()) { titleById[vid] = title; latestTitle = title }
                if (manual) seen.remove(url)
                submit(url, null, true)
            } catch (e: Exception) { diag = "YouTube gagal: " + (e.message ?: e.javaClass.simpleName).take(120) }
        }
    }

    @Volatile var ytArgs: String? = null
    // android_vr paling akhir: formatnya butuh PO Token sehingga unduhan sering 403.
    val YT_CLIENTS: List<String?> = listOf("youtube:player_client=tv,web_safari", "youtube:player_client=ios", null,
        "youtube:player_client=tv_simply", "youtube:player_client=mweb", "youtube:player_client=android_vr")
    internal val ytRe = Regex("(?:youtu\\.be/|youtube\\.com/(?:watch\\?v=|shorts/|live/|embed/))([\\w-]{11})")

    private fun ytdlp(u: String) {
        val yt = ytRe.find(u)
        if (yt != null) { Chain.run(yt.groupValues[1], u); return }
        Chain.runGeneric(u)
    }

    /** yt-dlp: mencoba beberapa klien. cookies = path file cookies (opsional). Melempar error bila semua gagal. */
    fun ytdlpTool(u: String, cookies: String?) {
        val yt = ytRe.find(u)
        Engine.await()
        val tries: List<String?> = if (yt != null) (if (cookies != null) listOf("youtube:player_client=web_safari,mweb", "youtube:player_client=tv", null, "youtube:player_client=web") else YT_CLIENTS) else listOf(null)
        var raw: String? = null
        var lastErr: Exception? = null
        for (t in tries) {
            try {
                val req = YoutubeDLRequest(u)
                req.addOption("--no-playlist")
                req.addOption("--no-warnings")
                req.addOption("--dump-single-json")
                req.addOption("--socket-timeout", "10")
                req.addOption("--extractor-retries", "1")
                req.addOption("--force-ipv4")
                if (cookies != null) req.addOption("--cookies", cookies)
                if (t != null) req.addOption("--extractor-args", t)
                raw = YoutubeDL.getInstance().execute(req).out
                ytArgs = t
                break
            } catch (e: Exception) { lastErr = e; if (yt == null) diag = "yt-dlp ${t ?: "default"} gagal, coba cara lain…" }
        }
        if (raw == null) throw lastErr ?: Exception("tidak bisa membaca video")
        val j = org.json.JSONObject(raw.substring(raw.indexOf('{')))
        val title = j.optString("title").ifBlank { nameOf(u) }
        val dur = j.optDouble("duration", 0.0).toLong()
        val fm = j.optJSONArray("formats")
        val out = mutableListOf<Candidate>()
        fun has(s: String) = s.isNotEmpty() && s != "none" && s != "null"
        class Fm(val o: org.json.JSONObject) {
            val h = o.optInt("height", 0)
            val hasV = has(o.optString("vcodec", "none"))
            val hasA = has(o.optString("acodec", "none"))
            val url = o.optString("url", "")
            val ext = o.optString("ext", "mp4")
            val hls = o.optString("protocol", "").startsWith("m3u8")
            val size = o.optLong("filesize", 0L).let { if (it > 0) it else o.optLong("filesize_approx", 0L) }
            val abr = o.optDouble("abr", 0.0)
            val ua = o.optJSONObject("http_headers")?.optString("User-Agent", "") ?: ""
            val vc = o.optString("vcodec", "")
            val lp = o.optInt("language_preference", -1)
            val note = o.optString("format_note", "").lowercase()
            val score: Double get() = lp * 1000.0 + abr + (if (note.contains("original") || note.contains("default")) 5000.0 else 0.0) - (if (note.contains("dubbed")) 5000.0 else 0.0)
        }
        val all = ArrayList<Fm>()
        if (fm != null) for (i in 0 until fm.length()) {
            val f = Fm(fm.optJSONObject(i) ?: continue)
            if (f.url.startsWith("http")) all.add(f)
        }
        if (yt != null && all.any { isGv(it.url) && !it.hls }) all.retainAll { isGv(it.url) && !it.hls }
        fun spec(ua: String, extra: String = ""): String? {
            val s = (if (ua.isNotEmpty()) "UA:$ua\n" else "") + extra
            return s.ifEmpty { null }
        }
        val allowed = intArrayOf(240, 360, 480, 720, 1080)
        fun bucket(h: Int): Int = if (h < 200 || h > 1100) 0 else allowed.minByOrNull { Math.abs(it - h) }!!
        val audios = all.filter { !it.hasV && it.hasA && !it.hls }
        val bestM4a = audios.filter { it.ext == "m4a" }.maxByOrNull { it.score }
        // alamat pratinjau cepat: video+suara resolusi kecil (mp4)
        val muxedMp4 = all.filter { it.hasV && it.hasA && !it.hls && it.ext == "mp4" && it.h > 0 }
        val hlsMux = all.filter { it.hasV && it.hasA && it.hls && it.h > 0 }
        val previewV = (muxedMp4.filter { it.h <= 360 }.maxByOrNull { it.h } ?: muxedMp4.minByOrNull { it.h }
            ?: hlsMux.filter { it.h <= 360 }.maxByOrNull { it.h } ?: hlsMux.minByOrNull { it.h })?.url
        for (b in allowed.reversedArray()) {
            val g = all.filter { it.hasV && bucket(it.h) == b }
            if (g.isEmpty()) continue
            val mux = g.filter { it.hasA && !it.hls && it.ext == "mp4" }.maxByOrNull { it.size }
            val vonly = g.filter { !it.hasA && !it.hls && it.ext == "mp4" && it.vc.startsWith("avc") }.maxByOrNull { it.size }
            val hlsF = g.filter { it.hasA && it.hls }.maxByOrNull { it.h }
            val other = g.filter { it.hasA && !it.hls && it.ext == "mp4" }.maxByOrNull { it.size }
            when {
                mux != null -> out.add(Candidate(key = "Y$u|$b", url = mux.url, title = title, kind = Kind.DIRECT, isAudio = false, ext = "mp4",
                    size = if (mux.size > 0) mux.size else -1, quality = "${b}p", duration = dur, formatSel = spec(mux.ua),
                    previewUrl = mux.url, referer = null, audioUrl = bestM4a?.url, fallbackUrl = previewV))
                vonly != null && bestM4a != null -> out.add(Candidate(key = "Y$u|$b", url = vonly.url, title = title, kind = Kind.DIRECT,
                    isAudio = false, ext = "mp4", size = if (vonly.size > 0) vonly.size + bestM4a.size else -1, quality = "${b}p", duration = dur,
                    formatSel = spec(vonly.ua, "MERGE:${bestM4a.url}\nAUA:${bestM4a.ua}\n"), previewUrl = vonly.url, referer = null, audioUrl = bestM4a.url, muted = true, fallbackUrl = previewV))
                hlsF != null -> out.add(Candidate(key = "Y$u|$b", url = hlsF.url, title = title, kind = Kind.HLS, isAudio = false, ext = "mp4",
                    size = -1, quality = "${b}p", duration = dur, formatSel = null, previewUrl = hlsF.url, referer = null, audioUrl = bestM4a?.url, fallbackUrl = previewV))
                other != null -> out.add(Candidate(key = "Y$u|$b", url = other.url, title = title, kind = Kind.DIRECT, isAudio = false, ext = other.ext,
                    size = if (other.size > 0) other.size else -1, quality = "${b}p", duration = dur, formatSel = spec(other.ua),
                    previewUrl = other.url, referer = null, audioUrl = bestM4a?.url, fallbackUrl = previewV))
            }
        }
        // audio: hanya m4a (paling sering bisa diputar)
        val au = bestM4a
        if (au != null) out.add(Candidate(key = "Y$u|a", url = au.url, title = title, kind = Kind.DIRECT, isAudio = true, ext = au.ext,
            size = if (au.size > 0) au.size else -1, quality = "audio ${au.abr.toInt()}k ${au.ext.uppercase()}", duration = dur,
            formatSel = spec(au.ua), previewUrl = au.url, referer = null, audioUrl = au.url))
        if (out.isEmpty()) throw Exception("tidak ada format yang bisa diunduh")
        Repo.addCandidates(out)
    }

    internal fun post(url: String, body: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 12000; c.readTimeout = 15000
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray()) }
        try { return c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    internal fun innertube(id: String, name: String, ver: String, extra: String, ua: String, num: String): org.json.JSONObject {
        val body = "{\"context\":{\"client\":{\"clientName\":\"$name\",\"clientVersion\":\"$ver\",$extra\"hl\":\"en\",\"gl\":\"US\"}}," +
            "\"videoId\":\"$id\",\"contentCheckOk\":true,\"racyCheckOk\":true}"
        val txt = post("https://www.youtube.com/youtubei/v1/player?prettyPrint=false", body,
            mapOf("User-Agent" to ua, "X-YouTube-Client-Name" to num, "X-YouTube-Client-Version" to ver, "Origin" to "https://www.youtube.com"))
        return org.json.JSONObject(txt)
    }

    /** Cara cadangan ala situs downloader: API internal YouTube (klien iOS/Android VR) lalu Piped. */
    internal fun youtubeFallback(id: String, page: String): Boolean {
        val out = mutableListOf<Candidate>()
        var title = "YouTube $id"
        var dur = 0L
        // 1) Klien iOS: manifest HLS berisi video+audio sudah menyatu
        try {
            val j = innertube(id, "IOS", "20.10.4", "\"deviceMake\":\"Apple\",\"deviceModel\":\"iPhone16,2\",\"osName\":\"iPhone\",\"osVersion\":\"18.3.2.22D82\",",
                "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)", "5")
            j.optJSONObject("videoDetails")?.let { title = it.optString("title", title); dur = it.optString("lengthSeconds", "0").toLongOrNull() ?: 0L }
            val sd = j.optJSONObject("streamingData")
            val hlsUrl = sd?.optString("hlsManifestUrl", "") ?: ""
            if (hlsUrl.isNotEmpty()) {
                val txt = getText(hlsUrl, null)
                var k = 0
                val lines = txt.lines()
                for (i in lines.indices) {
                    if (!lines[i].startsWith("#EXT-X-STREAM-INF")) continue
                    val res = Regex("RESOLUTION=(\\d+)x(\\d+)").find(lines[i])
                    var q = i + 1
                    while (q < lines.size && (lines[q].isBlank() || lines[q].startsWith("#"))) q++
                    if (q >= lines.size) continue
                    val vu = URI(hlsUrl).resolve(lines[q].trim()).toString()
                    val h = res?.groupValues?.get(2) ?: "?"
                    out.add(Candidate(key = "YF$id|hls$h|${k++}", url = vu, title = title, kind = Kind.HLS, isAudio = false,
                        ext = "mp4", size = -1, quality = "${h}p", duration = dur, formatSel = null, previewUrl = vu, referer = null))
                }
            }
            sd?.optJSONArray("formats")?.let { addFormats(it, id, title, dur, out, "ios") }
        } catch (e: Exception) { }
        // 2) Klien Android VR
        if (out.isEmpty()) try {
            val j = innertube(id, "ANDROID_VR", "1.62.27", "\"deviceMake\":\"Oculus\",\"deviceModel\":\"Quest 3\",\"osName\":\"Android\",\"osVersion\":\"12L\",\"androidSdkVersion\":32,",
                "com.google.android.apps.youtube.vr.oculus/1.62.27 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip", "28")
            j.optJSONObject("videoDetails")?.let { title = it.optString("title", title); dur = it.optString("lengthSeconds", "0").toLongOrNull() ?: 0L }
            val sd = j.optJSONObject("streamingData")
            sd?.optJSONArray("formats")?.let { addFormats(it, id, title, dur, out, "vr") }
            sd?.optJSONArray("adaptiveFormats")?.let { arr ->
                var best: org.json.JSONObject? = null
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    if (o.optString("mimeType").startsWith("audio/mp4") && o.optString("url").isNotEmpty() &&
                        (best == null || o.optLong("bitrate") > best.optLong("bitrate"))) best = o
                }
                best?.let { o -> out.add(Candidate(key = "YF$id|vra", url = o.getString("url"), title = title, kind = Kind.DIRECT, isAudio = true,
                    ext = "m4a", size = o.optString("contentLength", "-1").toLongOrNull() ?: -1, quality = "audio", duration = dur,
                    formatSel = null, previewUrl = o.getString("url"), referer = null)) }
            }
        } catch (e: Exception) { }
        // 3) Piped (situs downloader publik)
        if (out.isEmpty()) {
            for (base in listOf("https://pipedapi.kavin.rocks", "https://api.piped.private.coffee", "https://pipedapi.adminforge.de")) {
                try {
                    val j = org.json.JSONObject(getText("$base/streams/$id", null))
                    title = j.optString("title", title); dur = j.optLong("duration", dur)
                    val vs = j.optJSONArray("videoStreams")
                    if (vs != null) for (i in 0 until vs.length()) {
                        val o = vs.optJSONObject(i) ?: continue
                        if (o.optBoolean("videoOnly", true) || o.optString("url").isEmpty()) continue
                        out.add(Candidate(key = "YF$id|pp$i", url = o.getString("url"), title = title, kind = Kind.DIRECT, isAudio = false,
                            ext = "mp4", size = o.optLong("contentLength", -1), quality = o.optString("quality", "-"), duration = dur,
                            formatSel = null, previewUrl = o.getString("url"), referer = null))
                    }
                    val au = j.optJSONArray("audioStreams")
                    if (au != null && au.length() > 0) au.optJSONObject(0)?.let { o ->
                        if (o.optString("url").isNotEmpty()) out.add(Candidate(key = "YF$id|ppa", url = o.getString("url"), title = title,
                            kind = Kind.DIRECT, isAudio = true, ext = "m4a", size = o.optLong("contentLength", -1), quality = "audio",
                            duration = dur, formatSel = null, previewUrl = o.getString("url"), referer = null))
                    }
                    if (out.isNotEmpty()) break
                } catch (e: Exception) { }
            }
        }
        if (out.isEmpty()) return false
        Repo.addCandidates(out)
        return true
    }

    private fun addFormats(arr: org.json.JSONArray, id: String, title: String, dur: Long, out: MutableList<Candidate>, tag: String) {
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val url = o.optString("url", "")
            if (url.isEmpty()) continue
            out.add(Candidate(key = "YF$id|$tag$i", url = url, title = title, kind = Kind.DIRECT, isAudio = false, ext = "mp4",
                size = o.optString("contentLength", "-1").toLongOrNull() ?: -1, quality = o.optString("qualityLabel", "-"),
                duration = dur,
                formatSel = if (tag == "ios") "UA:com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"
                    else "UA:com.google.android.apps.youtube.vr.oculus/1.62.27 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
                previewUrl = url, referer = null))
        }
    }
}
