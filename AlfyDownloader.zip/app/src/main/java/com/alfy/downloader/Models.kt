package com.alfy.downloader

import org.json.JSONObject

val VIDEO_EXT = setOf("mp4", "mkv", "avi", "mov", "webm", "ts", "m3u8", "m4v", "3gp", "flv")
val AUDIO_EXT = setOf("mp3", "m4a", "wav", "aac", "acc", "flac", "ogg", "opus", "wma")

enum class Kind { DIRECT, HLS, YTDLP }
enum class Status { QUEUED, DOWNLOADING, PAUSED, DONE, ERROR }

data class Candidate(
    val key: String,
    val url: String,
    val title: String,
    val kind: Kind,
    val isAudio: Boolean,
    val ext: String,
    val size: Long,
    val quality: String,
    val duration: Long,
    val formatSel: String?,
    val previewUrl: String,
    val referer: String?,
    val toMp3: Boolean = false,
    val audioUrl: String? = null,
    val muted: Boolean = false,
    val fallbackUrl: String? = null,
    val source: String = "",
    val vid: String = "",
    val img: String = ""
)

data class DlItem(
    val id: String,
    val name: String,
    val url: String,
    val kind: Kind,
    val isAudio: Boolean,
    val toMp3: Boolean,
    val formatSel: String?,
    val referer: String?,
    val dir: String,
    val status: Status = Status.QUEUED,
    val progress: Int = 0,
    val total: Long = 0,
    val done: Long = 0,
    val speed: Long = 0,
    val resumable: Boolean = true,
    val error: String = "",
    val wifiOnly: Boolean = false,
    val retry: Boolean = true,
    val path: String = "",
    val time: Long = System.currentTimeMillis(),
    val thumb: String = "",
    val img: String = "",
    val source: String = "",
    val audioExt: String = "",
    val page: String = ""
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("name", name); put("url", url); put("kind", kind.name)
        put("isAudio", isAudio); put("toMp3", toMp3); put("sel", formatSel ?: "")
        put("ref", referer ?: ""); put("dir", dir); put("status", status.name)
        put("progress", progress); put("total", total); put("done", done)
        put("resumable", resumable); put("error", error); put("wifi", wifiOnly)
        put("retry", retry); put("path", path); put("time", time); put("thumb", thumb); put("img", img)
        put("source", source); put("audioExt", audioExt); put("page", page)
    }

    companion object {
        fun fromJson(o: JSONObject) = DlItem(
            id = o.getString("id"), name = o.getString("name"), url = o.getString("url"),
            kind = Kind.valueOf(o.getString("kind")), isAudio = o.optBoolean("isAudio"),
            toMp3 = o.optBoolean("toMp3"), formatSel = o.optString("sel").ifEmpty { null },
            referer = o.optString("ref").ifEmpty { null }, dir = o.getString("dir"),
            status = Status.valueOf(o.getString("status")), progress = o.optInt("progress"),
            total = o.optLong("total"), done = o.optLong("done"),
            resumable = o.optBoolean("resumable", true), error = o.optString("error"),
            wifiOnly = o.optBoolean("wifi"), retry = o.optBoolean("retry", true),
            path = o.optString("path"), time = o.optLong("time"), thumb = o.optString("thumb"), img = o.optString("img"),
            source = o.optString("source"), audioExt = o.optString("audioExt"), page = o.optString("page")
        )
    }
}
