package com.alfy.downloader.part3.core

import java.net.URI
import java.util.Locale

/** Per-app URL heuristics (used together with the detected foreground app) and stream-host labels. */
object AppHeuristics {
    class Rule(val label: String, val hosts: Regex, val media: Regex, val block: Regex?)

    private val AD = Regex("""(?i)(/ads?/|[?&]adformat=|/pagead/|doubleclick|/api/stats/|/ptracking|/log_event)""")
    private val tiktok = Rule(
        "TikTok",
        Regex("""(?i)(tiktokcdn\S*\.com|tiktokv\.com|byteoversea\.com|muscdn\.com)$"""),
        Regex("""(?i)(/video/|\.mp4|\.m4a)"""),
        null
    )

    private val rules: Map<String, Rule> = mapOf(
        "com.google.android.youtube" to Rule("YouTube", Regex("""(?i)(^|\.)googlevideo\.com$"""), Regex("""/videoplayback"""), AD),
        "com.twitter.android" to Rule("X", Regex("""(?i)(^|\.)(video|pbs)\.twimg\.com$"""), Regex("""(?i)\.(mp4|m3u8)(\?|$)"""), null),
        "com.instagram.android" to Rule("Instagram", Regex("""(?i)(cdninstagram\.com|fbcdn\.net)$"""), Regex("""(?i)\.(mp4|m4a)(\?|$)"""), null),
        "com.facebook.katana" to Rule("Facebook", Regex("""(?i)(fbcdn\.net|facebook\.com)$"""), Regex("""(?i)\.(mp4|m4a)(\?|$)"""), null),
        "com.zhiliaoapp.musically" to tiktok,
        "com.ss.android.ugc.trill" to tiktok,
        "com.reddit.frontpage" to Rule("Reddit", Regex("""(?i)(^|\.)redd\.it$"""), Regex("""(?i)(\.(mp4|m3u8)(\?|$)|DASH_|HLSPlaylist)"""), null)
    )

    private val browsers = setOf("com.android.chrome", "org.mozilla.firefox", "com.brave.browser", "com.microsoft.emmx", "com.opera.browser")

    /** Packages whose HTTPS traffic is worth inspecting (SNI) in root mode. */
    fun packages(): Set<String> = rules.keys + browsers

    private val streamHosts = listOf(
        Regex("""(^|\.)googlevideo\.com$""") to "YouTube",
        Regex("""(^|\.)(video|pbs)\.twimg\.com$""") to "X",
        Regex("""cdninstagram\.com$""") to "Instagram",
        Regex("""fbcdn\.net$""") to "Facebook",
        Regex("""(tiktokcdn\S*\.com|tiktokv\.com|byteoversea\.com)$""") to "TikTok",
        Regex("""(^|\.)v\.redd\.it$""") to "Reddit"
    )

    fun streamLabel(host: String): String? = streamHosts.firstOrNull { it.first.containsMatchIn(host) }?.second

    fun hostOf(url: String): String? = try {
        URI(url).host?.lowercase(Locale.ROOT)
    } catch (e: Exception) { null }

    /** true = definitely media, false = drop, null = no opinion. */
    fun accept(pkg: String?, url: String): Boolean? {
        if (pkg == null) return null
        val r = rules[pkg] ?: return null
        val host = hostOf(url) ?: return null
        if (!r.hosts.containsMatchIn(host)) return null
        if (r.block?.containsMatchIn(url) == true) return false
        return if (r.media.containsMatchIn(url)) true else null
    }

    private val chunkParams = setOf("range", "rn", "rbuf", "cpn", "alr")

    /** YouTube streams arrive in ranged chunks; strip chunk params so every chunk maps to one stream. */
    fun normalize(url: String): String {
        val host = hostOf(url) ?: return url
        if (!host.endsWith("googlevideo.com")) return url
        val i = url.indexOf('?')
        if (i < 0) return url
        val kept = url.substring(i + 1).split('&')
            .filter { p -> p.isNotEmpty() && p.substringBefore('=').lowercase(Locale.ROOT) !in chunkParams }
        return url.substring(0, i) + (if (kept.isEmpty()) "" else "?" + kept.joinToString("&"))
    }
}
