package com.alfy.downloader.part3.scan

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Root-based foreground app detection (no Accessibility Service). Polls only while the screen is on. */
object ForegroundWatcher {
    @Volatile var current: String? = null
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private val pkgRx = Regex("""u\d+\s+([\w.]+)/""")

    @Synchronized
    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            while (isActive) {
                val out = Shell.suOut("dumpsys activity activities | grep -E 'mResumedActivity|topResumedActivity'", 5)
                if (out == null) {
                    delay(15_000)
                    continue
                }
                current = pkgRx.find(out)?.groupValues?.get(1) ?: current
                delay(3_000)
            }
        }
    }

    @Synchronized
    fun stop() {
        job?.cancel()
        job = null
        current = null
    }
}
