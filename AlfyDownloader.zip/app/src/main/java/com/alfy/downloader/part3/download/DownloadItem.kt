package com.alfy.downloader.part3.download

import com.alfy.downloader.part3.core.Category
import org.json.JSONObject

enum class Status { QUEUED, DOWNLOADING, PAUSED, CONVERTING, DONE, FAILED }

data class DownloadItem(
    val id: String,
    val url: String,
    val title: String,
    val category: Category,
    val referer: String?,
    val userAgent: String,
    val isHls: Boolean,
    val hlsProgram: Int,
    val status: Status,
    val downloaded: Long,
    val total: Long,
    val speedBps: Long,
    val etaSec: Long,
    val durationSec: Double,
    val tmpPath: String,
    val ext: String,
    val finalUri: String?,
    val error: String?,
    val createdAt: Long,
    val engine: String = "direct",
    val fmtPlan: String? = null
) {
    val isYtDlp: Boolean get() = engine == "ytdlp"

    val pct: Int get() = if (total > 0) ((downloaded * 100) / total).toInt().coerceIn(0, 100) else 0

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("url", url); put("title", title); put("cat", category.name)
        put("ref", referer ?: JSONObject.NULL); put("ua", userAgent); put("hls", isHls); put("prog", hlsProgram)
        put("st", status.name); put("dl", downloaded); put("tot", total); put("dur", durationSec)
        put("tmp", tmpPath); put("ext", ext); put("uri", finalUri ?: JSONObject.NULL)
        put("err", error ?: JSONObject.NULL); put("t", createdAt)
        put("eng", engine); put("plan", fmtPlan ?: JSONObject.NULL)
    }

    companion object {
        fun fromJson(o: JSONObject) = DownloadItem(
            id = o.getString("id"), url = o.getString("url"), title = o.getString("title"),
            category = Category.valueOf(o.getString("cat")),
            referer = if (o.isNull("ref")) null else o.getString("ref"),
            userAgent = o.getString("ua"), isHls = o.optBoolean("hls"), hlsProgram = o.optInt("prog", -1),
            status = Status.valueOf(o.getString("st")), downloaded = o.optLong("dl"), total = o.optLong("tot"),
            speedBps = 0, etaSec = -1, durationSec = o.optDouble("dur", 0.0),
            tmpPath = o.getString("tmp"), ext = o.optString("ext", "mp4"),
            finalUri = if (o.isNull("uri")) null else o.getString("uri"),
            error = if (o.isNull("err")) null else o.getString("err"), createdAt = o.optLong("t"),
            engine = o.optString("eng", "direct"),
            fmtPlan = if (o.isNull("plan")) null else o.optString("plan")
        )
    }
}
