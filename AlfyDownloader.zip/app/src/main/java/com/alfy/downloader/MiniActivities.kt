package com.alfy.downloader

import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.core.content.ContextCompat

class PreviewActivity : Activity() {
    private var player: androidx.media3.exoplayer.ExoPlayer? = null
    private val ui = android.os.Handler(android.os.Looper.getMainLooper())
    private var tick: Runnable? = null
    private var hideRun: Runnable? = null
    private var spinner: ProgressBar? = null
    private var btnPlay: TextView? = null
    private var btnMute: TextView? = null
    private var seek: SeekBar? = null
    private var timeTv: TextView? = null
    private var surface: android.view.SurfaceView? = null
    private var root: FrameLayout? = null
    private var topBar: View? = null
    private var bottomBar: View? = null
    private var errBox: LinearLayout? = null
    private var errTv: TextView? = null
    private var vw = 0
    private var vh = 0
    private var closing = false
    private var muted = false
    private var failed = false
    private var ctlVisible = true
    private var scrubbing = false

    // data dari Intent
    private var mainUrl = ""
    private var audioUrl: String? = null
    private var baseUa: String? = null
    private var refIn: String? = null

    // anti-403: urutan sumber (plan) dan nomor percobaan User-Agent
    private var attempt = 0
    private var planIdx = 0
    private val plans = ArrayList<() -> androidx.media3.exoplayer.source.MediaSource>()
    private val maxRetry = 4

    private fun fmt(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(s / 60, s % 60) }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, radiusDp: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radiusDp).toFloat() }

    private fun btn(t: String, size: Float = 22f, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { onClick() }
    }

    // ---- User-Agent & header anti-403 -------------------------------------------------
    /** Daftar User-Agent yang dicoba berurutan. Yang pertama = klien yang membuat link (parameter c=). */
    private fun uaList(u: String): List<String> {
        val first = if (Resolver.qp(u, "c").isNotEmpty()) Resolver.uaForGv(u) else (baseUa ?: Resolver.UA)
        return listOf(first, Resolver.UA_IOS, Resolver.UA_VR, Resolver.UA_AND, Resolver.UA).distinct()
    }

    private fun pickFactory(uri: Uri): androidx.media3.datasource.DataSource.Factory {
        val s = uri.toString()
        val gv = s.contains("googlevideo.com")
        val ua: String = if (gv) { val l = uaList(s); l[attempt.coerceIn(0, l.size - 1)] } else (baseUa ?: Resolver.UA)
        val h = HashMap<String, String>()
        refIn?.let { h["Referer"] = it }
        if (gv) {
            if (ua.startsWith("Mozilla")) { h["Origin"] = "https://www.youtube.com"; h["Referer"] = "https://www.youtube.com/" }
            else h.remove("Referer")   // klien aplikasi (iOS/VR/Android) tidak mengirim Referer
        }
        return androidx.media3.datasource.DefaultHttpDataSource.Factory()
            .setUserAgent(ua).setDefaultRequestProperties(h)
            .setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(12000).setReadTimeoutMs(15000)
    }

    private fun httpCodeOf(e: Throwable): Int? {
        var t: Throwable? = e
        var n = 0
        while (t != null && n < 8) {
            if (t is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) return t.responseCode
            t = t.cause; n++
        }
        return null
    }

    /** (Re)mulai pemutaran memakai sumber plan saat ini dan nomor percobaan UA saat ini. */
    private fun startPlay(resume: Boolean) {
        val p = player ?: return
        try {
            val pos = if (resume) p.currentPosition.coerceAtLeast(0L) else 0L
            p.setMediaSource(plans[planIdx](), pos)
            p.prepare()
            p.playWhenReady = true
        } catch (e: Exception) {
            failed = true
            showError("Tidak bisa diputar")
        }
    }

    // ---- UI ---------------------------------------------------------------------------
    private fun showError(msg: String) {
        failed = true
        errTv?.text = msg
        errBox?.visibility = View.VISIBLE
        setCtl(true)
        refreshUi()
    }

    private fun refreshUi() {
        val p = player ?: return
        val st = p.playbackState
        val loading = !failed && (st == androidx.media3.common.Player.STATE_BUFFERING || st == androidx.media3.common.Player.STATE_IDLE)
        spinner?.visibility = if (loading) View.VISIBLE else View.GONE
        btnPlay?.text = if (p.playWhenReady && st != androidx.media3.common.Player.STATE_ENDED) "⏸" else "▶"
        btnMute?.text = if (muted) "🔇" else "🔊"
        if (!failed) errBox?.visibility = View.GONE
    }

    private fun setCtl(show: Boolean) {
        ctlVisible = show
        for (v in listOf(topBar, bottomBar)) {
            if (v == null) continue
            if (show) { v.visibility = View.VISIBLE; v.animate().alpha(1f).setDuration(180).start() }
            else v.animate().alpha(0f).setDuration(180).withEndAction { if (!ctlVisible) v.visibility = View.GONE }.start()
        }
        scheduleHide()
    }

    private fun scheduleHide() {
        hideRun?.let { ui.removeCallbacks(it) }
        val p = player
        if (!ctlVisible || failed || p == null || !p.playWhenReady) return
        val r = Runnable { if (!scrubbing && !failed) setCtl(false) }
        hideRun = r
        ui.postDelayed(r, 3500)
    }

    private fun fitVideo() {
        val sv = surface ?: return
        val r = root ?: return
        if (vw <= 0 || vh <= 0) return
        val W = if (r.width > 0) r.width else resources.displayMetrics.widthPixels
        val H = if (r.height > 0) r.height else resources.displayMetrics.heightPixels
        val scale = minOf(W.toFloat() / vw, H.toFloat() / vh)
        sv.layoutParams = FrameLayout.LayoutParams((vw * scale).toInt(), (vh * scale).toInt(), Gravity.CENTER)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val url = intent.getStringExtra("url") ?: run { finish(); return }
        mainUrl = url
        audioUrl = intent.getStringExtra("audio")
        val au = audioUrl
        val mode = intent.getStringExtra("mode") ?: "video"
        val sepAudio = intent.getBooleanExtra("muted", false) && au != null && au != url
        baseUa = intent.getStringExtra("ua")
        refIn = intent.getStringExtra("ref")
        val titleText = intent.getStringExtra("title") ?: ""
        val accent = 0xFF4DB6AC.toInt()

        val fl = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root = fl
        setContentView(fl)
        val sv = android.view.SurfaceView(this)
        surface = sv
        if (mode == "audio") {
            fl.addView(TextView(this).apply { text = "♪"; textSize = 96f; setTextColor(0x55FFFFFF); gravity = Gravity.CENTER },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            fl.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        }
        // ketuk layar = tampil/sembunyi kontrol
        fl.setOnClickListener { if (!failed) setCtl(!ctlVisible) }

        // animasi berputar saat memuat
        val sp = ProgressBar(this).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
        }
        spinner = sp
        fl.addView(sp, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))

        // bilah atas: kembali + judul (gradasi transparan)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(28), dp(16), dp(24))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0x00000000))
        }
        top.addView(btn("←", 26f) { closeNow() })
        top.addView(TextView(this).apply {
            text = titleText; textSize = 14f; setTextColor(Color.WHITE); maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        topBar = top
        fl.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        // bilah bawah berbentuk kapsul: jeda, waktu, geser, bisukan
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = round(0xCC121212.toInt(), 28); setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val pb = btn("⏸", 24f) {
            val p = player ?: return@btn
            if (p.playWhenReady && p.playbackState != androidx.media3.common.Player.STATE_ENDED) p.playWhenReady = false
            else { if (p.playbackState == androidx.media3.common.Player.STATE_ENDED) p.seekTo(0); p.playWhenReady = true }
            refreshUi(); scheduleHide()
        }
        btnPlay = pb
        val mb = btn("🔊", 20f) {
            muted = !muted
            player?.volume = if (muted) 0f else 1f
            refreshUi(); scheduleHide()
        }
        btnMute = mb
        val sb = SeekBar(this).apply {
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(accent)
        }
        seek = sb
        val tt = TextView(this).apply { text = "0:00 / 0:00"; setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(4), 0, dp(4), 0) }
        timeTv = tt
        bar.addView(pb)
        bar.addView(sb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(tt)
        bar.addView(mb)
        bottomBar = bar
        fl.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            setMargins(dp(12), 0, dp(12), dp(20))
        })
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) { if (fromUser) player?.seekTo(v.toLong()) }
            override fun onStartTrackingTouch(s: SeekBar?) { scrubbing = true; hideRun?.let { ui.removeCallbacks(it) } }
            override fun onStopTrackingTouch(s: SeekBar?) { scrubbing = false; scheduleHide() }
        })

        // kotak galat + tombol coba lagi
        val eb = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            background = round(0xE6212121.toInt(), 16); setPadding(dp(20), dp(16), dp(20), dp(16))
            visibility = View.GONE
        }
        val et = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER }
        errTv = et
        eb.addView(et)
        eb.addView(btn("↻ Coba lagi", 16f) {
            failed = false; attempt = 0; planIdx = 0
            errBox?.visibility = View.GONE
            startPlay(false); refreshUi()
        }.apply { background = round(accent, 20); setTextColor(0xFF00201D.toInt()) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })
        errBox = eb
        fl.addView(eb, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER).apply {
            setMargins(dp(24), 0, dp(24), 0)
        })

        try {
            // User-Agent/header dipilih per alamat saat dibuka (lihat pickFactory), jadi bisa berganti saat coba ulang.
            val base = androidx.media3.datasource.DefaultHttpDataSource.Factory()
            val msf = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(this)
                .setDataSourceFactory(androidx.media3.datasource.DataSource.Factory { ChunkedDataSource(base, pick = { u -> pickFactory(u) }) })
            fun ms(u: String): androidx.media3.exoplayer.source.MediaSource = msf.createMediaSource(androidx.media3.common.MediaItem.fromUri(u))

            plans.add {
                if (mode == "audio" && au != null) ms(au)
                else if (mode == "video" && sepAudio && au != null) androidx.media3.exoplayer.source.MergingMediaSource(ms(url), ms(au))
                else ms(url)
            }
            if (mode == "video") {
                val fbUrl = intent.getStringExtra("fallback")
                if (fbUrl != null && fbUrl != url) plans.add { ms(fbUrl) }
                if (sepAudio) plans.add { ms(url) }
            }

            val p = androidx.media3.exoplayer.ExoPlayer.Builder(this).build()
            player = p
            if (mode == "audio") {
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_VIDEO, true).build()
            } else p.setVideoSurfaceView(sv)
            p.addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlaybackStateChanged(state: Int) { refreshUi(); scheduleHide() }
                override fun onIsPlayingChanged(isPlaying: Boolean) { refreshUi(); scheduleHide() }
                override fun onVideoSizeChanged(v: androidx.media3.common.VideoSize) { vw = v.width; vh = v.height; fitVideo() }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    val hc = httpCodeOf(error)
                    if (hc == 403 && attempt < maxRetry) {      // 403 -> coba User-Agent/header klien YouTube lain
                        attempt++; startPlay(true); return
                    }
                    if (planIdx + 1 < plans.size) {             // lalu coba sumber cadangan
                        planIdx++; attempt = 0; startPlay(true); return
                    }
                    showError("Tidak bisa diputar (" + (if (hc != null) "HTTP $hc" else error.errorCodeName) + ").\nLink mungkin kedaluwarsa; pindai ulang videonya.")
                }
            })
            startPlay(false)
        } catch (e: Exception) {
            showError("Tidak bisa diputar")
        }
        val r = object : Runnable {
            override fun run() {
                val p = player
                if (p != null && !closing) {
                    try {
                        val d = p.duration
                        if (d > 0 && !scrubbing) { seek?.max = d.toInt(); seek?.progress = p.currentPosition.toInt() }
                        timeTv?.text = fmt(p.currentPosition) + " / " + fmt(if (d > 0) d else 0)
                        refreshUi()
                    } catch (e: Exception) { }
                    ui.postDelayed(this, 500)
                }
            }
        }
        tick = r; ui.post(r)
        refreshUi()
        scheduleHide()
    }

    /** Tutup seketika: suara berhenti, layar menutup, langsung kembali ke aplikasi sebelumnya. */
    private fun closeNow() {
        if (closing) return
        closing = true
        tick?.let { ui.removeCallbacks(it) }
        hideRun?.let { ui.removeCallbacks(it) }
        try { player?.playWhenReady = false } catch (e: Exception) { }
        finish()
        try { player?.release() } catch (e: Exception) { }
        player = null
    }

    override fun onBackPressed() { closeNow() }
    override fun dispatchKeyEvent(ev: android.view.KeyEvent): Boolean {
        if (ev.keyCode == android.view.KeyEvent.KEYCODE_BACK) {
            if (ev.action == android.view.KeyEvent.ACTION_UP) closeNow()
            return true
        }
        return super.dispatchKeyEvent(ev)
    }
    override fun onPause() { super.onPause(); try { player?.playWhenReady = false } catch (e: Exception) { } }
    override fun onDestroy() {
        closing = true
        tick?.let { ui.removeCallbacks(it) }
        hideRun?.let { ui.removeCallbacks(it) }
        try { player?.release() } catch (e: Exception) { }
        player = null
        super.onDestroy()
    }
}

class ClipActivity : Activity() {
    private var done = false
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !done) {
            done = true
            try {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
                val urls = Regex("https?://[^\\s]+").findAll(t).map { it.value }.toList()
                urls.forEach { Resolver.rescan(it) }
                if (urls.isNotEmpty()) Resolver.diag = "Clipboard: memindai ${urls.size} tautan…"
            } catch (e: Exception) { }
            finish()
            overridePendingTransition(0, 0)
        }
    }
}

class ShareActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val t = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
        val urls = Regex("https?://[^\\s]+").findAll(t).map { it.value }.toList()
        urls.forEach { Resolver.rescan(it) }
        if (Settings.canDrawOverlays(this) && !FloatingService.running)
            ContextCompat.startForegroundService(this, Intent(this, FloatingService::class.java))
        Toast.makeText(this, if (urls.isEmpty()) "Tidak ada tautan" else "Memindai tautan… cek menu mengambang", Toast.LENGTH_LONG).show()
        finish()
    }
}

class BrowserActivity : Activity() {
    private lateinit var wv: WebView
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF212121.toInt()) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val et = EditText(this).apply {
            setText(intent.getStringExtra("url") ?: "https://www.google.com")
            setSingleLine(); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val go = Button(this).apply { text = "Buka" }
        bar.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(go)
        wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.mediaPlaybackRequiresUserGesture = false
        wv.settings.mixedContentMode = 0
        // Google memblokir login di WebView ber-UA bawaan; UA Firefox biasanya diterima
        wv.settings.userAgentString = "Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0"
        try { android.webkit.CookieManager.getInstance().setAcceptCookie(true); android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true) } catch (e: Exception) { }
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url.toString()
                val rf = request.requestHeaders["Referer"] ?: view.url
                // v1.4: di situs embed ber-iklan (jwplyr/vidoy), video dari host lain = iklan -> abaikan
                if (Resolver.isJwPage(view.url) && !Resolver.jwMediaOk(u)) return null
                if (Resolver.isMedia(u)) Resolver.submit(u, rf)
                else if (WebTool.looksMedia(u, request)) Resolver.submitMedia(u, rf)   // v1.3: media tanpa ekstensi (Range/Accept video)
                return null
            }
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                et.setText(url); Resolver.submit(url)
            }
        }
        // v1.3: tombol unduh di halaman (setelah CAPTCHA) biasanya memicu unduhan file -> tangkap sebagai link
        wv.setDownloadListener { url, _, _, _, _ ->
            Resolver.submitMedia(url, wv.url)
            android.widget.Toast.makeText(this, "Link unduhan ditangkap → lihat daftar Tautan", android.widget.Toast.LENGTH_SHORT).show()
        }
        fun load() {
            var u = et.text.toString().trim()
            if (!u.startsWith("http")) u = if (u.contains(".") && !u.contains(" ")) "https://$u" else "https://www.google.com/search?q=" + Uri.encode(u)
            wv.loadUrl(u)
        }
        go.setOnClickListener { load() }
        root.addView(bar)
        root.addView(wv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        load()
    }

    override fun onPause() { try { android.webkit.CookieManager.getInstance().flush() } catch (e: Exception) { }; super.onPause() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (wv.canGoBack()) wv.goBack() else super.onBackPressed() }
}
