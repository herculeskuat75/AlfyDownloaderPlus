package com.alfy.downloader

import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.core.content.ContextCompat

class PreviewActivity : Activity() {
    private var player: androidx.media3.exoplayer.ExoPlayer? = null
    private val ui = android.os.Handler(android.os.Looper.getMainLooper())
    private var tick: Runnable? = null
    private var hideRun: Runnable? = null
    private var spinner: ProgressBar? = null
    private var btnPlay: TextView? = null
    private var btnMute: TextView? = null
    private var seek: SeekBar? = null
    private var timeTv: TextView? = null
    private var surface: android.view.SurfaceView? = null
    private var root: FrameLayout? = null
    private var topBar: View? = null
    private var bottomBar: View? = null
    private var errBox: LinearLayout? = null
    private var errTv: TextView? = null
    private var vw = 0
    private var vh = 0
    private var closing = false
    private var muted = false
    private var failed = false
    private var ctlVisible = true
    private var scrubbing = false

    // data dari Intent
    private var mainUrl = ""
    private var audioUrl: String? = null
    private var baseUa: String? = null
    private var refIn: String? = null

    // anti-403: urutan sumber (plan) dan nomor percobaan User-Agent
    private var attempt = 0
    private var planIdx = 0
    private val plans = ArrayList<() -> androidx.media3.exoplayer.source.MediaSource>()
    private val maxRetry = 4

    private fun fmt(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(s / 60, s % 60) }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, radiusDp: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radiusDp).toFloat() }

    private fun btn(t: String, size: Float = 22f, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { onClick() }
    }

    // ---- User-Agent & header anti-403 -------------------------------------------------
    /** Daftar User-Agent yang dicoba berurutan. Yang pertama = klien yang membuat link (parameter c=). */
    private fun uaList(u: String): List<String> {
        val first = if (Resolver.qp(u, "c").isNotEmpty()) Resolver.uaForGv(u) else (baseUa ?: Resolver.UA)
        return listOf(first, Resolver.UA_IOS, Resolver.UA_VR, Resolver.UA_AND, Resolver.UA).distinct()
    }

    private fun pickFactory(uri: Uri): androidx.media3.datasource.DataSource.Factory {
        val s = uri.toString()
        val gv = s.contains("googlevideo.com")
        val ua: String = if (gv) { val l = uaList(s); l[attempt.coerceIn(0, l.size - 1)] } else (baseUa ?: Resolver.UA)
        val h = HashMap<String, String>()
        refIn?.let { h["Referer"] = it }
        if (gv) {
            if (ua.startsWith("Mozilla")) { h["Origin"] = "https://www.youtube.com"; h["Referer"] = "https://www.youtube.com/" }
            else h.remove("Referer")   // klien aplikasi (iOS/VR/Android) tidak mengirim Referer
        }
        return androidx.media3.datasource.DefaultHttpDataSource.Factory()
            .setUserAgent(ua).setDefaultRequestProperties(h)
            .setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(12000).setReadTimeoutMs(15000)
    }

    private fun httpCodeOf(e: Throwable): Int? {
        var t: Throwable? = e
        var n = 0
        while (t != null && n < 8) {
            if (t is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) return t.responseCode
            t = t.cause; n++
        }
        return null
    }

    /** (Re)mulai pemutaran memakai sumber plan saat ini dan nomor percobaan UA saat ini. */
    private fun startPlay(resume: Boolean) {
        val p = player ?: return
        try {
            val pos = if (resume) p.currentPosition.coerceAtLeast(0L) else 0L
            p.setMediaSource(plans[planIdx](), pos)
            p.prepare()
            p.playWhenReady = true
        } catch (e: Exception) {
            failed = true
            showError("Tidak bisa diputar")
        }
    }

    // ---- UI ---------------------------------------------------------------------------
    private fun showError(msg: String) {
        failed = true
        errTv?.text = msg
        errBox?.visibility = View.VISIBLE
        setCtl(true)
        refreshUi()
    }

    private fun refreshUi() {
        val p = player ?: return
        val st = p.playbackState
        val loading = !failed && (st == androidx.media3.common.Player.STATE_BUFFERING || st == androidx.media3.common.Player.STATE_IDLE)
        spinner?.visibility = if (loading) View.VISIBLE else View.GONE
        btnPlay?.text = if (p.playWhenReady && st != androidx.media3.common.Player.STATE_ENDED) "⏸" else "▶"
        btnMute?.text = if (muted) "🔇" else "🔊"
        if (!failed) errBox?.visibility = View.GONE
    }

    private fun setCtl(show: Boolean) {
        ctlVisible = show
        for (v in listOf(topBar, bottomBar)) {
            if (v == null) continue
            if (show) { v.visibility = View.VISIBLE; v.animate().alpha(1f).setDuration(180).start() }
            else v.animate().alpha(0f).setDuration(180).withEndAction { if (!ctlVisible) v.visibility = View.GONE }.start()
        }
        scheduleHide()
    }

    private fun scheduleHide() {
        hideRun?.let { ui.removeCallbacks(it) }
        val p = player
        if (!ctlVisible || failed || p == null || !p.playWhenReady) return
        val r = Runnable { if (!scrubbing && !failed) setCtl(false) }
        hideRun = r
        ui.postDelayed(r, 3500)
    }

    private fun fitVideo() {
        val sv = surface ?: return
        val r = root ?: return
        if (vw <= 0 || vh <= 0) return
        val W = if (r.width > 0) r.width else resources.displayMetrics.widthPixels
        val H = if (r.height > 0) r.height else resources.displayMetrics.heightPixels
        val scale = minOf(W.toFloat() / vw, H.toFloat() / vh)
        sv.layoutParams = FrameLayout.LayoutParams((vw * scale).toInt(), (vh * scale).toInt(), Gravity.CENTER)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val url = intent.getStringExtra("url") ?: run { finish(); return }
        mainUrl = url
        audioUrl = intent.getStringExtra("audio")
        val au = audioUrl
        val mode = intent.getStringExtra("mode") ?: "video"
        val sepAudio = intent.getBooleanExtra("muted", false) && au != null && au != url
        baseUa = intent.getStringExtra("ua")
        refIn = intent.getStringExtra("ref")
        val titleText = intent.getStringExtra("title") ?: ""
        val accent = 0xFF4DB6AC.toInt()

        val fl = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root = fl
        setContentView(fl)
        val sv = android.view.SurfaceView(this)
        surface = sv
        if (mode == "audio") {
            fl.addView(TextView(this).apply { text = "♪"; textSize = 96f; setTextColor(0x55FFFFFF); gravity = Gravity.CENTER },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            fl.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        }
        // ketuk layar = tampil/sembunyi kontrol
        fl.setOnClickListener { if (!failed) setCtl(!ctlVisible) }

        // animasi berputar saat memuat
        val sp = ProgressBar(this).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
        }
        spinner = sp
        fl.addView(sp, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))

        // bilah atas: kembali + judul (gradasi transparan)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(28), dp(16), dp(24))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0x00000000))
        }
        top.addView(btn("←", 26f) { closeNow() })
        top.addView(TextView(this).apply {
            text = titleText; textSize = 14f; setTextColor(Color.WHITE); maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        topBar = top
        fl.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        // bilah bawah berbentuk kapsul: jeda, waktu, geser, bisukan
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = round(0xCC121212.toInt(), 28); setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val pb = btn("⏸", 24f) {
            val p = player ?: return@btn
            if (p.playWhenReady && p.playbackState != androidx.media3.common.Player.STATE_ENDED) p.playWhenReady = false
            else { if (p.playbackState == androidx.media3.common.Player.STATE_ENDED) p.seekTo(0); p.playWhenReady = true }
            refreshUi(); scheduleHide()
        }
        btnPlay = pb
        val mb = btn("🔊", 20f) {
            muted = !muted
            player?.volume = if (muted) 0f else 1f
            refreshUi(); scheduleHide()
        }
        btnMute = mb
        val sb = SeekBar(this).apply {
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(accent)
        }
        seek = sb
        val tt = TextView(this).apply { text = "0:00 / 0:00"; setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(4), 0, dp(4), 0) }
        timeTv = tt
        bar.addView(pb)
        bar.addView(sb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(tt)
        bar.addView(mb)
        bottomBar = bar
        fl.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            setMargins(dp(12), 0, dp(12), dp(20))
        })
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) { if (fromUser) player?.seekTo(v.toLong()) }
            override fun onStartTrackingTouch(s: SeekBar?) { scrubbing = true; hideRun?.let { ui.removeCallbacks(it) } }
            override fun onStopTrackingTouch(s: SeekBar?) { scrubbing = false; scheduleHide() }
        })

        // kotak galat + tombol coba lagi
        val eb = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            background = round(0xE6212121.toInt(), 16); setPadding(dp(20), dp(16), dp(20), dp(16))
            visibility = View.GONE
        }
        val et = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER }
        errTv = et
        eb.addView(et)
        eb.addView(btn("↻ Coba lagi", 16f) {
            failed = false; attempt = 0; planIdx = 0
            errBox?.visibility = View.GONE
            startPlay(false); refreshUi()
        }.apply { background = round(accent, 20); setTextColor(0xFF00201D.toInt()) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })
        errBox = eb
        fl.addView(eb, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER).apply {
            setMargins(dp(24), 0, dp(24), 0)
        })

        try {
            // User-Agent/header dipilih per alamat saat dibuka (lihat pickFactory), jadi bisa berganti saat coba ulang.
            val base = androidx.media3.datasource.DefaultHttpDataSource.Factory()
            val msf = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(this)
                .setDataSourceFactory(androidx.media3.datasource.DataSource.Factory { ChunkedDataSource(base, pick = { u -> pickFactory(u) }) })
            fun ms(u: String): androidx.media3.exoplayer.source.MediaSource = msf.createMediaSource(androidx.media3.common.MediaItem.fromUri(u))

            plans.add {
                if (mode == "audio" && au != null) ms(au)
                else if (mode == "video" && sepAudio && au != null) androidx.media3.exoplayer.source.MergingMediaSource(ms(url), ms(au))
                else ms(url)
            }
            if (mode == "video") {
                val fbUrl = intent.getStringExtra("fallback")
                if (fbUrl != null && fbUrl != url) plans.add { ms(fbUrl) }
                if (sepAudio) plans.add {
                    android.widget.Toast.makeText(this, "Audio gagal dimuat: video diputar tanpa suara. Tekan ↻ / buka ulang untuk coba lagi.", android.widget.Toast.LENGTH_LONG).show()
                    ms(url)
                }
            }

            val p = androidx.media3.exoplayer.ExoPlayer.Builder(this).build()
            player = p
            if (mode == "audio") {
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_VIDEO, true).build()
            } else p.setVideoSurfaceView(sv)
            p.addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlaybackStateChanged(state: Int) { refreshUi(); scheduleHide() }
                override fun onIsPlayingChanged(isPlaying: Boolean) { refreshUi(); scheduleHide() }
                override fun onVideoSizeChanged(v: androidx.media3.common.VideoSize) { vw = v.width; vh = v.height; fitVideo() }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    val hc = httpCodeOf(error)
                    if (hc == 403 && attempt < maxRetry) {      // 403 -> coba User-Agent/header klien YouTube lain
                        attempt++; startPlay(true); return
                    }
                    if (planIdx + 1 < plans.size) {             // lalu coba sumber cadangan
                        planIdx++; attempt = 0; startPlay(true); return
                    }
                    showError("Tidak bisa diputar (" + (if (hc != null) "HTTP $hc" else error.errorCodeName) + ").\nLink mungkin kedaluwarsa; pindai ulang videonya.")
                }
            })
            startPlay(false)
        } catch (e: Exception) {
            showError("Tidak bisa diputar")
        }
        val r = object : Runnable {
            override fun run() {
                val p = player
                if (p != null && !closing) {
                    try {
                        val d = p.duration
                        if (d > 0 && !scrubbing) { seek?.max = d.toInt(); seek?.progress = p.currentPosition.toInt() }
                        timeTv?.text = fmt(p.currentPosition) + " / " + fmt(if (d > 0) d else 0)
                        refreshUi()
                    } catch (e: Exception) { }
                    ui.postDelayed(this, 500)
                }
            }
        }
        tick = r; ui.post(r)
        refreshUi()
        scheduleHide()
    }

    /** Tutup seketika: suara berhenti, layar menutup, langsung kembali ke aplikasi sebelumnya. */
    private fun closeNow() {
        if (closing) return
        closing = true
        tick?.let { ui.removeCallbacks(it) }
        hideRun?.let { ui.removeCallbacks(it) }
        try { player?.playWhenReady = false } catch (e: Exception) { }
        finish()
        try { player?.release() } catch (e: Exception) { }
        player = null
    }

    override fun onBackPressed() { closeNow() }
    override fun dispatchKeyEvent(ev: android.view.KeyEvent): Boolean {
        if (ev.keyCode == android.view.KeyEvent.KEYCODE_BACK) {
            if (ev.action == android.view.KeyEvent.ACTION_UP) closeNow()
            return true
        }
        return super.dispatchKeyEvent(ev)
    }
    override fun onPause() { super.onPause(); try { player?.playWhenReady = false } catch (e: Exception) { } }
    override fun onDestroy() {
        closing = true
        tick?.let { ui.removeCallbacks(it) }
        hideRun?.let { ui.removeCallbacks(it) }
        try { player?.release() } catch (e: Exception) { }
        player = null
        super.onDestroy()
    }
}

class ClipActivity : Activity() {
    private var done = false
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !done) {
            done = true
            try {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
                val urls = Regex("https?://[^\\s]+").findAll(t).map { it.value }.toList()
                urls.forEach { Resolver.rescan(it, null, "Manual 📋 clipboard") }
                if (urls.isNotEmpty()) Resolver.diag = "Clipboard: memindai ${urls.size} tautan…"
            } catch (e: Exception) { }
            finish()
            overridePendingTransition(0, 0)
        }
    }
}

class ShareActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val t = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
        val urls = Regex("https?://[^\\s]+").findAll(t).map { it.value }.toList()
        urls.forEach { Resolver.rescan(it, null, "Share (menu Bagikan)") }
        if (Settings.canDrawOverlays(this) && !FloatingService.running)
            ContextCompat.startForegroundService(this, Intent(this, FloatingService::class.java))
        Toast.makeText(this, if (urls.isEmpty()) "Tidak ada tautan" else "Memindai tautan… cek menu mengambang", Toast.LENGTH_LONG).show()
        finish()
    }
}

/** v1.13: satu tab = satu WebView. Disimpan di object agar status tab tidak hilang saat berpindah layar. */
class BrowserTab(val wv: WebView) {
    @Volatile var url: String? = null
    @Volatile var title: String = "Tab baru"
    var progress: Int = 100
    @Volatile var lastTouch = 0L
    @Volatile var finishedAt = 0L
    @Volatile var pendingSel: String? = null   // v1.15: elemen terpilih (mode blokir elemen)
    @Volatile var desktop = false
}

object BrowserTabs {
    val tabs = mutableListOf<BrowserTab>()
    var cur = 0
    @Volatile var ui: BrowserActivity? = null
    @Volatile var pickTab: BrowserTab? = null   // v1.15: tab yang sedang dalam mode pilih elemen

    fun stopPick() {
        val p = pickTab ?: return
        pickTab = null; p.pendingSel = null
        ElementBlock.stopPick(p.wv)
        ui?.pickUpdate()
    }

    fun current(): BrowserTab? = tabs.getOrNull(cur)

    fun normalize(input: String): String {
        val u = input.trim()
        if (u.startsWith("http://") || u.startsWith("https://")) return u
        return if (u.contains(".") && !u.contains(" ")) "https://$u" else "https://www.google.com/search?q=" + Uri.encode(u)
    }

    fun create(url: String?, select: Boolean): BrowserTab {
        val w = WebView(android.content.MutableContextWrapper(Repo.app))
        val t = BrowserTab(w)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.settings.mixedContentMode = 0
        w.settings.setSupportMultipleWindows(true)
        w.settings.javaScriptCanOpenWindowsAutomatically = true
        // Google memblokir login di WebView ber-UA bawaan; UA Firefox biasanya diterima
        w.settings.userAgentString = "Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0"
        try { android.webkit.CookieManager.getInstance().setAcceptCookie(true); android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(w, true) } catch (e: Exception) { }
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url.toString()
                if (LinkBlock.isBlocked(u)) return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                if (AdBlock.isAd(u)) return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))   // v1.14: blokir domain iklan
                val rf = request.requestHeaders["Referer"] ?: t.url
                // v1.4: di situs embed ber-iklan (jwplyr/vidoy), video dari host lain = iklan -> abaikan
                if (Resolver.isJwPage(t.url) && !Resolver.jwMediaOk(u)) return null
                if (Resolver.isMedia(u)) Resolver.submit(u, rf, false, "Browser Alfy")
                else if (WebTool.looksMedia(u, request)) Resolver.submitMedia(u, rf, "Browser Alfy")   // v1.3: media tanpa ekstensi (Range/Accept video)
                return null
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (LinkBlock.isBlocked(request.url.toString())) return true
                if (request.isForMainFrame && AdBlock.strict(t.url)) {
                    fun hh(x: String?) = (try { Uri.parse(x ?: "").host } catch (e: Exception) { null } ?: "").lowercase()
                    val nu = request.url.toString()
                    if (hh(nu) != hh(t.url) && !Resolver.isMedia(nu) && !Resolver.jwMediaOk(nu) && !AdBlock.mediaLike(nu)) return true   // jwplyr.com: terkunci, tidak boleh pindah ke mana pun
                }
                // v1.14: blokir perpindahan halaman otomatis (tanpa sentuhan pengguna) setelah halaman selesai dimuat
                if (!AdBlock.redirectOn() || !request.isForMainFrame || request.hasGesture()) return false
                val now = System.currentTimeMillis()
                if (t.progress < 100 || now - t.finishedAt < 300 || now - t.lastTouch < 2000) return false
                fun h(x: String?) = (try { Uri.parse(x ?: "").host } catch (e: Exception) { null } ?: "").lowercase().removePrefix("www.")
                if (h(request.url.toString()) == h(t.url)) return false
                return true
            }
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                t.url = url
                ElementBlock.apply(view, url)
                if (pickTab === t) { t.pendingSel = null; ui?.pickUpdate() }
                t.progress = 0
                t.finishedAt = 0L
                // hanya tab yang sedang dilihat yang memperbarui halaman terakhir
                if (current() === t) Resolver.submit(url, null, false, "Browser Alfy")
                ui?.refresh()
            }
            override fun onPageCommitVisible(view: WebView, url: String) { ElementBlock.apply(view, url); AdBlock.cosmetic(view) }
            override fun onPageFinished(view: WebView, url: String) {
                ElementBlock.apply(view, url)
                AdBlock.cosmetic(view)
                if (pickTab === t) ElementBlock.startPick(view)
                t.progress = 100
                t.finishedAt = System.currentTimeMillis()
                BrowserData.addHistory(view.title ?: t.title, url)
                ui?.refresh()
            }
        }
        w.addJavascriptInterface(PickBridge(t), "AlfyBlock")
        w.setOnTouchListener { _, e -> if (e.action == android.view.MotionEvent.ACTION_DOWN) t.lastTouch = System.currentTimeMillis(); false }
        w.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message): Boolean {
                if (AdBlock.popupOn() || AdBlock.strict(t.url)) return false   // v1.14: tolak jendela baru / pop-up
                val nt = create(null, true)
                (resultMsg.obj as? WebView.WebViewTransport)?.webView = nt.wv
                resultMsg.sendToTarget()
                ui?.attachCurrent()
                return true
            }
            override fun onProgressChanged(view: WebView, newProgress: Int) { t.progress = newProgress; ui?.refresh() }
            override fun onReceivedTitle(view: WebView, title: String?) { if (!title.isNullOrBlank()) { t.title = title; ui?.refresh() } }
        }
        // v1.3: tombol unduh di halaman (setelah CAPTCHA) biasanya memicu unduhan file -> tangkap sebagai link
        w.setDownloadListener { url, _, _, _, _ ->
            Resolver.submitMedia(url, t.url, "Browser Alfy (unduhan)")
            Toast.makeText(Repo.app, "Link unduhan ditangkap → lihat daftar Tautan", Toast.LENGTH_SHORT).show()
        }
        w.setOnLongClickListener { v ->
            val hr = w.hitTestResult
            val type = hr.type
            if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                val img = if (type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) hr.extra else null
                val h = Handler(Looper.getMainLooper()) { m ->
                    val link = m.data?.getString("url")
                    if (!link.isNullOrBlank()) ui?.linkMenu(link, img)
                    true
                }
                w.requestFocusNodeHref(h.obtainMessage())
                true
            } else if (type == WebView.HitTestResult.IMAGE_TYPE && !hr.extra.isNullOrBlank()) {
                ui?.imageMenu(hr.extra!!); true
            } else false
        }
        tabs.add(t)
        if (select) cur = tabs.size - 1
        if (url != null) w.loadUrl(url)
        return t
    }

    fun close(i: Int) {
        if (i !in tabs.indices) return
        val t = tabs.removeAt(i)
        if (pickTab === t) { pickTab = null; ui?.pickUpdate() }
        (t.wv.parent as? ViewGroup)?.removeView(t.wv)
        // v1.15: lepas semua listener/jembatan sebelum destroy agar WebView & Activity tidak tertahan (kebocoran memori)
        try {
            t.wv.stopLoading()
            t.wv.setOnTouchListener(null); t.wv.setOnLongClickListener(null); t.wv.setDownloadListener(null)
            t.wv.removeJavascriptInterface("AlfyBlock")
            t.wv.setWebViewClient(WebViewClient()); t.wv.setWebChromeClient(null)
            t.wv.removeAllViews()
            t.wv.destroy()
        } catch (e: Throwable) { }
        if (tabs.isEmpty()) { create("https://www.google.com", true); return }
        if (i < cur) cur-- else if (cur >= tabs.size) cur = tabs.size - 1
    }
}

class BrowserActivity : Activity() {
    private lateinit var box: FrameLayout
    private lateinit var et: EditText
    private lateinit var pb: ProgressBar
    private lateinit var tabsBtn: Button
    private lateinit var menuBtn: Button
    private lateinit var reload: Button
    private lateinit var back: Button
    private lateinit var star: Button
    private lateinit var fwd: Button
    private lateinit var listBox: LinearLayout
    private lateinit var listScroll: ScrollView
    private lateinit var pickBar: LinearLayout
    private lateinit var pickTv: TextView
    private lateinit var pickOk: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF212121.toInt()) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun btn(t: String) = Button(this).apply { text = t; minWidth = 0; minimumWidth = 0; setPadding(18, 0, 18, 0) }
        back = btn("◀"); fwd = btn("▶"); reload = btn("⟳"); tabsBtn = btn("1")
        star = btn("☆"); val menu = btn("⋮")
        et = EditText(this).apply {
            setSingleLine(); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
        }
        menuBtn = menu
        tabsBtn.textSize = 20f; menu.textSize = 26f
        bar.addView(tabsBtn, LinearLayout.LayoutParams(dp(60), dp(56)))
        bar.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(menu, LinearLayout.LayoutParams(dp(60), dp(56)))
        pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        box = FrameLayout(this)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listScroll = ScrollView(this).apply { setBackgroundColor(0xFF212121.toInt()); visibility = View.GONE; addView(listBox) }
        pickTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f; maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END }
        pickOk = Button(this).apply { text = "Blokir"; isEnabled = false }
        val pickNo = Button(this).apply { text = "Batal" }
        pickBar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xEE212121.toInt()); setPadding(16, 8, 16, 8); visibility = View.GONE }
        val pickRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        pickRow.addView(pickNo); pickRow.addView(pickOk)
        pickBar.addView(pickTv); pickBar.addView(pickRow)
        pickNo.setOnClickListener { BrowserTabs.stopPick() }
        pickOk.setOnClickListener {
            val p = BrowserTabs.pickTab; val sl = p?.pendingSel
            if (p != null && sl != null) {
                val h = ElementBlock.host(p.url)
                if (h.isNotEmpty() && ElementBlock.add(h, sl)) {
                    ElementBlock.setOn(h, true)
                    ElementBlock.apply(p.wv, p.url, true)
                    Toast.makeText(this, "Elemen diblokir di $h", Toast.LENGTH_SHORT).show()
                }
                BrowserTabs.stopPick()
            }
        }
        root.addView(bar)
        root.addView(pb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 6))
        root.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        box.addView(listScroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box.addView(pickBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        fun edge(left: Boolean) {
            val v = View(this)
            var x0 = 0f; var y0 = 0f
            v.setOnTouchListener { _, e ->
                when (e.action) {
                    android.view.MotionEvent.ACTION_DOWN -> { x0 = e.rawX; y0 = e.rawY }
                    android.view.MotionEvent.ACTION_UP -> {
                        val dx = e.rawX - x0; val dy = e.rawY - y0
                        if (Math.abs(dx) > dp(50) && Math.abs(dx) > Math.abs(dy) * 1.5f) {
                            if (left && dx > 0) { if (listScroll.visibility != View.VISIBLE) toggleList() }
                            else if (!left && dx < 0) showMenu(menuBtn)
                        }
                    }
                }
                true
            }
            box.addView(v, FrameLayout.LayoutParams(dp(22), ViewGroup.LayoutParams.MATCH_PARENT, if (left) Gravity.START else Gravity.END))
        }
        edge(true); edge(false)
        setContentView(root)

        back.setOnClickListener { pop?.dismiss(); BrowserTabs.current()?.wv?.let { if (it.canGoBack()) it.goBack() } }
        fwd.setOnClickListener { pop?.dismiss(); BrowserTabs.current()?.wv?.let { if (it.canGoForward()) it.goForward() } }
        reload.setOnClickListener {
            pop?.dismiss()
            val t = BrowserTabs.current() ?: return@setOnClickListener
            if (t.progress < 100) t.wv.stopLoading().also { t.progress = 100; refresh() } else t.wv.reload()
        }
        tabsBtn.setOnClickListener { toggleList() }
        star.setOnClickListener {
            pop?.dismiss()
            val t = BrowserTabs.current() ?: return@setOnClickListener
            val ok = BrowserData.addBookmark(t.wv.title ?: t.title, t.url)
            Toast.makeText(this, if (ok) "Bookmark disimpan" else "Sudah ada di bookmark / halaman tidak valid", Toast.LENGTH_SHORT).show()
            refresh()
        }
        menu.setOnClickListener { showMenu(menu) }
        et.setOnEditorActionListener { _, _, _ -> go(); true }

        BrowserTabs.ui = this
        val u = intent.getStringExtra("url")
        if (BrowserTabs.tabs.isEmpty()) BrowserTabs.create(u ?: "https://www.google.com", true)
        else if (u != null) BrowserTabs.create(u, true)
        attachCurrent()
    }


    private var pop: PopupWindow? = null
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun showMenu(anchor: View) {
        pop?.dismiss()
        refresh()
        val ct = BrowserTabs.current()
        val ch = ElementBlock.host(ct?.url)
        val on = ElementBlock.isOn(ch)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply { setColor(0xFF303030.toInt()); cornerRadius = dp(10).toFloat() }
            setPadding(0, dp(4), 0, dp(4))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for (b in listOf(back, fwd, star, reload)) {
            (b.parent as? ViewGroup)?.removeView(b)
            top.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(top)
        val p = PopupWindow(col, dp(290), ViewGroup.LayoutParams.WRAP_CONTENT, true)
        p.elevation = dp(8).toFloat()
        pop = p
        fun item(t: String, chk: Boolean? = null, act: () -> Unit) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)) }
            r.addView(TextView(this).apply { text = t; textSize = 15f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (chk != null) r.addView(CheckBox(this).apply { isChecked = chk; isClickable = false; isFocusable = false })
            r.setOnClickListener { p.dismiss(); act() }
            col.addView(r)
        }
        item("Tab Baru") { BrowserTabs.create("https://www.google.com", true); listScroll.visibility = View.GONE; attachCurrent(); et.requestFocus(); et.selectAll() }
        item("Riwayat") { startActivityForResult(Intent(this, BrowserDataActivity::class.java).putExtra("mode", "history"), 7) }
        item("Bookmark-bookmark") { startActivityForResult(Intent(this, BrowserDataActivity::class.java).putExtra("mode", "bookmark"), 7) }
        item("Cari di Halaman") { findDialog() }
        item("Blokir Iklan", AdBlock.adOn()) { AdBlock.setAd(!AdBlock.adOn()) }
        item("Minta situs desktop", ct?.desktop == true) { toggleDesktop() }
        item("Blokir iklan & pop-up (pengaturan)") { startActivityForResult(Intent(this, BrowserDataActivity::class.java).putExtra("mode", "adblock"), 7) }
        item("Blokir elemen") { startPick() }
        item("Aturan blokir elemen") { startActivityForResult(Intent(this, BrowserDataActivity::class.java).putExtra("mode", "elemblock").putExtra("host", ch), 7) }
        item("Blokir elemen di situs ini", on) {
            if (ct == null || ch.isEmpty()) Toast.makeText(this, "Buka halaman web dulu", Toast.LENGTH_SHORT).show()
            else {
                ElementBlock.setOn(ch, !on)
                ElementBlock.apply(ct.wv, ct.url, true)
                Toast.makeText(this, "Blokir elemen di $ch: " + if (!on) "aktif" else "mati", Toast.LENGTH_SHORT).show()
            }
        }
        item("Daftar link diblokir") { linkBlockList() }
        val sv = ScrollView(this).apply { addView(col) }
        p.contentView = sv
        p.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        p.height = (resources.displayMetrics.heightPixels * 0.8).toInt()
        p.showAsDropDown(anchor, 0, 0, Gravity.END)
    }

    private fun toggleDesktop() {
        val t = BrowserTabs.current() ?: return
        t.desktop = !t.desktop
        val s = t.wv.settings
        s.userAgentString = if (t.desktop) "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0" else "Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0"
        s.useWideViewPort = t.desktop; s.loadWithOverviewMode = t.desktop
        t.wv.reload()
    }

    private fun findDialog() {
        val t = BrowserTabs.current() ?: return
        val e = EditText(this).apply { setSingleLine() }
        android.app.AlertDialog.Builder(this).setTitle("Cari di Halaman").setView(e)
            .setPositiveButton("Cari") { _, _ -> t.wv.findAllAsync(e.text.toString()) }
            .setNeutralButton("Berikutnya") { _, _ -> t.wv.findNext(true) }
            .setNegativeButton("Hapus sorotan") { _, _ -> t.wv.clearMatches() }.show()
    }

    private fun linkBlockList() {
        val l = LinkBlock.list()
        if (l.isEmpty()) { Toast.makeText(this, "Belum ada link yang diblokir", Toast.LENGTH_SHORT).show(); return }
        android.app.AlertDialog.Builder(this).setTitle("Link diblokir (ketuk untuk hapus)")
            .setItems(l.toTypedArray()) { _, i -> LinkBlock.remove(l[i]); Toast.makeText(this, "Dihapus dari daftar blokir", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("Tutup", null).show()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_RUNNING_LOW) try { BrowserTabs.current()?.wv?.clearCache(false) } catch (e: Exception) { }
    }

    private fun startPick() {
        val t = BrowserTabs.current() ?: return
        if (ElementBlock.host(t.url).isEmpty()) { Toast.makeText(this, "Buka halaman web dulu", Toast.LENGTH_SHORT).show(); return }
        listScroll.visibility = View.GONE
        BrowserTabs.stopPick()
        BrowserTabs.pickTab = t; t.pendingSel = null
        ElementBlock.startPick(t.wv)
        pickUpdate()
    }

    fun pickUpdate() {
        runOnUiThread {
            val p = BrowserTabs.pickTab
            if (p == null || p !== BrowserTabs.current()) { pickBar.visibility = View.GONE; return@runOnUiThread }
            val sl = p.pendingSel
            pickBar.visibility = View.VISIBLE
            pickTv.text = sl ?: "Mode pilih: sentuh elemen yang ingin diblokir (tautan tidak akan terbuka)"
            pickOk.isEnabled = sl != null
        }
    }

    private fun go() {
        val t = BrowserTabs.current() ?: return
        t.wv.loadUrl(BrowserTabs.normalize(et.text.toString()))
        t.wv.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(et.windowToken, 0)
    }

    fun attachCurrent() {
        val pt = BrowserTabs.pickTab
        if (pt != null && pt !== BrowserTabs.current()) BrowserTabs.stopPick()
        // lepas semua WebView dari kontainer lalu pasang tab aktif di bawah daftar tab
        for (t in BrowserTabs.tabs) {
            (t.wv.context as? android.content.MutableContextWrapper)?.baseContext = this
            if (t.wv.parent != null && t.wv !== BrowserTabs.current()?.wv) (t.wv.parent as ViewGroup).removeView(t.wv)
        }
        val cur = BrowserTabs.current() ?: return
        if (cur.wv.parent !== box) {
            (cur.wv.parent as? ViewGroup)?.removeView(cur.wv)
            box.addView(cur.wv, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        cur.url?.let { Resolver.submit(it, null, false, "Browser Alfy") }
        refresh()
        pickUpdate()
    }

    fun refresh() {
        runOnUiThread {
            val t = BrowserTabs.current() ?: return@runOnUiThread
            if (!et.hasFocus()) et.setText(t.url ?: "")
            pb.visibility = if (t.progress in 0..99) View.VISIBLE else View.GONE
            pb.progress = t.progress
            reload.text = if (t.progress < 100) "✕" else "⟳"
            back.isEnabled = t.wv.canGoBack(); fwd.isEnabled = t.wv.canGoForward()
            tabsBtn.text = BrowserTabs.tabs.size.toString()
            star.text = if (BrowserData.isBookmarked(t.url)) "★" else "☆"
            if (listScroll.visibility == View.VISIBLE) buildList()
        }
    }

    private fun toggleList() {
        if (listScroll.visibility == View.VISIBLE) listScroll.visibility = View.GONE
        else { buildList(); listScroll.visibility = View.VISIBLE }
    }

    private fun buildList() {
        listBox.removeAllViews()
        BrowserTabs.tabs.forEachIndexed { i, t ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(16, 12, 8, 12) }
            val tv = TextView(this).apply {
                text = (if (i == BrowserTabs.cur) "● " else "○ ") + t.title
                setTextColor(Color.WHITE); textSize = 16f; setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END
                setOnClickListener {
                    BrowserTabs.cur = i; listScroll.visibility = View.GONE; attachCurrent()
                }
            }
            val x = Button(this).apply { text = "✕"; setOnClickListener { BrowserTabs.close(i); attachCurrent(); buildList() } }
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(x)
            listBox.addView(row)
        }
    }

    fun imageMenu(src: String) {
        runOnUiThread {
            android.app.AlertDialog.Builder(this).setTitle(src)
                .setItems(arrayOf("Unduh gambar")) { _, _ -> downloadImage(src) }.show()
        }
    }

    private fun downloadImage(src: String) {
        try {
            if (!src.startsWith("http")) { Toast.makeText(this, "Gambar ini tidak bisa diunduh langsung", Toast.LENGTH_SHORT).show(); return }
            var name = src.substringBefore('#').substringBefore('?').substringAfterLast('/').ifBlank { "gambar" }
            if (!name.contains('.')) name += ".jpg"
            val t = BrowserTabs.current()
            val rq = android.app.DownloadManager.Request(Uri.parse(src))
                .setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, name)
            t?.url?.let { rq.addRequestHeader("Referer", it) }
            try { android.webkit.CookieManager.getInstance().getCookie(src)?.let { rq.addRequestHeader("Cookie", it) } } catch (e: Exception) { }
            t?.wv?.settings?.userAgentString?.let { rq.addRequestHeader("User-Agent", it) }
            (getSystemService(DOWNLOAD_SERVICE) as android.app.DownloadManager).enqueue(rq)
            Toast.makeText(this, "Mengunduh gambar: $name", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Gagal mengunduh gambar", Toast.LENGTH_SHORT).show() }
    }

    fun linkMenu(link: String, img: String? = null) {
        runOnUiThread {
            val base = arrayOf("Buka di tab baru", "Buka tab di latar belakang", "Tambahkan link ini ke daftar blokir")
            val items = if (img != null) arrayOf("Unduh gambar") + base else base
            android.app.AlertDialog.Builder(this)
                .setTitle(link)
                .setItems(items) { _, w0 ->
                    if (img != null && w0 == 0) { downloadImage(img); return@setItems }
                    val which = if (img != null) w0 - 1 else w0
                    when (which) {
                        0 -> { BrowserTabs.create(link, true); attachCurrent() }
                        1 -> {
                            BrowserTabs.create(link, false)
                            Toast.makeText(this, "Dibuka di tab latar belakang", Toast.LENGTH_SHORT).show()
                            refresh()
                        }
                        else -> Toast.makeText(this, if (LinkBlock.add(link)) "Link diblokir, tidak bisa diakses" else "Link tidak valid", Toast.LENGTH_SHORT).show()
                    }
                }.show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        val u = d?.getStringExtra("url")
        if (rc == 7 && res == RESULT_OK && u != null) BrowserTabs.current()?.wv?.loadUrl(u)
        else if (rc == 7) BrowserTabs.current()?.let { ElementBlock.apply(it.wv, it.url, true) }   // v1.15: aturan mungkin berubah
    }

    override fun onPause() { try { android.webkit.CookieManager.getInstance().flush() } catch (e: Exception) { }; super.onPause() }

    override fun onDestroy() {
        if (BrowserTabs.ui === this) BrowserTabs.ui = null
        BrowserTabs.stopPick()
        for (t in BrowserTabs.tabs) {
            (t.wv.parent as? ViewGroup)?.removeView(t.wv)
            (t.wv.context as? android.content.MutableContextWrapper)?.baseContext = Repo.app
        }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (listScroll.visibility == View.VISIBLE) { listScroll.visibility = View.GONE; return }
        if (BrowserTabs.pickTab != null) { BrowserTabs.stopPick(); return }
        val w = BrowserTabs.current()?.wv
        if (w != null && w.canGoBack()) w.goBack() else super.onBackPressed()
    }
}


/** v1.12: tombol 🚫 - daftar situs yang TIDAK discan. Ada di daftar = diblokir; tidak ada = discan seperti biasa. */
class BlockActivity : Activity() {
    private lateinit var listBox: LinearLayout
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dm = resources.displayMetrics
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply { setColor(0xFF262626.toInt()); cornerRadius = dp(14).toFloat(); setStroke(dp(1), 0x99FFFFFF.toInt()) }
        }
        fun tv(t: String, sp: Float, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sp; setTextColor(c) }
        root.addView(tv("🚫 Blokir scan situs", 16f).apply { setTypeface(null, android.graphics.Typeface.BOLD) })
        root.addView(tv("Situs di daftar ini tidak discan. Tidak ada di daftar = discan seperti biasa. youtube.com juga mencakup youtu.be/googlevideo; x.com juga twitter.com.", 11f, 0xFFBDBDBD.toInt()).apply { setPadding(0, dp(2), 0, dp(8)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val et = EditText(this).apply {
            hint = "contoh: youtube.com"; setHintTextColor(0xFF888888.toInt()); setTextColor(Color.WHITE); textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI; setSingleLine(true)
        }
        row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val add = tv("TAMBAH", 13f, 0xFF80CBC4.toInt()).apply { setTypeface(null, android.graphics.Typeface.BOLD); setPadding(dp(12), dp(8), dp(4), dp(8)) }
        fun doAdd() {
            val s = et.text.toString()
            if (s.isBlank()) return
            if (Block.add(s)) { et.setText(""); render() } else Toast.makeText(this, "Isi nama situs, mis. youtube.com", Toast.LENGTH_SHORT).show()
        }
        add.setOnClickListener { doAdd() }
        et.setOnEditorActionListener { _, _, _ -> doAdd(); true }
        row.addView(add)
        root.addView(row)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sc = ScrollView(this).apply { addView(listBox); setPadding(0, dp(8), 0, dp(8)) }
        root.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(tv("TUTUP", 13f, 0xFF80CBC4.toInt()).apply { setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.END; setPadding(dp(12), dp(8), dp(4), dp(4)); setOnClickListener { finish() } },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root, ViewGroup.LayoutParams((dm.widthPixels * 0.92).toInt(), (dm.heightPixels * 0.7).toInt()))
        window.setLayout((dm.widthPixels * 0.92).toInt(), (dm.heightPixels * 0.7).toInt())
        render()
    }

    private fun render() {
        listBox.removeAllViews()
        val l = Block.list()
        if (l.isEmpty()) listBox.addView(TextView(this).apply { text = "Daftar kosong: semua situs discan."; textSize = 13f; setTextColor(0xFFBDBDBD.toInt()) })
        l.forEachIndexed { i, e ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            r.addView(TextView(this).apply { text = "${i + 1}. $e"; textSize = 14f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(TextView(this).apply { text = "✕"; textSize = 18f; setTextColor(0xFFEF9A9A.toInt()); setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { Block.remove(e); render() } })
            listBox.addView(r)
        }
    }
}
