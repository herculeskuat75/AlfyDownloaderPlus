package com.alfy.downloader

import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.compose.runtime.mutableStateOf

private val sketchyRe = Regex("(?i)(slot|gacor|togel|judi|casino|bet(ting)?[0-9]*\\.|maxwin|zeus|toto|poker|bandar|jackpot|sbobet|parlay|1xbet|popads|popcash|adsterra|propeller|exoclick|clickadu|hilltopads|juicyads|trafficjunky)")

class PreviewActivity : Activity() {
    companion object { @Volatile var live: androidx.media3.exoplayer.ExoPlayer? = null; @Volatile var liveAct: PreviewActivity? = null; @Volatile var pending: Intent? = null }
    private var player: androidx.media3.exoplayer.ExoPlayer? = null
    private val ui = android.os.Handler(android.os.Looper.getMainLooper())
    private var tick: Runnable? = null
    private var hideRun: Runnable? = null
    private var spinner: ProgressBar? = null
    private var btnPlay: TextView? = null
    private var btnMute: TextView? = null
    private var muteBox: View? = null
    private var seek: SeekBar? = null
    private var timeTv: TextView? = null
    private var surface: android.view.SurfaceView? = null
    private var root: FrameLayout? = null
    private var topBar: View? = null
    private var bottomBar: View? = null
    private var errBox: LinearLayout? = null
    private var errTv: TextView? = null
    private var vw = 0
    private var vh = 0
    private var closing = false
    private var muted = false
    private var failed = false
    private var ctlVisible = true
    private var scrubbing = false

    // data dari Intent
    private var mainUrl = ""
    private var audioUrl: String? = null
    private var baseUa: String? = null
    private var refIn: String? = null

    // anti-403: urutan sumber (plan) dan nomor percobaan User-Agent
    private var attempt = 0
    private var planIdx = 0
    private val plans = ArrayList<() -> androidx.media3.exoplayer.source.MediaSource>()
    private val maxRetry = 4

    private fun fmt(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(s / 60, s % 60) }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, radiusDp: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radiusDp).toFloat() }

    private fun btn(t: String, size: Float = 22f, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { onClick() }
    }

    // ---- User-Agent & header anti-403 -------------------------------------------------
    /** Daftar User-Agent yang dicoba berurutan. Yang pertama = klien yang membuat link (parameter c=). */
    private fun uaList(u: String): List<String> {
        val first = if (Resolver.qp(u, "c").isNotEmpty()) Resolver.uaForGv(u) else (baseUa ?: Resolver.UA)
        return listOf(first, Resolver.UA_IOS, Resolver.UA_VR, Resolver.UA_AND, Resolver.UA).distinct()
    }

    private fun pickFactory(uri: Uri): androidx.media3.datasource.DataSource.Factory {
        val s = uri.toString()
        val gv = s.contains("googlevideo.com")
        val ua: String = if (gv) { val l = uaList(s); l[attempt.coerceIn(0, l.size - 1)] } else (baseUa ?: Resolver.UA)
        val h = HashMap<String, String>()
        refIn?.let { h["Referer"] = it }
        if (gv) {
            if (ua.startsWith("Mozilla")) { h["Origin"] = "https://www.youtube.com"; h["Referer"] = "https://www.youtube.com/" }
            else h.remove("Referer")   // klien aplikasi (iOS/VR/Android) tidak mengirim Referer
        }
        return androidx.media3.datasource.DefaultHttpDataSource.Factory()
            .setUserAgent(ua).setDefaultRequestProperties(h)
            .setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(12000).setReadTimeoutMs(15000)
    }

    private fun httpCodeOf(e: Throwable): Int? {
        var t: Throwable? = e
        var n = 0
        while (t != null && n < 8) {
            if (t is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) return t.responseCode
            t = t.cause; n++
        }
        return null
    }

    /** (Re)mulai pemutaran memakai sumber plan saat ini dan nomor percobaan UA saat ini. */
    private fun startPlay(resume: Boolean) {
        val p = player ?: return
        try {
            val pos = if (resume) p.currentPosition.coerceAtLeast(0L) else 0L
            p.stop(); p.clearMediaItems()
            p.setMediaSource(plans[planIdx](), pos)
            p.prepare()
            p.playWhenReady = true
        } catch (e: Exception) {
            failed = true
            showError("Tidak bisa diputar")
        }
    }

    // ---- UI ---------------------------------------------------------------------------
    private fun showError(msg: String) {
        failed = true
        errTv?.text = msg
        errBox?.visibility = View.VISIBLE
        setCtl(true)
        refreshUi()
    }

    private fun refreshUi() {
        val p = player ?: return
        val st = p.playbackState
        val loading = !failed && (st == androidx.media3.common.Player.STATE_BUFFERING || st == androidx.media3.common.Player.STATE_IDLE)
        spinner?.visibility = if (loading) View.VISIBLE else View.GONE
        btnPlay?.text = if (p.playWhenReady && st != androidx.media3.common.Player.STATE_ENDED) "⏸" else "▶"
        btnMute?.text = if (muted) "🔇" else "🔊"
        if (!failed) errBox?.visibility = View.GONE
    }

    private fun setCtl(show: Boolean) {
        ctlVisible = show
        for (v in listOf(topBar, bottomBar, muteBox)) {
            if (v == null) continue
            if (show) { v.visibility = View.VISIBLE; v.animate().alpha(1f).setDuration(180).start() }
            else v.animate().alpha(0f).setDuration(180).withEndAction { if (!ctlVisible) v.visibility = View.GONE }.start()
        }
        scheduleHide()
    }

    private fun scheduleHide() {
        hideRun?.let { ui.removeCallbacks(it) }
        val p = player
        if (!ctlVisible || failed || p == null || !p.playWhenReady) return
        val r = Runnable { if (!scrubbing && !failed) setCtl(false) }
        hideRun = r
        ui.postDelayed(r, 3500)
    }

    private fun fitVideo() {
        val sv = surface ?: return
        val r = root ?: return
        if (vw <= 0 || vh <= 0) return
        val W = if (r.width > 0) r.width else resources.displayMetrics.widthPixels
        val H = if (r.height > 0) r.height else resources.displayMetrics.heightPixels
        val scale = minOf(W.toFloat() / vw, H.toFloat() / vh)
        sv.layoutParams = FrameLayout.LayoutParams((vw * scale).toInt(), (vh * scale).toInt(), Gravity.CENTER)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        if (closing || i.getStringExtra("url") == null) return
        pending = i; setIntent(i); recreate()   // ganti video langsung tanpa kembali
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pending?.let { setIntent(it); pending = null }
        val url = intent.getStringExtra("url") ?: run { finish(); return }
        // satu instance: matikan total pemutar/layar pratinjau lama sebelum yang baru dibuat
        try { val prev = liveAct; if (prev != null && prev !== this) prev.closeNow() } catch (e: Exception) { }
        try { live?.let { it.playWhenReady = false; it.stop(); it.clearMediaItems(); it.release() } } catch (e: Exception) { }
        live = null
        liveAct = this
        mainUrl = url
        audioUrl = intent.getStringExtra("audio")
        val au = audioUrl
        val mode = intent.getStringExtra("mode") ?: "video"
        val sepAudio = intent.getBooleanExtra("muted", false) && au != null && au != url
        baseUa = intent.getStringExtra("ua")
        refIn = intent.getStringExtra("ref")
        val titleText = intent.getStringExtra("title") ?: ""
        val accent = 0xFF4DB6AC.toInt()

        val fl = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root = fl
        setContentView(fl)
        val sv = android.view.SurfaceView(this)
        surface = sv
        if (mode == "audio") {
            fl.addView(TextView(this).apply { text = "♪"; textSize = 96f; setTextColor(0x55FFFFFF); gravity = Gravity.CENTER },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            fl.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        }
        // ketuk layar = tampil/sembunyi kontrol
        fl.setOnClickListener { if (!failed) setCtl(!ctlVisible) }

        // animasi berputar saat memuat
        val sp = ProgressBar(this).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
        }
        spinner = sp
        fl.addView(sp, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))

        // bilah atas: kembali + judul (gradasi transparan)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(28), dp(16), dp(24))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0x00000000))
        }
        top.addView(btn("←", 26f) { closeNow() })
        top.addView(TextView(this).apply {
            text = titleText; textSize = 14f; setTextColor(Color.WHITE); maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        topBar = top
        fl.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        // bilah bawah berbentuk kapsul: jeda, waktu, geser, bisukan
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = round(0xCC121212.toInt(), 28); setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val pb = btn("⏸", 24f) {
            val p = player ?: return@btn
            if (p.playWhenReady && p.playbackState != androidx.media3.common.Player.STATE_ENDED) p.playWhenReady = false
            else { if (p.playbackState == androidx.media3.common.Player.STATE_ENDED) p.seekTo(0); p.playWhenReady = true }
            refreshUi(); scheduleHide()
        }
        btnPlay = pb
        val mb = btn("🔊", 20f) {
            muted = !muted
            player?.volume = if (muted) 0f else 1f
            refreshUi(); scheduleHide()
        }
        btnMute = mb
        val sb = SeekBar(this).apply {
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(accent)
        }
        seek = sb
        val tt = TextView(this).apply { text = "0:00 / 0:00"; setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(4), 0, dp(4), 0) }
        timeTv = tt
        bar.addView(pb)
        bar.addView(sb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(tt)
        bottomBar = bar
        fl.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            setMargins(dp(12), 0, dp(12), dp(20))
        })
        mb.background = round(0xCC121212.toInt(), 28)
        muteBox = mb
        fl.addView(mb, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(12), 0, 0, dp(92))
        })
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) { if (fromUser) player?.seekTo(v.toLong()) }
            override fun onStartTrackingTouch(s: SeekBar?) { scrubbing = true; hideRun?.let { ui.removeCallbacks(it) } }
            override fun onStopTrackingTouch(s: SeekBar?) { scrubbing = false; scheduleHide() }
        })

        // kotak galat + tombol coba lagi
        val eb = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            background = round(0xE6212121.toInt(), 16); setPadding(dp(20), dp(16), dp(20), dp(16))
            visibility = View.GONE
        }
        val et = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER }
        errTv = et
        eb.addView(et)
        eb.addView(btn("↻ Coba lagi", 16f) {
            failed = false; attempt = 0; planIdx = 0
            errBox?.visibility = View.GONE
            startPlay(false); refreshUi()
        }.apply { background = round(accent, 20); setTextColor(0xFF00201D.toInt()) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })
        errBox = eb
        fl.addView(eb, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER).apply {
            setMargins(dp(24), 0, dp(24), 0)
        })

        try {
            // User-Agent/header dipilih per alamat saat dibuka (lihat pickFactory), jadi bisa berganti saat coba ulang.
            val base = androidx.media3.datasource.DefaultHttpDataSource.Factory()
            val msf = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(this)
                .setDataSourceFactory(androidx.media3.datasource.DataSource.Factory { ChunkedDataSource(base, pick = { u -> pickFactory(u) }) })
            val msfLocal = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(androidx.media3.datasource.DefaultDataSource.Factory(this))
            fun ms(u: String): androidx.media3.exoplayer.source.MediaSource =
                (if (u.startsWith("file:") || u.startsWith("/")) msfLocal else msf).createMediaSource(androidx.media3.common.MediaItem.fromUri(if (u.startsWith("/")) "file://$u" else u))

            plans.add {
                if (mode == "audio" && au != null) ms(au)
                else if (mode == "video" && sepAudio && au != null) androidx.media3.exoplayer.source.MergingMediaSource(ms(url), ms(au))
                else ms(url)
            }
            if (mode == "video") {
                val fbUrl = intent.getStringExtra("fallback")
                if (fbUrl != null && fbUrl != url) plans.add { ms(fbUrl) }
                if (sepAudio) plans.add {
                    android.widget.Toast.makeText(this, "Audio gagal dimuat: video diputar tanpa suara. Tekan ↻ / buka ulang untuk coba lagi.", android.widget.Toast.LENGTH_LONG).show()
                    ms(url)
                }
            }

            try { live?.let { it.playWhenReady = false; it.stop(); it.clearMediaItems(); it.release() } } catch (e: Exception) { }
            val p = androidx.media3.exoplayer.ExoPlayer.Builder(this).build()
            player = p; live = p
            if (mode == "audio") {
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_VIDEO, true).build()
            } else p.setVideoSurfaceView(sv)
            p.addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlaybackStateChanged(state: Int) { refreshUi(); scheduleHide() }
                override fun onIsPlayingChanged(isPlaying: Boolean) { refreshUi(); scheduleHide() }
                override fun onVideoSizeChanged(v: androidx.media3.common.VideoSize) { vw = v.width; vh = v.height; fitVideo() }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    val hc = httpCodeOf(error)
                    if (hc == 403 && attempt < maxRetry) {      // 403 -> coba User-Agent/header klien YouTube lain
                        attempt++; startPlay(true); return
                    }
                    if (planIdx + 1 < plans.size) {             // lalu coba sumber cadangan
                        planIdx++; attempt = 0; startPlay(true); return
                    }
                    showError("Tidak bisa diputar (" + (if (hc != null) "HTTP $hc" else error.errorCodeName) + ").\nLink mungkin kedaluwarsa; pindai ulang videonya.")
                }
            })
            startPlay(false)
        } catch (e: Exception) {
            showError("Tidak bisa diputar")
        }
        val r = object : Runnable {
            override fun run() {
                val p = player
                if (p != null && !closing) {
                    try {
                        val d = p.duration
                        if (d > 0 && !scrubbing) { seek?.max = d.toInt(); seek?.progress = p.currentPosition.toInt() }
                        timeTv?.text = fmt(p.currentPosition) + " / " + fmt(if (d > 0) d else 0)
                        refreshUi()
                    } catch (e: Exception) { }
                    ui.postDelayed(this, 500)
                }
            }
        }
        tick = r; ui.post(r)
        refreshUi()
        scheduleHide()
    }

    /** Tutup seketika: suara berhenti, layar menutup, langsung kembali ke aplikasi sebelumnya. */
    private fun closeNow() {
        if (closing) return
        closing = true
        tick?.let { ui.removeCallbacks(it) }
        hideRun?.let { ui.removeCallbacks(it) }
        try { player?.playWhenReady = false } catch (e: Exception) { }
        finish()
        try { player?.let { it.stop(); it.clearMediaItems(); it.release(); if (live === it) live = null } } catch (e: Exception) { }
        player = null
    }

    override fun onBackPressed() { closeNow() }
    override fun dispatchKeyEvent(ev: android.view.KeyEvent): Boolean {
        if (ev.keyCode == android.view.KeyEvent.KEYCODE_BACK) {
            if (ev.action == android.view.KeyEvent.ACTION_UP) closeNow()
            return true
        }
        return super.dispatchKeyEvent(ev)
    }
    override fun onPause() { super.onPause(); try { player?.playWhenReady = false } catch (e: Exception) { } }
    override fun onDestroy() {
        closing = true
        tick?.let { ui.removeCallbacks(it) }
        hideRun?.let { ui.removeCallbacks(it) }
        try { player?.let { it.stop(); it.clearMediaItems(); it.release(); if (live === it) live = null } } catch (e: Exception) { }
        player = null
        if (liveAct === this) liveAct = null
        super.onDestroy()
    }
}

class ClipActivity : Activity() {
    private var done = false
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !done) {
            done = true
            try {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
                val urls = Regex("https?://[^\\s]+").findAll(t).map { it.value }.toList()
                urls.forEach { Resolver.rescan(it, null, "Manual 📋 clipboard") }
                if (urls.isNotEmpty()) Resolver.diag = "Clipboard: memindai ${urls.size} tautan…"
            } catch (e: Exception) { }
            finish()
            overridePendingTransition(0, 0)
        }
    }
}

class ShareActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val t = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
        val urls = Regex("https?://[^\\s]+").findAll(t).map { it.value }.toList()
        urls.forEach { Resolver.rescan(it, null, "Share (menu Bagikan)") }
        if (Settings.canDrawOverlays(this) && !FloatingService.running)
            ContextCompat.startForegroundService(this, Intent(this, FloatingService::class.java))
        Toast.makeText(this, if (urls.isEmpty()) "Tidak ada tautan" else "Memindai tautan… cek menu mengambang", Toast.LENGTH_LONG).show()
        finish()
    }
}

/** v1.13: satu tab = satu WebView. Disimpan di object agar status tab tidak hilang saat berpindah layar. */
class BrowserTab(val wv: WebView) {
    @Volatile var url: String? = null
    @Volatile var title: String = "Tab baru"
    var progress: Int = 100
    @Volatile var lastTouch = 0L
    @Volatile var finishedAt = 0L
    @Volatile var pendingSel: String? = null   // v1.15: elemen terpilih (mode blokir elemen)
    @Volatile var desktop = false
    @Volatile var scopeUrl: String = ""   // v1.61: URL terakhir yang memulai scope scan
}

/** v1.61: STRICT SCOPING WebView - URL tab aktif berubah = buang total hasil/cache/antrean scan sebelumnya. */
internal fun scopeNav(tab: BrowserTab, isCurrent: Boolean, url: String) {
    if (!isCurrent || !url.startsWith("http")) return
    val k = url.substringBefore('#')
    if (k == tab.scopeUrl) return
    tab.scopeUrl = k
    val h = try { android.net.Uri.parse(url).host ?: "" } catch (e: Exception) { "" }
    Resolver.beginScope(Repo.app.packageName, h)
}

object BrowserTabs {
    val tabs = mutableListOf<BrowserTab>()
    var cur = 0
    @Volatile var ui: BrowserActivity? = null
    @Volatile var pickTab: BrowserTab? = null   // v1.15: tab yang sedang dalam mode pilih elemen

    fun stopPick() {
        val p = pickTab ?: return
        pickTab = null; p.pendingSel = null
        ElementBlock.stopPick(p.wv)
        ui?.pickUpdate()
    }

    fun current(): BrowserTab? = tabs.getOrNull(cur)

    fun normalize(input: String): String {
        val u = input.trim()
        if (u.startsWith("http://") || u.startsWith("https://")) return u
        return if (u.contains(".") && !u.contains(" ")) "https://$u" else "https://www.google.com/search?q=" + Uri.encode(u)
    }

    fun create(url: String?, select: Boolean): BrowserTab {
        val w = WebView(android.content.MutableContextWrapper(Repo.app))
        val t = BrowserTab(w)
        w.overScrollMode = View.OVER_SCROLL_ALWAYS   // efek memantul/elastis ala Chrome
        w.settings.javaScriptEnabled = true
        NetAdblock.setup(w)
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.settings.mixedContentMode = 0
        w.settings.setSupportMultipleWindows(true)
        w.settings.javaScriptCanOpenWindowsAutomatically = true
        @Suppress("DEPRECATION") w.settings.saveFormData = true   // autofill: simpan data form
        if (android.os.Build.VERSION.SDK_INT >= 26) w.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_YES)   // autofill: kenali WebView di framework Autofill
        // Google memblokir login di WebView ber-UA bawaan; UA Firefox biasanya diterima
        w.settings.userAgentString = "Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0"
        try { android.webkit.CookieManager.getInstance().setAcceptCookie(true); android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(w, true) } catch (e: Exception) { }
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url.toString()
                if (u.contains(".m3u8", true)) Resolver.noteHls(u, request.requestHeaders["Referer"] ?: t.url)   // v1.63: catat m3u8 terbaru untuk force-refresh
                if (LinkBlock.isBlocked(u)) return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                if (Block.isBlocked(u)) return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                if (AdBlock.isListed(u)) return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                if (AdBlock.isAd(u, SiteSettings.adsOverride(t.url))) return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))   // v1.14: blokir domain iklan
                NetAdblock.intercept(view, request)?.let { return it }   // blokir host manual (ad_hosts.txt)
                val rf = request.requestHeaders["Referer"] ?: t.url
                // v1.4: di situs embed ber-iklan (jwplyr/vidoy), video dari host lain = iklan -> abaikan
                if (Resolver.isJwPage(t.url) && !Resolver.jwMediaOk(u)) return null
                if (!SiteSettings.scan(t.url)) return null
                if (HlsSnifferTool.onRequest(u, rf, t.url, "HLS Sniffer")) return null
                if (Resolver.isMedia(u)) Resolver.submit(u, rf, false, "Browser Alfy")
                else if (WebTool.looksMedia(u, request)) Resolver.submitMedia(u, rf, "Browser Alfy")   // v1.3: media tanpa ekstensi (Range/Accept video)
                return null
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (LinkBlock.isBlocked(request.url.toString())) return true
                if (Block.isBlocked(request.url.toString())) return true
                if (AdBlock.isListed(request.url.toString())) return true
                // v1.124: blokir redirect otomatis (isRedirect tanpa gesture); klik user (hasGesture) selalu lolos
                if (request.hasGesture()) return false.also { if (request.isForMainFrame) try { SiteSettings.apply(t, request.url.toString()) } catch (e: Throwable) { } }
                if (request.isForMainFrame && request.isRedirect && SiteSettings.redirect(t.url)) {
                    fun hr(x: String?) = (try { Uri.parse(x ?: "").host } catch (e: Exception) { null } ?: "").lowercase().removePrefix("www.")
                    val cu = t.url
                    if (!cu.isNullOrBlank() && !Wallpaper.isNewTab(cu) && hr(request.url.toString()) != hr(cu) && !Resolver.isMedia(request.url.toString()) && !AdBlock.mediaLike(request.url.toString())) return true
                }
                if (request.isForMainFrame) try { SiteSettings.apply(t, request.url.toString()) } catch (e: Throwable) { }
                if (request.isForMainFrame && AdBlock.strict(t.url)) {
                    fun hh(x: String?) = (try { Uri.parse(x ?: "").host } catch (e: Exception) { null } ?: "").lowercase()
                    val nu = request.url.toString()
                    if (hh(nu) != hh(t.url) && !Resolver.isMedia(nu) && !Resolver.jwMediaOk(nu) && !AdBlock.mediaLike(nu)) return true   // jwplyr.com: terkunci, tidak boleh pindah ke mana pun
                }
                // v1.122: blokir redirect otomatis mencurigakan (judi/iklan) ke situs lain; navigasi di situs yang sama tetap lolos
                if (request.isForMainFrame && !request.hasGesture() && SiteSettings.redirect(t.url)) {
                    val nu0 = request.url.toString()
                    fun hs(x: String?) = (try { Uri.parse(x ?: "").host } catch (e: Exception) { null } ?: "").lowercase().removePrefix("www.")
                    if (hs(nu0) != hs(t.url) && !Resolver.isMedia(nu0) && !AdBlock.mediaLike(nu0) &&
                        (AdBlock.isAd(nu0, SiteSettings.adsOverride(t.url)) || sketchyRe.containsMatchIn(nu0))) return true
                }
                // v1.14: blokir perpindahan halaman otomatis (tanpa sentuhan pengguna) setelah halaman selesai dimuat
                if (!SiteSettings.redirect(t.url) || !request.isForMainFrame || request.hasGesture()) return false
                val now = System.currentTimeMillis()
                if (t.progress < 100 || now - t.finishedAt < 300 || now - t.lastTouch < 2000) return false
                fun h(x: String?) = (try { Uri.parse(x ?: "").host } catch (e: Exception) { null } ?: "").lowercase().removePrefix("www.")
                if (h(request.url.toString()) == h(t.url)) return false
                return true
            }
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                t.url = url
                NetAdblock.onPageStarted(view, url)
                if (Wallpaper.isNewTab(url)) { t.title = "Tab baru"; return }
                scopeNav(t, current() === t, url)   // v1.61: situs baru -> clear() semua cache scan
                if (SiteSettings.apply(t, url)) { view.post { try { view.reload() } catch (e: Throwable) { } }; return }   // pengaturan situs berubah (JS/desktop): muat ulang sekali
                ElementBlock.apply(view, url)
                if (SiteSettings.redirect(url)) view.evaluateJavascript("(function(){try{window.open=function(){return null;};document.addEventListener('click',function(e){if(!e.isTrusted){e.stopPropagation();e.preventDefault();return false;}},true);}catch(x){}try{history.pushState=function(){};history.replaceState=function(){};}catch(x){}})();", null)
                if (pickTab === t) { t.pendingSel = null; ui?.pickUpdate() }
                t.progress = 0
                t.finishedAt = 0L
                // hanya tab yang sedang dilihat yang memperbarui halaman terakhir
                if (current() === t && SiteSettings.scan(url)) Resolver.submit(url, null, false, "Browser Alfy")
                ui?.refresh()
            }
            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                // v1.57: X adalah SPA - perpindahan ke x.com/.../status/ID tidak memicu onPageStarted -> picu scan (Syndication/fxtwitter) otomatis
                scopeNav(t, current() === t, url)   // v1.61: SPA (YouTube/X) pindah halaman -> cache scan dibuang
                XHomeScan.inject(view, url)   // v1.59: auto-scan beranda X (SPA)
                if (current() === t && Resolver.xStatusId(url) != null && SiteSettings.scan(url)) { t.url = url; Resolver.submit(url, null, true, "Browser Alfy") }
            }
            override fun onPageCommitVisible(view: WebView, url: String) { ElementBlock.apply(view, url); AdBlock.cosmetic(view, SiteSettings.adsOverride(url)); YtThumbScan.inject(view, url); XHomeScan.inject(view, url) }
            override fun onPageFinished(view: WebView, url: String) {
                ElementBlock.apply(view, url)
                AdBlock.cosmetic(view, SiteSettings.adsOverride(url))
                if (pickTab === t) ElementBlock.startPick(view)
                YtThumbScan.inject(view, url)
                XHomeScan.inject(view, url)
                t.progress = 100
                t.finishedAt = System.currentTimeMillis()
                BrowserData.addHistory(view.title ?: t.title, url)
                if (current() === t && url.startsWith("http")) AppPreferences.lastVisitedUrl = url
                ui?.refresh()
            }
        }
        w.addJavascriptInterface(PickBridge(t), "AlfyBlock")
        w.addJavascriptInterface(YtThumbScan.Bridge(t), "AlfyYT")
        w.addJavascriptInterface(XHomeScan.Bridge(t), "AlfyX")
        w.setOnTouchListener { _, e -> if (e.action == android.view.MotionEvent.ACTION_DOWN) t.lastTouch = System.currentTimeMillis(); false }
        w.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message): Boolean {
                if (SiteSettings.popup(t.url) || SiteSettings.redirect(t.url) || AdBlock.strict(t.url)) return false   // v1.14: tolak jendela baru / pop-up
                val nt = create(null, true)
                (resultMsg.obj as? WebView.WebViewTransport)?.webView = nt.wv
                resultMsg.sendToTarget()
                ui?.attachCurrent()
                return true
            }
            override fun onProgressChanged(view: WebView, newProgress: Int) { t.progress = newProgress; ui?.refresh() }
            override fun onReceivedTitle(view: WebView, title: String?) { if (!title.isNullOrBlank()) { t.title = title; ui?.refresh() } }
        }
        // v1.3: tombol unduh di halaman (setelah CAPTCHA) biasanya memicu unduhan file -> tangkap sebagai link
        w.setDownloadListener { url, _, _, _, _ ->
            Resolver.submitMedia(url, t.url, "Browser Alfy (unduhan)")
            Toast.makeText(Repo.app, "Link unduhan ditangkap → lihat daftar Tautan", Toast.LENGTH_SHORT).show()
        }
        w.setOnLongClickListener { v ->
            val hr = w.hitTestResult
            val type = hr.type
            if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                val img = if (type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) hr.extra else null
                val h = Handler(Looper.getMainLooper()) { m ->
                    val link = m.data?.getString("url")
                    if (!link.isNullOrBlank()) ui?.linkMenu(link, img)
                    true
                }
                w.requestFocusNodeHref(h.obtainMessage())
                true
            } else if (type == WebView.HitTestResult.IMAGE_TYPE && !hr.extra.isNullOrBlank()) {
                ui?.imageMenu(hr.extra!!); true
            } else false
        }
        tabs.add(t)
        if (select) cur = tabs.size - 1
        if (Wallpaper.isNewTab(url)) { t.url = Wallpaper.NEWTAB; Wallpaper.load(w) }
        else if (url != null) { try { SiteSettings.apply(t, url) } catch (e: Throwable) { }; w.loadUrl(url) }
        return t
    }

    fun close(i: Int) {
        if (i !in tabs.indices) return
        val t = tabs.removeAt(i)
        if (pickTab === t) { pickTab = null; ui?.pickUpdate() }
        (t.wv.parent as? ViewGroup)?.removeView(t.wv)
        // v1.15: lepas semua listener/jembatan sebelum destroy agar WebView & Activity tidak tertahan (kebocoran memori)
        try {
            t.wv.stopLoading()
            t.wv.setOnTouchListener(null); t.wv.setOnLongClickListener(null); t.wv.setDownloadListener(null)
            t.wv.removeJavascriptInterface("AlfyBlock"); t.wv.removeJavascriptInterface("AlfyYT"); t.wv.removeJavascriptInterface("AlfyX")
            t.wv.setWebViewClient(WebViewClient()); t.wv.setWebChromeClient(null)
            t.wv.removeAllViews()
            t.wv.destroy()
        } catch (e: Throwable) { }
        if (tabs.isEmpty()) { create("https://www.google.com", true); return }
        if (i < cur) cur-- else if (cur >= tabs.size) cur = tabs.size - 1
    }
}

/** ScrollView yang mengenali geser horizontal: dir>0 = geser ke kanan, dir<0 = geser ke kiri. */
class SwipeScroll(c: android.content.Context, private val dir: Int, private val onSwipe: () -> Unit) : ScrollView(c) {
    private var x0 = 0f; private var y0 = 0f; private var hit = false
    private val slop = android.view.ViewConfiguration.get(c).scaledTouchSlop * 2
    private fun ok(dx: Float, dy: Float) = Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.5f && (dx * dir > 0)
    override fun onInterceptTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { x0 = e.x; y0 = e.y; hit = false }
            android.view.MotionEvent.ACTION_MOVE -> if (ok(e.x - x0, e.y - y0)) { hit = true; return true }
        }
        return super.onInterceptTouchEvent(e)
    }
    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        if (hit) {
            if (e.actionMasked == android.view.MotionEvent.ACTION_UP) { hit = false; if (ok(e.x - x0, e.y - y0)) onSwipe() }
            else if (e.actionMasked == android.view.MotionEvent.ACTION_CANCEL) hit = false
            return true
        }
        return super.onTouchEvent(e)
    }
}

/** Keputusan buka/tutup panel geser: ikut arah dorongan terakhir, lalu posisi. */
fun panelShouldOpen(tx: Float, w: Float, lastDir: Int): Boolean =
    if (lastDir > 0) tx > -w * 0.75f else if (lastDir < 0) tx > -w * 0.25f else tx > -w * 0.5f

/** ScrollView panel kiri: bisa ditarik/didorong, panel mengikuti jari. */
class DragScroll(c: android.content.Context, private val right: Boolean = false, private val onSettle: (Boolean) -> Unit) : ScrollView(c) {
    private var x0 = 0f; private var y0 = 0f; private var sx = 0f; private var q0 = 0f; private var q = 0f; private var drag = false
    private val slop = android.view.ViewConfiguration.get(c).scaledTouchSlop
    override fun onInterceptTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { x0 = e.rawX; y0 = e.rawY; drag = false; animate().cancel() }
            android.view.MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - x0; val dy = e.rawY - y0
                if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.2f) {
                    drag = true; sx = e.rawX; q0 = Math.abs(translationX) / Math.max(1, width); q = q0; return true
                }
            }
        }
        return super.onInterceptTouchEvent(e)
    }
    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        if (drag) {
            when (e.actionMasked) {
                // v1.37: digeser ke arah mana pun = menutup panel (mengikuti jari)
                android.view.MotionEvent.ACTION_MOVE -> {
                    q = Math.max(0f, Math.min(1f, q0 + Math.abs(e.rawX - sx) / Math.max(1, width)))
                    translationX = (if (right) 1f else -1f) * q * width
                }
                android.view.MotionEvent.ACTION_UP -> { drag = false; onSettle(q < 0.4f) }
                android.view.MotionEvent.ACTION_CANCEL -> { drag = false; onSettle(q < 0.5f) }
            }
            return true
        }
        // area kosong panel (tanpa anak yang tersentuh): MOVE tidak lewat onIntercept, jadi deteksi geser mendatar di sini
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { x0 = e.rawX; y0 = e.rawY; animate().cancel() }
            android.view.MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - x0; val dy = e.rawY - y0
                if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.2f) {
                    drag = true; sx = e.rawX; q0 = Math.abs(translationX) / Math.max(1, width); q = q0
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
            }
        }
        super.onTouchEvent(e)
        return true
    }
}

/** Baris aksi geser seragam (ala 1DM+): satu baris mendatar; geser ke kanan saat di awal = tutup. */
class StripScroll(c: android.content.Context, private val onClose: () -> Unit) : HorizontalScrollView(c) {
    private var x0 = 0f; private var y0 = 0f; private var hit = false
    private val slop = android.view.ViewConfiguration.get(c).scaledTouchSlop * 2
    override fun onInterceptTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { x0 = e.x; y0 = e.y; hit = false }
            android.view.MotionEvent.ACTION_MOVE -> {
                val dx = e.x - x0
                if (scrollX == 0 && dx > slop && dx > Math.abs(e.y - y0) * 1.5f) { hit = true; return true }
            }
        }
        return super.onInterceptTouchEvent(e)
    }
    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        if (hit) {
            if (e.actionMasked == android.view.MotionEvent.ACTION_UP) { hit = false; onClose() }
            else if (e.actionMasked == android.view.MotionEvent.ACTION_CANCEL) hit = false
            return true
        }
        return super.onTouchEvent(e)
    }
}

class BrowserActivity : androidx.activity.ComponentActivity() {
    private val bmOpen = mutableStateOf(false)
    private val bmItems = mutableStateOf<List<PageItem>>(emptyList())
    private val pgTitles = mutableStateOf<List<String>>(emptyList())
    private val pgCur = mutableStateOf(0)
    private var bmView: androidx.compose.ui.platform.ComposeView? = null
    private lateinit var stripWrap: LinearLayout
    private lateinit var barView: LinearLayout
    private lateinit var rootView: LinearLayout
    private lateinit var stripRow: LinearLayout
    private lateinit var stripScroll: StripScroll
    private lateinit var box: FrameLayout
    private lateinit var et: EditText
    private lateinit var pb: ProgressBar
    private lateinit var lb: LoadBar
    private lateinit var tabsBtn: Button
    private lateinit var menuBtn: Button
    private lateinit var reload: Button
    private lateinit var back: Button
    private lateinit var star: Button
    private lateinit var fwd: Button
    private lateinit var listBox: LinearLayout
    private lateinit var listScroll: ScrollView
    private lateinit var listBoxR: LinearLayout
    private val sw = PanelSwipe()
    private val tabHist = ArrayList<BrowserTab>(); private var shownTab: BrowserTab? = null; private var navBack = false
    private var srl: androidx.swiperefreshlayout.widget.SwipeRefreshLayout? = null
    private lateinit var listScrollR: ScrollView
    private lateinit var pickBar: LinearLayout
    private lateinit var pickTv: TextView
    private lateinit var pickOk: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Wallpaper.uiColor()) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        barView = bar; rootView = root
        fun btn(t: String) = Button(this).apply { text = t; minWidth = 0; minimumWidth = 0; setPadding(18, 0, 18, 0) }
        back = btn(Icons.get("back")); fwd = btn(Icons.get("fwd")); reload = btn(Icons.get("reload")); tabsBtn = btn("1")
        star = btn(Icons.get("star")); val menu = btn(Icons.get("menu"))
        et = EditText(this).apply {
            setSingleLine(); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
        }
        menuBtn = menu
        tabsBtn.textSize = 20f; menu.textSize = 26f
        val homeBtn = btn(Icons.get("home")).apply { textSize = 18f }
        bar.addView(homeBtn, LinearLayout.LayoutParams(dp(52), dp(56)))
        bar.addView(tabsBtn, LinearLayout.LayoutParams(dp(60), dp(56)))
        bar.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(menu, LinearLayout.LayoutParams(dp(60), dp(56)))
        pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        lb = LoadBar(this)
        box = object : FrameLayout(this@BrowserActivity) {
            override fun onInterceptTouchEvent(e: android.view.MotionEvent): Boolean = sw.intercept(e)
            override fun onTouchEvent(e: android.view.MotionEvent): Boolean = sw.touch(e)
        }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listScroll = DragScroll(this, false) { open -> settlePanel(open) }.apply { setBackgroundColor(Wallpaper.uiColor()); visibility = View.GONE; addView(listBox) }
        listBoxR = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listScrollR = DragScroll(this, true) { open -> settlePanel(open, true) }.apply { setBackgroundColor(Wallpaper.uiColor()); visibility = View.GONE; addView(listBoxR) }
        pickTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f; maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END }
        pickOk = Button(this).apply { text = "SELESAI" }
        pickBar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xEE212121.toInt()); setPadding(16, 8, 16, 8); visibility = View.GONE }
        val pickRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        pickRow.addView(pickOk)
        pickBar.addView(pickTv); pickBar.addView(pickRow)
        pickOk.setOnClickListener { BrowserTabs.stopPick() }
        stripRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), 0, dp(8), 0) }
        stripScroll = StripScroll(this) { closeStrip() }.apply { isHorizontalScrollBarEnabled = false; addView(stripRow) }
        val stripX = btn(Icons.get("stop")).apply { setOnClickListener { closeStrip() } }
        stripWrap = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Wallpaper.barColor()); visibility = View.GONE; elevation = dp(4).toFloat() }
        stripWrap.addView(stripX, LinearLayout.LayoutParams(dp(52), ViewGroup.LayoutParams.MATCH_PARENT))
        stripWrap.addView(stripScroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        val barHost = object : FrameLayout(this@BrowserActivity) {
            private var ax = 0f; private var ay = 0f; private var swp = false; private var inEt = false
            override fun onInterceptTouchEvent(e: android.view.MotionEvent): Boolean {
                when (e.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> {
                        ax = e.rawX; ay = e.rawY; swp = false
                        val r = android.graphics.Rect(); inEt = et.getGlobalVisibleRect(r) && r.contains(e.rawX.toInt(), e.rawY.toInt())
                    }
                    android.view.MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - ax; val dy = e.rawY - ay
                        if (!inEt && !stripOn() && dx < -dp(40) && Math.abs(dx) > Math.abs(dy) * 1.5f) { swp = true; return true }
                    }
                }
                return false
            }
            override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
                if (!swp) return false
                if (e.actionMasked == android.view.MotionEvent.ACTION_UP) { swp = false; if (listScrollR.visibility != View.VISIBLE) showMenu(menuBtn) }
                else if (e.actionMasked == android.view.MotionEvent.ACTION_CANCEL) swp = false
                return true
            }
        }
        barHost.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        barHost.addView(stripWrap, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(barHost)
        root.addView(lb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        listScroll.isFillViewport = true
        listScrollR.isFillViewport = true
        val scrim = View(this).apply { setBackgroundColor(0x99000000.toInt()); visibility = View.GONE; alpha = 0f; setOnClickListener { sw.closeAll() } }
        box.addView(scrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box.viewTreeObserver.addOnPreDrawListener {
            val pw0 = resources.displayMetrics.widthPixels * 0.8f
            val a = Math.max(if (listScroll.visibility == View.VISIBLE) 1f - Math.abs(listScroll.translationX) / pw0 else 0f,
                             if (listScrollR.visibility == View.VISIBLE) 1f - Math.abs(listScrollR.translationX) / (resources.displayMetrics.widthPixels * 0.74f) else 0f).coerceIn(0f, 1f)
            scrim.alpha = a
            val vis = if (a > 0.01f) View.VISIBLE else View.GONE
            if (scrim.visibility != vis) scrim.visibility = vis
            true
        }
        box.addView(listScroll, FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.8f).toInt(), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START or Gravity.TOP))
        box.addView(listScrollR, FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.74f).toInt(), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END or Gravity.TOP))
        box.addView(pickBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        bmView = androidx.compose.ui.platform.ComposeView(this).apply {
            visibility = View.GONE
            setContent { AlfyTheme(wallpaperBg = false) { BookmarkDrawerUi(bmOpen.value, bmItems.value, onClose = { closeBookmarks() },
                onHidden = { bmView?.visibility = View.GONE }, onAdd = { bmAddCurrent() },
                onOpen = { p -> closeBookmarks(); BrowserTabs.current()?.wv?.loadUrl(p.url) }, onMenu = { bmItemMenu(it) }) } }
        }
        box.addView(bmView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box.addView(drawer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        applyThemeUi()
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        root.isFocusable = true; root.isFocusableInTouchMode = true; root.requestFocus()
        et.setOnFocusChangeListener { v, f -> if (!f) (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0) }
        // Keyboard hanya muncul saat kolom URL disentuh (bukan otomatis saat fokus berpindah)
        et.setShowSoftInputOnFocus(false)
        et.setOnTouchListener { v, ev ->
            if (ev.actionMasked == android.view.MotionEvent.ACTION_UP) v.post { showKb() }
            false
        }

        back.setOnClickListener { pop?.dismiss(); BrowserTabs.current()?.wv?.let { if (it.canGoBack()) it.goBack() } }
        fwd.setOnClickListener { pop?.dismiss(); BrowserTabs.current()?.wv?.let { if (it.canGoForward()) it.goForward() } }
        reload.setOnClickListener {
            pop?.dismiss()
            val t = BrowserTabs.current() ?: return@setOnClickListener
            if (t.progress < 100) t.wv.stopLoading().also { t.progress = 100; refresh() } else t.wv.reload()
        }
        tabsBtn.setOnClickListener { toggleList() }
        homeBtn.setOnClickListener {
            pop?.dismiss()
            val hu = homeUrl()
            val t = BrowserTabs.current()
            if (t == null) { BrowserTabs.create(hu, true); attachCurrent() } else t.wv.loadUrl(hu)
        }
        star.setOnClickListener {
            pop?.dismiss()
            val t = BrowserTabs.current() ?: return@setOnClickListener
            if (BrowserData.isBookmarked(t.url)) {
                BrowserData.removeBookmarkUrl(t.url)
                Toast.makeText(this, "Bookmark dihapus", Toast.LENGTH_SHORT).show()
            } else {
                val ok = BrowserData.addBookmark(t.wv.title ?: t.title, t.url)
                Toast.makeText(this, if (ok) "Bookmark disimpan" else "Halaman tidak valid", Toast.LENGTH_SHORT).show()
            }
            star.text = if (BrowserData.isBookmarked(t.url)) Icons.get("starOn") else Icons.get("star")
            refreshBm(); refresh()
        }
        star.setOnLongClickListener { pop?.dismiss(); showBookmarks(); true }
        menu.setOnClickListener { showMenu(menu) }
        et.setOnEditorActionListener { _, _, _ -> go(); true }

        BrowserTabs.ui = this
        val u = intent.getStringExtra("url")
        if (BrowserTabs.tabs.isEmpty()) {
            // v1.40: pulihkan tab (urutan + tab aktif) yang tersimpan permanen
            val sv = (Repo.prefs().getString("tabsSave", null) ?: "").lines().filter { it.isNotEmpty() }
            if (sv.isNotEmpty()) {
                for (x in sv) BrowserTabs.create(x, false)
                BrowserTabs.cur = Repo.prefs().getInt("tabsCur", 0).coerceIn(0, BrowserTabs.tabs.size - 1)
                if (u != null) BrowserTabs.create(u, true)
            } else BrowserTabs.create(u ?: AppPreferences.lastVisitedUrl.ifEmpty { "https://www.google.com" }, true)
        } else if (u != null) BrowserTabs.create(u, true)
        attachCurrent()
    }

    private val drawer by lazy { RightDrawer(this) }
    private fun openDrawer(content: View, closed: (() -> Unit)? = null) {
        pop?.dismiss(); hideKb()
        if (stripOn()) closeStrip()
        listScroll.visibility = View.GONE; listScrollR.visibility = View.GONE
        drawer.show(content, closed)
    }
    private fun closeBookmarks() { bmOpen.value = false }
    private fun refreshBm() { bmItems.value = BrowserData.bookmarks().let { l -> l.filter { it.fav } + l.filter { !it.fav } } }
    private fun showBookmarks() {
        pop?.dismiss(); hideKb()
        if (stripOn()) closeStrip()
        listScroll.visibility = View.GONE; listScrollR.visibility = View.GONE
        refreshBm()
        bmView?.visibility = View.VISIBLE
        bmOpen.value = true
    }
    private fun bmAddCurrent() {
        val t = BrowserTabs.current() ?: return
        val ok = BrowserData.addBookmark(t.wv.title ?: t.title, t.url)
        Toast.makeText(this, if (ok) "Bookmark disimpan" else "Sudah ada di bookmark / halaman tidak valid", Toast.LENGTH_SHORT).show()
        refreshBm(); refresh()
    }
    private fun bmItemMenu(p: PageItem) {
        android.app.AlertDialog.Builder(this).setTitle(p.title)
            .setItems(arrayOf("Hapus", "Ganti nama", if (p.fav) "Hapus dari favorit" else "Tandai favorit")) { _, w ->
                when (w) {
                    0 -> { BrowserData.removeBookmark(p); refreshBm(); refresh() }
                    1 -> {
                        val e = EditText(this).apply { setText(p.title); setSelectAllOnFocus(true); setSingleLine() }
                        android.app.AlertDialog.Builder(this).setTitle("Ganti nama").setView(e)
                            .setPositiveButton("Simpan") { _, _ -> BrowserData.renameBookmark(p, e.text.toString()); refreshBm() }
                            .setNegativeButton("Batal", null).show()
                    }
                    else -> { BrowserData.toggleFavorite(p); refreshBm() }
                }
            }.show()
    }

    private fun homeUrl(): String = Repo.prefs().getString("homeUrl", null)?.takeIf { it.isNotBlank() } ?: "https://www.google.com"
    private fun showHomeSettings() {
        val cur = homeUrl()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        val dlg = android.app.AlertDialog.Builder(this).setTitle("Pengaturan").setView(col).setNegativeButton("Tutup", null).create()
        col.addView(Button(this).apply { text = "Alamat beranda\n$cur"; isAllCaps = false; setOnClickListener { dlg.dismiss(); editHome(cur) } })
        col.addView(Button(this).apply { text = "Tema (Katalog)"; isAllCaps = false; setOnClickListener { dlg.dismiss(); startActivity(Intent(this@BrowserActivity, ThemeCatalogActivity::class.java)) } })
        col.addView(Button(this).apply { text = "Ganti Tema Sekarang"; isAllCaps = false; setOnClickListener {
            Toast.makeText(this@BrowserActivity, "Mengunduh tema…", Toast.LENGTH_SHORT).show()
            Wallpaper.refresh { ok -> runOnUiThread {
                if (ok) { Wallpaper.reloadTabs(); Toast.makeText(this@BrowserActivity, "Tema diganti", Toast.LENGTH_SHORT).show() }
                else Toast.makeText(this@BrowserActivity, "Gagal mengunduh tema", Toast.LENGTH_SHORT).show()
            } }
        } })
        col.addView(Switch(this).apply { text = "Ganti Tema Otomatis (Harian)"; isChecked = AppPreferences.wallpaperAuto
            setPadding(0, dp(12), 0, dp(12)); setOnCheckedChangeListener { _, c -> AppPreferences.wallpaperAuto = c } })
        dlg.show()
    }
    private fun editHome(cur: String) {
        val e = EditText(this).apply { setText(cur); setSelectAllOnFocus(true); setSingleLine(); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI }
        android.app.AlertDialog.Builder(this).setTitle("Edit alamat beranda").setView(e)
            .setPositiveButton("Simpan") { _, _ ->
                var u = e.text.toString().trim()
                if (u.isEmpty()) u = "https://www.google.com" else if (!u.contains("://")) u = "https://$u"
                Repo.prefs().edit().putString("homeUrl", u).apply()
                Toast.makeText(this, "Beranda disimpan", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null).show()
    }
    private fun saveTabs() {
        try {
            val cu = BrowserTabs.current()
            val keep = BrowserTabs.tabs.filter { !(it.url ?: it.wv.url).isNullOrEmpty() }
            val urls = keep.map { (it.url ?: it.wv.url)!! }
            Repo.prefs().edit().putString("tabsSave", urls.joinToString("\n")).putInt("tabsCur", keep.indexOf(cu).coerceAtLeast(0)).apply()
        } catch (e: Exception) { }
    }


    private var pop: PopupWindow? = null
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** Isi menu (baris tombol + daftar pilihan); dipakai popup tombol ☰ dan panel geser kanan. */
    private fun fillMenu(col: LinearLayout, close: () -> Unit, horiz: Boolean = false) {
        val ct = BrowserTabs.current()
        val ch = ElementBlock.host(ct?.url)
        val on = ElementBlock.isOn(ch)
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for (b in listOf(back, fwd, star, reload)) {
            (b.parent as? ViewGroup)?.removeView(b); b.minWidth = 0; b.minimumWidth = 0
            if (horiz) col.addView(b, LinearLayout.LayoutParams(dp(52), dp(44)).apply { setMargins(dp(2), 0, dp(2), 0) })
            else top.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        if (!horiz) {
            top.setPadding(dp(8), dp(10), dp(8), dp(10))
            for (b in listOf(back, fwd, star, reload)) {
                b.background = null; b.setTextColor(Color.WHITE); b.textSize = 22f; b.setPadding(0, 0, 0, 0)
            }
            fun ic(s: String, act: () -> Unit) = TextView(this).apply {
                text = s; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                setOnClickListener { close(); act() }
            }
            top.addView(ic(Icons.get("gear")) { showHomeSettings() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(ic(Icons.get("mainmenu")) { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)); finish() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            col.addView(top)
        }
        val rows = ArrayList<Pair<String, View>>()
        fun item(t: String, chk: Boolean? = null, act: () -> Unit) {
            if (horiz) { val c = chip(t, chk, close, act); c.tag = t; rows.add(t to c); return }
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(11), dp(16), dp(11)) }
            val icon = when {
                t.startsWith("Tab Baru") -> Icons.get("m_new"); t.startsWith("Tambahkan situs") -> Icons.get("m_pin"); t == "Riwayat" -> Icons.get("m_hist")
                t.startsWith("Bookmark") -> Icons.get("m_bm"); t.startsWith("Cari") -> Icons.get("m_find"); t == "Blokir Iklan" -> Icons.get("m_ad")
                t.startsWith("Minta situs") -> Icons.get("m_desk"); t.startsWith("Blokir elemen") || t.startsWith("Aturan") || t.startsWith("Blokir situs") -> Icons.get("m_elem")
                t.startsWith("Pengaturan") -> Icons.get("m_set"); else -> Icons.get("m_filter")
            }
            r.addView(TextView(this).apply { text = icon; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(32), ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(18) })
            r.addView(TextView(this).apply { text = t; textSize = 17f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (chk != null) r.addView(Switch(this).apply { isChecked = chk; isClickable = false; isFocusable = false
                val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
                thumbTintList = android.content.res.ColorStateList(st, intArrayOf(0xFF80CBC4.toInt(), 0xFFBDBDBD.toInt()))
                trackTintList = android.content.res.ColorStateList(st, intArrayOf(0x6680CBC4, 0x66FFFFFF)) })
            r.setOnClickListener { close(); act() }
            r.tag = t
            rows.add(t to r)
        }
        item("Tab Baru") { BrowserTabs.create(Wallpaper.NEWTAB, true); listScroll.visibility = View.GONE; listScrollR.visibility = View.GONE; attachCurrent(); et.requestFocus(); et.selectAll(); showKb() }
        item("Tema") { startActivity(Intent(this, ThemeCatalogActivity::class.java)) }
        item("Tambahkan situs ke layar utama") { SiteShortcut.pinWithFavicon(this, ct?.url ?: ct?.wv?.url, ct?.wv?.title ?: ct?.title, try { ct?.wv?.favicon } catch (e: Throwable) { null }) }
        item("Riwayat") { openDrawer(BrowserDataPanel(this, "history", "", { drawer.close() }, { u -> drawer.close(); BrowserTabs.current()?.wv?.loadUrl(u) },
            { u, bg -> drawer.close(); if (!bg) { BrowserTabs.create(u, true); attachCurrent() } else { BrowserTabs.create(u, false); Toast.makeText(this, "Dibuka di tab latar belakang", Toast.LENGTH_SHORT).show(); refresh() } }).build()) }
        item("Bookmark-bookmark") { showBookmarks() }
        item("Cari di Halaman") { findDialog() }
        item("Blokir Iklan", AdBlock.adOn()) { AdBlock.setAd(!AdBlock.adOn()) }
        item("Minta situs desktop", ct?.desktop == true) { toggleDesktop() }
        item("Blokir situs ini") {
            if (ch.isEmpty()) Toast.makeText(this, "Buka halaman web dulu", Toast.LENGTH_SHORT).show()
            else {
                val ok = Block.add(ch)
                if (ok) try { BrowserTabs.current()?.wv?.loadUrl("about:blank") } catch (e: Throwable) { }
                Toast.makeText(this, if (ok) "Situs $ch diblokir, tidak bisa diakses lagi" else "Situs tidak valid", Toast.LENGTH_SHORT).show()
            }
        }
        item("Blokir elemen") { startPick() }
        item("Blokir elemen di situs ini", on) {
            if (ct == null || ch.isEmpty()) Toast.makeText(this, "Buka halaman web dulu", Toast.LENGTH_SHORT).show()
            else {
                ElementBlock.setOn(ch, !on)
                ElementBlock.apply(ct.wv, ct.url, true)
                Toast.makeText(this, "Blokir elemen di $ch: " + if (!on) "aktif" else "mati", Toast.LENGTH_SHORT).show()
            }
        }
        item("Pengaturan situs ini") { SiteSettings.panel(this, ct) { drawer.close() }?.let { openDrawer(it) } }
        item("Blokir & Filter") { openDrawer(BlockHubPanel(this, 0) { drawer.close() }.build()) { BrowserTabs.current()?.let { ElementBlock.apply(it.wv, it.url, true) } } }
        // v1.39: urutan menu bebas diatur (tahan lama lalu seret naik/turun), disimpan permanen
        val saved = (Repo.prefs().getString("menuOrder", null) ?: "").lines().filter { it.isNotEmpty() }
        val sorted = rows.withIndex().sortedBy { (i, r) -> val k = saved.indexOf(r.first); if (k < 0) 1000 + i else k }.map { it.value }
        val lst = LinearLayout(this).apply { orientation = if (horiz) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        for ((_, v) in sorted) lst.addView(v)
        col.addView(lst)
        for ((_, v) in sorted) enableReorder(v, v, lst, 400L, horiz) { _, _ ->
            val order = (0 until lst.childCount).mapNotNull { lst.getChildAt(it).tag as? String }
            Repo.prefs().edit().putString("menuOrder", order.joinToString("\n")).apply()
        }
    }

    private fun buildMenuPanel() {
        listBoxR.removeAllViews()
        listBoxR.setPadding(0, dp(4), 0, dp(4)); listScrollR.setBackgroundColor(Wallpaper.uiColor2())
        fillMenu(listBoxR, { settlePanel(false, true) })
        Wallpaper.tintTree(listScrollR, Wallpaper.onColor(Wallpaper.uiColor2()))
    }

    private fun stripOn() = ::stripWrap.isInitialized && stripWrap.visibility == View.VISIBLE

    private fun chip(t: String, chk: Boolean?, close: () -> Unit, act: () -> Unit) = TextView(this).apply {
        text = (if (chk == true) "☑ " else if (chk == false) "☐ " else "") + t
        textSize = 14f; setTextColor(Color.WHITE); setSingleLine(); gravity = Gravity.CENTER
        setPadding(dp(14), dp(10), dp(14), dp(10))
        background = android.graphics.drawable.GradientDrawable().apply { setColor(0xFF424242.toInt()); cornerRadius = dp(18).toFloat() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(4), 0, dp(4), 0) }
        setOnClickListener { close(); act() }
    }

    /** Satu pola untuk semua menu browser: baris aksi mendatar masuk dari kanan di bar atas. */
    private fun openStrip(fill: (LinearLayout) -> Unit = { fillMenu(it, { closeStrip() }, true) }) {
        pop?.dismiss(); hideKb()
        refresh()
        listScroll.visibility = View.GONE; listScrollR.visibility = View.GONE
        stripRow.removeAllViews()
        fill(stripRow)
        stripScroll.scrollTo(0, 0)
        stripWrap.animate().cancel()
        if (stripWrap.visibility != View.VISIBLE) { stripWrap.translationX = resources.displayMetrics.widthPixels.toFloat(); stripWrap.visibility = View.VISIBLE }
        stripWrap.animate().translationX(0f).setDuration(220).setInterpolator(android.view.animation.DecelerateInterpolator(1.4f)).start()
    }

    private fun closeStrip() {
        if (!stripOn()) return
        stripWrap.animate().cancel()
        stripWrap.animate().translationX(resources.displayMetrics.widthPixels.toFloat()).setDuration(200).withEndAction {
            stripWrap.visibility = View.GONE; stripWrap.translationX = 0f
        }.start()
    }

    private fun showMenu(anchor: View) {
        if (listScrollR.visibility == View.VISIBLE) { settlePanel(false, true); return }
        pop?.dismiss(); hideKb(); refresh()
        if (stripOn()) closeStrip()
        listScroll.animate().cancel(); listScroll.visibility = View.GONE; listScroll.translationX = 0f
        listScrollR.animate().cancel()
        buildMenuPanel()
        listScrollR.translationX = resources.displayMetrics.widthPixels * 0.74f
        listScrollR.visibility = View.VISIBLE
        settlePanel(true, true)
    }

    private fun toggleDesktop() {
        val t = BrowserTabs.current() ?: return
        t.desktop = !t.desktop
        val s = t.wv.settings
        s.userAgentString = if (t.desktop) "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0" else "Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0"
        s.useWideViewPort = t.desktop; s.loadWithOverviewMode = t.desktop
        t.wv.reload()
    }

    private fun findDialog() {
        val t = BrowserTabs.current() ?: return
        val e = EditText(this).apply { setSingleLine() }
        android.app.AlertDialog.Builder(this).setTitle("Cari di Halaman").setView(e)
            .setPositiveButton("Cari") { _, _ -> t.wv.findAllAsync(e.text.toString()) }
            .setNeutralButton("Berikutnya") { _, _ -> t.wv.findNext(true) }
            .setNegativeButton("Hapus sorotan") { _, _ -> t.wv.clearMatches() }.show()
    }

    private fun linkBlockList() {
        val l = LinkBlock.list()
        if (l.isEmpty()) { Toast.makeText(this, "Belum ada link yang diblokir", Toast.LENGTH_SHORT).show(); return }
        android.app.AlertDialog.Builder(this).setTitle("Link diblokir (ketuk untuk hapus)")
            .setItems(l.toTypedArray()) { _, i -> LinkBlock.remove(l[i]); Toast.makeText(this, "Dihapus dari daftar blokir", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("Tutup", null).show()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_RUNNING_LOW) try { BrowserTabs.current()?.wv?.clearCache(false) } catch (e: Exception) { }
    }

    private fun startPick() {
        val t = BrowserTabs.current() ?: return
        if (ElementBlock.host(t.url).isEmpty()) { Toast.makeText(this, "Buka halaman web dulu", Toast.LENGTH_SHORT).show(); return }
        listScroll.visibility = View.GONE; listScrollR.visibility = View.GONE
        BrowserTabs.stopPick()
        BrowserTabs.pickTab = t; t.pendingSel = null
        ElementBlock.startPick(t.wv)
        pickUpdate()
    }

    private fun blockPending() {
        val p = BrowserTabs.pickTab; val sl = p?.pendingSel
        if (p != null && sl != null) {
            val h = ElementBlock.host(p.url)
            if (h.isNotEmpty() && ElementBlock.add(h, sl)) {
                ElementBlock.setOn(h, true)
                ElementBlock.apply(p.wv, p.url, true)
                Toast.makeText(this, "Elemen diblokir di $h", Toast.LENGTH_SHORT).show()
            }
            p.pendingSel = null
            pickUpdate()
        }
    }

    /** Konfirmasi sebelum memblokir elemen (anti-clickjacking). */
    fun confirmPick(sel: String, tag: String, cls: String) {
        runOnUiThread {
            if (isFinishing) return@runOnUiThread
            pickUpdate()
            val c = if (cls.isBlank()) "-" else cls.take(120)
            android.app.AlertDialog.Builder(this)
                .setMessage("Blokir elemen ini?\nTag: $tag\nClass: $c")
                .setCancelable(false)
                .setNegativeButton("Batal") { _, _ -> BrowserTabs.pickTab?.pendingSel = null; pickUpdate() }
                .setPositiveButton("Blokir") { _, _ -> blockPending() }
                .show()
        }
    }

    fun pickUpdate() {
        runOnUiThread {
            val p = BrowserTabs.pickTab
            if (p == null || p !== BrowserTabs.current()) { pickBar.visibility = View.GONE; return@runOnUiThread }
            val sl = p.pendingSel
            pickBar.visibility = View.VISIBLE
            pickTv.text = sl ?: "Mode pilih: sentuh elemen yang ingin diblokir (tautan tidak akan terbuka)"
            pickOk.isEnabled = true
        }
    }

    private fun showKb() {
        try {
            if (!et.hasFocus()) et.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showSoftInput(et, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        } catch (e: Exception) { }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::et.isInitialized && !et.hasFocus()) hideKb()
    }

    private fun hideKb() {
        try {
            if (et.hasFocus()) { et.clearFocus(); (findViewById<ViewGroup>(android.R.id.content).getChildAt(0))?.requestFocus() }
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(et.windowToken, 0)
        } catch (e: Exception) { }
    }

    /** Terapkan Sumber Gambar + Gaya UI: latar (gambar/warna), bar atas, drawer, dan kontras teks. */
    private fun applyThemeUi() {
        try {
            val bgc = Wallpaper.uiColor(); val bar = Wallpaper.barColor(); val dr = Wallpaper.uiColor2()
            val img = if (Wallpaper.isTransparent()) Wallpaper.bgDrawable() else null
            if (img != null) rootView.background = img else rootView.setBackgroundColor(bgc)
            barView.setBackgroundColor(bar)
            if (::stripWrap.isInitialized) stripWrap.setBackgroundColor(bar)
            val onBar = Wallpaper.onColor(bar)
            et.setTextColor(onBar); et.setHintTextColor((onBar and 0x00FFFFFF) or 0x88000000.toInt())
            listScroll.setBackgroundColor(if (Wallpaper.isTransparent()) dr else bgc); listScrollR.setBackgroundColor(dr)
            Wallpaper.tintTree(listScroll, Wallpaper.onColor(if (Wallpaper.isTransparent()) dr else bgc)); Wallpaper.tintTree(listScrollR, Wallpaper.onColor(dr))
        } catch (e: Throwable) { }
    }

    override fun onResume() {
        super.onResume()
        if (::et.isInitialized) hideKb()
        applyThemeUi()
        try { for (t in BrowserTabs.tabs) t.wv.onResume() } catch (e: Exception) { }
        try { BrowserTabs.current()?.wv?.resumeTimers() } catch (e: Exception) { }
        if (Wallpaper.needsDaily()) Wallpaper.refresh { ok -> if (ok) runOnUiThread { Wallpaper.reloadTabs() } }
    }

    private fun go() {
        val t = BrowserTabs.current() ?: return
        t.wv.loadUrl(BrowserTabs.normalize(et.text.toString()))
        t.wv.requestFocus()
        hideKb()
    }

    fun attachCurrent() {
        BrowserTabs.current()?.let { ct0 -> ct0.url?.let { u0 -> ct0.scopeUrl = ""; scopeNav(ct0, true, u0) } }   // v1.61: ganti tab = ganti scope
        val pt = BrowserTabs.pickTab
        if (pt != null && pt !== BrowserTabs.current()) BrowserTabs.stopPick()
        // lepas semua WebView dari kontainer lalu pasang tab aktif di bawah daftar tab
        for (t in BrowserTabs.tabs) {
            (t.wv.context as? android.content.MutableContextWrapper)?.baseContext = this
            if (t.wv.parent != null && t.wv !== BrowserTabs.current()?.wv) (t.wv.parent as ViewGroup).removeView(t.wv)
        }
        val cur = BrowserTabs.current() ?: return
        if (srl == null || cur.wv.parent !== srl) {
            (cur.wv.parent as? ViewGroup)?.removeView(cur.wv)
            srl?.let { box.removeView(it) }
            val sr = androidx.swiperefreshlayout.widget.SwipeRefreshLayout(this)
            sr.setColorSchemeColors(0xFF80CBC4.toInt(), 0xFF4DB6AC.toInt())
            sr.setProgressBackgroundColorSchemeColor(0xFF303030.toInt())
            sr.setDistanceToTriggerSync(dp(120))
            sr.setOnChildScrollUpCallback { _, _ -> cur.wv.scrollY > 0 }
            sr.setOnRefreshListener { BrowserTabs.current()?.wv?.reload(); sr.postDelayed({ sr.isRefreshing = false }, 1200) }
            sr.addOnLayoutChangeListener { v, _, t, _, b, _, ot, _, ob ->
                if (b - t != ob - ot && b - t > 0) {   // spinner di tengah layar (tidak menutupi bar alamat)
                    val h = b - t; val c = dp(40)
                    (v as androidx.swiperefreshlayout.widget.SwipeRefreshLayout).setProgressViewOffset(true, h / 4 - c / 2, h / 2 - c / 2)
                }
            }
            sr.addView(cur.wv, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            box.addView(sr, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            sr.post { val h = sr.height; if (h > 0) { val c = dp(40); sr.setProgressViewOffset(true, h / 4 - c / 2, h / 2 - c / 2) } }
            cur.wv.overScrollMode = View.OVER_SCROLL_ALWAYS
            srl = sr
        }
        if (shownTab !== cur) {
            if (!navBack) shownTab?.let { if (BrowserTabs.tabs.contains(it)) { tabHist.remove(it); tabHist.add(it) } }
            shownTab = cur
        }
        navBack = false
        cur.url?.takeIf { !Wallpaper.isNewTab(it) }?.let { Resolver.submit(it, null, false, "Browser Alfy") }
        refresh()
        pickUpdate()
    }

    fun refresh() {
        runOnUiThread {
            val t = BrowserTabs.current() ?: return@runOnUiThread
            pgTitles.value = BrowserTabs.tabs.map { it.title }; pgCur.value = BrowserTabs.cur
            if (!et.hasFocus()) et.setText(t.url ?: "")
            pb.visibility = if (t.progress in 0..99) View.VISIBLE else View.GONE
            pb.progress = t.progress
            lb.setLoad(t.progress)
            reload.text = if (t.progress < 100) Icons.get("stop") else Icons.get("reload")
            back.isEnabled = t.wv.canGoBack(); fwd.isEnabled = t.wv.canGoForward()
            tabsBtn.text = BrowserTabs.tabs.size.toString()
            star.text = if (BrowserData.isBookmarked(t.url)) Icons.get("starOn") else Icons.get("star")
            if (listScroll.visibility == View.VISIBLE) buildList()
            if (listScrollR.visibility == View.VISIBLE) buildMenuPanel()
        }
    }

    /**
     * v1.36: gesture geser panel kiri (daftar tab) dan kanan (menu) dari mana saja.
     * Geser ke kanan = panel kiri masuk, geser ke kiri = panel kanan masuk; panel yang lain ikut keluar bersamaan (bergantian).
     * Dari tepi layar sensitif; dari tengah layar hanya geser yang benar-benar mendatar (agar tidak bentrok dengan scroll vertikal).
     * Menutup: geser ke arah mana pun dari mana saja (panel yang sedang keluar menutup); geser ke arah panel seberang menukar panel.
     */
    private inner class PanelSwipe {
        private var mode = -1   // -1 abaikan, 1 menunggu, 2 aktif
        private var downX = 0f; private var downY = 0f; private var lastX = 0f; private var dir = 0
        private var edge = false; private var edgeL = false; private var edgeR = false; private var rightward = true
        private var inc: ScrollView? = null; private var out: ScrollView? = null; private var closeOnly = false
        private var p0 = 0f; private var p = 0f; private var scrimTap = false
        private fun pwOf(v: View?): Float = if (v === listScrollR) resources.displayMetrics.widthPixels * 0.74f else resources.displayMetrics.widthPixels * 0.8f

        private fun covers(v: View, x: Float): Boolean {
            if (v.visibility != View.VISIBLE) return false
            val r = android.graphics.Rect()
            return v.getGlobalVisibleRect(r) && x >= r.left && x <= r.right
        }

        fun intercept(e: android.view.MotionEvent): Boolean {
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; lastX = e.rawX; dir = 0
                    val w = resources.displayMetrics.widthPixels
                    edgeL = e.rawX < dp(20); edgeR = e.rawX > w - dp(20); edge = edgeL || edgeR
                    mode = if (covers(listScroll, e.rawX) || covers(listScrollR, e.rawX)) -1 else 1
                    // area gelap di luar panel: ambil alih sentuhan agar WebView tidak menelannya (ketuk = tutup)
                    scrimTap = mode == 1 && (listScroll.visibility == View.VISIBLE || listScrollR.visibility == View.VISIBLE || stripOn())
                    return scrimTap
                }
                android.view.MotionEvent.ACTION_POINTER_DOWN -> { if (mode == 1) mode = -1; return mode == 2 }
                android.view.MotionEvent.ACTION_MOVE -> {
                    if (mode == 1) {
                        val dx = e.rawX - downX; val dy = e.rawY - downY
                        val adx = Math.abs(dx); val ady = Math.abs(dy)
                        val sens = edge || listScroll.visibility == View.VISIBLE || listScrollR.visibility == View.VISIBLE || stripOn()
                        if (adx > (if (sens) dp(12) else dp(48)) && adx > ady * (if (sens) 1.2f else 3f)) {
                            mode = if (begin(dx > 0)) 2 else -1
                        } else if (ady > dp(16) && ady > adx) mode = -1
                    }
                    return mode == 2
                }
            }
            return mode == 2
        }

        fun touch(e: android.view.MotionEvent): Boolean {
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> return true
                android.view.MotionEvent.ACTION_MOVE -> {
                    if (mode == 1) intercept(e)
                    if (mode == 2) update(e)
                    return true
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    if (mode == 2) settle(e.actionMasked == android.view.MotionEvent.ACTION_CANCEL)
                    else if (scrimTap && mode == 1 && e.actionMasked == android.view.MotionEvent.ACTION_UP &&
                        Math.abs(e.rawX - downX) < dp(16) && Math.abs(e.rawY - downY) < dp(16)) closeAll()
                    scrimTap = false
                    mode = -1
                    return true
                }
            }
            return mode == 2
        }

        fun closeAll() {
            if (stripOn()) closeStrip()
            if (listScroll.visibility == View.VISIBLE) settlePanel(false, false)
            if (listScrollR.visibility == View.VISIBLE) settlePanel(false, true)
        }

        private fun begin(right: Boolean): Boolean {
            closeOnly = false
            if (!right) {   // geser ke kiri = baris aksi seragam
                if (listScroll.visibility == View.VISIBLE) settlePanel(false, false)
                if (edgeR && listScrollR.visibility != View.VISIBLE && !bmOpen.value && !drawer.open) showMenu(menuBtn)
                return false
            }
            if (stripOn()) { closeStrip(); return false }
            val cur = if (listScroll.visibility == View.VISIBLE) listScroll else if (listScrollR.visibility == View.VISIBLE) listScrollR else null
            if (cur != null) {
                val swap = (cur === listScroll && !right && edgeR) || (cur === listScrollR && right && edgeL)
                if (!swap) {
                    // panel sedang keluar: geseran dari area gelap mana pun (arah mana pun) menutupnya
                    cur.animate().cancel(); inc = cur; out = null; closeOnly = true
                    p0 = Math.min(1f, Math.abs(cur.translationX) / pwOf(cur)); p = p0
                    return true
                }
            }
            if (!(if (right) edgeL else edgeR)) return false
            val i = if (right) listScroll else listScrollR
            val o = if (right) listScrollR else listScroll
            i.animate().cancel(); o.animate().cancel()
            if (i.visibility != View.VISIBLE) {
                if (right) buildList() else buildMenuPanel()
                i.translationX = if (right) -pwOf(i) else pwOf(i); i.visibility = View.VISIBLE
            }
            inc = i; out = o; rightward = right
            p0 = 1f - Math.abs(i.translationX) / pwOf(i); p = p0
            return true
        }

        private fun update(e: android.view.MotionEvent) {
            val d = e.rawX - lastX; if (d != 0f) dir = if (d > 0) 1 else -1
            lastX = e.rawX
            if (closeOnly) {
                val c = inc ?: return
                p = Math.max(0f, Math.min(1f, p0 + Math.abs(e.rawX - downX) / pwOf(c)))
                c.translationX = (if (c === listScroll) -pwOf(c) else pwOf(c)) * p
                return
            }
            val moved = if (rightward) e.rawX - downX else downX - e.rawX
            val i = inc ?: return; val o = out ?: return
            p = Math.max(0f, Math.min(1f, p0 + moved / pwOf(i)))
            i.translationX = (if (rightward) -pwOf(i) else pwOf(i)) * (1f - p)
            if (o.visibility == View.VISIBLE) o.translationX = (if (rightward) pwOf(o) else -pwOf(o)) * p
        }

        private fun slide(v: View, to: Float, hide: Boolean) {
            v.animate().translationX(to).setDuration(220).setInterpolator(android.view.animation.DecelerateInterpolator(1.4f)).withEndAction {
                if (hide && Math.abs(v.translationX - to) <= 1f) { v.visibility = View.GONE; v.translationX = 0f }
            }.start()
        }

        private fun settle(cancel: Boolean) {
            val i = inc ?: return
            if (closeOnly) {
                if (if (cancel) p > 0.5f else p > 0.35f) slide(i, if (i === listScroll) -pwOf(i) else pwOf(i), true) else slide(i, 0f, false)
                return
            }
            val o = out ?: return
            val fwd = if (rightward) dir > 0 else dir < 0
            val open = if (cancel || dir == 0) p > 0.5f else if (fwd) p > 0.2f else p > 0.8f
            val inHidden = if (rightward) -pwOf(i) else pwOf(i)
            val outHidden = if (rightward) pwOf(o) else -pwOf(o)
            if (open) {
                slide(i, 0f, false)
                if (o.visibility == View.VISIBLE) slide(o, outHidden, true)
            } else {
                slide(i, inHidden, true)
                if (o.visibility == View.VISIBLE) slide(o, 0f, false)
            }
        }
    }

    private fun settlePanel(open: Boolean, right: Boolean = false) {
        val p = if (right) listScrollR else listScroll
        val pw = p.width.toFloat().takeIf { it > 0f } ?: (resources.displayMetrics.widthPixels * 0.8f)
        val hidden = if (right) pw else -pw
        if (open) p.animate().translationX(0f).setDuration(220).setInterpolator(android.view.animation.DecelerateInterpolator(1.4f)).start()
        else p.animate().translationX(hidden).setDuration(220).setInterpolator(android.view.animation.DecelerateInterpolator(1.4f)).withEndAction {
            if (Math.abs(p.translationX - hidden) <= 1f) { p.visibility = View.GONE; p.translationX = 0f }
        }.start()
    }

    private fun toggleList() {
        listScroll.animate().cancel(); listScroll.translationX = 0f
        listScrollR.animate().cancel(); listScrollR.visibility = View.GONE; listScrollR.translationX = 0f
        if (listScroll.visibility == View.VISIBLE) listScroll.visibility = View.GONE
        else { buildList(); applyThemeUi(); listScroll.visibility = View.VISIBLE }
    }

    private fun buildList() {
        fillList(listBox)
    }

    /** Tahan lama lalu seret ke atas/bawah untuk mengubah urutan baris di dalam list. */
    private fun enableReorder(handle: View, row: View, list: LinearLayout, delay: Long = 400L, horiz: Boolean = false, onDone: (Int, Int) -> Unit) {
        var dragging = false; var startY = 0f; var from = 0; var tgt = 0
        var tops = FloatArray(0); var hs = FloatArray(0)
        val start = Runnable {
            dragging = true; from = list.indexOfChild(row); tgt = from
            tops = FloatArray(list.childCount) { (if (horiz) list.getChildAt(it).left else list.getChildAt(it).top).toFloat() }
            hs = FloatArray(list.childCount) { (if (horiz) list.getChildAt(it).width else list.getChildAt(it).height).toFloat() }
            handle.parent?.requestDisallowInterceptTouchEvent(true)
            row.alpha = 0.85f; row.translationZ = dp(8).toFloat()
            handle.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        }
        handle.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> { startY = if (horiz) e.rawX else e.rawY; dragging = false; if (delay == 0L) { start.run(); true } else { v.postDelayed(start, delay); false } }
                android.view.MotionEvent.ACTION_MOVE -> {
                    if (!dragging) {
                        if (delay != 0L && Math.abs((if (horiz) e.rawX else e.rawY) - startY) > dp(10)) v.removeCallbacks(start)
                        false
                    } else {
                        val dy = (if (horiz) e.rawX else e.rawY) - startY
                        if (horiz) row.translationX = dy else row.translationY = dy
                        val cy = tops[from] + dy + hs[from] / 2f
                        var t = from
                        for (i in from + 1 until tops.size) if (cy > tops[i] + hs[i] / 2f) t = i
                        for (i in from - 1 downTo 0) if (cy < tops[i] + hs[i] / 2f) t = i
                        for (i in tops.indices) {
                            if (i == from) continue
                            val shift = if (from < t && i in (from + 1)..t) -hs[from] else if (from > t && i in t until from) hs[from] else 0f
                            (if (horiz) list.getChildAt(i).animate().translationX(shift) else list.getChildAt(i).animate().translationY(shift)).setDuration(120).start()
                        }
                        tgt = t
                        true
                    }
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    v.removeCallbacks(start)
                    if (dragging) {
                        dragging = false
                        for (i in 0 until list.childCount) { list.getChildAt(i).animate().cancel(); list.getChildAt(i).translationY = 0f; list.getChildAt(i).translationX = 0f }
                        row.alpha = 1f; row.translationZ = 0f
                        if (e.actionMasked == android.view.MotionEvent.ACTION_UP && tgt != from) {
                            val f = from; val t = tgt
                            list.post { list.removeViewAt(f); list.addView(row, t); onDone(f, t) }
                        }
                        true
                    } else false
                }
                else -> false
            }
        }
    }

    private fun reorderTabs(from: Int, to: Int) {
        val ct = BrowserTabs.current()
        val t = BrowserTabs.tabs.removeAt(from)
        BrowserTabs.tabs.add(to, t)
        BrowserTabs.cur = BrowserTabs.tabs.indexOf(ct).coerceAtLeast(0)
        saveTabs()
        buildList()
    }

    private fun fillList(lb: LinearLayout) {
        lb.removeAllViews()
        BrowserTabs.tabs.forEachIndexed { i, t ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(16, 12, 8, 12) }
            val tv = TextView(this).apply {
                text = (if (i == BrowserTabs.cur) "● " else "○ ") + (i + 1) + ". " + t.title
                setTextColor(Color.WHITE); textSize = 14f; setSingleLine(false); maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END
                setOnClickListener {
                    BrowserTabs.cur = i; listScroll.visibility = View.GONE; listScrollR.visibility = View.GONE; attachCurrent()
                }
            }
            val x = Button(this).apply { text = "✕"; setOnClickListener { BrowserTabs.close(i); attachCurrent(); saveTabs(); buildList() } }
            val grip = TextView(this).apply { text = "☰"; setTextColor(0xFFBDBDBD.toInt()); textSize = 20f; setPadding(0, 0, dp(10), 0); isClickable = true }
            row.addView(grip)
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(x)
            lb.addView(row)
            enableReorder(tv, row, lb) { f, t -> reorderTabs(f, t) }
            enableReorder(grip, row, lb, 0L) { f, t -> reorderTabs(f, t) }
        }
    }

    private fun stripLabel(r: LinearLayout, t: String) = r.addView(TextView(this).apply {
        text = t; textSize = 12f; setTextColor(0xFFBDBDBD.toInt()); setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END
        maxWidth = dp(150); setPadding(dp(8), 0, dp(8), 0)
    })

    private fun popupMenu(title: String, items: List<Pair<String, () -> Unit>>) {
        android.app.AlertDialog.Builder(this).setTitle(title.take(80))
            .setItems(items.map { it.first }.toTypedArray()) { _, k -> items[k].second() }
            .setNegativeButton("Tutup", null).show()
    }

    fun imageMenu(src: String) {
        runOnUiThread { popupMenu(src, listOf("Unduh gambar" to { downloadImage(src) })) }
    }

    private fun downloadImage(src: String) {
        try {
            if (!src.startsWith("http")) { Toast.makeText(this, "Gambar ini tidak bisa diunduh langsung", Toast.LENGTH_SHORT).show(); return }
            var name = src.substringBefore('#').substringBefore('?').substringAfterLast('/').ifBlank { "gambar" }
            if (!name.contains('.')) name += ".jpg"
            val t = BrowserTabs.current()
            val rq = android.app.DownloadManager.Request(Uri.parse(src))
                .setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, name)
            t?.url?.let { rq.addRequestHeader("Referer", it) }
            try { android.webkit.CookieManager.getInstance().getCookie(src)?.let { rq.addRequestHeader("Cookie", it) } } catch (e: Exception) { }
            t?.wv?.settings?.userAgentString?.let { rq.addRequestHeader("User-Agent", it) }
            (getSystemService(DOWNLOAD_SERVICE) as android.app.DownloadManager).enqueue(rq)
            Toast.makeText(this, "Mengunduh gambar: $name", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Gagal mengunduh gambar", Toast.LENGTH_SHORT).show() }
    }

    private fun copyLinkText(link: String) {
        try {
            (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("link", link))
            Toast.makeText(this, "Link disalin", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Gagal menyalin", Toast.LENGTH_SHORT).show() }
    }

    private fun previewLink(link: String) {
        val tvUrl = TextView(this).apply {
            text = link; textSize = 14f; setTextIsSelectable(true)
            val pd = (16 * resources.displayMetrics.density).toInt(); setPadding(pd, pd, pd, pd)
        }
        val sv = ScrollView(this).apply { addView(tvUrl) }
        android.app.AlertDialog.Builder(this).setTitle("Tujuan link").setView(sv)
            .setPositiveButton("Buka di tab baru") { _, _ -> BrowserTabs.create(link, true); attachCurrent() }
            .setNeutralButton("Salin") { _, _ -> copyLinkText(link) }
            .setNegativeButton("Tutup", null).show()
    }

    fun linkMenu(link: String, img: String? = null) {
        runOnUiThread {
            val l = ArrayList<Pair<String, () -> Unit>>()
            if (img != null) l.add("Unduh gambar" to { downloadImage(img) })
            l.add("Buka di tab baru" to { BrowserTabs.create(link, true); attachCurrent() })
            l.add("Buka tab di latar belakang" to {
                BrowserTabs.create(link, false)
                Toast.makeText(this, "Dibuka di tab latar belakang", Toast.LENGTH_SHORT).show()
                refresh()
            })
            l.add("Pratinjau link" to { previewLink(link) })
            l.add("Salin link" to { copyLinkText(link) })
            l.add("Bagikan" to {
                try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, link), "Bagikan link")) }
                catch (e: Exception) { Toast.makeText(this, "Tidak bisa membagikan", Toast.LENGTH_SHORT).show() }
            })
            l.add("Buka di aplikasi lain" to {
                try { startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW, Uri.parse(link)), "Buka dengan")) }
                catch (e: Exception) { Toast.makeText(this, "Tidak ada aplikasi untuk link ini", Toast.LENGTH_SHORT).show() }
            })
            l.add("Tambahkan link ini ke daftar blokir" to {
                Toast.makeText(this, if (LinkBlock.add(link)) "Link diblokir, tidak bisa diakses" else "Link tidak valid", Toast.LENGTH_SHORT).show()
            })
            popupMenu(link, l)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        val u = d?.getStringExtra("url")
        val nt = d?.getStringExtra("newTabUrl")
        val bg = d?.getStringExtra("bgTabUrl")
        if (rc == 7 && res == RESULT_OK && nt != null) { BrowserTabs.create(nt, true); attachCurrent() }
        else if (rc == 7 && res == RESULT_OK && bg != null) {
            BrowserTabs.create(bg, false)
            Toast.makeText(this, "Dibuka di tab latar belakang", Toast.LENGTH_SHORT).show()
            refresh()
        }
        else if (rc == 7 && res == RESULT_OK && u != null) BrowserTabs.current()?.wv?.loadUrl(u)
        else if (rc == 7) BrowserTabs.current()?.let { ElementBlock.apply(it.wv, it.url, true) }   // v1.15: aturan mungkin berubah
    }

    override fun onPause() {
        try { android.webkit.CookieManager.getInstance().flush() } catch (e: Exception) { }
        saveTabs()
        // hemat RAM/CPU: jeda semua tab (tanpa destroy, halaman tidak refresh)
        try { for (t in BrowserTabs.tabs) t.wv.onPause() } catch (e: Exception) { }
        // pauseTimers bersifat global; jangan jalankan bila scan latar (WebView tersembunyi) sedang aktif
        try { if (!Chain.busy() && ScanLimit.active.isEmpty()) BrowserTabs.current()?.wv?.pauseTimers() } catch (e: Exception) { }
        super.onPause()
    }

    override fun onDestroy() {
        if (BrowserTabs.ui === this) BrowserTabs.ui = null
        BrowserTabs.stopPick()
        for (t in BrowserTabs.tabs) {
            (t.wv.parent as? ViewGroup)?.removeView(t.wv)
            (t.wv.context as? android.content.MutableContextWrapper)?.baseContext = Repo.app
        }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    /** Pull-to-refresh kini lewat SwipeRefreshLayout (attachCurrent). */
    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        if (ev.actionMasked == android.view.MotionEvent.ACTION_DOWN && et.hasFocus()) {
            val r = android.graphics.Rect(); et.getGlobalVisibleRect(r)
            if (!r.contains(ev.rawX.toInt(), ev.rawY.toInt())) hideKb()
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onBackPressed() {
        if (drawer.open) { drawer.close(); return }
        if (bmOpen.value) { closeBookmarks(); return }
        if (et.hasFocus()) { hideKb(); return }
        if (stripOn()) { closeStrip(); return }
        if (listScroll.visibility == View.VISIBLE || listScrollR.visibility == View.VISIBLE) { listScroll.visibility = View.GONE; listScrollR.visibility = View.GONE; return }
        if (BrowserTabs.pickTab != null) { BrowserTabs.stopPick(); return }
        val w = BrowserTabs.current()?.wv
        if (w != null && w.canGoBack()) { w.goBack(); return }
        // v1.39: tidak ada riwayat halaman -> kembali ke tab yang dibuka sebelumnya (bukan langsung keluar)
        while (tabHist.isNotEmpty()) {
            val t = tabHist.removeAt(tabHist.size - 1)
            val i = BrowserTabs.tabs.indexOf(t)
            if (i >= 0 && t !== BrowserTabs.current()) { navBack = true; BrowserTabs.cur = i; attachCurrent(); return }
        }
        super.onBackPressed()
    }
}


/** v1.12: tombol 🚫 - daftar situs yang TIDAK discan. Ada di daftar = diblokir; tidak ada = discan seperti biasa. */
class BlockActivity : Activity() {
    private lateinit var listBox: LinearLayout
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dm = resources.displayMetrics
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply { setColor(0xFF262626.toInt()); cornerRadius = dp(14).toFloat(); setStroke(dp(1), 0x99FFFFFF.toInt()) }
        }
        fun tv(t: String, sp: Float, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sp; setTextColor(c) }
        root.addView(tv("🚫 Blokir scan situs", 16f).apply { setTypeface(null, android.graphics.Typeface.BOLD) })
        root.addView(tv("Situs di daftar ini tidak discan. Tidak ada di daftar = discan seperti biasa. youtube.com juga mencakup youtu.be/googlevideo; x.com juga twitter.com.", 11f, 0xFFBDBDBD.toInt()).apply { setPadding(0, dp(2), 0, dp(8)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val et = EditText(this).apply {
            hint = "contoh: youtube.com"; setHintTextColor(0xFF888888.toInt()); setTextColor(Color.WHITE); textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI; setSingleLine(true)
            background = android.graphics.drawable.GradientDrawable().apply { setColor(0xFF2C2C2C.toInt()); cornerRadius = dp(8).toFloat(); setStroke(dp(1), 0xFF555555.toInt()) }; setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val add = tv("TAMBAH", 13f, 0xFF212121.toInt()).apply { setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply { setColor(0xFF80CBC4.toInt()); cornerRadius = dp(8).toFloat() }; setPadding(dp(14), dp(10), dp(14), dp(10)) }
        (add as TextView).layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) }
        fun doAdd() {
            val s = et.text.toString()
            if (s.isBlank()) return
            if (Block.add(s)) { et.setText(""); render() } else Toast.makeText(this, "Isi nama situs, mis. youtube.com", Toast.LENGTH_SHORT).show()
        }
        add.setOnClickListener { doAdd() }
        et.setOnEditorActionListener { _, _, _ -> doAdd(); true }
        row.addView(add)
        root.addView(row)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sc = ScrollView(this).apply { addView(listBox); setPadding(0, dp(8), 0, dp(8)) }
        root.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(tv("TUTUP", 13f, 0xFF80CBC4.toInt()).apply { setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.END; setPadding(dp(12), dp(8), dp(4), dp(4)); setOnClickListener { finish() } },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root, ViewGroup.LayoutParams((dm.widthPixels * 0.92).toInt(), (dm.heightPixels * 0.7).toInt()))
        window.setLayout((dm.widthPixels * 0.92).toInt(), (dm.heightPixels * 0.7).toInt())
        render()
    }

    private fun render() {
        listBox.removeAllViews()
        val l = Block.list()
        if (l.isEmpty()) listBox.addView(TextView(this).apply { text = "Daftar kosong: semua situs discan."; textSize = 13f; setTextColor(0xFFBDBDBD.toInt()) })
        l.forEachIndexed { i, e ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = android.graphics.drawable.GradientDrawable().apply { setColor(0xFF2C2C2C.toInt()); cornerRadius = dp(10).toFloat() }; setPadding(dp(14), dp(4), dp(4), dp(4))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) } }
            r.addView(TextView(this).apply { text = "${i + 1}. $e"; textSize = 14f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(TextView(this).apply { text = "✕"; textSize = 18f; setTextColor(0xFFEF9A9A.toInt()); setPadding(dp(14), dp(10), dp(14), dp(10)); setOnClickListener { Block.remove(e); render() } })
            listBox.addView(r)
        }
    }
}
