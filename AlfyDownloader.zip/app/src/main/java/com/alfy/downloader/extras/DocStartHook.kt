package com.alfy.downloader.extras

import android.webkit.WebView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject

/**
 * Pemantau ringan di dalam halaman web (WebView). Disuntik SEBELUM skrip situs berjalan.
 * Melapor: URL media dari fetch/XHR/atur src, dan terutama currentSrc dari elemen video/audio yang SEDANG DIPUTAR
 * (kind = "play") -> berguna menyaring iklan. Hanya melapor, tidak mengubah/menghalangi halaman.
 *
 * Belum dipanggil kode lama. Cara pakai (panggil SEBELUM loadUrl, javaScriptEnabled harus true):
 *   DocStartHook.install(webView) { url, kind, page -> Resolver.submitMedia(url, page, "Hook halaman ($kind)") }
 * Mengembalikan false bila WebView perangkat tidak mendukung -> biarkan jalur lama bekerja.
 */
object DocStartHook {
    const val BRIDGE = "AlfyHook"

    fun supported(): Boolean = try {
        WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT) &&
            WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)
    } catch (e: Throwable) { false }

    fun install(webView: WebView, onHit: (url: String, kind: String, page: String) -> Unit): Boolean {
        if (!supported()) return false
        return try {
            WebViewCompat.addWebMessageListener(webView, BRIDGE, setOf("*")) { _, message, _, _, _ ->
                try {
                    val d = message.data
                    if (d != null) {
                        val o = JSONObject(d)
                        val u = o.optString("u")
                        if (u.startsWith("http")) onHit(u, o.optString("k"), o.optString("p"))
                    }
                } catch (e: Throwable) { }
            }
            WebViewCompat.addDocumentStartJavaScript(webView, SCRIPT, setOf("*"))
            true
        } catch (e: Throwable) { false }
    }

    private val SCRIPT = """
(function(){
  if (window.__alfyH || !window.AlfyHook) return;
  window.__alfyH = 1;
  var seen = {}, n = 0;
  var re = /\.(?:mp4|m3u8|mpd|webm|m4a|mp3|flv|mov)(?:[?#&]|${'$'})|videoplayback|mime=(?:video|audio)/i;
  function rep(u, k) {
    try {
      if (!u || typeof u !== 'string') return;
      var a = document.createElement('a'); a.href = u; u = a.href;
      if (u.indexOf('http') !== 0) return;
      if (k !== 'play' && !re.test(u)) return;
      var key = k + '|' + u;
      if (seen[key] || n > 200) return;
      seen[key] = 1; n++;
      AlfyHook.postMessage(JSON.stringify({u: u, k: k, p: location.href}));
    } catch (e) {}
  }
  try {
    var f = window.fetch;
    if (f) window.fetch = function(i) { try { rep(typeof i === 'string' ? i : (i && i.url), 'fetch'); } catch (e) {} return f.apply(this, arguments); };
  } catch (e) {}
  try {
    var xo = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(m, u) { try { rep(String(u), 'xhr'); } catch (e) {} return xo.apply(this, arguments); };
  } catch (e) {}
  try {
    var d = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'src');
    if (d && d.set) Object.defineProperty(HTMLMediaElement.prototype, 'src', {
      get: d.get, configurable: true, enumerable: d.enumerable,
      set: function(v) { try { rep(String(v), 'src'); } catch (e) {} return d.set.call(this, v); }
    });
  } catch (e) {}
  function scan() {
    try {
      var l = document.querySelectorAll('video,audio,source');
      for (var i = 0; i < l.length && i < 30; i++) {
        var e = l[i], u = e.currentSrc || e.src;
        rep(u, (e.paused === false) ? 'play' : 'src');
      }
    } catch (e) {}
  }
  setInterval(scan, 2000);
})();
"""
}
