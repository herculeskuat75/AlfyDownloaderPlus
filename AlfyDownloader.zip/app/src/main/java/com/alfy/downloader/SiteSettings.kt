package com.alfy.downloader

import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.widget.*
import org.json.JSONObject

/**
 * Pengaturan per situs (key = host tanpa "www."), disimpan permanen di prefs "siteSettings" (JSON).
 * Hanya menyimpan nilai yang DIUBAH; kunci yang tidak ada = ikuti pengaturan global (perilaku lama tidak berubah).
 * Tri-state: null = ikuti global, true = aktif, false = mati.
 */
object SiteSettings {
    private const val KEY = "siteSettings"
    const val UA_DESKTOP = "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"
    const val UA_MOBILE = "Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0"
    private val FIELDS = listOf("desktop", "js", "popup", "scan", "ads")

    fun host(url: String?): String {
        val h = try { Uri.parse(url ?: "").host } catch (e: Exception) { null } ?: return ""
        return h.lowercase().removePrefix("www.")
    }

    @Synchronized private fun readAll(): JSONObject =
        try { JSONObject(Repo.prefs().getString(KEY, null) ?: "{}") } catch (e: Exception) { JSONObject() }

    @Synchronized fun get(host: String, field: String): Boolean? {
        if (host.isEmpty()) return null
        val o = readAll().optJSONObject(host) ?: return null
        return if (o.has(field)) o.optBoolean(field) else null
    }

    @Synchronized fun set(host: String, field: String, v: Boolean?) {
        if (host.isEmpty()) return
        val all = readAll()
        val o = all.optJSONObject(host) ?: JSONObject()
        if (v == null) o.remove(field) else o.put(field, v)
        if (o.length() == 0) all.remove(host) else all.put(host, o)
        Repo.prefs().edit().putString(KEY, all.toString()).apply()
    }

    @Synchronized fun reset(host: String) {
        val all = readAll(); all.remove(host)
        Repo.prefs().edit().putString(KEY, all.toString()).apply()
    }

    // ---- nilai efektif (null/tanpa pengaturan -> pakai global) ----
    fun adsOverride(url: String?): Boolean? = get(host(url), "ads")
    fun popup(url: String?): Boolean = get(host(url), "popup") ?: AdBlock.popupOn()
    fun redirect(url: String?): Boolean = get(host(url), "popup") ?: AdBlock.redirectOn()
    fun scanHost(h: String): Boolean = get(h.lowercase().removePrefix("www."), "scan") != false
    fun scan(url: String?): Boolean = scanHost(host(url))

    /** Terapkan JS & mode desktop/mobile ke tab. true = ada perubahan sehingga halaman perlu dimuat ulang. Panggil di thread utama. */
    fun apply(t: BrowserTab, url: String?): Boolean {
        val h = host(url); if (h.isEmpty()) return false
        val js = get(h, "js") ?: true
        val dsk = get(h, "desktop") ?: t.desktop
        val ua = if (dsk) UA_DESKTOP else UA_MOBILE
        val st = try { t.wv.settings } catch (e: Throwable) { return false }
        val changed = st.javaScriptEnabled != js || st.userAgentString != ua
        if (changed) {
            st.javaScriptEnabled = js
            st.userAgentString = ua
            st.useWideViewPort = dsk; st.loadWithOverviewMode = dsk
        }
        return changed
    }

    /** Panel "Pengaturan situs ini" (isi di drawer kanan). null = tidak ada halaman web. */
    fun panel(a: Activity, t: BrowserTab?, onClose: () -> Unit): android.view.View? {
        val h = host(t?.url ?: t?.wv?.url)
        if (t == null || h.isEmpty()) { Toast.makeText(a, "Buka halaman web dulu", Toast.LENGTH_SHORT).show(); return null }
        val dp = a.resources.displayMetrics.density
        val col = android.widget.LinearLayout(a).apply { orientation = android.widget.LinearLayout.VERTICAL; setPadding((16 * dp).toInt(), (8 * dp).toInt(), (16 * dp).toInt(), 0) }
        val labels = mapOf(
            "desktop" to "Mode situs", "js" to "JavaScript", "popup" to "Blokir pop-up & redirect",
            "scan" to "Scan otomatis", "ads" to "Blokir iklan")
        val opts = mapOf(
            "desktop" to listOf("Ikuti global" to null, "Desktop" to true, "Mobile" to false),
            "js" to listOf("Ikuti global (aktif)" to null, "Aktif" to true, "Mati" to false),
            "popup" to listOf("Ikuti global" to null, "Blokir" to true, "Izinkan" to false),
            "scan" to listOf("Ikuti global" to null, "Mati untuk situs ini" to false),
            "ads" to listOf("Ikuti global" to null, "Aktif" to true, "Mati" to false))
        col.addView(TextView(a).apply { text = h; textSize = 16f; setTextColor(Color.WHITE); setPadding(0, 0, 0, (8 * dp).toInt()) })
        val spinners = HashMap<String, Spinner>()
        for (f in FIELDS) {
            col.addView(TextView(a).apply { text = labels[f]; textSize = 13f; setTextColor(Color.WHITE); setPadding(0, (6 * dp).toInt(), 0, 0) })
            val o = opts[f]!!
            val sp = Spinner(a)
            sp.adapter = object : ArrayAdapter<String>(a, android.R.layout.simple_spinner_dropdown_item, o.map { it.first }) {
                override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View =
                    super.getView(position, convertView, parent).also { (it as? TextView)?.setTextColor(Color.WHITE) }
            }
            val cur = get(h, f)
            sp.setSelection(o.indexOfFirst { it.second == cur }.coerceAtLeast(0))
            spinners[f] = sp
            col.addView(sp)
        }
        fun tx(s: String, c: Int, onClick: () -> Unit) = TextView(a).apply {
            text = s; textSize = 13f; setTextColor(c); setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding((12 * dp).toInt(), (8 * dp).toInt(), (12 * dp).toInt(), (8 * dp).toInt()); setOnClickListener { onClick() }
        }
        val teal = 0xFF80CBC4.toInt()
        val head = android.widget.LinearLayout(a).apply { orientation = android.widget.LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        head.addView(TextView(a).apply { text = "Pengaturan situs ini"; textSize = 18f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) },
            android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(tx("TUTUP", teal) { onClose() })
        val foot = android.widget.LinearLayout(a).apply { orientation = android.widget.LinearLayout.HORIZONTAL; gravity = android.view.Gravity.END; setPadding(0, (16 * dp).toInt(), 0, (16 * dp).toInt()) }
        foot.addView(tx("Reset", teal) {
            reset(h)
            try { apply(t, t.url ?: t.wv.url); t.wv.reload() } catch (e: Throwable) { }
            Toast.makeText(a, "Kembali ke pengaturan global: $h", Toast.LENGTH_SHORT).show()
            onClose()
        })
        foot.addView(tx("Batal", teal) { onClose() })
        foot.addView(tx("Simpan", teal) {
            for (f in FIELDS) set(h, f, opts[f]!![spinners[f]!!.selectedItemPosition].second)
            try { apply(t, t.url ?: t.wv.url) } catch (e: Throwable) { }
            Toast.makeText(a, "Tersimpan untuk $h", Toast.LENGTH_SHORT).show()
            onClose()
        })
        col.addView(foot)
        val root = android.widget.LinearLayout(a).apply { orientation = android.widget.LinearLayout.VERTICAL; setBackgroundColor(0xFF212121.toInt()); setPadding((16 * dp).toInt(), (14 * dp).toInt(), 0, (10 * dp).toInt()) }
        root.addView(head, android.widget.LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = (16 * dp).toInt() })
        root.addView(ScrollView(a).apply { addView(col) }, android.widget.LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }
}
