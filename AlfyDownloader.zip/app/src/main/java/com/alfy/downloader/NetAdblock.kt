package com.alfy.downloader

import com.github.edsuns.adfilter.AdFilter
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

/** LAPIS 1 - Adblock jaringan nyata via Edsuns AdblockAndroid (API langsung, tanpa refleksi). */
object NetAdblock {
    @Volatile var filter: AdFilter? = null
    private val main = Handler(Looper.getMainLooper())

    val ready get() = filter != null

    /** shouldInterceptRequest: non-null = blokir request ini. */
    fun intercept(view: WebView?, req: WebResourceRequest): WebResourceResponse? {
        val f = filter ?: return null
        val result = f.shouldIntercept(view, req)
        return result.resourceResponse
    }

    fun setup(webView: WebView) { filter?.setupWebView(webView) }

    fun onPageStarted(view: WebView, url: String) { filter?.performScript(view, url) }

    fun status(): String =
        if (filter == null) "✗ Adblock jaringan tidak aktif" else "✓ Adblock jaringan aktif"

    /** Daftarkan & unduh filter lewat manajemen unduhan bawaan library. */
    fun sync(): String {
        val f = filter ?: return "gagal: library adblock tidak aktif"
        val urls = NetFilterStore.urls()
        val ids = NetFilterStore.ids()
        val vm = f.viewModel
        var ok = 0
        for (k in ids.keys().asSequence().toList().filter { it !in urls }) { vm.removeFilter(ids.getString(k)); ids.remove(k) }
        for (u in urls) {
            var id = ids.optString(u, "")
            if (id.isEmpty()) {
                val name = android.net.Uri.parse(u).host ?: u
                id = vm.addFilter(name, u).id
                ids.put(u, id)
            }
            vm.setFilterEnabled(id, true)
            vm.download(id)
            ok++
        }
        NetFilterStore.saveIds(ids)
        val msg = if (urls.isEmpty()) "tidak ada URL filter" else "$ok/${urls.size} daftar diunduh"
        NetFilterStore.setLast(msg)
        return msg
    }

    fun syncAsync() { main.post { try { sync() } catch (e: Throwable) { NetFilterStore.setLast("gagal: " + (e.message ?: "")) } } }
}

/** Penyimpanan SharedPreferences untuk menu "Blokir & Filter" (URL daftar filter, auto-update, id filter). */
object NetFilterStore {
    private fun p() = Repo.app.getSharedPreferences("alfy_netfilter", 0)
    fun urls(): List<String> = try {
        val a = JSONArray(p().getString("urls", "[]")); (0 until a.length()).map { a.getString(it) }
    } catch (e: Exception) { emptyList() }
    fun add(u: String): Boolean {
        val x = u.trim()
        if (!(x.startsWith("http://") || x.startsWith("https://")) || x.length < 12 || x.contains(' ')) return false
        val l = urls().toMutableList(); if (x !in l) l.add(x)
        p().edit().putString("urls", JSONArray(l).toString()).apply(); return true
    }
    fun remove(u: String) { p().edit().putString("urls", JSONArray(urls().filter { it != u }).toString()).apply() }
    fun ids(): JSONObject = try { JSONObject(p().getString("ids", "{}")) } catch (e: Exception) { JSONObject() }
    fun saveIds(o: JSONObject) { p().edit().putString("ids", o.toString()).apply() }
    fun auto() = p().getBoolean("auto", true)
    fun setAuto(v: Boolean) { p().edit().putBoolean("auto", v).apply() }
    fun hours() = p().getInt("hours", 24)
    fun setHours(h: Int) { p().edit().putInt("hours", h).apply() }
    fun last() = p().getString("last", "belum pernah diperbarui") ?: ""
    fun setLast(m: String) {
        val t = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        p().edit().putString("last", "$t — $m").apply()
    }
}

/** Pengunduhan & pembaruan filter dikelola library Edsuns; di sini hanya memicu sinkron. */
object NetFilterSync {
    fun schedule(ctx: Context) { NetAdblock.syncAsync() }
    fun now(ctx: Context) { NetAdblock.syncAsync() }
}
