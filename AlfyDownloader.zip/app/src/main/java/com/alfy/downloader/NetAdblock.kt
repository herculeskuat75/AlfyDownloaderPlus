package com.alfy.downloader

import android.content.Context
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView

/** Adblock host-based murni: daftar host dari assets/ad_hosts.txt, tanpa library eksternal. */
object NetAdblock {
    @Volatile private var hosts: HashSet<String> = HashSet()
    @Volatile var ready = false

    fun init(ctx: Context) {
        Thread {
            try {
                val hs = HashSet<String>()
                ctx.assets.open("ad_hosts.txt").bufferedReader().useLines { ls ->
                    ls.map { it.trim().lowercase() }.filter { it.isNotEmpty() && !it.startsWith("#") }.forEach { hs.add(it) }
                }
                hosts = hs; ready = true
            } catch (e: Throwable) { ready = false }
        }.apply { isDaemon = true }.start()
    }

    private fun listed(host: String): Boolean {
        var x = host.lowercase()
        val hs = hosts
        while (true) {
            if (x in hs) return true
            val i = x.indexOf('.')
            if (i < 0) return false
            x = x.substring(i + 1)
        }
    }

    /** shouldInterceptRequest: non-null = blokir request ini. */
    fun intercept(view: WebView?, req: WebResourceRequest): WebResourceResponse? {
        if (!ready || !NetFilterStore.enabled()) return null
        val h = req.url.host ?: return null
        return if (listed(h)) WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0))) else null
    }

    /** v1.134: true bila host URL ada di ad_hosts.txt (dipakai WebView tersembunyi untuk membuang URL iklan). */
    fun isAdUrl(u: String): Boolean {
        if (!ready) return false
        val h = (try { android.net.Uri.parse(u).host } catch (e: Throwable) { null }) ?: return false
        return listed(h)
    }

    fun setup(webView: WebView) { }
    fun onPageStarted(view: WebView, url: String) { }

    fun status(): String =
        if (!NetFilterStore.enabled()) "✗ Blokir host manual nonaktif"
        else if (ready) "✓ Blokir host manual aktif (${hosts.size} host)" else "… memuat daftar host"
}

/** Penyimpanan on/off blokir host manual untuk menu "Blokir & Filter". */
object NetFilterStore {
    private fun p() = Repo.app.getSharedPreferences("alfy_netfilter", 0)
    fun enabled() = p().getBoolean("host_block", true)
    fun setEnabled(v: Boolean) { p().edit().putBoolean("host_block", v).apply() }
}
