package com.alfy.downloader.part3.scan

import com.alfy.downloader.part3.core.CaptureHub
import com.alfy.downloader.part3.core.Source
import com.alfy.downloader.part3.core.UrlRegistry
import com.alfy.downloader.part3.ytdlp.YtDlpResolver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * Root-only answer to encrypted (HTTPS/SNI) streams: the stream bytes cannot be read, but the player publishes
 * what is playing to the system media session. We read that title and let yt-dlp resolve it, so the video shows
 * up in the list without copy/paste. If it cannot be resolved the user still has Paste / Share / Screen Scan.
 */
object MediaSessionResolver {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val tried = ConcurrentHashMap<String, Long>()
    private val pkgRx = Regex("""package=([\w.]+)""")
    private val descRx = Regex("""description=(.+)""")
    private val playingRx = Regex("""state=PlaybackState \{state=3""")

    private fun playingTitle(dump: String): String? {
        // Split per session block and keep the YouTube one that is actually playing.
        val blocks = dump.split(Regex("""\n(?=\s{2,}\S.*\(userId=\d+\))"""))
        for (b in blocks) {
            val pkg = pkgRx.find(b)?.groupValues?.get(1) ?: continue
            if (!pkg.contains("youtube")) continue
            if (!playingRx.containsMatchIn(b)) continue
            val d = descRx.find(b)?.groupValues?.get(1)?.trim() ?: continue
            val clean = d.replace(Regex("""(,\s*null)+\s*$"""), "").trim()
            if (clean.length >= 3) return clean
        }
        return null
    }

    fun onEncryptedStream(label: String) {
        if (label != "YouTube") return
        val now = System.currentTimeMillis()
        val last = tried["yt"]
        if (last != null && now - last < 20_000L) return
        tried["yt"] = now
        scope.launch {
            val dump = Shell.suOut("dumpsys media_session", 6) ?: return@launch
            val title = playingTitle(dump) ?: return@launch
            val k = "ytsearch:" + title.lowercase()
            if (tried.put(k, now) != null) return@launch
            if (tried.size > 200) tried.clear()
            when (val r = YtDlpResolver.resolve("ytsearch1:$title", null, Source.NETWORK, null, null, title)) {
                is YtDlpResolver.Result.Ok -> CaptureHub.addResolved(r.candidates)
                is YtDlpResolver.Result.Fail -> Unit
            }
        }
    }
}
