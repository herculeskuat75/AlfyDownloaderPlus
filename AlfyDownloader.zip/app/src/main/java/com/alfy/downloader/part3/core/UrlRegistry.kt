package com.alfy.downloader.part3.core

import android.content.Context
import android.content.SharedPreferences
import java.net.URI
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Global duplicate prevention: every capture method must pass through validate() + tryClaim(). */
object UrlRegistry {
    private const val PREFS = "alfyd_p3_registry"
    private const val KEY = "keys"
    private const val MAX = 3000
    private const val PERSIST_DELAY_MS = 5000L

    /** Bounded, insertion-ordered in-memory cache: oldest keys are evicted first (no RAM bloat). */
    private val keys: MutableSet<String> = java.util.Collections.synchronizedSet(
        java.util.Collections.newSetFromMap(object : java.util.LinkedHashMap<String, Boolean>(1024, 0.75f, false) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?): Boolean = size > MAX
        })
    )
    private val recent = ConcurrentHashMap<String, Long>()
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    @Volatile private var persistPending = false
    @Volatile private var prefs: SharedPreferences? = null

    private val volatileParams = setOf(
        "fbclid", "gclid", "token", "expires", "expire", "exp", "e", "sig", "lsig", "signature", "st",
        "hdnts", "policy", "key-pair-id", "hash", "md5", "nva", "nvb", "wmssign", "wmsauthsign", "verify", "ts", "_"
    )

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        keys.addAll(p.getStringSet(KEY, emptySet()) ?: emptySet())
        prefs = p
    }

    /** Returns a normalized absolute http(s) URL, or null if the input is not a valid absolute URL. */
    fun validate(raw: String?): String? {
        if (raw == null) return null
        val t = raw.trim().trim('"', '\'', '<', '>', '(', ')', '[', ']', ',', ';', '.')
        if (t.isEmpty() || t.length > 4096 || t.any { it.isWhitespace() }) return null
        val uri = try { URI(t) } catch (e: Exception) { return null }
        if (!uri.isAbsolute || uri.isOpaque) return null
        val scheme = uri.scheme?.lowercase(Locale.ROOT) ?: return null
        if (scheme != "http" && scheme != "https") return null
        val host = uri.host?.lowercase(Locale.ROOT) ?: return null
        if (host == "localhost" || (!host.contains('.') && !host.contains(':'))) return null
        if (host.startsWith("127.") || host == "0.0.0.0" || host.startsWith("10.77.")) return null
        if (uri.userInfo != null) return null
        val defaultPort = if (scheme == "http") 80 else 443
        val port = if (uri.port == -1 || uri.port == defaultPort) "" else ":${uri.port}"
        val path = uri.rawPath?.takeIf { it.isNotEmpty() } ?: "/"
        val q = uri.rawQuery?.let { "?$it" } ?: ""
        return "$scheme://$host$port$path$q"
    }

    /** Stable identity: drops fragments, tracking params and expiring signature params. */
    fun keyOf(url: String): String {
        val i = url.indexOf('?')
        if (i < 0) return url
        val base = url.substring(0, i)
        val params = url.substring(i + 1).split('&').filter { it.isNotEmpty() }.filter { p ->
            val n = p.substringBefore('=').lowercase(Locale.ROOT)
            !(n in volatileParams || n.startsWith("utm_") || n.startsWith("x-amz-") || n.startsWith("x-goog-"))
        }.sorted()
        return if (params.isEmpty()) base else base + "?" + params.joinToString("&")
    }

    /** True when the same key was seen less than [ms] ago (burst of identical requests). */
    fun debounce(key: String, ms: Long = 1500L): Boolean {
        val now = System.currentTimeMillis()
        if (recent.size > 400) recent.clear()
        val last = recent.put(key, now)
        return last != null && now - last < ms
    }

    fun tryClaim(key: String): Boolean {
        val added = keys.add(key)
        if (added) persist()
        return added
    }

    fun contains(key: String) = keys.contains(key)

    fun release(key: String) { if (keys.remove(key)) persist() }

    fun clear() { keys.clear(); recent.clear(); persist() }

    /** Writes to disk at most once every few seconds. */
    private fun persist() {
        if (persistPending) return
        persistPending = true
        handler.postDelayed({
            persistPending = false
            val p = prefs ?: return@postDelayed
            val snapshot = synchronized(keys) { HashSet(keys) }
            p.edit().putStringSet(KEY, snapshot).apply()
        }, PERSIST_DELAY_MS)
    }
}

object UrlKind {
    enum class Kind { MEDIA, PAGE, OTHER }

    // Supported formats: MP4, MKV, TS, M3U8 (video) and M4A (priority), MP3 (audio).
    private val mediaExt = setOf("mp4", "mkv", "ts", "m3u8", "m4a", "mp3")
    private val pageExt = setOf("", "html", "htm", "php", "asp", "aspx", "jsp", "shtml", "json")

    fun extOf(url: String): String {
        val path = url.substringBefore('?').substringBefore('#')
        val name = path.substringAfterLast('/')
        return if (name.contains('.')) name.substringAfterLast('.').lowercase(Locale.ROOT) else ""
    }

    fun kind(url: String): Kind {
        if (url.contains(".m3u8", true) || url.contains("/videoplayback")) return Kind.MEDIA
        val e = extOf(url)
        return when {
            e in mediaExt -> Kind.MEDIA
            e in pageExt -> Kind.PAGE
            else -> Kind.OTHER
        }
    }

    fun isMediaExt(e: String) = e in mediaExt

    fun isSegment(url: String) = extOf(url) == "ts"

    fun nameOf(url: String): String {
        val last = url.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')
        val base = if (last.contains('.')) last.substringBeforeLast('.') else last
        val dec = try { java.net.URLDecoder.decode(base, "UTF-8") } catch (ignored: Exception) { base }
        return dec.ifBlank { "media_${System.currentTimeMillis()}" }
    }
}
