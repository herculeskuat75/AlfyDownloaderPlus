package com.alfy.downloader

/** Memori pusat: semua setelan permanen disimpan di SharedPreferences "s" (sama dengan Repo.prefs()), tahan Force Stop / restore. */
object AppPreferences {
    private fun p() = Repo.prefs()

    var isLightAnimation: Boolean
        get() = p().getBoolean("isLightAnimation", true)
        set(v) { p().edit().putBoolean("isLightAnimation", v).apply() }

    var lastVisitedUrl: String
        get() = p().getString("lastVisitedUrl", "") ?: ""
        set(v) { p().edit().putString("lastVisitedUrl", v).apply() }

    /** Kunci "scanAll" dipertahankan agar nilai lama pengguna tidak hilang. */
    var isAutoScanEnabled: Boolean
        get() = p().getBoolean("scanAll", true)
        set(v) { p().edit().putBoolean("scanAll", v).apply() }

    /** Kunci "blockAds" dipertahankan agar nilai lama pengguna tidak hilang. */
    var isAdblockEnabled: Boolean
        get() = p().getBoolean("blockAds", true)
        set(v) { p().edit().putBoolean("blockAds", v).apply() }

    /** Status root perangkat (ada file su). Diisi di MainActivity saat aplikasi dibuka. */
    var isRooted: Boolean
        get() = p().getBoolean("isRooted", false)
        set(v) { p().edit().putBoolean("isRooted", v).apply() }

    var hasAskedAccessibility: Boolean
        get() = p().getBoolean("hasAskedAccessibility", false)
        set(v) { p().edit().putBoolean("hasAskedAccessibility", v).apply() }

    /** Tanggal (yyyy-MM-dd) terakhir wallpaper New Tab diganti. */
    var wallpaperLastDate: String
        get() = p().getString("wallpaperLastDate", "") ?: ""
        set(v) { p().edit().putString("wallpaperLastDate", v).apply() }

    var themeCatalogUrl: String
        get() = p().getString("themeCatalogUrl", Wallpaper.CATALOG_URL)?.ifBlank { Wallpaper.CATALOG_URL } ?: Wallpaper.CATALOG_URL
        set(v) { p().edit().putString("themeCatalogUrl", v).apply() }

    /** Gaya UI tema: "dynamic" (Palette) atau "transparent" (kaca). */
    var themeStyle: String
        get() = p().getString("themeStyle", "dynamic") ?: "dynamic"
        set(v) { p().edit().putString("themeStyle", v).apply() }
    /** Sumber gambar tema: "online" (katalog/acak) atau "gallery" (Galeri HP); path/URL-nya di themeImagePath. */
    val themeSource: String get() = p().getString("themeSource", "online") ?: "online"
    val themeImagePath: String get() = p().getString("themeImagePath", "") ?: ""

    var wallpaperAuto: Boolean
        get() = p().getBoolean("wallpaperAuto", false)
        set(v) { p().edit().putBoolean("wallpaperAuto", v).apply() }

    // ---------- Profil Tools: NamaProfil -> daftar ID tool (JSON di prefs "toolProfiles") ----------
    const val DEFAULT_PROFILE = "Default"

    /** Profil khusus (tanpa "Default": Default = centang manual & selalu ada). */
    fun customProfiles(): LinkedHashMap<String, List<String>> {
        val out = LinkedHashMap<String, List<String>>()
        try {
            val o = org.json.JSONObject(p().getString("toolProfiles", "{}") ?: "{}")
            for (k in o.keys()) {
                val a = o.getJSONArray(k)
                out[k] = (0 until a.length()).map { a.getString(it) }
            }
        } catch (e: Exception) { }
        return out
    }

    fun profileNames(): List<String> = listOf(DEFAULT_PROFILE) + customProfiles().keys

    fun profileTools(name: String): Set<String>? = customProfiles()[name]?.toSet()

    fun saveProfile(name: String, tools: List<String>) {
        if (name.equals(DEFAULT_PROFILE, true) || name.isBlank()) return
        val m = customProfiles(); m[name.trim()] = tools
        writeProfiles(m)
    }

    fun deleteProfile(name: String) {
        if (name == DEFAULT_PROFILE) return
        val m = customProfiles(); m.remove(name)
        writeProfiles(m)
        if (activeProfile == name) activeProfile = DEFAULT_PROFILE
    }

    private fun writeProfiles(m: Map<String, List<String>>) {
        val o = org.json.JSONObject()
        for ((k, v) in m) o.put(k, org.json.JSONArray(v))
        p().edit().putString("toolProfiles", o.toString()).apply()
        Tool.invalidateProfile()
        Tool.syncAll()
    }

    /** Profil aktif saat ini; bila profilnya sudah tidak ada, otomatis kembali ke Default. */
    var activeProfile: String
        get() {
            val a = p().getString("activeProfile", DEFAULT_PROFILE) ?: DEFAULT_PROFILE
            return if (a == DEFAULT_PROFILE || customProfiles().containsKey(a)) a else DEFAULT_PROFILE
        }
        set(v) { p().edit().putString("activeProfile", v).apply(); Tool.invalidateProfile() }

    // ---------- Dynamic Endpoint Manager: semua URL API bisa diganti dari Pengaturan > Developer tanpa build ulang ----------
    class EndpointField(val label: String, val key: String, val def: String, val multi: Boolean = false) {
        fun get(): String = (Repo.prefs().getString(key, null) ?: "").trim().ifEmpty { def }
        fun set(v: String) { Repo.prefs().edit().putString(key, v.trim()).apply() }
        fun reset() { Repo.prefs().edit().remove(key).apply() }
    }

    private val DEF_PIPED = listOf("https://pipedapi.kavin.rocks", "https://api.piped.private.coffee", "https://pipedapi.adminforge.de", "https://pipedapi.reallyaweso.me", "https://api.piped.yt", "https://pipedapi.darkness.services", "https://pipedapi.drgns.space", "https://piped-api.privacy.com.de", "https://pipedapi.leptons.xyz", "https://pipedapi.nosebs.ru")
    private val DEF_INV = listOf("https://yewtu.be", "https://inv.nadeko.net", "https://invidious.nerdvpn.de", "https://invidious.privacyredirect.com", "https://invidious.f5.si", "https://inv.tux.pizza", "https://invidious.materialio.us", "https://iv.melmac.space")

    val epBtch = EndpointField("BtchApi (base URL)", "ep_btch", "https://btch-downloader-api.vercel.app/api/download/")
    val epCobalt = EndpointField("Cobalt (API URL)", "ep_cobalt", "https://api.cobalt.tools/api/json")
    val epInnerTube = EndpointField("InnerTube (player URL)", "ep_innertube", "https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
    val epPiped = EndpointField("Piped API (satu URL per baris)", "ep_piped", DEF_PIPED.joinToString("\n"), true)
    val epInv = EndpointField("Invidious (satu URL per baris)", "ep_inv", DEF_INV.joinToString("\n"), true)
    val epPipedList = EndpointField("Piped: daftar instance (JSON)", "ep_piped_list", "https://piped-instances.kavin.rocks/")
    val epInvList = EndpointField("Invidious: daftar instance (JSON)", "ep_inv_list", "https://api.invidious.io/instances.json?sort_by=health")
    val epFx = EndpointField("fxtwitter (base URL)", "ep_fx", "https://api.fxtwitter.com")
    val epVx = EndpointField("vxtwitter (base URL)", "ep_vx", "https://api.vxtwitter.com")
    val epSyn = EndpointField("Syndication (tweet-result URL)", "ep_syn", "https://cdn.syndication.twimg.com/tweet-result")
    val epYtdlpRelease = EndpointField("yt-dlp: GitHub release API", "ep_ytdlp_release", "https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest")

    val endpointFields: List<EndpointField> get() = listOf(epBtch, epCobalt, epInnerTube, epPiped, epInv, epPipedList, epInvList, epFx, epVx, epSyn, epYtdlpRelease)
    fun resetEndpoints() { for (f in endpointFields) f.reset() }

    private fun lines(f: EndpointField, def: List<String>): List<String> =
        f.get().lines().map { it.trim().trimEnd('/') }.filter { it.startsWith("http") }.ifEmpty { def }

    val btchApiUrl: String get() = epBtch.get().let { if (it.endsWith("/")) it else "$it/" }
    val cobaltApiUrl: String get() = epCobalt.get()
    val innerTubeUrl: String get() = epInnerTube.get()
    val pipedApis: List<String> get() = lines(epPiped, DEF_PIPED)
    val invidiousApis: List<String> get() = lines(epInv, DEF_INV)
    val pipedListUrl: String get() = epPipedList.get()
    val invidiousListUrl: String get() = epInvList.get()
    val fxtwitterUrl: String get() = epFx.get().trimEnd('/')
    val vxtwitterUrl: String get() = epVx.get().trimEnd('/')
    val syndicationUrl: String get() = epSyn.get()
    val ytdlpReleaseUrl: String get() = epYtdlpRelease.get()
}
