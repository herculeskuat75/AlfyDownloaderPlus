package com.alfy.downloader

/** Memori pusat: semua setelan permanen disimpan di SharedPreferences "s" (sama dengan Repo.prefs()), tahan Force Stop / restore. */
object AppPreferences {
    private fun p() = Repo.prefs()

    var isLightAnimation: Boolean
        get() = p().getBoolean("isLightAnimation", true)
        set(v) { p().edit().putBoolean("isLightAnimation", v).apply() }

    var lastVisitedUrl: String
        get() = p().getString("lastVisitedUrl", "") ?: ""
        set(v) { p().edit().putString("lastVisitedUrl", v).apply() }

    /** Kunci "scanAll" dipertahankan agar nilai lama pengguna tidak hilang. */
    var isAutoScanEnabled: Boolean
        get() = p().getBoolean("scanAll", true)
        set(v) { p().edit().putBoolean("scanAll", v).apply() }

    /** Kunci "blockAds" dipertahankan agar nilai lama pengguna tidak hilang. */
    var isAdblockEnabled: Boolean
        get() = p().getBoolean("blockAds", true)
        set(v) { p().edit().putBoolean("blockAds", v).apply() }

    /** Status root perangkat (ada file su). Diisi di MainActivity saat aplikasi dibuka. */
    var isRooted: Boolean
        get() = p().getBoolean("isRooted", false)
        set(v) { p().edit().putBoolean("isRooted", v).apply() }

    var hasAskedAccessibility: Boolean
        get() = p().getBoolean("hasAskedAccessibility", false)
        set(v) { p().edit().putBoolean("hasAskedAccessibility", v).apply() }

    /** Tanggal (yyyy-MM-dd) terakhir wallpaper New Tab diganti. */
    var wallpaperLastDate: String
        get() = p().getString("wallpaperLastDate", "") ?: ""
        set(v) { p().edit().putString("wallpaperLastDate", v).apply() }

    var wallpaperAuto: Boolean
        get() = p().getBoolean("wallpaperAuto", false)
        set(v) { p().edit().putBoolean("wallpaperAuto", v).apply() }
}
