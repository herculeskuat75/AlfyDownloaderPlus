package com.alfy.downloader

object AppConfig {
    const val PREFS = "alfy_prefs"
    const val DEFAULT_FOLDER = "DownloadAlfy47"
    const val SUBFOLDER_VIDEO = "video"
    const val SUBFOLDER_MUSIC = "music"
}
