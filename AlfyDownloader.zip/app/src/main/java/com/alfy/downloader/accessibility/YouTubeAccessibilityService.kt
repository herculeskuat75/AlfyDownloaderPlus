package com.alfy.downloader.accessibility

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.alfy.downloader.part3.core.CaptureHub

/**
 * Smart, read-only accessibility service that watches ONLY YouTube / YouTube Music (and the address bar of
 * common browsers) — see res/xml/accessibility_service_config.xml. It never performs gestures, never reads
 * key events or typed text, so it cannot interfere with the keyboard or cause typing lag in other apps.
 *
 * Event flow (all heavy work is off the main thread):
 *   window event → debounce (350 ms, max 1 scan / 900 ms) → walk node tree (max [MAX_NODES]) →
 *   video ID in text?  → [YouTubeDetector.onVideoId]
 *   else player visible + title → [YouTubeDetector.onTitle] (needs the same title in 2 consecutive scans)
 */
class YouTubeAccessibilityService : AccessibilityService() {

    private val thread = HandlerThread("alfy-a11y").apply { start() }
    private val bg = Handler(thread.looper)
    private var lastScanAt = 0L
    private var stableSig: String? = null
    private var stableCount = 0
    private var wasOnPlayer = false

    private val scanTask = Runnable { scan() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg !in WATCHED) return
        if (!YouTubeDetector.enabled(this) || CaptureHub.throttled) return
        // Fast path: a share toast / sheet may carry the link in the event text itself.
        for (t in event.text) {
            val id = YouTubeIdExtractor.findId(t)
            if (id != null) { YouTubeDetector.onVideoId(this, id); return }
        }
        bg.removeCallbacks(scanTask)
        val gap = MIN_GAP_MS - (System.currentTimeMillis() - lastScanAt)
        bg.postDelayed(scanTask, maxOf(DEBOUNCE_MS, gap))
    }

    override fun onInterrupt() { bg.removeCallbacks(scanTask) }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        bg.removeCallbacks(scanTask)
        YouTubeDetector.resetCurrent()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        bg.removeCallbacksAndMessages(null)
        thread.quitSafely()
        super.onDestroy()
    }

    // ───────────────────────── Scan ─────────────────────────

    private class Found {
        var urlId: String? = null
        var playerVisible = false
        var miniPlayer = false
        var title: String? = null
        var miniTitle: String? = null
        var channel: String? = null
        var nodes = 0
    }

    private fun scan() {
        lastScanAt = System.currentTimeMillis()
        val debug = YouTubeDetector.debug(this)
        val root = (try { rootInActiveWindow } catch (e: Throwable) { null }) ?: return
        val pkg = root.packageName?.toString()
        if (pkg == null || pkg !in WATCHED) { release(root); return }
        val f = Found()
        val dump = if (debug) StringBuilder() else null
        try {
            walk(root, 0, pkg, f, dump)
        } catch (e: Throwable) {
            if (debug) Log.d(TAG, "walk failed: ${e.message}")
        } finally {
            release(root)
        }
        if (dump != null) Log.d(TAG, "pkg=$pkg nodes=${f.nodes}\n$dump")

        // 1) ID straight from the UI.
        f.urlId?.let { YouTubeDetector.onVideoId(this, it); return }

        // 2) Only the YouTube apps expose a player we can read a title from.
        val onPlayer = pkg in TITLE_PACKAGES && (f.playerVisible || f.miniPlayer)
        if (!onPlayer) {
            if (wasOnPlayer) { wasOnPlayer = false; YouTubeDetector.resetCurrent() }
            stableSig = null; stableCount = 0
            return
        }
        wasOnPlayer = true
        val title = YouTubeIdExtractor.cleanTitle(if (f.playerVisible) f.title ?: f.miniTitle else f.miniTitle)
            ?: return
        val sig = title.lowercase() + "|" + (f.channel ?: "").lowercase()
        if (sig == stableSig) stableCount++ else { stableSig = sig; stableCount = 1 }
        if (stableCount == 2) YouTubeDetector.onTitle(this, title, f.channel)
        else if (stableCount == 1) {
            // Re-check shortly so the "2 consecutive scans" rule does not wait for another UI event.
            bg.removeCallbacks(scanTask)
            bg.postDelayed(scanTask, MIN_GAP_MS)
        }
    }

    private fun walk(node: AccessibilityNodeInfo, depth: Int, pkg: String, f: Found, dump: StringBuilder?) {
        if (f.nodes >= MAX_NODES || depth > MAX_DEPTH) return
        f.nodes++
        val id = node.viewIdResourceName
        val text = node.text?.toString()
        val desc = node.contentDescription?.toString()

        dump?.let {
            if (!id.isNullOrEmpty() || !text.isNullOrEmpty() || !desc.isNullOrEmpty())
                it.append("  ".repeat(minOf(depth, 12))).append(id ?: "-")
                    .append(" | t=").append(text?.take(80)).append(" | d=").append(desc?.take(80)).append('\n')
        }

        if (f.urlId == null) {
            f.urlId = YouTubeIdExtractor.findId(text?.take(MAX_TEXT)) ?: YouTubeIdExtractor.findId(desc?.take(MAX_TEXT))
        }

        if (pkg in TITLE_PACKAGES && id != null) {
            val shortId = id.substringAfter(":id/")
            if (PLAYER_ID_RX.containsMatchIn(shortId)) f.playerVisible = true
            if (MINI_ID_RX.containsMatchIn(shortId)) f.miniPlayer = true
            if (f.title == null && !text.isNullOrBlank() && TITLE_ID_RX.matches(shortId)) f.title = text
            if (f.miniTitle == null && MINI_TITLE_ID_RX.containsMatchIn(shortId) && !text.isNullOrBlank()) f.miniTitle = text
            if (f.channel == null && !text.isNullOrBlank() && CHANNEL_ID_RX.matches(shortId)) f.channel = text
        }
        // Some builds put "Title - 3 minutes - Go to channel - …" on the player/metadata node instead of text.
        if (pkg in TITLE_PACKAGES && f.title == null && !desc.isNullOrBlank() &&
            id != null && META_ID_RX.containsMatchIn(id.substringAfter(":id/"))
        ) f.title = YouTubeIdExtractor.titleFromDescription(desc)

        val n = node.childCount
        for (i in 0 until n) {
            if (f.nodes >= MAX_NODES) break
            val c = try { node.getChild(i) } catch (e: Throwable) { null } ?: continue
            try { walk(c, depth + 1, pkg, f, dump) } finally { release(c) }
        }
    }

    @Suppress("DEPRECATION")
    private fun release(n: AccessibilityNodeInfo) {
        if (Build.VERSION.SDK_INT < 33) try { n.recycle() } catch (ignored: Throwable) { }
    }

    companion object {
        private const val TAG = "AlfyA11y"
        private const val DEBOUNCE_MS = 350L
        private const val MIN_GAP_MS = 900L
        private const val MAX_NODES = 450
        private const val MAX_DEPTH = 40
        private const val MAX_TEXT = 4000

        const val PKG_YOUTUBE = "com.google.android.youtube"
        const val PKG_YT_MUSIC = "com.google.android.apps.youtube.music"

        /** Must match android:packageNames in res/xml/accessibility_service_config.xml. */
        val WATCHED = setOf(
            PKG_YOUTUBE, PKG_YT_MUSIC,
            "com.android.chrome", "org.mozilla.firefox", "com.brave.browser", "com.microsoft.emmx",
            "com.opera.browser", "com.sec.android.app.sbrowser"
        )
        private val TITLE_PACKAGES = setOf(PKG_YOUTUBE, PKG_YT_MUSIC)

        // ── View-ID heuristics for the YouTube app. YouTube may rename ids between releases: turn on
        //    "Debug log" in Settings, play a video, read `adb logcat -s AlfyA11y` and adjust these 6 patterns.
        private val PLAYER_ID_RX = Regex("""(?i)^(watch_player|watch_while_layout|player_view|player_control_play_pause_replay_button|watch_while_time_bar_view|time_bar_current_time)$""")
        private val MINI_ID_RX = Regex("""(?i)(floaty_bar|miniplayer|mini_player)""")
        private val TITLE_ID_RX = Regex("""(?i)(title|video_title|watch_title)""")
        private val MINI_TITLE_ID_RX = Regex("""(?i)((floaty|mini_?player).*title|title.*(floaty|mini_?player))""")
        private val CHANNEL_ID_RX = Regex("""(?i)(channel_name|channel_title|owner_name|byline|subtitle)""")
        private val META_ID_RX = Regex("""(?i)(watch_metadata|video_info|metadata)""")
    }
}
