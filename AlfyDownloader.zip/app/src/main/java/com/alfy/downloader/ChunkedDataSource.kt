package com.alfy.downloader

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.TransferListener

/**
 * googlevideo menolak permintaan tanpa Range / terlalu besar (HTTP 403).
 * Sumber data ini meminta file per potongan 4MB (sama seperti pengunduh), lalu menyambungkannya.
 * Alamat selain googlevideo/videoplayback diteruskan apa adanya.
 */
class ChunkedDataSource(
    private val f: DataSource.Factory,
    private val chunk: Long = 4L * 1024 * 1024,
    /** Opsional: pilih pabrik HTTP (User-Agent/header) sesuai alamat yang dibuka. */
    private val pick: ((Uri) -> DataSource.Factory)? = null
) : DataSource {
    private var fac: DataSource.Factory = f
    private val ls = ArrayList<TransferListener>()
    private var cur: DataSource? = null
    private var spec: DataSpec? = null
    private var uri: Uri? = null
    private var pass = false
    private var pos = 0L
    private var left = C.LENGTH_UNSET.toLong()
    private var chunkLeft = 0L
    private var eof = false

    override fun addTransferListener(t: TransferListener) { ls.add(t) }

    private fun openChunk(): Boolean {
        val want = if (left != C.LENGTH_UNSET.toLong()) minOf(chunk, left) else chunk
        if (want <= 0) return false
        val ds = fac.createDataSource()
        ls.forEach { ds.addTransferListener(it) }
        val s = spec!!.buildUpon().setPosition(pos).setLength(want).build()
        val n: Long
        try { n = ds.open(s) } catch (e: HttpDataSource.InvalidResponseCodeException) {
            try { ds.close() } catch (x: Exception) { }
            if (e.responseCode == 416 && pos > 0) return false
            throw e
        }
        if (n == 0L) { try { ds.close() } catch (x: Exception) { }; return false }
        cur = ds
        chunkLeft = if (n != C.LENGTH_UNSET.toLong()) n else want
        return true
    }

    override fun open(dataSpec: DataSpec): Long {
        spec = dataSpec; uri = dataSpec.uri; eof = false
        fac = pick?.invoke(dataSpec.uri) ?: f
        val u = dataSpec.uri.toString()
        pass = !(u.contains("googlevideo.com") && u.contains("videoplayback"))
        if (pass) {
            val ds = fac.createDataSource()
            ls.forEach { ds.addTransferListener(it) }
            cur = ds
            return ds.open(dataSpec)
        }
        pos = dataSpec.position; left = dataSpec.length
        if (!openChunk()) { eof = true; return 0 }
        return dataSpec.length
    }

    override fun read(buf: ByteArray, off: Int, len: Int): Int {
        if (len == 0) return 0
        if (pass) return cur?.read(buf, off, len) ?: C.RESULT_END_OF_INPUT
        if (eof) return C.RESULT_END_OF_INPUT
        while (true) {
            val ds = cur ?: return C.RESULT_END_OF_INPUT
            val want = if (chunkLeft > 0) minOf(len.toLong(), chunkLeft).toInt() else len
            val n = ds.read(buf, off, want)
            if (n == C.RESULT_END_OF_INPUT) {
                try { ds.close() } catch (e: Exception) { }
                cur = null
                val short = chunkLeft > 0
                if (short || (left != C.LENGTH_UNSET.toLong() && left <= 0) || !openChunk()) { eof = true; return C.RESULT_END_OF_INPUT }
                continue
            }
            pos += n
            if (left != C.LENGTH_UNSET.toLong()) left -= n
            chunkLeft -= n
            return n
        }
    }

    override fun getUri(): Uri? = cur?.uri ?: uri
    override fun getResponseHeaders(): Map<String, List<String>> = cur?.responseHeaders ?: emptyMap()
    override fun close() { try { cur?.close() } catch (e: Exception) { }; cur = null }
}
