package com.alfy.downloader

/** v1.61: deteksi modul LSPosed "Hook pemutar". Aman: semua error ditangkap. */
object HookStatus {
    /** Diset true oleh HookEntry (via refleksi) saat modul dimuat LSPosed di proses ini. */
    @JvmField @Volatile var hooked: Boolean = false

    private fun has(cl: ClassLoader?, n: String): Boolean = try {
        if (cl == null) false else { Class.forName(n, false, cl); true }
    } catch (_: Throwable) { false }

    /** Cek keberadaan XposedBridge/XposedHelpers lewat beberapa ClassLoader (kompatibel Android 12L). */
    fun bridgePresent(): Boolean = try {
        val names = listOf("de.robv.android.xposed.XposedBridge", "de.robv.android.xposed.XposedHelpers")
        val loaders = ArrayList<ClassLoader?>()
        try { loaders.add(HookStatus::class.java.classLoader) } catch (_: Throwable) { }
        try { loaders.add(Thread.currentThread().contextClassLoader) } catch (_: Throwable) { }
        try { loaders.add(ClassLoader.getSystemClassLoader()) } catch (_: Throwable) { }
        try { loaders.add(Class.forName("android.app.Application").classLoader) } catch (_: Throwable) { }
        // telusuri rantai parent classloader aplikasi
        try {
            var p = HookStatus::class.java.classLoader?.parent
            var i = 0
            while (p != null && i++ < 6) { loaders.add(p); p = p.parent }
        } catch (_: Throwable) { }
        loaders.any { l -> names.any { has(l, it) } }
    } catch (_: Throwable) { false }

    fun active(): Boolean = try { hooked || bridgePresent() } catch (_: Throwable) { false }
}
