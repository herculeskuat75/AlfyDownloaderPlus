package com.alfy.downloader

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator

/** Indikator loading halaman: garis tebal gradient mengalir + titik ujung berdenyut. Semua animator berhenti saat selesai/tersembunyi. */
class LoadBar(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val lineH = 5f * d
    private val dotR = 6f * d
    private val colors = intArrayOf(
        0xFFFF1744.toInt(), 0xFFFF9100.toInt(), 0xFFFFEA00.toInt(),
        0xFF00E676.toInt(), 0xFF2979FF.toInt(), 0xFFAA00FF.toInt(), 0xFFFF1744.toInt()
    )
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val mtx = Matrix()
    private var shader: LinearGradient? = null
    private var shaderW = 0
    private var shown = 0f      // progres tampil 0..100 (dianimasikan)
    private var target = 0
    private var phase = 0f      // 0..1 berulang
    private var flow: ValueAnimator? = null
    private var prog: ValueAnimator? = null
    private var fade: ValueAnimator? = null
    private var finishing = false

    init { visibility = GONE }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (dotR * 2 + 4 * d).toInt())
    }

    fun setLoad(p: Int) {
        val v = p.coerceIn(0, 100)
        if (v >= 100) {
            if (visibility != VISIBLE || finishing) return
            target = 100
            finishing = true
            animateTo(100f, 220) { startFade() }
            return
        }
        if (finishing || visibility != VISIBLE) {
            fade?.cancel(); fade = null
            finishing = false
            alpha = 1f
            shown = 0f
            visibility = VISIBLE
        }
        startFlow()
        if (v < target) { prog?.cancel(); shown = v.toFloat(); invalidate() }
        target = v
        animateTo(v.toFloat(), 300) {}
    }

    private fun animateTo(to: Float, dur: Long, end: () -> Unit) {
        prog?.cancel()
        val a = ValueAnimator.ofFloat(shown, to).apply {
            duration = dur
            interpolator = DecelerateInterpolator()
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) { if (!cancelled) end() }
            })
        }
        prog = a; a.start()
    }

    private fun startFade() {
        fade?.cancel()
        fade = ValueAnimator.ofFloat(1f, 0f).apply {
            duration = 350
            addUpdateListener { alpha = it.animatedValue as Float }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) { if (!cancelled) hideAndStop() }
            })
            start()
        }
    }

    private fun startFlow() {
        if (flow?.isRunning == true) return
        flow = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1400
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { phase = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun stopAll() {
        flow?.cancel(); flow = null
        prog?.cancel(); prog = null
        fade?.cancel(); fade = null
    }

    private fun hideAndStop() {
        stopAll()
        finishing = false
        shown = 0f; target = 0; alpha = 1f
        visibility = GONE
    }

    override fun onDetachedFromWindow() { super.onDetachedFromWindow(); stopAll(); finishing = false; visibility = GONE; shown = 0f; target = 0; alpha = 1f }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); if (w <= 0f) return
        if (shader == null || shaderW != width) {
            shader = LinearGradient(0f, 0f, w, 0f, colors, null, Shader.TileMode.REPEAT)
            shaderW = width
            linePaint.shader = shader
        }
        mtx.setTranslate(phase * w, 0f)
        shader!!.setLocalMatrix(mtx)
        val cy = height / 2f
        val pw = (w * shown / 100f).coerceIn(0f, w)
        if (pw > 0f) {
            rect.set(0f, cy - lineH / 2, pw, cy + lineH / 2)
            c.drawRoundRect(rect, lineH / 2, lineH / 2, linePaint)
        }
        // warna titik berganti mengikuti fase
        val f = (phase * 2f) % 1f * (colors.size - 1)
        val i = f.toInt().coerceAtMost(colors.size - 2)
        val col = blend(colors[i], colors[i + 1], f - i)
        val pulse = 0.5f + 0.5f * Math.sin(phase * 2 * Math.PI * 3).toFloat() // 3 denyut per siklus
        val cx = pw.coerceIn(dotR, (w - dotR).coerceAtLeast(dotR))
        haloPaint.color = col; haloPaint.alpha = (70 + 60 * pulse).toInt()
        c.drawCircle(cx, cy, dotR * (1.0f + 0.15f * pulse), haloPaint)
        dotPaint.color = col; dotPaint.alpha = (150 + 105 * pulse).toInt()
        c.drawCircle(cx, cy, dotR * (0.72f + 0.2f * pulse), dotPaint)
    }

    private fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )
}
