package com.alfy.downloader.part3.ui

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.alfy.downloader.part3.Part3
import com.alfy.downloader.part3.core.CaptureHub
import com.alfy.downloader.part3.core.Category
import com.alfy.downloader.part3.core.MediaCandidate
import com.alfy.downloader.part3.download.DownloadService
import com.alfy.downloader.part3.download.StorageHelper
import com.alfy.downloader.part3.util.Fmt

/**
 * IDM-style dialogs on top of any app:
 *  1. Download dialog: rename file, change extension, size / duration, copy source URL, preview video / audio.
 *  2. File conflict dialog: Overwrite / Auto-Rename (keep both) / Skip / Cancel.
 * [direct] = skip the edit dialog (used by "Download" buttons); conflicts are still asked.
 */
class DownloadDialogActivity : ComponentActivity() {

    companion object {
        private const val E_KEYS = "keys"
        private const val E_DIRECT = "direct"

        fun open(ctx: Context, keys: List<String>, direct: Boolean) {
            if (keys.isEmpty()) return
            ctx.startActivity(
                Intent(ctx, DownloadDialogActivity::class.java)
                    .putStringArrayListExtra(E_KEYS, ArrayList(keys))
                    .putExtra(E_DIRECT, direct)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    private val queue = ArrayDeque<String>()
    private var direct = false
    private var current: AlertDialog? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Part3.init(this)
        direct = intent.getBooleanExtra(E_DIRECT, false)
        intent.getStringArrayListExtra(E_KEYS)?.let { queue.addAll(it) }
        next()
    }

    override fun onDestroy() {
        try { current?.dismiss() } catch (e: Exception) { }
        super.onDestroy()
    }

    private fun builder(): AlertDialog.Builder =
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun defaultExt(c: MediaCandidate) = if (c.isHls) "mp4" else c.ext

    private fun next() {
        val key = queue.removeFirstOrNull()
        if (key == null) { finish(); return }
        val c = CaptureHub.candidates.value.firstOrNull { it.key == key }
        if (c == null) { next(); return }
        if (direct) proceed(c, StorageHelper.sanitize(c.title), defaultExt(c)) else showEdit(c)
    }

    // ---------------- download dialog ----------------

    private fun label(text: String) = TextView(this).apply {
        this.text = text; textSize = 12f; setTextColor(Color.parseColor("#9AA3B5"))
        setPadding(0, dp(10), 0, dp(2))
    }

    private fun smallButton(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 12f; transformationMethod = null
        setOnClickListener { onClick() }
    }

    private fun showEdit(c: MediaCandidate) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        box.addView(TextView(this).apply {
            text = "${c.qualityLabel}  •  ${Fmt.size(c.sizeBytes)}  •  ${Fmt.duration(c.durationSec)}  •  " +
                if (c.category == Category.VIDEO) "Video" else "Musik"
            textSize = 13f; setTextColor(Color.WHITE)
        })

        box.addView(label("Nama file"))
        val nameEt = EditText(this).apply {
            setText(StorageHelper.sanitize(c.title)); setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT; setTextColor(Color.WHITE)
        }
        box.addView(nameEt, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        box.addView(label(if (c.isHls) "Ekstensi (HLS selalu digabung ke MP4)" else if (c.isYtDlp) "Ekstensi (yt-dlp + FFmpeg menggabungkan otomatis)" else "Ekstensi"))
        val extEt = EditText(this).apply {
            setText(defaultExt(c)); setSingleLine(true); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT
            isEnabled = !c.isHls
        }
        box.addView(extEt, LinearLayout.LayoutParams(dp(120), WRAP_CONTENT))

        box.addView(label("Sumber"))
        box.addView(TextView(this).apply {
            text = c.url; textSize = 11f; maxLines = 4; setTextColor(Color.parseColor("#CFD8E6"))
            setTextIsSelectable(true)
        })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.START }
        row.addView(smallButton("📋 Salin URL") { copyUrl(c.url) })
        if (!c.isYtDlp) {
            row.addView(smallButton("🎬 Video") { Part3.preview(this, c.url, c.referer, c.userAgent, c.title, false) })
            row.addView(smallButton("🎧 Audio") { Part3.preview(this, c.url, c.referer, c.userAgent, c.title, true) })
        }
        box.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })

        val d = builder()
            .setTitle("Unduh berkas")
            .setView(box)
            .setPositiveButton("Unduh") { _, _ ->
                val name = StorageHelper.sanitize(nameEt.text.toString())
                val ext = extEt.text.toString().trim().trim('.').lowercase().ifBlank { defaultExt(c) }
                proceed(c, name, ext)
            }
            .setNegativeButton("Lewati") { _, _ -> next() }
            .setOnCancelListener { finish() }
            .create()
        current = d
        d.show()
    }

    private fun copyUrl(url: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("url", url))
        Toast.makeText(this, "URL disalin", Toast.LENGTH_SHORT).show()
    }

    // ---------------- conflict dialog ----------------

    private fun proceed(c: MediaCandidate, name: String, ext: String) {
        val fileName = "$name.$ext"
        val existing = StorageHelper.findExisting(this, fileName, c.category)
        if (existing == null) {
            start(c, name, ext)
            next()
            return
        }
        val items = arrayOf(
            "Timpa (Overwrite)",
            "Ganti nama otomatis (simpan keduanya)",
            "Lewati (Skip)",
            "Batal (Cancel)"
        )
        val d = builder()
            .setTitle("Berkas sudah ada")
            .setMessage("\"$fileName\" sudah ada di folder ${StorageHelper.folderName(this)}.")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        StorageHelper.deleteFinal(this, existing)
                        start(c, name, ext)
                        next()
                    }
                    1 -> {
                        start(c, StorageHelper.uniqueName(this, name, ext, c.category), ext)
                        next()
                    }
                    2 -> next()
                    else -> finish()
                }
            }
            .setOnCancelListener { finish() }
            .create()
        current = d
        d.show()
    }

    private fun start(c: MediaCandidate, name: String, ext: String) {
        DownloadService.enqueue(this, c, name, ext)
        CaptureHub.remove(c.key)
        Toast.makeText(this, "Unduhan dimulai", Toast.LENGTH_SHORT).show()
    }
}
