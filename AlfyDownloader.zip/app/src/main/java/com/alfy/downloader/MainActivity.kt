package com.alfy.downloader

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    private val tick = mutableStateOf(0)
    private var askedOverlay = false

    // Izin diminta SATU PER SATU: tiap langkah menunggu pengguna selesai sebelum lanjut ke izin berikutnya.
    private var step = 0
    private var waiting = false
    private var leftApp = false
    private var gen = 0
    private val ui = android.os.Handler(android.os.Looper.getMainLooper())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { AlfyTheme { App(tick.value) } }
        ui.postDelayed({ rootFirst() }, 300)
    }

    /** v1.9: izin ROOT diminta PERTAMA (sekali, mencakup semua alat), baru izin lain; izin lain otomatis ikut diberikan lewat root. */
    private fun rootFirst() {
        Thread {
            val was = RootGate.granted
            val ok = RootGate.ensure(true)
            if (ok && !was) NetSniffer.enableSync(packageName, false) else if (!ok) RootGate.watch()
            ui.post { next() }
        }.apply { isDaemon = true }.start()
    }

    private fun startFloat() {
        try {
            if (Settings.canDrawOverlays(this) && !FloatingService.running)
                ContextCompat.startForegroundService(this, Intent(this, FloatingService::class.java))
        } catch (e: Exception) { }
    }

    private fun later(ms: Long) { val g = ++gen; ui.postDelayed({ if (g == gen) next() }, ms) }

    /** Jalankan langkah berikutnya yang masih kurang. Hanya satu permintaan pada satu waktu. */
    private fun next() {
        waiting = false; leftApp = false
        startFloat()
        while (true) {
            val s = step++
            when (s) {
                0 -> {  // penyimpanan
                    val miss = listOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
                    if (miss.isNotEmpty()) { waiting = true; ActivityCompat.requestPermissions(this, miss.toTypedArray(), 1); return }
                }
                1 -> {  // notifikasi
                    if (Build.VERSION.SDK_INT >= 33 &&
                        ContextCompat.checkSelfPermission(this, "android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                        waiting = true; ActivityCompat.requestPermissions(this, arrayOf("android.permission.POST_NOTIFICATIONS"), 2); return
                    }
                }
                2 -> {  // tampil di atas aplikasi lain
                    if (!Settings.canDrawOverlays(this)) {
                        waiting = true
                        Toast.makeText(this, "Izinkan 'Tampil di atas aplikasi lain' untuk AlfyDownloader+", Toast.LENGTH_LONG).show()
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
                    }
                }
                3 -> {  // aksesibilitas (scan otomatis)
                    if (!accEnabled(this)) {
                        waiting = true
                        Toast.makeText(this, "Aktifkan 'AlfyDownloader+' di Aksesibilitas (untuk scan otomatis)", Toast.LENGTH_LONG).show()
                        try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e: Exception) { waiting = false }
                        if (waiting) return
                    }
                }
                4 -> {  // baterai
                    val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
                    if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                        waiting = true
                        try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) } catch (e: Exception) { waiting = false }
                        if (waiting) return
                    }
                }
                5 -> { NetSniffer.enable(packageName); return }  // terakhir: akses root (jika ada)
                else -> { tick.value++; return }
            }
        }
    }

    override fun onPause() { super.onPause(); if (waiting) leftApp = true }

    override fun onResume() {
        super.onResume()
        tick.value++
        startFloat()
        if (!RootGate.granted) RootGate.watch()   // v1.9: baru diizinkan di Magisk -> aktif otomatis
        // kembali dari layar pengaturan -> lanjut ke izin berikutnya (setelah jeda singkat)
        if (waiting && leftApp) later(500)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
            Regex("https?://[^\\s]+").findAll(t).forEach { Resolver.submit(it.value, null, true, "Manual (clipboard saat buka aplikasi)") }
        } catch (e: Exception) { }
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r); tick.value++
        waiting = false; later(400)
    }
}

@Composable
fun App(tick: Int) {
    var screen by remember { mutableStateOf("home") }
    Home(tick) { screen = it }
}

private fun openFile(ctx: Context, d: DlItem) {
    try {
        val mime = if (d.isAudio) "audio/*" else "video/*"
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.fromFile(File(d.path)), mime)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) { Toast.makeText(ctx, "Tidak ada pemutar", Toast.LENGTH_SHORT).show() }
}

private fun accEnabled(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
    return s.contains(ctx.packageName)
}

@Composable
fun Home(tick: Int, go: (String) -> Unit) {
    val ctx = LocalContext.current
    val all by Repo.downloads.collectAsState()
    val detected by Repo.detected.collectAsState()
    var tab by remember { mutableStateOf(0) }
    var showPerm by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var showGuide by remember { mutableStateOf(false) }
    val list = when (tab) {
        0 -> all
        1 -> all.filter { it.status != Status.DONE }
        else -> all.filter { it.status == Status.DONE }
    }
    val missing = !Settings.canDrawOverlays(ctx) || !accEnabled(ctx)

    Box(Modifier.fillMaxSize().background(Color(0xFF212121))) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("AlfyDownloader+", fontSize = 20.sp, color = Color.White, modifier = Modifier.weight(1f))
                TextButton(onClick = { ctx.startActivity(Intent(ctx, BrowserActivity::class.java)) }) { Text("🌐", fontSize = 20.sp) }
                TextButton(onClick = { showGuide = true }) { Text("📖", fontSize = 20.sp) }
                TextButton(onClick = { showPerm = true }) { Text(if (missing) "⚠️" else "⚙", fontSize = 20.sp) }
            }
            TabRow(selectedTabIndex = tab, containerColor = Color(0xFF212121)) {
                val names = listOf("SEMUA (${all.size})", "MENGUNDUH (${all.count { it.status != Status.DONE }})",
                    "SELESAI (${all.count { it.status == Status.DONE }})", "TERDETEKSI (${detected.size})")
                names.forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, fontSize = 11.sp, maxLines = 1) })
                }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                if (tab == 3) {
                    items(detected, key = { it.key }) { c ->
                        Column(Modifier.fillMaxWidth().background(Color(0xFF689F98)).clickable {
                            ctx.startActivity(Intent(ctx, DownloadDialogActivity::class.java).putExtra("key", c.key))
                        }.padding(12.dp)) {
                            Text((if (c.isAudio) "🎵 " else "🎞 ") + c.title, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("${c.quality} • ${fmtSize(c.size)} • ${fmtDur(c.duration)}", color = Color(0xFFE0F2F1), fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(1.dp))
                    }
                } else {
                    items(list, key = { it.id }) { d -> DlRow(d); Spacer(Modifier.height(1.dp)) }
                }
            }
        }
        FloatingActionButton(onClick = { showAdd = true }, containerColor = Color(0xFF80CBC4),
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) { Text("+", fontSize = 28.sp, color = Color.White) }
    }

    if (showAdd) {
        var url by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Tambah tautan") },
            text = { OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("https://…") }) },
            confirmButton = {
                TextButton(onClick = {
                    Resolver.submit(url, null, true, "Manual (tambah tautan)"); showAdd = false; tab = 3
                    Toast.makeText(ctx, "Memindai tautan…", Toast.LENGTH_SHORT).show()
                }) { Text("PINDAI") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("BATAL") } }
        )
    }
    if (showGuide) {
        var st by remember { mutableStateOf(NetSniffer.status) }
        LaunchedEffect(Unit) { while (true) { st = NetSniffer.status + "\n" + VpnTool.status + "\n" + Resolver.diag + "\n" + ToolLog.text(); kotlinx.coroutines.delay(500) } }
        AlertDialog(
            onDismissRequest = { showGuide = false },
            title = { Text("Pemantau alamat jaringan") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Button(modifier = Modifier.fillMaxWidth(), onClick = {
                        NetSniffer.enable(ctx.packageName)
                        if (Settings.canDrawOverlays(ctx) && !FloatingService.running)
                            ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingService::class.java))
                    }) { Text("AKTIFKAN PEMANTAU ALAMAT") }
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                        try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (e: Exception) { }
                    }) { Text("IZIN AKSES NOTIFIKASI (deteksi tanpa root)") }
                    Spacer(Modifier.height(6.dp))
                    var noVpn by remember { mutableStateOf(VpnTool.enabled()) }
                    Row(Modifier.clickable { noVpn = !noVpn; VpnTool.set(noVpn) }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = noVpn, onCheckedChange = { noVpn = it; VpnTool.set(it) })
                        Text("Lepaskan Alfy dari VPN (pakai IP jaringan asli untuk memindai & mengunduh)", fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                        ctx.startActivity(Intent(ctx, BrowserDataActivity::class.java).putExtra("mode", "adblock"))
                    }) { Text("BLOKIR IKLAN & POP-UP BROWSER (sakelar + daftar domain)") }
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                        ctx.startActivity(Intent(ctx, BrowserActivity::class.java).putExtra("url", "https://accounts.google.com/ServiceLogin?service=youtube&continue=https://m.youtube.com/"))
                    }) { Text("LOGIN YOUTUBE (untuk cookies, pakai akun cadangan)") }
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { NetSniffer.installTcpdump() }) { Text("PASANG TCPDUMP OTOMATIS") }
                    Spacer(Modifier.height(6.dp))
                    var sniff by remember { mutableStateOf(Repo.prefs().getBoolean("sniffAll", false)) }
                    Row(Modifier.clickable {
                        sniff = !sniff; Repo.prefs().edit().putBoolean("sniffAll", sniff).apply(); NetSniffer.stop(); NetSniffer.start()
                    }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = sniff, onCheckedChange = {
                            sniff = it; Repo.prefs().edit().putBoolean("sniffAll", it).apply(); NetSniffer.stop(); NetSniffer.start()
                        })
                        Text("Pantau SEMUA lalu lintas (logcat/tcpdump). Bisa memunculkan banyak link yang tidak kamu buka.", fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    var thumb by remember { mutableStateOf(Repo.prefs().getBoolean("autoThumb", true)) }
                    Row(Modifier.clickable { thumb = !thumb; Repo.prefs().edit().putBoolean("autoThumb", thumb).apply() }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = thumb, onCheckedChange = { thumb = it; Repo.prefs().edit().putBoolean("autoThumb", it).apply() })
                        Text("Scan otomatis thumbnail YouTube saat daftar/hasil pencarian dilihat (maks. 8 per 10 menit)", fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Status: $st" + (if (Engine.ready) "" else "\nMesin unduh: " + (Engine.error ?: "memuat…")), fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "PENJELASAN\n\n" +
                        "• AKTIFKAN PEMANTAU: meminta akses root (izinkan di Magisk/KernelSU), lalu otomatis memberi izin overlay, aksesibilitas, dan baca log, kemudian memantau alamat yang diakses semua aplikasi. Tekan lagi bila status menunjukkan masalah.\n\n" +
                        "ALAT PEMINDAI YOUTUBE (jalan bersamaan di latar belakang; hasilnya di panel menu mengambang)\n" +
                        "1. ytFast: bertanya ke API pemutar YouTube seolah-olah aplikasi iOS / headset VR.\n" +
                        "2. NewPipe: library aplikasi NewPipe, meniru pemutar web YouTube.\n" +
                        "3. yt-dlp: mencoba 6 klien YouTube (IPv4 dipaksa).\n" +
                        "4. yt-dlp+cookies: sama dengan yt-dlp tetapi membawa cookies login. INI YANG PALING MUNGKIN BERHASIL di IP VPN, karena YouTube tidak menanyakan 'bukan bot' pada akun yang sudah login.\n" +
                        "5. Piped/Invidious: daftar server publik diambil otomatis, banyak server dicoba sekaligus. Link diproksikan lewat server itu, jadi tidak terikat IP VPN-mu.\n" +
                        "6. HLS iOS/VR: daftar putar iOS lalu klien VR (mulai setelah 3 detik bila belum ada hasil).\n" +
                        "7. WebView: membuka pemutar YouTube asli secara tersembunyi lalu menangkap link googlevideo (mulai setelah 5 detik; memakai login yang sama).\n" +
                        "Baris log: ✓ berhasil, ✗ alasan gagal, ⏳ berjalan. Setiap link diberi label [alat] yang membuatnya. Bila semua gagal, tunggu 60 detik lalu otomatis dicoba sekali lagi.\n\n" +
                        "BILA SEMUA ALAT ✗ 'bot check' / LOGIN_REQUIRED (IP VPN ditandai YouTube)\n" +
                        "• Tekan LOGIN YOUTUBE, masuk dengan AKUN CADANGAN (bukan akun utama), selesaikan sampai halaman YouTube terbuka, lalu tutup. Cookies dipakai otomatis oleh alat 4 dan 7. Tetap nyalakan VPN seperti biasa; login cukup sekali, ulangi bila cookies kedaluwarsa.\n" +
                        "• Root: cookies Firefox dan browser Chromium (Chrome, Brave, Kiwi, Edge) yang sudah login YouTube juga dibaca otomatis bila tidak terenkripsi. Bila status menulis 'terenkripsi', pakai LOGIN YOUTUBE.\n" +
                        "• Jangan ganti server/kota VPN di tengah proses: link googlevideo terikat ke IP yang meminta (kecuali dari alat 5).\n" +
                        "• 'Lepaskan Alfy dari VPN' hanya untuk yang punya kuota di luar VPN; abaikan bila tidak.\n\n" +
                        "PENDETEKSI VIDEO (tahap 1)\n" +
                        "• Akses Notifikasi: tekan IZIN AKSES NOTIFIKASI lalu aktifkan AlfyDownloader+. Judul + channel video YouTube/ReVanced yang sedang diputar dibaca lewat MediaSession, tanpa root.\n" +
                        "• Aksesibilitas, media_session (root), logcat, clipboard, dan menu Share tetap berjalan.\n\n" +
                        "• PASANG TCPDUMP OTOMATIS: memasang tcpdump lewat Termux supaya alamat HTTP polos (http://…) terbaca langsung dari jaringan. Butuh Termux terpasang dan internet. Alternatif: modul Magisk 'tcpdump'.\n\n" +
                        "• Otomatis hanya untuk yang sedang kamu akses: alamat di kolom URL browser dan video YouTube yang sedang diputar (media session, root). Untuk Shorts/layar lain, tekan tombol 🔍 di menu mengambang: layar yang sedang terbuka dipindai saat itu juga (aksesibilitas HARUS aktif). 📋 memindai clipboard. Hasil bisa meleset bila ada video berjudul sama.\n\n" +
                        "• Alamat yang terbaca: URL dari log aplikasi (logcat), teks di layar (aksesibilitas), isi halaman web, dan paket HTTP polos. Hasilnya muncul sebagai angka merah di tombol mengambang.\n\n" +
                        "• Batasan: alamat HTTPS lengkap terenkripsi di jaringan sehingga tidak terlihat oleh tcpdump. Mencegat HTTPS penuh (sertifikat sendiri) belum ada di versi ini.\n\n" +
                        "• Agar tidak dimatikan sistem: Pengaturan > Aplikasi > AlfyDownloader+ > Baterai > Tanpa batasan.",
                        fontSize = 13.sp
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showGuide = false }) { Text("TUTUP") } }
        )
    }
    if (showPerm) {
        val ov = Settings.canDrawOverlays(ctx)
        val ac = accEnabled(ctx)
        val st = ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        AlertDialog(
            onDismissRequest = { showPerm = false },
            title = { Text("Izin aplikasi") },
            text = {
                Column {
                    TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))) }) {
                        Text((if (ov) "✅ " else "❗ ") + "Tampil di atas aplikasi lain (menu mengambang)") }
                    TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
                        Text((if (ac) "✅ " else "❗ ") + "Aksesibilitas: AlfyDownloader+ (scan URL browser)") }
                    TextButton(onClick = {
                        ActivityCompat.requestPermissions(ctx as Activity, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
                    }) { Text((if (st) "✅ " else "❗ ") + "Penyimpanan") }
                    val bat = (ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
                    TextButton(onClick = {
                        try { ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))) } catch (e: Exception) { }
                    }) { Text((if (bat) "✅ " else "❗ ") + "Tanpa batasan baterai (agar tidak dimatikan sistem)") }
                    TextButton(onClick = { NetSniffer.enable(ctx.packageName) }) {
                        Text((if (NetSniffer.status.contains("Root: aktif")) "✅ " else "❗ ") + "Akses root (ketuk untuk meminta ulang)") }
                    Text("Warna tombol mengambang", fontSize = 13.sp)
                    for ((label, key, def) in listOf(Triple("Tombol", "bubbleIdx", 0), Triple("Panah", "arrowIdx", 8))) {
                        var sel by remember { mutableStateOf(Repo.prefs().getInt(key, def)) }
                        Text(label, fontSize = 12.sp)
                        for (row in 0..1) Row {
                            for (i in row * 5 until row * 5 + 5) {
                                val shape = androidx.compose.foundation.shape.CircleShape
                                Box(Modifier.padding(3.dp).size(30.dp)
                                    .background(if (i == 0) Color.Transparent else Color(Palette.colors[i]), shape)
                                    .then(if (i == 0) Modifier.background(androidx.compose.ui.graphics.Brush.sweepGradient(Palette.rainbow.map { Color(it) }), shape) else Modifier)
                                    .border(if (sel == i) 3.dp else 1.dp, if (sel == i) Color(0xFF00BFA5) else Color.Gray, shape)
                                    .clickable { sel = i; Repo.prefs().edit().putInt(key, i).apply() })
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPerm = false }) { Text("TUTUP") } }
        )
    }
}

@Composable
fun DlRow(d: DlItem) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var menu by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf(false) }
    val stText = when (d.status) {
        Status.QUEUED -> "Antre"; Status.DOWNLOADING -> "Mengunduh"; Status.PAUSED -> "Dijeda"
        Status.DONE -> "Selesai"; Status.ERROR -> "Gagal"
    }
    Row(Modifier.fillMaxWidth().background(Color(0xFF689F98)).clickable { if (d.status == Status.DONE) openFile(ctx, d) }.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(if (d.isAudio) "🎵" else "🎞️", fontSize = 26.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(buildAnnotatedString {
                append(d.name + " (Lanjutkan: ")
                withStyle(SpanStyle(color = if (d.resumable) Color(0xFF006400) else Color.Red, fontWeight = FontWeight.Bold)) {
                    append(if (d.resumable) "Ya" else "Tidak")
                }
                append(")")
            }, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Row {
                Text("${d.progress}% | ${if (d.status == Status.DONE) fmtSize(d.total) else fmtSize(d.done) + "/" + fmtSize(d.total)}",
                    color = Color(0xFFE0F2F1), fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text(stText + if (d.status == Status.DOWNLOADING && d.speed > 0) " ${fmtSize(d.speed)}/s" else "",
                    color = Color(0xFFE0F2F1), fontSize = 12.sp)
            }
            if (d.status == Status.DOWNLOADING || d.status == Status.PAUSED || d.status == Status.QUEUED)
                LinearProgressIndicator(progress = { d.progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Color.White)
            if (!d.resumable && (d.status == Status.ERROR || d.status == Status.PAUSED))
                Text("Tidak dapat dilanjutkan: ${d.error.ifBlank { "server tidak mendukung Range" }}. Unduhan akan diulang dari awal.",
                    color = Color(0xFFFFEBEE), fontSize = 12.sp)
            else if (d.error.isNotBlank()) Text(d.error, color = Color(0xFFFFEBEE), fontSize = 12.sp)
        }
        Box {
            Text("⋮", fontSize = 26.sp, color = Color.White, modifier = Modifier.clickable { menu = true }.padding(8.dp))
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                if (d.status == Status.DONE) {
                    DropdownMenuItem(text = { Text("Buka") }, onClick = { menu = false; openFile(ctx, d) })
                } else if (d.status == Status.DOWNLOADING || d.status == Status.QUEUED) {
                    DropdownMenuItem(text = { Text("Jeda") }, onClick = { menu = false; DownloadService.cmd(ctx, "pause", d.id) })
                } else {
                    DropdownMenuItem(text = { Text("Lanjutkan / Ulangi") }, onClick = { menu = false; DownloadService.cmd(ctx, "start", d.id) })
                }
                DropdownMenuItem(text = { Text("Detail") }, onClick = { menu = false; detail = true })
                DropdownMenuItem(text = { Text("Hapus dari daftar") }, onClick = {
                    menu = false; DownloadService.cmd(ctx, "cancel", d.id); Repo.remove(d.id)
                })
                DropdownMenuItem(text = { Text("Hapus + file") }, onClick = {
                    menu = false; DownloadService.cmd(ctx, "cancel", d.id)
                    try { if (d.path.isNotEmpty()) File(d.path).delete(); File(d.dir, d.name + ".part").delete() } catch (e: Exception) { }
                    Repo.remove(d.id)
                })
            }
        }
    }
    if (detail) AlertDialog(
        onDismissRequest = { detail = false },
        title = { Text("Detail") },
        text = {
            Text("Nama: ${d.name}\nStatus: $stText\nUkuran: ${fmtSize(d.total)}\nDapat dilanjutkan: ${if (d.resumable) "Ya" else "Tidak"}\n" +
                "Folder: ${d.dir}\nURL: ${d.url}\n" + (if (d.error.isNotBlank()) "Catatan: ${d.error}" else ""), fontSize = 13.sp)
        },
        confirmButton = { TextButton(onClick = { detail = false }) { Text("TUTUP") } }
    )
}
