package com.alfy.downloader

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

/**
 * Alat khusus situs (v1.3):
 *  - jw()   : situs berbasis JW Player / halaman unduh (jwplyr.com, *.overfetch.video). Membaca HTML + iframe,
 *             membuka kemasan JavaScript (p,a,c,k,e,d) dan base64 (atob), lalu menguji tiap kandidat link.
 *  - xApi() : X / Twitter lewat API publik syndication (tanpa login, jauh lebih cepat daripada yt-dlp).
 * Semua fungsi mengembalikan null bila berhasil, selain itu alasan gagal (tampil di log alat).
 */
object SiteTool {
    private const val MAX_BYTES = 1_500_000
    private const val TAG = "JWPlayer"

    /** Penanda halaman CAPTCHA / verifikasi manusia (Cloudflare Turnstile, reCAPTCHA, hCaptcha, dll). */
    internal val captchaRe = Regex("turnstile|cf-chl|challenges\\.cloudflare|g-recaptcha|h-captcha|hcaptcha|just a moment|captcha|verifikasi bahwa anda|verify you are human",
        RegexOption.IGNORE_CASE)

    private val mediaUrlRe = Regex("https?://[^\\s\"'<>\\\\)]+")
    private val mediaExtRe = Regex("\\.(?:mp4|m3u8|webm|mkv|mp3|m4a|mov|m4v)(?:[?#]|$)", RegexOption.IGNORE_CASE)
    private val keyRe = Regex("[\"']?(?:file|src|source|video_url|videoUrl|hls|hlsUrl|mp4|stream|download_url|downloadUrl|url|link)[\"']?\\s*[:=]\\s*[\"'](https?://[^\"'\\s<>]+|/[^\"'\\s<>]+)[\"']", RegexOption.IGNORE_CASE)
    private val tagRe = Regex("<(source|video|iframe|a)\\b[^>]*?\\b(?:src|href|data-src)\\s*=\\s*[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
    private val followRe = Regex("/(?:e|v|d|f|embed|dl|download|file|stream|watch|play|player)/", RegexOption.IGNORE_CASE)
    private val packedRe = Regex("\\}\\('((?:[^'\\\\]|\\\\.)*)',\\s*(\\d+),\\s*(\\d+),\\s*'((?:[^'\\\\]|\\\\.)*)'\\.split\\('\\|'\\)")
    private val atobRe = Regex("atob\\(\\s*[\"']([A-Za-z0-9+/=]{16,})[\"']\\s*\\)")
    private val titleRe = Regex("<title[^>]*>([^<]{1,200})</title>", RegexOption.IGNORE_CASE)
    private val ogTitleRe = Regex("property=[\"']og:title[\"'][^>]*content=[\"']([^\"']{1,200})[\"']", RegexOption.IGNORE_CASE)
    private val adRe = Regex("doubleclick|googlesyndication|googleads|imasdk|adservice|/vast|adsystem|pubads|adnxs|popads", RegexOption.IGNORE_CASE)

    private fun norm(s: String) = s.replace("\\/", "/").replace("\\u002F", "/", true).replace("\\x2F", "/", true)
        .replace("\\u0026", "&", true).replace("&amp;", "&")

    /** Ambil teks halaman. Mengembalikan (kode HTTP, isi) atau null bila gagal koneksi. Kode >= 400 tetap dibaca (halaman CAPTCHA sering 403). */
    private fun fetch(u: String, ref: String?, to: Int = 8000): Pair<Int, String>? {
        var conn: HttpURLConnection? = null
        return try {
            val k = URL(u).openConnection() as HttpURLConnection
            conn = k
            k.connectTimeout = to; k.readTimeout = to; k.instanceFollowRedirects = true
            k.setRequestProperty("User-Agent", Resolver.UA)
            k.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8")
            k.setRequestProperty("Accept-Language", "id-ID,id;q=0.9,en;q=0.8")
            val rf = ref ?: Resolver.defaultRef(u)
            if (rf != null) k.setRequestProperty("Referer", rf)
            try {
                val ck = android.webkit.CookieManager.getInstance().getCookie(u)
                if (ck != null && ck.isNotBlank()) k.setRequestProperty("Cookie", ck)
            } catch (e: Throwable) { }
            val code = k.responseCode
            val st = if (code >= 400) k.errorStream else k.inputStream
            if (st == null) {
                Pair(code, "")
            } else {
                val buf = ByteArray(MAX_BYTES)
                var n = 0
                st.use { s -> while (n < MAX_BYTES) { val r = s.read(buf, n, MAX_BYTES - n); if (r < 0) break; n += r } }
                Pair(code, String(buf, 0, n, Charsets.UTF_8))
            }
        } catch (e: Exception) { null } finally { try { conn?.disconnect() } catch (e: Exception) { } }
    }

    // ---------- pembuka kemasan JavaScript Dean Edwards: eval(function(p,a,c,k,e,d){...}('...',62,120,'a|b'.split('|'))) ----------
    internal fun unpack(js: String): List<String> {
        val out = ArrayList<String>()
        for (m in packedRe.findAll(js)) {
            try {
                var p = m.groupValues[1].replace("\\'", "'").replace("\\\\", "\\")
                val a = m.groupValues[2].toInt()
                val cnt = m.groupValues[3].toInt()
                val k = m.groupValues[4].split("|")
                if (a < 2 || cnt > 4000) continue
                fun enc(n: Int): String {
                    val head = if (n < a) "" else enc(n / a)
                    val r = n % a
                    return head + (if (r > 35) (r + 29).toChar().toString() else Integer.toString(r, 36))
                }
                for (i in cnt - 1 downTo 0) {
                    val w = k.getOrNull(i) ?: continue
                    if (w.isEmpty()) continue
                    p = p.replace(Regex("\\b" + Regex.escape(enc(i)) + "\\b")) { w }
                }
                out.add(p)
            } catch (e: Exception) { }
        }
        return out
    }

    private fun decodeAtob(t: String): List<String> {
        val out = ArrayList<String>()
        for (m in atobRe.findAll(t)) {
            try { out.add(String(android.util.Base64.decode(m.groupValues[1], android.util.Base64.DEFAULT), Charsets.UTF_8)) } catch (e: Exception) { }
        }
        return out
    }

    private fun resolve(base: String, u: String): String? = try {
        if (u.startsWith("http")) u else if (u.startsWith("//")) "https:$u" else URI(base).resolve(u).toString()
    } catch (e: Exception) { null }

    private fun titleOf(html: String): String {
        val t = ogTitleRe.find(html)?.groupValues?.get(1) ?: titleRe.find(html)?.groupValues?.get(1) ?: ""
        return t.replace("&amp;", "&").replace("&#39;", "'").replace("&quot;", "\"").trim().take(100)
    }

    /**
     * JW Player / halaman unduh. Urutan: baca halaman (+ halaman embed tebakan /e/ID, /v/ID) -> kumpulkan kandidat link
     * dari HTML, JS terbuka-kemasan, dan base64 -> ikuti iframe/tautan unduh (maks 6 halaman) -> uji semua kandidat.
     */
    fun jw(page: String): String? {
        Resolver.rejects.clear()
        val seenPages = LinkedHashSet<String>()
        val queue = ArrayDeque<Pair<String, String?>>()
        queue.add(Pair(page, null))
        // dugaan struktur umum host file video: /d/ID = halaman unduh, /e/ID atau /v/ID = halaman putar
        Regex("^(https?://[^/]+)/d/([^/?#]+)").find(page)?.let { m ->
            for (p in listOf("e", "v", "embed")) queue.add(Pair(m.groupValues[1] + "/" + p + "/" + m.groupValues[2], page))
        }
        val hard = LinkedHashMap<String, String?>()   // alamat -> referer (kemungkinan besar media)
        val soft = LinkedHashMap<String, String?>()   // kandidat tebakan, wajib lolos uji
        var title = ""
        var captcha = false
        var lastCode = 0
        var fetched = 0
        val deadline = System.currentTimeMillis() + 20_000
        while (queue.isNotEmpty() && fetched < 6 && System.currentTimeMillis() < deadline) {
            val (u, ref) = queue.removeFirst()
            if (!seenPages.add(u)) continue
            val r = fetch(u, ref ?: if (u == page) (if (Resolver.isJwPage(u)) Resolver.jwRef(u) else null) else page) ?: continue
            fetched++; lastCode = r.first
            val raw = r.second
            if (r.first >= 400 && raw.isBlank()) continue
            if (captchaRe.containsMatchIn(raw)) captcha = true
            if (title.isBlank()) title = titleOf(raw)
            // semua teks yang perlu dipindai: HTML asli + hasil buka kemasan + hasil base64
            val texts = ArrayList<String>()
            texts.add(raw)
            val un = unpack(raw)
            texts.addAll(un)
            for (t in (listOf(raw) + un)) texts.addAll(decodeAtob(t))
            for (t0 in texts) {
                val t = norm(t0)
                for (m in mediaUrlRe.findAll(t)) {
                    val x = m.value.trimEnd('.', ',', ';', ')')
                    if (adRe.containsMatchIn(x)) continue
                    if (mediaExtRe.containsMatchIn(x) || Resolver.isMedia(x)) hard.putIfAbsent(x, u)
                }
                for (m in keyRe.findAll(t)) {
                    val x = resolve(u, m.groupValues[1]) ?: continue
                    if (adRe.containsMatchIn(x) || x == u || x in hard) continue
                    if (mediaExtRe.containsMatchIn(x)) hard.putIfAbsent(x, u) else soft.putIfAbsent(x, u)
                }
                for (m in tagRe.findAll(t)) {
                    val tag = m.groupValues[1].lowercase()
                    val x = resolve(u, m.groupValues[2]) ?: continue
                    if (!x.startsWith("http") || adRe.containsMatchIn(x) || x == u) continue
                    if (tag == "source" || tag == "video") { if (mediaExtRe.containsMatchIn(x)) hard.putIfAbsent(x, u) else soft.putIfAbsent(x, u) }
                    else if (followRe.containsMatchIn(x) && x !in seenPages && queue.size < 8) queue.add(Pair(x, u))
                }
            }
            // sudah ada kandidat kuat: tidak perlu menelusuri lebih jauh (di situs ber-iklan hanya hitung host file milik situs)
            if (hard.keys.any { !Resolver.isJwPage(page) || Resolver.jwMediaOk(it) }) break
        }
        // uji kandidat secara paralel (maks 12), tiap thread memberi label sumber yang sama
        // v1.4: di situs embed ber-iklan, video dari host lain (bukan overfetch/vidoy/jwplyr) adalah IKLAN (mis. video judol) -> dibuang
        var ads = 0
        val all = (hard.entries.map { it.key to it.value } + soft.entries.map { it.key to it.value }).distinctBy { it.first }
        val own = all.filter { Resolver.jwMediaOk(it.first) }
        ads = all.size - own.size
        val cands = (if (Resolver.isJwPage(page)) own else all).take(12)
        val okCount = java.util.concurrent.atomic.AtomicInteger(0)
        val ths = cands.map { (x, ref) ->
            Thread {
                ToolLog.tl.set(TAG)
                try { if (Resolver.addMediaChecked(x, ref ?: page, title, x in hard)) okCount.incrementAndGet() } catch (e: Throwable) { }
                finally { ToolLog.tl.remove() }
            }.apply { isDaemon = true; start() }
        }
        ths.forEach { try { it.join(10_000) } catch (e: Exception) { } }
        if (okCount.get() > 0) return null
        if (captcha) { Resolver.captchaPage = page; return "butuh CAPTCHA → ketuk 🌐 di panel" }
        if (fetched == 0) return "halaman tidak terbuka"
        val why = Resolver.rejects.toList().distinct().take(3).joinToString("; ")
        return "tanpa link di halaman (HTTP $lastCode, ${cands.size} kandidat ditolak" + (if (why.isNotBlank()) ": $why" else "") +
            (if (ads > 0) ", $ads iklan diabaikan" else "") + ")"
    }

    // ---------- X / Twitter ----------
    /** Token syndication: (id / 1e15 * PI) dalam basis 36, tanpa '0' dan '.' (sama seperti rumus yang dipakai yt-dlp). */
    private fun tweetToken(id: String): String {
        val v = (id.toDouble() / 1e15) * Math.PI
        val ip = v.toLong()
        var f = v - ip
        val sb = StringBuilder(java.lang.Long.toString(ip, 36))
        sb.append('.')
        var i = 0
        while (f > 0 && i < 12) { f *= 36; val d = f.toInt(); sb.append(Character.forDigit(d, 36)); f -= d; i++ }
        return sb.toString().replace("0", "").replace(".", "")
    }

    /** v1.55: mp4 X tanpa jalur suara (atom moov ada, "soun" tidak ada)? false hanya bila pasti tanpa suara. */
    private fun audioOk(u: String): Boolean = try {
        val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 5000; c.readTimeout = 5000
        c.setRequestProperty("User-Agent", Resolver.UA); c.setRequestProperty("Range", "bytes=0-300000")
        val buf = ByteArray(300_001); var n = 0
        c.inputStream.use { ins -> while (n < buf.size) { val r = ins.read(buf, n, buf.size - n); if (r < 0) break; n += r } }
        c.disconnect()
        val t = String(buf, 0, n, Charsets.ISO_8859_1)
        !(t.contains("moov") && !t.contains("soun"))
    } catch (e: Throwable) { true }

    private fun synObj(id: String): JSONObject? {
        for (tok in listOf(tweetToken(id), "a")) {
            val r = fetch("${AppPreferences.syndicationUrl}?id=$id&lang=en&token=$tok", "https://platform.twitter.com/", 4500) ?: continue
            if (r.first == 200 && r.second.trim().startsWith("{")) { try { val j = JSONObject(r.second); if (j.length() > 0) return j } catch (e: Exception) { } }
        }
        return null
    }

    /** HLS (master m3u8, suara+video digabung ffmpeg) dari syndication: cadangan bila mp4 tanpa suara. */
    private fun xHls(o: JSONObject, id: String, title: String): List<Candidate> {
        val out = ArrayList<Candidate>()
        val md = o.optJSONArray("mediaDetails") ?: return out
        for (i in 0 until md.length()) {
            val vs = md.optJSONObject(i)?.optJSONObject("video_info")?.optJSONArray("variants") ?: continue
            for (k in 0 until vs.length()) {
                val v = vs.optJSONObject(k) ?: continue
                val u = v.optString("url", "")
                if (u.startsWith("http") && v.optString("content_type", "").contains("mpegurl", true))
                    out.add(Candidate(key = "X$id|hls$i", url = u, title = title, kind = Kind.HLS, isAudio = false, ext = "m3u8",
                        size = -1, quality = "HLS + suara", duration = 0, formatSel = null, previewUrl = u, referer = null))
            }
        }
        return out
    }

    /** Tandai mp4 tanpa suara; bila ada, tambahkan HLS bersuara dari syndication. */
    private fun xFixAudio(out: MutableList<Candidate>, id: String, title: String, syn: JSONObject?) {
        var bad = false
        for (i in out.indices) {
            val c = out[i]
            if (c.kind == Kind.DIRECT && c.ext == "mp4" && !audioOk(c.url)) { out[i] = c.copy(muted = true, quality = c.quality + " tanpa suara"); bad = true }
        }
        if (bad) { val o = syn ?: synObj(id); if (o != null) out.addAll(xHls(o, id, title)) }
    }

    /** v1.4: API publik fxtwitter/vxtwitter (tanpa login). Jauh lebih andal daripada syndication yang kini sering kosong. */
    private fun xFx(id: String): String? {
        val bases = listOf("${AppPreferences.fxtwitterUrl}/status/$id", "${AppPreferences.vxtwitterUrl}/Twitter/status/$id")
        var title = ""
        val out = ArrayList<Candidate>()
        for (b in bases) {
            val r = fetch(b, "https://x.com/", 4500) ?: continue
            if (r.first != 200 || !r.second.trim().startsWith("{")) continue
            val j = try { JSONObject(r.second) } catch (e: Exception) { continue }
            val tw = j.optJSONObject("tweet") ?: j.optJSONObject("status")
            if (tw != null) {
                title = tw.optString("text").replace(Regex("https?://t\\.co/\\w+"), "").trim()
                for (src in listOf(tw, tw.optJSONObject("quote"))) {
                    val vids = src?.optJSONObject("media")?.optJSONArray("videos") ?: continue
                    for (i in 0 until vids.length()) {
                        val v = vids.optJSONObject(i) ?: continue
                        val u = v.optString("url", "")
                        if (!u.startsWith("http")) continue
                        val h = v.optInt("height", 0)
                        out.add(Candidate(key = "X$id|fx$i|${u.takeLast(24)}", url = u, title = (if (title.isBlank()) "X $id" else title).take(80),
                            kind = if (u.contains(".m3u8")) Kind.HLS else Kind.DIRECT, isAudio = false,
                            ext = if (u.contains(".m3u8")) "m3u8" else "mp4", size = -1, quality = if (h > 0) "${h}p" else "video",
                            duration = v.optDouble("duration", 0.0).toLong(), formatSel = null, previewUrl = u, referer = null))
                    }
                }
            }
            val me = j.optJSONArray("media_extended")      // format vxtwitter
            if (out.isEmpty() && me != null) for (i in 0 until me.length()) {
                val m = me.optJSONObject(i) ?: continue
                val t = m.optString("type", "")
                val u = m.optString("url", "")
                if ((t == "video" || t == "gif") && u.startsWith("http")) {
                    if (title.isBlank()) title = j.optString("text").replace(Regex("https?://t\\.co/\\w+"), "").trim()
                    out.add(Candidate(key = "X$id|vx$i|${u.takeLast(24)}", url = u, title = (if (title.isBlank()) "X $id" else title).take(80),
                        kind = Kind.DIRECT, isAudio = false, ext = "mp4", size = -1, quality = "video", duration = 0, formatSel = null, previewUrl = u, referer = null))
                }
            }
            if (out.isNotEmpty()) break
        }
        if (out.isEmpty()) return null
        xFixAudio(out, id, (if (title.isBlank()) "X $id" else title).take(80), null)
        Repo.addCandidates(out)
        return "ok"
    }

    /** v1.7: part 1 = hanya fxtwitter/vxtwitter, 2 = hanya syndication, 0 = keduanya berurutan (perilaku lama). Dipisah agar jalan PARALEL di log alat. */
    private val xReserved = setOf("home", "i", "explore", "search", "notifications", "messages", "settings", "compose", "hashtag", "tos", "privacy", "login", "intent", "share", "about", "jobs", "lists", "bookmarks")

    /** v1.10: halaman profil X (x.com/nama, termasuk subdomain): ambil postingan terbaru lewat fxtwitter v2 (tanpa login), cadangan vxtwitter. */
    private fun xProfile(handle: String): String? {
        val r = fetch("${AppPreferences.fxtwitterUrl}/2/profile/$handle/statuses", "https://x.com/", 6000)
        val out = ArrayList<Candidate>()
        if (r != null && r.first == 200 && r.second.trim().startsWith("{")) {
            val arr = try { JSONObject(r.second).optJSONArray("results") } catch (e: Exception) { null }
            if (arr != null) for (n in 0 until arr.length()) {
                val tw = arr.optJSONObject(n) ?: continue
                val id = tw.optString("id", "")
                val title = tw.optString("text").replace(Regex("https?://t\\.co/\\w+"), "").trim()
                for (src in listOf(tw, tw.optJSONObject("quote"))) {
                    val vids = src?.optJSONObject("media")?.optJSONArray("videos") ?: continue
                    for (i in 0 until vids.length()) {
                        val v = vids.optJSONObject(i) ?: continue
                        val u = v.optString("url", "")
                        if (!u.startsWith("http")) continue
                        val h = v.optInt("height", 0)
                        out.add(Candidate(key = "X$id|pf$i|${u.takeLast(24)}", url = u, title = (if (title.isBlank()) "X $handle $id" else title).take(80),
                            kind = if (u.contains(".m3u8")) Kind.HLS else Kind.DIRECT, isAudio = false,
                            ext = if (u.contains(".m3u8")) "m3u8" else "mp4", size = -1, quality = if (h > 0) "${h}p" else "video",
                            duration = v.optDouble("duration", 0.0).toLong(), formatSel = null, previewUrl = u, referer = null))
                    }
                }
            }
        }
        if (out.isEmpty()) return "profil @$handle tanpa video (fxtwitter)"
        Repo.addCandidates(out)
        return null
    }

    fun xApi(page: String, part: Int = 0): String? {
        val id0 = Regex("status(?:es)?/(\\d{5,25})").find(page)?.groupValues?.get(1)
        if (id0 == null) {
            if (part == 2) return "bukan tautan status"
            val h = try { android.net.Uri.parse(page).pathSegments.firstOrNull()?.lowercase() } catch (e: Exception) { null }
            if (h == null || h in xReserved || !Regex("^[a-z0-9_]{1,15}$").matches(h)) return "bukan tautan status"
            return xProfile(h)
        }
        val id = id0
        if (part != 2) {
            if (xFx(id) != null) return null
            if (part == 1) return "fxtwitter/vxtwitter tanpa data"
        }
        var j: JSONObject? = null
        for (tok in listOf(tweetToken(id), "a")) {
            val r = fetch("${AppPreferences.syndicationUrl}?id=$id&lang=en&token=$tok", "https://platform.twitter.com/", 4500) ?: continue
            if (r.first == 200 && r.second.trim().startsWith("{")) { try { j = JSONObject(r.second) } catch (e: Exception) { } }
            if (j != null && j.length() > 0) break
        }
        val o = j ?: return "fxtwitter & syndication tanpa data"
        val text = o.optString("text").replace(Regex("https?://t\\.co/\\w+"), "").trim()
        val title = (if (text.isBlank()) "X $id" else text).take(80)
        val out = ArrayList<Candidate>()
        val md = o.optJSONArray("mediaDetails")
        if (md != null) for (i in 0 until md.length()) {
            val vi = md.optJSONObject(i)?.optJSONObject("video_info") ?: continue
            val dur = vi.optLong("duration_millis", 0L) / 1000
            val vs = vi.optJSONArray("variants") ?: continue
            for (k in 0 until vs.length()) {
                val v = vs.optJSONObject(k) ?: continue
                val u = v.optString("url", "")
                if (!u.startsWith("http") || v.optString("content_type", "") != "video/mp4") continue
                val h = Regex("/(\\d{3,4})x(\\d{3,4})/").find(u)?.groupValues?.get(2)
                out.add(Candidate(key = "X$id|${v.optLong("bitrate", 0L)}|$i", url = u, title = title, kind = Kind.DIRECT, isAudio = false, ext = "mp4",
                    size = -1, quality = if (h != null) "${h}p" else "video", duration = dur, formatSel = null, previewUrl = u, referer = null))
            }
        }
        val tv = o.optJSONObject("video")?.optJSONArray("variants")
        if (out.isEmpty() && tv != null) for (k in 0 until tv.length()) {
            val v = tv.optJSONObject(k) ?: continue
            val u = v.optString("src", "")
            if (u.startsWith("http") && v.optString("type", "") == "video/mp4")
                out.add(Candidate(key = "X$id|v$k", url = u, title = title, kind = Kind.DIRECT, isAudio = false, ext = "mp4",
                    size = -1, quality = "video", duration = 0, formatSel = null, previewUrl = u, referer = null))
        }
        if (out.isEmpty()) return "post tanpa video"
        xFixAudio(out, id, title, o)
        Repo.addCandidates(out)
        return null
    }
}
