package com.alfy.downloader

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.JavascriptInterface
import android.webkit.WebView
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * v1.58: YouTube auto-scan thumbnail di WebView browser.
 * JS (MutationObserver + IntersectionObserver + debounce scroll) hanya melaporkan thumbnail Shorts/video yang
 * SEDANG TERLIHAT di viewport; ID dikirim lewat JavascriptInterface "AlfyYT", lalu masuk antrian ringan
 * (1 video / 4 dtk, maks 20 per 10 menit) dan dipindai lewat Resolver.submit -> muncul di daftar deteksi.
 */
object YtThumbScan {
    private val idRe = Regex("^[A-Za-z0-9_-]{11}$")
    private val queue = ConcurrentLinkedQueue<String>()
    private val done = ConcurrentHashMap.newKeySet<String>()
    private val h = Handler(Looper.getMainLooper())
    @Volatile private var pumping = false
    private var winAt = 0L
    private var winCount = 0

    private val JS = """(function(){
if(window.__alfyYT)return;window.__alfyYT=1;var dead=false;window.__alfyYTStop=function(){dead=true;try{io.disconnect();}catch(x){}try{mo.disconnect();}catch(x){}if(tFlush)clearTimeout(tFlush);if(tMut)clearTimeout(tMut);pend=[];added=[];window.__alfyYT=0;};
var SEL='a[href*="/watch?v="],a[href*="/shorts/"]';
var RE=/(?:[?&]v=|\/shorts\/)([a-zA-Z0-9_-]{11})(?![a-zA-Z0-9_-])/;
var seen={},pend=[],added=[],tFlush=null,tMut=null,tScr=null,watched=0;
function idOf(a){var m=RE.exec(a.getAttribute('href')||'');return m?m[1]:null;}
var io=new IntersectionObserver(function(es){
  if(dead)return;
  for(var i=0;i<es.length;i++){if(!es[i].isIntersecting)continue;var e=es[i].target;try{io.unobserve(e);}catch(x){}if(watched>0)watched--;
    var id=idOf(e);if(id&&!seen[id]){seen[id]=1;pend.push(id);}}
  if(pend.length)sched();
},{threshold:0,rootMargin:'60% 0px 60% 0px'});
function watch(e){if(watched>600)return;var id=idOf(e);if(!id||seen[id])return;if(e.__ay===id)return;e.__ay=id;watched++;io.observe(e);}
function sched(){if(dead||tFlush)return;tFlush=setTimeout(flush,100);}
function flush(){
  tFlush=null;
  if(dead||document.hidden)return;
  var out=pend.splice(0,12);
  if(out.length){try{AlfyYT.ids(out.join(','));}catch(x){}}
  if(pend.length)sched();
}
var curV=null;
function mainId(){var m=RE.exec(location.pathname+location.search);if(!m)return;if(m[1]===curV)return;curV=m[1];if(seen[m[1]])return;seen[m[1]]=1;try{AlfyYT.ids(m[1]);}catch(x){}}
function scanAll(){var q=document.querySelectorAll(SEL);for(var i=0;i<q.length&&i<300;i++)watch(q[i]);}
function drain(){
  tMut=null;if(dead)return;var n=added;added=[];
  for(var i=0;i<n.length&&i<300;i++){var x=n[i];
    if(x.nodeType!==1)continue;
    try{if(x.matches&&x.matches(SEL))watch(x);
    var q=x.querySelectorAll?x.querySelectorAll(SEL):[];
    for(var j=0;j<q.length&&j<80;j++)watch(q[j]);}catch(e){}}
}
var mo=new MutationObserver(function(ms){
  for(var i=0;i<ms.length;i++){
    if(ms[i].type==='attributes'){if(added.length<400)added.push(ms[i].target);continue;}
    var a=ms[i].addedNodes;for(var j=0;j<a.length;j++){if(added.length<400)added.push(a[j]);}}
  if(!tMut)tMut=setTimeout(drain,80);
});
function start(){
  var r=document.body||document.documentElement;
  mo.observe(r,{childList:true,subtree:true,attributes:true,attributeFilter:['href']});
  scanAll();
}
window.addEventListener('scroll',function(){if(dead||tScr)return;tScr=setTimeout(function(){tScr=null;scanAll();},250);},{passive:true});
document.addEventListener('visibilitychange',function(){if(!document.hidden)sched();});
window.addEventListener('yt-navigate-finish',function(){curV=null;setTimeout(function(){mainId();scanAll();sched();},600);});
window.addEventListener('popstate',function(){curV=null;sched();});
start();mainId();
})();"""

    private fun host(u: String?): String = (try { Uri.parse(u ?: "").host } catch (e: Exception) { null } ?: "").lowercase()

    fun isYt(u: String?): Boolean { val x = host(u); return x == "youtube.com" || x.endsWith(".youtube.com") }

    fun enabled(url: String?): Boolean =
        Scan.enabled() && Repo.prefs().getBoolean("autoThumb", true) && isYt(url) && SiteSettings.scan(url)

    /** Pasang pengamat DOM (aman dipanggil berulang: skrip menjaga dirinya sendiri). */
    fun inject(wv: WebView, url: String?) {
        if (!enabled(url)) return
        try { wv.evaluateJavascript(JS, null) } catch (e: Throwable) { }
    }

    /** Scan otomatis OFF: kosongkan antrean, hentikan pump, matikan JS observer di semua tab WebView. */
    fun stop() {
        queue.clear(); done.clear(); pumping = false
        h.removeCallbacksAndMessages(null)
        val js = "try{window.__alfyYTStop&&window.__alfyYTStop();}catch(e){}"
        h.post { try { for (t in BrowserTabs.tabs.toList()) { try { t.wv.evaluateJavascript(js, null) } catch (e: Throwable) { } } } catch (e: Throwable) { } }
    }

    /** Scan otomatis ON lagi: pasang ulang observer di tab aktif. */
    fun resume() { h.post { try { BrowserTabs.current()?.let { inject(it.wv, it.url); XHomeScan.inject(it.wv, it.url) } } catch (e: Throwable) { } } }

    class Bridge(private val t: BrowserTab) {
        @JavascriptInterface fun ids(s: String?) {
            if (s == null || s.length > 200) return
            if (BrowserTabs.current() !== t || !enabled(t.url)) return   // hanya tab yang sedang dilihat, di YouTube
            for (id in s.split(',').take(16)) {
                if (!idRe.matches(id) || !done.add(id)) continue
                if (queue.size >= 200) queue.poll()
                queue.add(id)
            }
            h.post { pump() }
        }
    }

    private fun pump() {
        if (pumping) return
        pumping = true
        h.postDelayed({ tick() }, 50)
    }

    // Antrean diproses berurutan, 1 per siklus, jeda 500ms antar pengambilan.
    private fun tick() {
        if (!Scan.enabled()) { queue.clear(); pumping = false; return }
        val now = SystemClock.elapsedRealtime()
        if (now - winAt > 600_000L) { winAt = now; winCount = 0 }
        if (queue.isEmpty()) { pumping = false; return }
        if (winCount < 150 && Chain.runningCount() < 2) {
            val id = queue.poll()
            if (id != null && Scan.enabled()) {
                winCount++
                Thread {
                    try {
                        ToolLog.tl.set("Browser Alfy (auto-scan)")
                        val r = if (Tool.on("NewPipe")) NP.fetch(id) else "NewPipe mati"
                        // gagal -> jalur penuh (yt-dlp dll) sebagai cadangan
                        if (r != null) Resolver.submit("https://www.youtube.com/watch?v=$id", null, true, "Browser Alfy (auto-scan)")
                    } catch (e: Throwable) {
                        Resolver.submit("https://www.youtube.com/watch?v=$id", null, true, "Browser Alfy (auto-scan)")
                    } finally { ToolLog.tl.remove() }
                    h.post { h.postDelayed({ tick() }, 500) }
                }.start()
                return
            }
        }
        h.postDelayed({ tick() }, 500)
    }
}
