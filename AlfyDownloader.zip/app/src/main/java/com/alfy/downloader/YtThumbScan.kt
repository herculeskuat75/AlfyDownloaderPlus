package com.alfy.downloader

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.JavascriptInterface
import android.webkit.WebView
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * v1.58: YouTube auto-scan thumbnail di WebView browser.
 * JS (MutationObserver + IntersectionObserver + debounce scroll) hanya melaporkan thumbnail Shorts/video yang
 * SEDANG TERLIHAT di viewport; ID dikirim lewat JavascriptInterface "AlfyYT", lalu masuk antrian ringan
 * (1 video / 4 dtk, maks 20 per 10 menit) dan dipindai lewat Resolver.submit -> muncul di daftar deteksi.
 */
object YtThumbScan {
    private val idRe = Regex("^[A-Za-z0-9_-]{11}$")
    private val queue = ConcurrentLinkedQueue<String>()
    private val done = ConcurrentHashMap.newKeySet<String>()
    private val h = Handler(Looper.getMainLooper())
    @Volatile private var pumping = false
    private var winAt = 0L
    private var winCount = 0

    private val JS = """(function(){
if(window.__alfyYT)return;window.__alfyYT=1;
var SEL='a[href*="/watch?v="],a[href*="/shorts/"],a[href*="youtu.be/"],img[src*="ytimg.com/vi"]';
var RE=/(?:[?&]v=|\/shorts\/|\/vi\/|\/vi_webp\/|youtu\.be\/)([A-Za-z0-9_-]{11})(?![A-Za-z0-9_-])/;
var seen={},vs=[],added=[],tFlush=null,tMut=null,lastScroll=0,watched=0;
function idOf(e){var s=e.getAttribute('href')||e.getAttribute('src')||e.getAttribute('data-src')||'';var m=RE.exec(s);return m?m[1]:null;}
var io=new IntersectionObserver(function(es){
  for(var i=0;i<es.length;i++){var e=es[i].target;
    if(es[i].isIntersecting){if(vs.indexOf(e)<0)vs.push(e);}
    else{var k=vs.indexOf(e);if(k>=0)vs.splice(k,1);}}
  sched();
},{threshold:0.5});
function watch(e){if(watched>400)return;var id=idOf(e);if(!id||seen[id]||e.__ay)return;e.__ay=1;watched++;io.observe(e);}
function sched(){if(tFlush)clearTimeout(tFlush);tFlush=setTimeout(flush,600);}
function flush(){
  tFlush=null;
  if(document.hidden)return;
  if(Date.now()-lastScroll<500){sched();return;}
  var out=[],keep=[];
  for(var i=0;i<vs.length;i++){var e=vs[i];var id=idOf(e);
    if(id&&!seen[id]&&out.length<12){seen[id]=1;out.push(id);try{io.unobserve(e);}catch(x){}watched--;}
    else if(id&&!seen[id])keep.push(e);}
  vs=keep;
  if(out.length){try{AlfyYT.ids(out.join(','));}catch(x){}}
  if(keep.length)sched();
}
function drain(){
  tMut=null;var n=added;added=[];
  for(var i=0;i<n.length&&i<150;i++){var x=n[i];
    if(x.nodeType!==1)continue;
    try{if(x.matches&&x.matches(SEL))watch(x);
    var q=x.querySelectorAll?x.querySelectorAll(SEL):[];
    for(var j=0;j<q.length&&j<60;j++)watch(q[j]);}catch(e){}}
}
var mo=new MutationObserver(function(ms){
  for(var i=0;i<ms.length;i++){var a=ms[i].addedNodes;for(var j=0;j<a.length;j++){if(added.length<300)added.push(a[j]);}}
  if(!tMut)tMut=setTimeout(drain,300);
});
function start(){
  var r=document.body||document.documentElement;
  mo.observe(r,{childList:true,subtree:true});
  var q=document.querySelectorAll(SEL);for(var i=0;i<q.length&&i<80;i++)watch(q[i]);
}
window.addEventListener('scroll',function(){lastScroll=Date.now();sched();},{passive:true});
document.addEventListener('visibilitychange',function(){if(!document.hidden)sched();});
start();
})();"""

    private fun host(u: String?): String = (try { Uri.parse(u ?: "").host } catch (e: Exception) { null } ?: "").lowercase()

    fun isYt(u: String?): Boolean { val x = host(u); return x == "youtube.com" || x.endsWith(".youtube.com") }

    fun enabled(url: String?): Boolean =
        Scan.enabled() && Repo.prefs().getBoolean("autoThumb", true) && isYt(url) && SiteSettings.scan(url)

    /** Pasang pengamat DOM (aman dipanggil berulang: skrip menjaga dirinya sendiri). */
    fun inject(wv: WebView, url: String?) {
        if (!enabled(url)) return
        try { wv.evaluateJavascript(JS, null) } catch (e: Throwable) { }
    }

    class Bridge(private val t: BrowserTab) {
        @JavascriptInterface fun ids(s: String?) {
            if (s == null || s.length > 200) return
            if (BrowserTabs.current() !== t || !enabled(t.url)) return   // hanya tab yang sedang dilihat, di YouTube
            for (id in s.split(',').take(12)) {
                if (!idRe.matches(id) || !done.add(id)) continue
                if (queue.size < 40) queue.add(id)
            }
            h.post { pump() }
        }
    }

    private fun pump() {
        if (pumping) return
        pumping = true
        h.postDelayed({ tick() }, 500)
    }

    private fun tick() {
        val now = SystemClock.elapsedRealtime()
        if (now - winAt > 600_000L) { winAt = now; winCount = 0 }
        if (queue.isEmpty()) { pumping = false; return }
        if (winCount < 20 && Chain.runningCount() < 2) {
            val id = queue.poll()
            if (id != null) {
                winCount++
                Resolver.submit("https://www.youtube.com/watch?v=$id", null, true, "Browser Alfy (auto-scan)")
            }
        }
        h.postDelayed({ tick() }, 4000)
    }
}
