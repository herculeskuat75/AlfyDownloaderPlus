package com.alfy.downloader

import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.TextUtils
import android.view.Gravity
import android.graphics.Rect
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewConfiguration
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

class FloatingService : Service() {
    companion object { @Volatile var running = false; @Volatile var inst: FloatingService? = null }

    private lateinit var wm: WindowManager
    private var bubble: FrameLayout? = null
    private var badge: TextView? = null
    private var circleView: TextView? = null
    private var ringView: RingView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private val prefL = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, k ->
        if (k == "bubbleIdx" || k == "arrowIdx" || k?.startsWith("ic_") == true || k == "ringOn" || k == "ringSpeed" || k == "bubbleScale" || k == "flameOn" || k == "flameColor" || k == "flameRainbow" || k == "flameSize" || k == "flameSwirl" || k == "sparkOn" || k == "sparkAmount" || k == "sparkFollow") applyStyle()
        if (k == "showPanelLog") ui.post { applyLogVis() }
        if (k == "isLightAnimation") { lightAnim = AppPreferences.isLightAnimation; applyStyle() }
    }
    private var panel: FrameLayout? = null
    private var lightAnim = true
    private var logJob: kotlinx.coroutines.Job? = null
    private var pw = 0; private var ph = 0; private var px = -1; private var py = -1
    private var panelLp: WindowManager.LayoutParams? = null
    private var dsx = 0; private var dsy = 0; private var dtx = 0f; private var dty = 0f
    private var list: LinearLayout? = null
    private var listSc: ScrollView? = null
    private var savedScrollY = 0
    private var title: TextView? = null
    private var logL: TextView? = null
    private var logScV: View? = null
    private fun applyLogVis() {
        val v = logScV ?: return
        val on = Repo.prefs().getBoolean("showPanelLog", true)
        v.visibility = if (on) View.VISIBLE else View.GONE
        (v.layoutParams as? LinearLayout.LayoutParams)?.let { it.weight = if (on) 1.1f else 0f; it.height = if (on) 0 else 0; v.layoutParams = it }
    }
    private var logR: TextView? = null
    private var logF: TextView? = null
    private val scope = MainScope()
    private val expanded = HashSet<String>()
    private val cm by lazy { getSystemService(CLIPBOARD_SERVICE) as ClipboardManager }
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { readClip() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val type get() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        inst = this
        lightAnim = AppPreferences.isLightAnimation
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(1, makeNotif(this, "Menu mengambang aktif • ${Repo.detected.value.size} file tersedia", icon = android.R.drawable.stat_sys_download_done))
        addBubble()
        NetSniffer.start()
        scope.launch {
            Repo.detected.collect { l ->
                val b = badge
                if (b != null) { b.text = l.size.toString(); b.visibility = if (l.isEmpty()) View.GONE else View.VISIBLE }
                if (panel != null) render()
                postNotif(this@FloatingService, 1, makeNotif(this@FloatingService, "${l.size} file tersedia diunduh", icon = android.R.drawable.stat_sys_download_done))
            }
        }
        try { cm.addPrimaryClipChangedListener(clipListener) } catch (e: Exception) { }
        Repo.prefs().registerOnSharedPreferenceChangeListener(prefL)
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int = START_STICKY

    private val ui = android.os.Handler(android.os.Looper.getMainLooper())

    private fun feedClip(t: String): Int {
        val urls = Regex("https?://[^\\s]+").findAll(t).map { it.value }.toList()
        urls.forEach { Resolver.rescan(it, null, "Clipboard") }
        return urls.size
    }

    private fun readClip() { pullClip() }

    /** Baca clipboard terbaru. Android 10+ hanya mengizinkan jendela berfokus: coba jendela 1px, lalu cadangan activity transparan (+root). */
    fun pullClip() {
        if (AlfyAccessibilityService.inst?.readClipDirect() == true) return
        val t = try { cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() } catch (e: Exception) { null }
        if (!t.isNullOrBlank()) { if (feedClip(t) > 0) Resolver.diag = "Clipboard: memindai tautan…"; return }
        if (NetSniffer.clipRoot) { NetSniffer.readClipRootOnce(); return }
        // jangan mencuri fokus saat keyboard tampil (sedang mengetik)
        if (AlfyAccessibilityService.inst?.keyboardShown() == true) return
        var ok = false
        try {
            var removed = false
            lateinit var v: View
            v = object : View(this) {
                override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
                    super.onWindowFocusChanged(hasWindowFocus)
                    if (!hasWindowFocus || removed) return
                    try {
                        val x = cm.primaryClip?.getItemAt(0)?.coerceToText(this@FloatingService)?.toString() ?: ""
                        if (x.isNotBlank()) ok = true
                        if (feedClip(x) > 0) Resolver.diag = "Clipboard: memindai tautan…"
                    } catch (e: Exception) { }
                    removed = true
                    ui.post { try { wm.removeView(v) } catch (e: Exception) { } }
                }
            }
            val lp = WindowManager.LayoutParams(1, 1, type,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
            wm.addView(v, lp)
            ui.postDelayed({
                if (!removed) { removed = true; try { wm.removeView(v) } catch (e: Exception) { } }
                if (!ok) launchClipActivity()
            }, 900)
        } catch (e: Exception) { launchClipActivity() }
    }

    private fun launchClipActivity() {
        if (AlfyAccessibilityService.inst?.keyboardShown() == true) return
        try { startActivity(Intent(this, ClipActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {
            Thread { try { Runtime.getRuntime().exec(arrayOf("su", "-c", "am start -n $packageName/.ClipActivity")).waitFor() } catch (x: Exception) { } }.start()
        }
    }

    private var dismissView: FrameLayout? = null
    private fun showDismiss() {
        if (dismissView != null) return
        val sz = dp(64)
        val fl = FrameLayout(this)
        val c = TextView(this).apply {
            text = "✕"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC000000.toInt()); setStroke(dp(2), Color.WHITE) }
        }
        fl.addView(c, FrameLayout.LayoutParams(sz, sz))
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(56) }
        try { wm.addView(fl, lp); dismissView = fl } catch (e: Exception) { }
    }
    private fun hideDismiss() { dismissView?.let { try { wm.removeView(it) } catch (e: Exception) { } }; dismissView = null }

    /** Apakah pusat tombol sedang berada di atas lingkaran X di bawah layar. */
    private fun overDismiss(bx: Int, by: Int): Boolean {
        val dm = resources.displayMetrics
        val half = dp(31)
        val cx = bx + half; val cy = by + half
        val tx = dm.widthPixels / 2; val ty = dm.heightPixels - dp(56) - dp(32)
        val dx = (cx - tx).toDouble(); val dy = (cy - ty).toDouble()
        if (by + 2 * half >= dm.heightPixels - 150) return true
        return Math.sqrt(dx * dx + dy * dy) < dp(80)
    }

    private fun addBubble() {
        val size = (dp(62) * Repo.prefs().getFloat("bubbleScale", 1f).coerceIn(0.5f, 3f)).toInt()
        val fl = FrameLayout(this)
        val circle = TextView(this).apply {
            text = "⬇"; textSize = 36f; setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                colors = intArrayOf(0xFFFF4081.toInt(), 0xFF7C4DFF.toInt(), 0xFF00E5FF.toInt())
                orientation = GradientDrawable.Orientation.TL_BR
                setStroke(dp(2), Color.WHITE)
            }
        }
        val pad = (size * 0.5f).toInt()
        fl.addView(circle, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
        circleView = circle
        val rg = RingView(this, size)
        fl.addView(rg, FrameLayout.LayoutParams(size + 2 * pad, size + 2 * pad, Gravity.CENTER))
        ringView = rg
        val bd = TextView(this).apply {
            textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.RED) }
            visibility = View.GONE
        }
        fl.addView(bd, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP or Gravity.END).apply { topMargin = pad; rightMargin = pad })
        badge = bd
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(220) }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        var longFired = false; var pinching = false; var afterPinch = false; var scaled = false
        var d0 = 1f; var s0 = 1f
        val hnd = android.os.Handler(android.os.Looper.getMainLooper())
        val longRun = Runnable {
            if (!moved && !pinching) {
                longFired = true
                try { fl.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS) } catch (e: Exception) { }
                showBubblePopup()
            }
        }
        fun pdist(e: MotionEvent): Float {
            val dx = e.getX(0) - e.getX(1); val dy = e.getY(0) - e.getY(1)
            return Math.max(1f, Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat())
        }
        fl.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY
                    moved = false; longFired = false; pinching = false; afterPinch = false; scaled = false
                    val ms = (Repo.prefs().getFloat("longPressSec", 1.5f).coerceIn(1f, 5f) * 1000f).toLong()
                    hnd.removeCallbacks(longRun); hnd.postDelayed(longRun, ms)
                    true
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    // Dua jari: renggangkan = membesar, cubit = mengecil (hanya bila opsinya aktif)
                    if (e.pointerCount == 2 && Repo.prefs().getBoolean("pinchOn", true)) {
                        hnd.removeCallbacks(longRun)
                        pinching = true; moved = true; scaled = true
                        d0 = pdist(e); s0 = Repo.prefs().getFloat("bubbleScale", 1f).coerceIn(0.5f, 3f)
                        fl.parent?.requestDisallowInterceptTouchEvent(true)
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (pinching) {
                        if (e.pointerCount >= 2) {
                            val ns = (s0 * pdist(e) / d0).coerceIn(0.5f, 3f)
                            if (abs(ns - Repo.prefs().getFloat("bubbleScale", 1f)) > 0.01f) Repo.prefs().edit().putFloat("bubbleScale", ns).apply()
                        }
                    } else if (!afterPinch) {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) { moved = true; hnd.removeCallbacks(longRun) }
                        if (moved) {
                            lp.x = sx + dx; lp.y = sy + dy; wm.updateViewLayout(fl, lp)
                            showDismiss()
                            val over = overDismiss(lp.x, lp.y)
                            dismissView?.let { it.scaleX = if (over) 1.3f else 1f; it.scaleY = if (over) 1.3f else 1f }
                            fl.alpha = if (over) 0.6f else 1f
                        }
                    }
                    true
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    if (pinching && e.pointerCount <= 2) { pinching = false; afterPinch = true }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    hnd.removeCallbacks(longRun)
                    val over = moved && !scaled && !afterPinch && overDismiss(lp.x, lp.y)
                    hideDismiss()
                    fl.alpha = 1f
                    pinching = false
                    if (over) {
                        confirmDismiss()
                    } else if (!moved && !longFired && !afterPinch && e.actionMasked == MotionEvent.ACTION_UP) togglePanel()
                    true
                }
                else -> false
            }
        }
        wm.addView(fl, lp)
        bubble = fl
        bubbleLp = lp
        applyStyle()
        val n = Repo.detected.value.size
        bd.text = n.toString(); bd.visibility = if (n == 0) View.GONE else View.VISIBLE
    }

    private fun applyStyle() {
        val c = circleView ?: return
        val p = Repo.prefs()
        ringView?.let { it.visibility = if (p.getBoolean("ringOn", true)) View.VISIBLE else View.GONE; it.speed = p.getFloat("ringSpeed", 0.5f) }
        val bi = p.getInt("bubbleIdx", 0).coerceIn(0, Palette.colors.size - 1)
        val ai = p.getInt("arrowIdx", 8).coerceIn(0, Palette.colors.size - 1)
        val sc = p.getFloat("bubbleScale", 1f).coerceIn(0.5f, 3f)
        val fsz = p.getFloat("flameSize", 1f).coerceIn(0f, 3f)
        val sparkOn = p.getBoolean("sparkOn", true); val sparkAmt = if (sparkOn) p.getFloat("sparkAmount", 1f).coerceIn(0f, if (lightAnim) 1f else 3f) else 0f
        val sz = (dp(62) * sc).toInt(); val pd = Math.min((sz * Math.max(0.5f + 0.5f * Math.max(0f, fsz - 1f), if (sparkAmt > 0.02f) 0.8f else 0f)).toInt(), resources.displayMetrics.widthPixels / 2)
        val size = sz.toFloat()
        c.layoutParams = (c.layoutParams as FrameLayout.LayoutParams).apply { width = sz; height = sz }
        ringView?.let { r ->
            r.inner = sz; r.flameSize = fsz; r.flameColor = p.getInt("flameColor", 0xFF1E88FF.toInt()); r.rainbow = p.getBoolean("flameRainbow", false); r.swirl = p.getBoolean("flameSwirl", false); r.flame = fsz > 0.05f; r.sparkOn = sparkOn; r.sparkAmount = sparkAmt; r.sparkFollow = p.getBoolean("sparkFollow", true)
            r.layoutParams = (r.layoutParams as FrameLayout.LayoutParams).apply { width = sz + 2 * pd; height = sz + 2 * pd }
        }
        badge?.let { b -> b.layoutParams = (b.layoutParams as FrameLayout.LayoutParams).apply { topMargin = pd; rightMargin = pd } }
        c.textSize = 36f * sc
        bubble?.let { b -> bubbleLp?.let { try { wm.updateViewLayout(b, it) } catch (e: Exception) { } } }
        val img = p.getString("ic_bubbleImg", null)?.let { java.io.File(it) }?.takeIf { it.exists() }
        c.text = if (img != null) "" else Icons.get("bubble")
        if (img != null) {
            try {
                val bmp = android.graphics.BitmapFactory.decodeFile(img.path)
                val rd = androidx.core.graphics.drawable.RoundedBitmapDrawableFactory.create(resources, bmp)
                rd.isCircular = true
                c.background = rd; c.invalidate(); return
            } catch (e: Throwable) { }
        }
        c.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            if (bi == 0) { gradientType = GradientDrawable.SWEEP_GRADIENT; colors = Palette.rainbow }
            else setColor(Palette.colors[bi])
            setStroke(dp(2), Color.WHITE)
        }
        if (ai == 0) {
            c.paint.shader = android.graphics.LinearGradient(0f, 0f, size, size, Palette.rainbow, null, android.graphics.Shader.TileMode.CLAMP)
        } else {
            c.paint.shader = null
            c.setTextColor(Palette.colors[ai])
        }
        c.invalidate()
    }

    private fun closePanel() { try { listSc?.let { if (panel != null) savedScrollY = it.scrollY } } catch (e: Exception) { }; logJob?.cancel(); logJob = null; hideOptions(); panel?.let { try { wm.removeView(it) } catch (e: Exception) { } }; panel = null }

    // ---------- v1.11: tombol ⚙ = pengaturan scan (kotak centang) ----------
    private var optView: View? = null
    private fun hideOptions() { AppPreferences.onProfilesChanged = null; optView?.let { try { wm.removeView(it) } catch (e: Exception) { } }; optView = null; optStatus.clear(); optHint.clear(); optMode = null }

    // v1.12: ⚙ = pilihan scan otomatis/agresif + 27 tool (centang = aktif) dengan log status tiap tool di bawah namanya
    private val optStatus = LinkedHashMap<String, TextView>()
    private val optHint = LinkedHashMap<String, TextView>()
    private var optMode: TextView? = null
    private val optSpin = LinkedHashMap<String, android.widget.ProgressBar>()

    private fun refreshOptions() {
        optMode?.text = "Mode scan: ${Scan.modeText()}"
        for ((n, tv) in optStatus) {
            val s = ToolStatus.state(n)
            tv.text = ToolStatus.label(n)
            tv.setTextColor(ToolStatus.color(s))
            optSpin[n]?.visibility = if (s == ToolStatus.St.SCAN) View.VISIBLE else View.GONE
        }
        for ((n, hv) in optHint) {
            val h = if (ToolStatus.state(n) == ToolStatus.St.FAIL) ScanReport.hintFor(n) else null
            if (h == null) hv.visibility = View.GONE else { hv.text = h.text(); hv.visibility = View.VISIBLE }
        }
    }

    private fun showOptions() {
        if (optView != null) { hideOptions(); return }
        val p = Repo.prefs()
        optStatus.clear(); optSpin.clear(); optHint.clear()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(10))
            background = GradientDrawable().apply { setColor(0xF2202020.toInt()); cornerRadius = dp(14).toFloat(); setStroke(dp(1), 0x99FFFFFF.toInt()) }
        }
        box.addView(txt("⚙ Pengaturan scan & tools", 15f).apply { setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, 0, 0, dp(2)) })
        val modeTv = txt("", 12f, 0xFF80CBC4.toInt()).apply { setPadding(0, 0, 0, dp(4)) }
        optMode = modeTv
        box.addView(modeTv)
        val sc = ScrollView(this)
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sc.addView(inner)
        lateinit var cbAggr: android.widget.CheckBox
        val toolBoxes = ArrayList<android.widget.CheckBox>()
        fun cb(label: String, hint: String?, key: String, def: Boolean, after: (Boolean) -> Unit): android.widget.CheckBox {
            val c = android.widget.CheckBox(this).apply {
                text = label; textSize = 13f; setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
                isChecked = p.getBoolean(key, def)
                setOnCheckedChangeListener { _, v -> p.edit().putBoolean(key, v).apply(); after(v); updateLog(); refreshOptions() }
            }
            inner.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            if (hint != null) inner.addView(txt(hint, 11f, 0xFFBDBDBD.toInt()).apply { setPadding(dp(32), 0, 0, dp(6)) })
            return c
        }
        cb("Tampilkan Log di Panel Melayang", "OFF = area log disembunyikan, daftar download memenuhi panel.", "showPanelLog", true) { applyLogVis() }
        val cbScan = cb("Scan otomatis (aktif) / tidak (☐)", "Dimatikan = semua scan otomatis berhenti (tombol 🔍 / 📋 / Bagikan tetap jalan).", "scanAll", true) { v ->
            Tool.syncAll()
            if (!v) { try { Chain.cancelAll() } catch (e: Throwable) { } } else { try { YtThumbScan.resume() } catch (e: Throwable) { } }
            if (!v) android.widget.Toast.makeText(this, "Scan otomatis semua tools DIMATIKAN", android.widget.Toast.LENGTH_SHORT).show()
        }
        cbAggr = cb("Scan agresif (☑) / normal (☐)", "Agresif = semua metode tiap tool dipakai; lebih berat & lebih lama. Normal = bawaan.", "scanAggr", false) { v ->
            if (v && !cbScan.isChecked) cbScan.isChecked = true
            android.widget.Toast.makeText(this, if (v) "Mode AGRESIF aktif" else "Mode normal", android.widget.Toast.LENGTH_SHORT).show()
        }
        cbAggr.isEnabled = true
        var bulk = false
        val master = android.widget.CheckBox(this).apply {
            text = "Aktifkan semua tools"; textSize = 14f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
            buttonTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            isChecked = Tool.allOn()
        }
        fun syncMaster() { val a = Tool.allOn(); if (master.isChecked != a) { bulk = true; master.isChecked = a; bulk = false } }
        master.setOnCheckedChangeListener { _, v ->
            if (bulk) return@setOnCheckedChangeListener
            bulk = true
            Tool.setAll(v)
            for (b in toolBoxes) b.isChecked = v
            if (v && !cbScan.isChecked) cbScan.isChecked = true
            bulk = false
            android.widget.Toast.makeText(this, if (v) "Semua tools AKTIF" else "Semua tools DIMATIKAN", android.widget.Toast.LENGTH_SHORT).show()
            updateLog(); refreshOptions()
        }
        inner.addView(master, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        // ---- Profil Tools: pilih profil aktif + tombol Kelola Profil ----
        val profList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val profHint = txt("Profil khusus aktif: centang manual diabaikan, hanya tool profil ini yang jalan.", 11f, 0xFFFFCC80.toInt()).apply { setPadding(dp(10), 0, 0, dp(4)) }
        lateinit var profTv: TextView
        fun profSync() {
            profTv.text = "Profil aktif: ${AppPreferences.activeProfile} ▾"
            profHint.visibility = if (AppPreferences.activeProfile == AppPreferences.DEFAULT_PROFILE) View.GONE else View.VISIBLE
        }
        fun profBuild() {
            profList.removeAllViews()
            val act = AppPreferences.activeProfile
            for (nm in AppPreferences.profileNames()) {
                profList.addView(txt((if (nm == act) "● " else "○ ") + nm, 13f) {
                    AppPreferences.activeProfile = nm
                    Tool.syncAll(); Chain.resetQueue()
                    profList.visibility = View.GONE
                    profSync(); profBuild(); updateLog(); refreshOptions()
                    android.widget.Toast.makeText(this, "Profil: $nm", android.widget.Toast.LENGTH_SHORT).show()
                }.apply { setPadding(dp(24), dp(6), dp(10), dp(6)) })
            }
        }
        profTv = txt("", 13f, 0xFF80CBC4.toInt()) {
            profBuild(); profSync()
            profList.visibility = if (profList.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }.apply { setTypeface(null, android.graphics.Typeface.BOLD) }
        val profRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        profRow.addView(profTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        profRow.addView(txt("⚙ Kelola Profil", 13f, 0xFF80CBC4.toInt()) {
            hideOptions()
            try { startActivity(Intent(this, ProfileActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
        }.apply { setTypeface(null, android.graphics.Typeface.BOLD) })
        profSync(); profBuild()
        AppPreferences.onProfilesChanged = { profBuild(); profSync() }
        inner.addView(profRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        inner.addView(profList, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        inner.addView(profHint, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        inner.addView(txt("TOOLS (centang = aktif)", 12f, 0xFF80CBC4.toInt()).apply { setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(8), 0, dp(2)) })
        Tool.all.forEachIndexed { i, n ->
            val c = android.widget.CheckBox(this).apply {
                text = "${i + 1}. $n"; textSize = 13f; setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
                isChecked = Tool.manualOn(n)
                setOnCheckedChangeListener { _, v -> if (bulk) return@setOnCheckedChangeListener; Tool.set(n, v); syncMaster(); updateLog(); refreshOptions() }
            }
            toolBoxes.add(c)
            inner.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val st = txt("", 12f, 0xFF9E9E9E.toInt()).apply { setTypeface(null, android.graphics.Typeface.BOLD) }
            val pb = android.widget.ProgressBar(this).apply { isIndeterminate = true; visibility = View.GONE }
            val stRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(32), 0, 0, dp(6)) }
            stRow.addView(pb, LinearLayout.LayoutParams(dp(16), dp(16)).apply { rightMargin = dp(6) })
            stRow.addView(st, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            stRow.addView(txt("📋 Salin laporan untuk AI", 12f, 0xFF80CBC4.toInt()) { ToolStatus.copyDetail(this, n) }.apply { setTypeface(null, android.graphics.Typeface.BOLD) })
            optStatus[n] = st; optSpin[n] = pb
            inner.addView(stRow)
            val hv = txt("", 11f, 0xFFFFCC80.toInt()).apply { setPadding(dp(32), 0, 0, dp(6)); visibility = View.GONE }
            optHint[n] = hv
            inner.addView(hv)
        }
        refreshOptions()
        box.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        box.addView(txt("TUTUP", 13f, 0xFF80CBC4.toInt()) { hideOptions() }.apply { gravity = Gravity.END; setTypeface(null, android.graphics.Typeface.BOLD) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams((dm.widthPixels * 0.9).toInt(), (dm.heightPixels * 0.8).toInt(), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        try { wm.addView(box, lp); optView = box } catch (e: Exception) { }
    }

    // ---------- tekan lama tombol: popup pengaturan ukuran (cubit 2 jari) ----------
    private var popView: View? = null
    private fun hideBubblePopup() { popView?.let { try { wm.removeView(it) } catch (e: Exception) { } }; popView = null }
    private fun showBubblePopup() {
        if (popView != null) { hideBubblePopup(); return }
        val p = Repo.prefs()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(10))
            background = GradientDrawable().apply { setColor(0xF2202020.toInt()); cornerRadius = dp(16).toFloat(); setStroke(dp(1), 0x99FFFFFF.toInt()) }
        }
        box.addView(txt("↔ Ukuran tombol mengambang", 15f).apply { setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, 0, 0, dp(6)) })
        val cbx = android.widget.CheckBox(this).apply {
            text = "Ubah ukuran dengan 2 jari"; textSize = 14f; setTextColor(Color.WHITE)
            buttonTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            isChecked = p.getBoolean("pinchOn", true)
            setOnCheckedChangeListener { _, v ->
                p.edit().putBoolean("pinchOn", v).apply()
                android.widget.Toast.makeText(this@FloatingService, if (v) "Aktif: cubit/renggangkan 2 jari di tombol" else "Ubah ukuran 2 jari dimatikan", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        box.addView(cbx, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(txt("• Tarik dua arah (renggangkan 2 jari) = membesar\n• Dorong dua arah (cubit 2 jari) = mengecil\nLama tekan popup ini diatur di Pengaturan (1–5 detik).", 12f, 0xFFBDBDBD.toInt()).apply { setPadding(dp(4), dp(4), 0, dp(8)) })
        box.addView(txt("TUTUP", 14f, 0xFF80CBC4.toInt()) { hideBubblePopup() }.apply { gravity = Gravity.END; setTypeface(null, android.graphics.Typeface.BOLD) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams((dm.widthPixels * 0.85).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        try { wm.addView(box, lp); popView = box } catch (e: Exception) { }
    }
    private var confirmDlg: android.app.AlertDialog? = null
    private fun confirmDismiss() {
        if (confirmDlg?.isShowing == true) return
        val busy = try { Chain.busy() } catch (e: Throwable) { false }
        val msg = if (busy) "⚠ Proses unduhan sedang berjalan. \"Hentikan Aplikasi\" akan membatalkannya.\n\nSembunyikan panel saja agar proses tetap berjalan di latar belakang?"
                  else "Pilih tindakan untuk menu mengambang."
        try {
            val d = android.app.AlertDialog.Builder(android.view.ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_Alert))
                .setTitle("Tutup menu mengambang?")
                .setMessage(msg)
                .setPositiveButton("Sembunyikan Panel") { _, _ ->
                    closePanel(); hideBubblePopup()
                    bubble?.let { try { wm.removeView(it) } catch (e: Exception) { } }
                    bubble = null; bubbleLp = null
                    android.widget.Toast.makeText(this, "Panel disembunyikan. Layanan tetap berjalan di latar belakang.", android.widget.Toast.LENGTH_LONG).show()
                }
                .setNegativeButton("Hentikan Aplikasi") { _, _ ->
                    try { Chain.cancelAll() } catch (e: Throwable) { }
                    try { logJob?.cancel(); logJob = null } catch (e: Exception) { }
                    scope.cancel()
                    stopSelf()
                }
                .setNeutralButton("Batal", null)
                .create()
            d.window?.setType(type)
            confirmDlg = d
            d.show()
        } catch (e: Exception) { }
    }

    private fun togglePanel() { if (panel != null) closePanel() else buildPanel() }

    private fun txt(t: String, sp: Float, color: Int = Color.WHITE, onClick: (() -> Unit)? = null) =
        TextView(this).apply {
            text = t; textSize = sp; setTextColor(color)
            if (onClick != null) { setPadding(dp(10), dp(6), dp(10), dp(6)); setOnClickListener { onClick() } }
        }

    private fun colorize(lines: List<String>): android.text.SpannableStringBuilder {
        val sb = android.text.SpannableStringBuilder()
        for (line in lines) {
            val st = sb.length
            sb.append(line).append('\n')
            val col = when {
                line.contains("✗") -> 0xFFEF9A9A.toInt()
                line.contains("✓") -> 0xFFA5D6A7.toInt()
                line.contains("Sedang scan") -> 0xFFFFE082.toInt()
                line.contains("⏳") -> 0xFFFFE082.toInt()
                line.contains("– ") -> 0xFF9E9E9E.toInt()
                else -> 0xFFEEEEEE.toInt()
            }
            sb.setSpan(android.text.style.ForegroundColorSpan(col), st, sb.length, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (sb.isNotEmpty()) sb.delete(sb.length - 1, sb.length)
        return sb
    }

    /** v1.8: SEMUA alat (pemindai + pemantau root, termasuk tcpdump) dalam 2 kolom: separuh pertama di kiri, sisanya di kanan; huruf 13sp. */
    private fun updateLog() {
        val t = title ?: return
        t.text = "Tautan terdeteksi (${Repo.detected.value.size})"
        val all = ToolStatus.panelLines()
        val half = (all.size + 1) / 2
        logL?.text = colorize(all.take(half))
        logR?.text = colorize(all.drop(half))
        val f = ArrayList<String>()
        f.add("Scan otomatis: ${Scan.modeText()} • semua alat memindai (⚙ untuk ubah)")
        f.add(RootGate.status)
        f.add(NetSniffer.status)
        f.add(VpnTool.status)
        if (NetSniffer.lastHit.isNotEmpty()) f.add("Link terakhir (logcat): " + NetSniffer.lastHit)
        if (Resolver.diag.isNotBlank()) f.add(Resolver.diag)
        if (ToolLog.winner.isNotEmpty()) f.add("→ link dari ${ToolLog.winner}")
        val collab = ToolStatus.collabLines(6)
        if (collab.isNotEmpty()) { f.add("🤝 Kolaborasi tool:"); collab.forEach { f.add("  $it") } }
        if (!Engine.ready) f.add("Mesin unduh: " + (Engine.error ?: "memuat…"))
        if (optView != null) refreshOptions()
        logF?.text = f.map { it.replace("\n", " ").trim().let { x -> if (x.length > 120) x.take(119) + "…" else x } }.joinToString("\n")
    }

    /**
     * v1.9: panel bisa digeser dari mana saja (kecuali pinggir = ubah ukuran) dan dicubit/direnggangkan dua jari untuk mengecil/membesar.
     * Usapan biasa menggulir log/daftar; TAHAN 2 detik (getar) lalu geser untuk memindah panel. Header tetap bisa langsung digeser.
     */
    private inner class PanelFrame(c: Context) : FrameLayout(c) {
        var zones: List<View> = emptyList()
        private val slop = ViewConfiguration.get(c).scaledTouchSlop
        private var downX = 0f; private var downY = 0f; private var sx = 0; private var sy = 0
        private var instant = false; private var armed = false; private var dragging = false
        private var ignore = false; private var afterPinch = false
        private val armRun = Runnable { armed = true; try { performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS) } catch (e: Exception) { } }
        private val sg = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val lp = panelLp ?: return false
                val dm = resources.displayMetrics
                val f = d.scaleFactor
                val nw = (lp.width * f).toInt().coerceIn(dp(170), dm.widthPixels)
                val nh = (lp.height * f).toInt().coerceIn(dp(130), dm.heightPixels)
                lp.x += (lp.width - nw) / 2; lp.y += (lp.height - nh) / 2
                lp.width = nw; lp.height = nh
                px = lp.x; py = lp.y; pw = nw; ph = nh
                try { wm.updateViewLayout(this@PanelFrame, lp) } catch (e: Exception) { }
                return true
            }
        })

        private fun posIn(v: View): Rect {
            var l = 0; var t = 0; var p: View = v
            while (p !== this) {
                l += p.left; t += p.top
                val par = p.parent as? View ?: break
                p = par
            }
            return Rect(l, t, l + v.width, t + v.height)
        }

        private fun inHandle(x: Float, y: Float): Boolean {
            val e = dp(18); val c = dp(30); val w = width; val h = height
            if (x < e || x > w - e || y < e || y > h - e) return true
            return (x < c || x > w - c) && (y < c || y > h - c)
        }

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            if (!ignore || ev.actionMasked == MotionEvent.ACTION_DOWN) try { sg.onTouchEvent(ev) } catch (e: Exception) { }
            return super.dispatchTouchEvent(ev)
        }

        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    removeCallbacks(armRun)
                    downX = ev.rawX; downY = ev.rawY
                    val lp = panelLp; sx = lp?.x ?: 0; sy = lp?.y ?: 0
                    dragging = false; armed = false; afterPinch = false
                    ignore = inHandle(ev.x, ev.y)
                    instant = !ignore && zones.any { posIn(it).contains(ev.x.toInt(), ev.y.toInt()) }
                    if (!ignore && !instant) postDelayed(armRun, Repo.prefs().getInt("holdMs", 2000).coerceIn(300, 6000).toLong())
                    return false
                }
                MotionEvent.ACTION_POINTER_DOWN -> { if (!ignore) { removeCallbacks(armRun); afterPinch = true; return true } }
                MotionEvent.ACTION_MOVE -> {
                    if (ignore) return false
                    if (sg.isInProgress || afterPinch) return true
                    val dx = ev.rawX - downX; val dy = ev.rawY - downY
                    val far = dx * dx + dy * dy > slop * slop
                    if (!dragging && far) {
                        if (instant || armed) { dragging = true; return true }
                        removeCallbacks(armRun)
                    }
                    return dragging
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { removeCallbacks(armRun); dragging = false; afterPinch = false }
            }
            return false
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> return !ignore
                MotionEvent.ACTION_POINTER_DOWN -> { afterPinch = true; return true }
                MotionEvent.ACTION_MOVE -> {
                    if (afterPinch || sg.isInProgress) return true
                    if (!dragging) {
                        val dx = ev.rawX - downX; val dy = ev.rawY - downY
                        if (dx * dx + dy * dy > slop * slop && (instant || armed)) dragging = true else return true
                    }
                    val lp = panelLp ?: return true
                    val dm = resources.displayMetrics
                    lp.x = (sx + (ev.rawX - downX).toInt()).coerceIn(-lp.width + dp(60), dm.widthPixels - dp(60))
                    lp.y = (sy + (ev.rawY - downY).toInt()).coerceIn(-dp(10), dm.heightPixels - dp(40))
                    px = lp.x; py = lp.y
                    try { wm.updateViewLayout(this, lp) } catch (e: Exception) { }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { removeCallbacks(armRun); dragging = false; afterPinch = false; return true }
            }
            return true
        }
    }

    private fun buildPanel() {
        val dm = resources.displayMetrics
        val outer = PanelFrame(this).apply {
            background = GradientDrawable().apply { setColor(0xF2303030.toInt()); cornerRadius = dp(14).toFloat() }
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val t = txt("", 15f).apply { setTypeface(null, android.graphics.Typeface.BOLD) }
        title = t
        head.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val dragTouch = View.OnTouchListener { _, ev ->
            val pl = panelLp ?: return@OnTouchListener false
            val pv = panel ?: return@OnTouchListener false
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { dsx = pl.x; dsy = pl.y; dtx = ev.rawX; dty = ev.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    pl.x = dsx + (ev.rawX - dtx).toInt(); pl.y = dsy + (ev.rawY - dty).toInt(); px = pl.x; py = pl.y
                    try { wm.updateViewLayout(pv, pl) } catch (e: Exception) { }
                    true
                }
                else -> true
            }
        }
        t.setOnTouchListener(dragTouch)
        head.setOnTouchListener(dragTouch)
        head.addView(txt("⚙", 18f) { showOptions() })
        head.addView(txt("📖", 18f) {
            // v1.50: salin laporan untuk AI (instruksi + profil app + lingkungan + daftar semua tool + detail tool yang gagal)
            val ok = try { cm.setPrimaryClip(android.content.ClipData.newPlainText("log tools gagal", ScanReport.build())); true } catch (e: Throwable) { false }
            android.widget.Toast.makeText(this, if (ok) "Laporan tool gagal (untuk AI) disalin" else "Gagal menyalin log", android.widget.Toast.LENGTH_SHORT).show()
        })
        head.addView(txt("🔍", 18f) {
            val acc = AlfyAccessibilityService.inst
            if (acc != null) acc.scanNow(true)
            android.widget.Toast.makeText(this, if (acc == null) "Aktifkan aksesibilitas dulu (📖)" else "Memindai layar…", android.widget.Toast.LENGTH_SHORT).show()
        })
        head.addView(txt("📋", 18f) {
            startActivity(Intent(this, ClipActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        head.addView(txt("🗑", 18f) { Repo.detected.value = emptyList(); Resolver.reset() })
        head.addView(txt("✕", 18f) { closePanel() })
        root.addView(head)
        val actRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        actRow.addView(txt("⚡ SCAN MAKSIMAL + LAPORAN", 13f, 0xFF80CBC4.toInt()) {
            startActivity(Intent(this, ReportActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.apply { setPadding(dp(10), dp(6), dp(10), dp(6)); setTypeface(null, android.graphics.Typeface.BOLD) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actRow.addView(txt("🔄 SCAN ULANG", 13f, 0xFFFFE082.toInt()) { ToolStatus.rescanOnce(this) }.apply {
            setPadding(dp(14), dp(9), dp(14), dp(9)); gravity = Gravity.CENTER; setTypeface(null, android.graphics.Typeface.BOLD)
            background = GradientDrawable().apply { setColor(0x33FFE082); cornerRadius = dp(10).toFloat(); setStroke(dp(1), 0xFFFFE082.toInt()) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(4), 0, dp(4), 0) })
        root.addView(actRow)
        // v1.8: log SEMUA alat dalam 2 kolom (kiri 1..N/2, kanan sisanya) + status sistem di bawahnya; area ini bisa digulir
        val logBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply { setColor(0x40000000); cornerRadius = dp(8).toFloat() }
        }
        val cols = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tl = txt("", 13f, 0xFFEEEEEE.toInt()).apply { setLineSpacing(0f, 1.1f); setPadding(0, 0, dp(6), 0) }
        val tr = txt("", 13f, 0xFFEEEEEE.toInt()).apply { setLineSpacing(0f, 1.1f); setPadding(dp(6), 0, 0, 0) }
        val tf = txt("", 12f, 0xFFBDBDBD.toInt()).apply { setLineSpacing(0f, 1.08f); setPadding(0, dp(6), 0, 0) }
        logL = tl; logR = tr; logF = tf
        cols.addView(tl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        cols.addView(tr, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        logBox.addView(cols, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        logBox.addView(tf, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val logSc = ScrollView(this)
        logSc.addView(logBox)
        root.addView(logSc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.1f).apply { setMargins(dp(4), 0, dp(4), dp(3)) })
        logScV = logSc; applyLogVis()
        val sc = ScrollView(this)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sc.addView(l)
        list = l
        listSc = sc
        // v1.10: geser dari mana saja HANYA setelah ditahan 2 detik; usapan biasa = menggulir log/daftar
        root.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        if (pw <= 0) { pw = (dm.widthPixels * 0.94).toInt(); ph = (dm.heightPixels * 0.6).toInt() }
        if (px < 0) { px = (dm.widthPixels * 0.03).toInt(); py = (dm.heightPixels * 0.2).toInt() }
        val m = dp(14)
        outer.addView(root, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply { setMargins(m, m, m, m) })
        // gagang tarik di 4 sisi + 4 sudut: perkecil/perbesar ke kiri, kanan, atas, bawah
        val e = dp(18); val c = dp(30)
        outer.addView(handle(true, false, false, false, 1), FrameLayout.LayoutParams(e, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START).apply { topMargin = c; bottomMargin = c })
        outer.addView(handle(false, true, false, false, 1), FrameLayout.LayoutParams(e, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END).apply { topMargin = c; bottomMargin = c })
        outer.addView(handle(false, false, true, false, 2), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, e, Gravity.TOP).apply { leftMargin = c; rightMargin = c })
        outer.addView(handle(false, false, false, true, 2), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, e, Gravity.BOTTOM).apply { leftMargin = c; rightMargin = c })
        outer.addView(handle(true, false, true, false, 0), FrameLayout.LayoutParams(c, c, Gravity.TOP or Gravity.START))
        outer.addView(handle(false, true, true, false, 0), FrameLayout.LayoutParams(c, c, Gravity.TOP or Gravity.END))
        outer.addView(handle(true, false, false, true, 0), FrameLayout.LayoutParams(c, c, Gravity.BOTTOM or Gravity.START))
        outer.addView(handle(false, true, false, true, 0), FrameLayout.LayoutParams(c, c, Gravity.BOTTOM or Gravity.END))
        val lp = WindowManager.LayoutParams(
            pw, ph, type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = px; y = py }
        panelLp = lp
        wm.addView(outer, lp)
        panel = outer
        logJob?.cancel()
        logJob = scope.launch { while (true) { kotlinx.coroutines.delay(1000); updateLog() } }   // hanya jalan saat panel terbuka
        render()
        listSc?.let { sv -> val y = savedScrollY; sv.post { try { sv.scrollTo(0, y) } catch (e: Exception) { } } }
    }

    /** Gagang ubah ukuran: l/r/t/b = sisi yang ditarik. bar: 1 = garis tegak, 2 = garis datar, 0 = sudut. */
    private fun handle(l: Boolean, r: Boolean, t: Boolean, b: Boolean, bar: Int): View {
        val v = FrameLayout(this)
        val gr = View(this).apply {
            background = GradientDrawable().apply { setColor(0x88FFFFFF.toInt()); cornerRadius = dp(2).toFloat() }
        }
        when (bar) {
            1 -> v.addView(gr, FrameLayout.LayoutParams(dp(4), dp(40), Gravity.CENTER))
            2 -> v.addView(gr, FrameLayout.LayoutParams(dp(40), dp(4), Gravity.CENTER))
            else -> v.addView(gr, FrameLayout.LayoutParams(dp(8), dp(8), Gravity.CENTER))
        }
        var sx = 0; var sy = 0; var sw = 0; var sh = 0; var tx = 0f; var ty = 0f
        v.setOnTouchListener { _, ev ->
            val lp = panelLp ?: return@setOnTouchListener false
            val pv = panel ?: return@setOnTouchListener false
            val dm = resources.displayMetrics
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; sw = lp.width; sh = lp.height; tx = ev.rawX; ty = ev.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - tx).toInt(); val dy = (ev.rawY - ty).toInt()
                    val minW = dp(170); val minH = dp(130)
                    var nx = sx; var ny = sy; var nw = sw; var nh = sh
                    if (r) nw = (sw + dx).coerceIn(minW, dm.widthPixels)
                    if (l) { nw = (sw - dx).coerceIn(minW, dm.widthPixels); nx = sx + (sw - nw) }
                    if (b) nh = (sh + dy).coerceIn(minH, dm.heightPixels)
                    if (t) { nh = (sh - dy).coerceIn(minH, dm.heightPixels); ny = sy + (sh - nh) }
                    lp.x = nx; lp.y = ny; lp.width = nw; lp.height = nh
                    px = nx; py = ny; pw = nw; ph = nh
                    try { wm.updateViewLayout(pv, lp) } catch (e: Exception) { }
                    true
                }
                else -> true
            }
        }
        return v
    }

    private fun render() {
        val l = list ?: return
        val items = Repo.detected.value.sortedBy { it.seq }   // urut mutlak ascending: no.1 di atas
        updateLog()
        val keepY = listSc?.scrollY ?: 0
        l.removeAllViews()
        if (items.isEmpty()) {
            l.addView(txt("Belum ada tautan. Buka video di browser/YouTube, atau tekan 📋 untuk scan clipboard.", 13f, 0xFFBDBDBD.toInt()).apply { setPadding(dp(8), dp(16), dp(8), dp(16)) })
            return
        }
        for ((idx, c) in items.withIndex()) {
            val row = SwipeRow(this) { dismissCand(c) }.apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(6), dp(8))
                background = ColorDrawable(0xFF689F98.toInt())
                setOnClickListener { if (!expanded.add(c.key)) expanded.remove(c.key); render() }
            }
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            top.addView(txt("${idx + 1}. " + (if (c.isAudio) "🎵" else "🎞"), 14f))
            top.addView(txt("⋮", 24f) { if (!expanded.add(c.key)) expanded.remove(c.key); render() })
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(txt(c.title, 14f).apply {
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END
                setOnClickListener { closePanel(); openDialog(c) }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            info.addView(txt("${c.quality} • ${fmtSize(c.size)} • ${fmtDur(c.duration)}" + (if (c.source.isNotEmpty()) " • [${c.source}]" else ""), 12f, 0xFFE0F2F1.toInt()))
            top.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(top)
            if (c.key in expanded) {
                val pr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                val pi = Resolver.previewInfo(c)
                if (!c.isAudio) pr.addView(txt("▶ Pratinjau Video", 13f, 0xFF1B1B1B.toInt()) { closePanel(); preview(c, false) })
                if (c.isAudio || !c.muted || pi.audio != null) pr.addView(txt("♪ Pratinjau Suara", 13f, 0xFF1B1B1B.toInt()) { closePanel(); preview(c, true) })
                row.addView(pr)
                row.addView(txt("Alamat: ${c.url}", 11f, 0xFFE0F2F1.toInt()).apply { maxLines = 4; ellipsize = TextUtils.TruncateAt.END })
                val ar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                ar.addView(txt("📋 Salin alamat video", 12f, 0xFF1B1B1B.toInt()) {
                    try {
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("url", c.url))
                        android.widget.Toast.makeText(this, "Alamat disalin", android.widget.Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) { }
                })
                ar.addView(txt("🚫 Blokir link ini", 12f, 0xFF7F0000.toInt()) {
                    if (LinkBlock.add(c.url)) {
                        android.widget.Toast.makeText(this, "Link diblokir", android.widget.Toast.LENGTH_SHORT).show()
                        dismissCand(c)
                    } else android.widget.Toast.makeText(this, "Link ini tidak bisa diblokir", android.widget.Toast.LENGTH_SHORT).show()
                })
                row.addView(ar)
            }
            l.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(2) })
        }
        listSc?.let { sv -> sv.post { try { sv.scrollTo(0, keepY) } catch (e: Exception) { } } }
    }

    private fun dismissCand(c: Candidate) {
        try { Resolver.forget(c.url, c.key) } catch (e: Throwable) { }
        Repo.detected.value = Repo.detected.value.filter { it.key != c.key }
        expanded.remove(c.key)
        render()
    }

    /** Klik nama file: langsung mulai unduh (nama/folder/ekstensi bawaan, tanpa dialog). */
    private fun startDirect(c: Candidate) {
        try {
            val ext = when { c.kind == Kind.HLS -> "mp4"; c.toMp3 -> "mp3"; else -> c.ext }
            val dir = Paths.dirFor(c.isAudio)
            val nm = uniqueFile(dir, safeName(c.title) + "." + ext).name
            enqueue(this, c, nm, dir.path, false, true, true)
            android.widget.Toast.makeText(this, "Sedang diunduh: $nm", android.widget.Toast.LENGTH_SHORT).show()
        } catch (e: Throwable) {
            android.widget.Toast.makeText(this, "Gagal memulai unduhan", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun openDialog(c: Candidate) {
        startActivity(Intent(this, DownloadDialogActivity::class.java).putExtra("key", c.key)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun preview(c: Candidate, audioOnly: Boolean) {
        val pi = Resolver.previewInfo(c)
        startActivity(Intent(this, PreviewActivity::class.java).putExtra("url", pi.url)
            .putExtra("audio", pi.audio).putExtra("muted", pi.muted).putExtra("fallback", pi.fallback).putExtra("mode", if (audioOnly) "audio" else "video")
            .putExtra("ua", uaOf(c.formatSel)).putExtra("ref", c.referer).putExtra("title", c.title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onDestroy() {
        running = false
        inst = null
        hideDismiss()
        try { confirmDlg?.dismiss() } catch (e: Exception) { }
        hideOptions()
        hideBubblePopup()
        NetSniffer.stop()
        try { Chain.cancelAll() } catch (e: Throwable) { }
        try { logJob?.cancel(); logJob = null } catch (e: Exception) { }
        try { Repo.prefs().unregisterOnSharedPreferenceChangeListener(prefL) } catch (e: Exception) { }
        try { cm.removePrimaryClipChangedListener(clipListener) } catch (e: Exception) { }
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        scope.cancel()
        super.onDestroy()
    }
}

/** Geser baris ke kiri ATAU kanan untuk menghapusnya (mengikuti jari, ada animasi; baris lain merapat mulus). */
class SwipeRow(c: android.content.Context, private val onDismiss: () -> Unit) : LinearLayout(c) {
    private var x0 = 0f; private var y0 = 0f; private var drag = false; private var off = 0f
    private var vt: android.view.VelocityTracker? = null
    // sangat sensitif: ambang gerak setengah dari touch slop sistem
    private val slop = Math.max(3f, android.view.ViewConfiguration.get(c).scaledTouchSlop * 0.3f)
    // kecepatan lepas minimum sangat rendah: usapan secepat/selambat apa pun tetap memicu hapus
    private val escapeVel = 150f
    private val thresholdFrac = 0.1f
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                x0 = e.rawX; y0 = e.rawY; drag = false; animate().cancel()
                vt?.recycle(); vt = android.view.VelocityTracker.obtain()
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                val dx = e.rawX - x0; val dy = e.rawY - y0
                if (!drag && Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy)) {
                    drag = true; off = x0 + (if (dx > 0) slop else -slop)
                    setLayerType(LAYER_TYPE_HARDWARE, null)
                    parent?.requestDisallowInterceptTouchEvent(true); return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (!drag) { vt?.recycle(); vt = null }
        }
        return drag
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!drag) return super.onTouchEvent(e)
        vt?.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                translationX = e.rawX - off
                alpha = 1f - Math.min(1f, Math.abs(translationX) / Math.max(1, width) * 0.8f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                drag = false
                var vx = 0f
                vt?.let { it.computeCurrentVelocity(1000); vx = it.xVelocity; it.recycle() }; vt = null
                val moved = Math.abs(translationX) > width * thresholdFrac
                val fling = Math.abs(vx) > escapeVel && (translationX == 0f || vx * translationX > 0f)
                if (e.actionMasked == MotionEvent.ACTION_UP && (moved || fling)) {
                    val dir = if (translationX != 0f) (if (translationX > 0f) 1f else -1f) else (if (vx >= 0f) 1f else -1f)
                    animate().translationX(dir * width).alpha(0f).setDuration(140)
                        .setInterpolator(android.view.animation.DecelerateInterpolator()).withEndAction {
                        val h = Math.max(1, height)
                        layoutParams.height = h
                        android.animation.ValueAnimator.ofInt(h, 0).apply {
                            duration = 140
                            addUpdateListener { a -> layoutParams.height = a.animatedValue as Int; requestLayout() }
                            addListener(object : android.animation.AnimatorListenerAdapter() { override fun onAnimationEnd(a: android.animation.Animator) { onDismiss() } })
                            start()
                        }
                    }.start()
                } else animate().translationX(0f).alpha(1f).setDuration(160)
                    .setInterpolator(android.view.animation.DecelerateInterpolator())
                    .withEndAction { setLayerType(LAYER_TYPE_NONE, null) }.start()
            }
        }
        return true
    }
}
