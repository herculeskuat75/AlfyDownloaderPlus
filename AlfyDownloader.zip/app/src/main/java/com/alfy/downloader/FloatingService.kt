package com.alfy.downloader

import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

class FloatingService : Service() {
    companion object { @Volatile var running = false; @Volatile var inst: FloatingService? = null }

    private lateinit var wm: WindowManager
    private var bubble: FrameLayout? = null
    private var badge: TextView? = null
    private var circleView: TextView? = null
    private val prefL = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, k ->
        if (k == "bubbleIdx" || k == "arrowIdx") applyStyle()
    }
    private var panel: FrameLayout? = null
    private var pw = 0; private var ph = 0; private var px = -1; private var py = -1
    private var panelLp: WindowManager.LayoutParams? = null
    private var dsx = 0; private var dsy = 0; private var dtx = 0f; private var dty = 0f
    private var list: LinearLayout? = null
    private var title: TextView? = null
    private var logL: TextView? = null
    private var logR: TextView? = null
    private var diagTv: TextView? = null
    private val scope = MainScope()
    private val expanded = HashSet<String>()
    private val cm by lazy { getSystemService(CLIPBOARD_SERVICE) as ClipboardManager }
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { readClip() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val type get() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        inst = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(1, makeNotif(this, "Menu mengambang aktif • ${Repo.detected.value.size} file tersedia"))
        addBubble()
        NetSniffer.start()
        scope.launch {
            while (true) {
                kotlinx.coroutines.delay(1000)
                if (panel != null) updateLog()
            }
        }
        scope.launch {
            Repo.detected.collect { l ->
                val b = badge
                if (b != null) { b.text = l.size.toString(); b.visibility = if (l.isEmpty()) View.GONE else View.VISIBLE }
                if (panel != null) render()
                postNotif(this@FloatingService, 1, makeNotif(this@FloatingService, "${l.size} file tersedia diunduh"))
            }
        }
        try { cm.addPrimaryClipChangedListener(clipListener) } catch (e: Exception) { }
        Repo.prefs().registerOnSharedPreferenceChangeListener(prefL)
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int = START_STICKY

    private val ui = android.os.Handler(android.os.Looper.getMainLooper())

    private fun feedClip(t: String): Int {
        val urls = Regex("https?://[^\\s]+").findAll(t).map { it.value }.toList()
        urls.forEach { Resolver.rescan(it) }
        return urls.size
    }

    private fun readClip() { pullClip() }

    /** Baca clipboard terbaru. Android 10+ hanya mengizinkan jendela berfokus: coba jendela 1px, lalu cadangan activity transparan (+root). */
    fun pullClip() {
        if (AlfyAccessibilityService.inst?.readClipDirect() == true) return
        val t = try { cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() } catch (e: Exception) { null }
        if (!t.isNullOrBlank()) { if (feedClip(t) > 0) Resolver.diag = "Clipboard: memindai tautan…"; return }
        if (NetSniffer.clipRoot) { NetSniffer.readClipRootOnce(); return }
        // jangan mencuri fokus saat keyboard tampil (sedang mengetik)
        if (AlfyAccessibilityService.inst?.keyboardShown() == true) return
        var ok = false
        try {
            var removed = false
            lateinit var v: View
            v = object : View(this) {
                override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
                    super.onWindowFocusChanged(hasWindowFocus)
                    if (!hasWindowFocus || removed) return
                    try {
                        val x = cm.primaryClip?.getItemAt(0)?.coerceToText(this@FloatingService)?.toString() ?: ""
                        if (x.isNotBlank()) ok = true
                        if (feedClip(x) > 0) Resolver.diag = "Clipboard: memindai tautan…"
                    } catch (e: Exception) { }
                    removed = true
                    ui.post { try { wm.removeView(v) } catch (e: Exception) { } }
                }
            }
            val lp = WindowManager.LayoutParams(1, 1, type,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
            wm.addView(v, lp)
            ui.postDelayed({
                if (!removed) { removed = true; try { wm.removeView(v) } catch (e: Exception) { } }
                if (!ok) launchClipActivity()
            }, 900)
        } catch (e: Exception) { launchClipActivity() }
    }

    private fun launchClipActivity() {
        if (AlfyAccessibilityService.inst?.keyboardShown() == true) return
        try { startActivity(Intent(this, ClipActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {
            Thread { try { Runtime.getRuntime().exec(arrayOf("su", "-c", "am start -n $packageName/.ClipActivity")).waitFor() } catch (x: Exception) { } }.start()
        }
    }

    private var dismissView: FrameLayout? = null
    private fun showDismiss() {
        if (dismissView != null) return
        val sz = dp(64)
        val fl = FrameLayout(this)
        val c = TextView(this).apply {
            text = "✕"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC000000.toInt()); setStroke(dp(2), Color.WHITE) }
        }
        fl.addView(c, FrameLayout.LayoutParams(sz, sz))
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(56) }
        try { wm.addView(fl, lp); dismissView = fl } catch (e: Exception) { }
    }
    private fun hideDismiss() { dismissView?.let { try { wm.removeView(it) } catch (e: Exception) { } }; dismissView = null }

    /** Apakah pusat tombol sedang berada di atas lingkaran X di bawah layar. */
    private fun overDismiss(bx: Int, by: Int): Boolean {
        val dm = resources.displayMetrics
        val half = dp(31)
        val cx = bx + half; val cy = by + half
        val tx = dm.widthPixels / 2; val ty = dm.heightPixels - dp(56) - dp(32)
        val dx = (cx - tx).toDouble(); val dy = (cy - ty).toDouble()
        return Math.sqrt(dx * dx + dy * dy) < dp(80)
    }

    private fun addBubble() {
        val size = dp(62)
        val fl = FrameLayout(this)
        val circle = TextView(this).apply {
            text = "⬇"; textSize = 36f; setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                colors = intArrayOf(0xFFFF4081.toInt(), 0xFF7C4DFF.toInt(), 0xFF00E5FF.toInt())
                orientation = GradientDrawable.Orientation.TL_BR
                setStroke(dp(2), Color.WHITE)
            }
        }
        fl.addView(circle, FrameLayout.LayoutParams(size, size))
        circleView = circle
        val bd = TextView(this).apply {
            textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.RED) }
            visibility = View.GONE
        }
        fl.addView(bd, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP or Gravity.END))
        badge = bd
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(220) }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        fl.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = sx + dx; lp.y = sy + dy; wm.updateViewLayout(fl, lp)
                        showDismiss()
                        val over = overDismiss(lp.x, lp.y)
                        dismissView?.let { it.scaleX = if (over) 1.3f else 1f; it.scaleY = if (over) 1.3f else 1f }
                        fl.alpha = if (over) 0.6f else 1f
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val over = moved && overDismiss(lp.x, lp.y)
                    hideDismiss()
                    fl.alpha = 1f
                    if (over) {
                        android.widget.Toast.makeText(this, "Menu mengambang disembunyikan. Buka aplikasi untuk menampilkan lagi.", android.widget.Toast.LENGTH_LONG).show()
                        stopSelf()
                    } else if (!moved && e.action == MotionEvent.ACTION_UP) togglePanel()
                    true
                }
                else -> false
            }
        }
        wm.addView(fl, lp)
        bubble = fl
        applyStyle()
        val n = Repo.detected.value.size
        bd.text = n.toString(); bd.visibility = if (n == 0) View.GONE else View.VISIBLE
    }

    private fun applyStyle() {
        val c = circleView ?: return
        val p = Repo.prefs()
        val bi = p.getInt("bubbleIdx", 0).coerceIn(0, Palette.colors.size - 1)
        val ai = p.getInt("arrowIdx", 8).coerceIn(0, Palette.colors.size - 1)
        val size = dp(62).toFloat()
        c.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            if (bi == 0) { gradientType = GradientDrawable.SWEEP_GRADIENT; colors = Palette.rainbow }
            else setColor(Palette.colors[bi])
            setStroke(dp(2), Color.WHITE)
        }
        if (ai == 0) {
            c.paint.shader = android.graphics.LinearGradient(0f, 0f, size, size, Palette.rainbow, null, android.graphics.Shader.TileMode.CLAMP)
        } else {
            c.paint.shader = null
            c.setTextColor(Palette.colors[ai])
        }
        c.invalidate()
    }

    /**
     * v1.7: panel yang bisa digeser dengan menekan DI MANA SAJA: geser mendatar di mana pun, tahan lama (0,4 dtk) lalu geser ke segala arah,
     * atau geser ke segala arah dari area yang bukan daftar (judul, log, ruang kosong). Tepi (gagang) tetap untuk ubah ukuran.
     */
    private inner class PanelFrame : FrameLayout(this@FloatingService) {
        private var dX = 0f; private var dY = 0f; private var sX = 0; private var sY = 0
        private var drag = false; private var lpress = false; private var onEdge = false
        private val slop = android.view.ViewConfiguration.get(this@FloatingService).scaledTouchSlop * 3
        private val lpRun = Runnable { lpress = true; try { performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS) } catch (e: Exception) { } }

        private fun begin(e: MotionEvent) {
            dX = e.rawX; dY = e.rawY; sX = panelLp?.x ?: 0; sY = panelLp?.y ?: 0
            drag = false; lpress = false
            val m = dp(40)
            onEdge = e.x < m || e.y < m || e.x > width - m || e.y > height - m
            removeCallbacks(lpRun); postDelayed(lpRun, 600)
        }
        private fun moveTo(e: MotionEvent) {
            val lp = panelLp ?: return
            lp.x = sX + (e.rawX - dX).toInt(); lp.y = sY + (e.rawY - dY).toInt(); px = lp.x; py = lp.y
            try { wm.updateViewLayout(this, lp) } catch (x: Exception) { }
        }
        override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> begin(e)
                MotionEvent.ACTION_MOVE -> {
                    if (onEdge) return false
                    val dx = e.rawX - dX; val dy = e.rawY - dY
                    if (!drag && (abs(dx) > slop || abs(dy) > slop)) {
                        if (lpress || abs(dx) > abs(dy) * 2f) drag = true else removeCallbacks(lpRun)
                    }
                    if (drag) { moveTo(e); return true }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { removeCallbacks(lpRun); drag = false }
            }
            return false
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { begin(e); return true }
                MotionEvent.ACTION_MOVE -> {
                    if (!drag && (abs(e.rawX - dX) > slop || abs(e.rawY - dY) > slop)) drag = true
                    if (drag) moveTo(e)
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { removeCallbacks(lpRun); drag = false; return true }
            }
            return super.onTouchEvent(e)
        }
    }

    private fun closePanel() { panel?.let { try { wm.removeView(it) } catch (e: Exception) { } }; panel = null }
    private fun togglePanel() { if (panel != null) closePanel() else buildPanel() }

    private fun txt(t: String, sp: Float, color: Int = Color.WHITE, onClick: (() -> Unit)? = null) =
        TextView(this).apply {
            text = t; textSize = sp; setTextColor(color)
            if (onClick != null) { setPadding(dp(10), dp(6), dp(10), dp(6)); setOnClickListener { onClick() } }
        }

    private fun colorize(lines: List<String>): android.text.SpannableStringBuilder {
        val sb = android.text.SpannableStringBuilder()
        for (line in lines) {
            val st = sb.length
            sb.append(line).append('\n')
            val col = when {
                line.contains("✗") -> 0xFFEF9A9A.toInt()
                line.contains("✓") -> 0xFFA5D6A7.toInt()
                line.contains("⏳") -> 0xFFFFE082.toInt()
                else -> 0xFFBDBDBD.toInt()
            }
            sb.setSpan(android.text.style.ForegroundColorSpan(col), st, sb.length, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (sb.isNotEmpty()) sb.delete(sb.length - 1, sb.length)
        return sb
    }

    private fun short(t: String, n: Int = 60) = t.replace("\n", " ").trim().let { if (it.length > n) it.take(n - 1) + "…" else it }

    /** v1.7: SEMUA alat (pemindai link + pemantau sistem + tcpdump) bernomor, dibagi 2 kolom (1-5 kiri, 6-10 kanan, dst), huruf 13sp. */
    private fun updateLog() {
        val t = title ?: return
        t.text = "Tautan (${Repo.detected.value.size})"
        val items = ArrayList<String>(ToolLog.lines())
        var n = items.size
        fun sys(name: String, st: String) { n++; items.add("$n. $name  ${short(st, 40)}") }
        sys("Root logcat", if (NetSniffer.status.startsWith("Root: aktif")) "✓ aktif, semua lalu lintas dipindai" else "✗ " + NetSniffer.status)
        sys("tcpdump", NetSniffer.tcpStatus)
        sys("MediaSession", NetSniffer.mediaStatus)
        sys("Clipboard root", if (NetSniffer.clipRoot) "✓ aktif" else "✗ belum/ tanpa root")
        sys("Notifikasi", AlfyNotifService.status.let { if (it.contains("✓")) "✓ aktif" else "✗ " + it.substringAfter(": ") })
        sys("Aksesibilitas", if (AlfyAccessibilityService.inst != null) "✓ aktif" else "✗ mati")
        sys("Lepas VPN", VpnTool.status.substringAfter(": ").let { if (it.startsWith("aktif")) "✓ $it" else "✗ $it" })
        val half = (items.size + 1) / 2
        logL?.text = colorize(items.take(half))
        logR?.text = colorize(items.drop(half))
        val all = ArrayList<String>()
        if (Resolver.diag.isNotBlank()) all.add(Resolver.diag)
        if (ToolLog.winner.isNotEmpty()) all.add("→ link dari ${ToolLog.winner}")
        if (!Engine.ready) all.add("Mesin unduh: " + (Engine.error ?: "memuat…"))
        diagTv?.text = all.joinToString("\n") { short(it, 120) }
    }

    private fun ico(t: String, onClick: () -> Unit) = txt(t, 14f, Color.WHITE, onClick).apply { setPadding(dp(7), dp(2), dp(7), dp(2)) }

    private fun buildPanel() {
        val dm = resources.displayMetrics
        val outer = PanelFrame().apply {
            background = GradientDrawable().apply { setColor(0xF2303030.toInt()); cornerRadius = dp(14).toFloat() }
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val t = txt("", 15f).apply { setTypeface(null, android.graphics.Typeface.BOLD); setPadding(dp(6), 0, 0, 0) }
        title = t
        head.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val dragTouch = View.OnTouchListener { _, ev ->
            val pl = panelLp ?: return@OnTouchListener false
            val pv = panel ?: return@OnTouchListener false
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { dsx = pl.x; dsy = pl.y; dtx = ev.rawX; dty = ev.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    pl.x = dsx + (ev.rawX - dtx).toInt(); pl.y = dsy + (ev.rawY - dty).toInt(); px = pl.x; py = pl.y
                    try { wm.updateViewLayout(pv, pl) } catch (e: Exception) { }
                    true
                }
                else -> true
            }
        }
        t.setOnTouchListener(dragTouch)
        head.setOnTouchListener(dragTouch)
        head.addView(ico("🔍") {
            val acc = AlfyAccessibilityService.inst
            if (acc != null) acc.scanNow()
            android.widget.Toast.makeText(this, if (acc == null) "Aktifkan aksesibilitas dulu (📖)" else "Memindai layar…", android.widget.Toast.LENGTH_SHORT).show()
        })
        head.addView(ico("📋") {
            startActivity(Intent(this, ClipActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        head.addView(ico("🗑") { Repo.detected.value = emptyList(); Resolver.reset() })
        head.addView(ico("✕") { closePanel() })
        root.addView(head)
        // log alat: 2 kolom (kiri 1..N/2, kanan sisanya), 13sp; TIDAK digulir agar seluruh panel bisa digeser dari sini
        val logBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply { setColor(0x40000000); cornerRadius = dp(8).toFloat() }
        }
        val cols = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tl = txt("", 13f, 0xFFEEEEEE.toInt()).apply { setLineSpacing(0f, 1.1f) }
        val tr = txt("", 13f, 0xFFEEEEEE.toInt()).apply { setLineSpacing(0f, 1.1f); setPadding(dp(6), 0, 0, 0) }
        val dg = txt("", 12f, 0xFFBDBDBD.toInt()).apply { setPadding(0, dp(4), 0, 0) }
        logL = tl; logR = tr; diagTv = dg
        cols.addView(tl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        cols.addView(tr, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        logBox.addView(cols)
        logBox.addView(dg)
        root.addView(logBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(4), 0, dp(4), dp(3)) })
        val sc = ScrollView(this)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sc.addView(l)
        list = l
        root.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        if (pw <= 0) { pw = (dm.widthPixels * 0.94).toInt(); ph = (dm.heightPixels * 0.6).toInt() }
        if (px < 0) { px = (dm.widthPixels * 0.03).toInt(); py = dp(24) }
        val m = dp(14)
        outer.addView(root, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply { setMargins(m, m, m, m) })
        // gagang tarik di 4 sisi + 4 sudut: perkecil/perbesar ke kiri, kanan, atas, bawah
        val e = dp(28); val c = dp(48)
        outer.addView(handle(true, false, false, false, 1), FrameLayout.LayoutParams(e, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START).apply { topMargin = c; bottomMargin = c })
        outer.addView(handle(false, true, false, false, 1), FrameLayout.LayoutParams(e, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END).apply { topMargin = c; bottomMargin = c })
        outer.addView(handle(false, false, true, false, 2), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, e, Gravity.TOP).apply { leftMargin = c; rightMargin = c })
        outer.addView(handle(false, false, false, true, 2), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, e, Gravity.BOTTOM).apply { leftMargin = c; rightMargin = c })
        outer.addView(handle(true, false, true, false, 0), FrameLayout.LayoutParams(c, c, Gravity.TOP or Gravity.START))
        outer.addView(handle(false, true, true, false, 0), FrameLayout.LayoutParams(c, c, Gravity.TOP or Gravity.END))
        outer.addView(handle(true, false, false, true, 0), FrameLayout.LayoutParams(c, c, Gravity.BOTTOM or Gravity.START))
        outer.addView(handle(false, true, false, true, 0), FrameLayout.LayoutParams(c, c, Gravity.BOTTOM or Gravity.END))
        val lp = WindowManager.LayoutParams(
            pw, ph, type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = px; y = py }
        panelLp = lp
        wm.addView(outer, lp)
        panel = outer
        render()
    }

    /** Gagang ubah ukuran: l/r/t/b = sisi yang ditarik. bar: 1 = garis tegak, 2 = garis datar, 0 = sudut. */
    private fun handle(l: Boolean, r: Boolean, t: Boolean, b: Boolean, bar: Int): View {
        val v = FrameLayout(this)
        val gr = View(this).apply {
            background = GradientDrawable().apply { setColor(0x88FFFFFF.toInt()); cornerRadius = dp(2).toFloat() }
        }
        when (bar) {
            1 -> v.addView(gr, FrameLayout.LayoutParams(dp(5), dp(56), Gravity.CENTER))
            2 -> v.addView(gr, FrameLayout.LayoutParams(dp(56), dp(5), Gravity.CENTER))
            else -> v.addView(gr, FrameLayout.LayoutParams(dp(8), dp(8), Gravity.CENTER))
        }
        var sx = 0; var sy = 0; var sw = 0; var sh = 0; var tx = 0f; var ty = 0f
        var moveMode = false
        v.setOnTouchListener { _, ev ->
            val lp = panelLp ?: return@setOnTouchListener false
            val pv = panel ?: return@setOnTouchListener false
            val dm = resources.displayMetrics
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; sw = lp.width; sh = lp.height; tx = ev.rawX; ty = ev.rawY
                    // v1.7: menekan pil di TENGAH garis tepi = geser seluruh panel ke mana saja; bagian garis lainnya & sudut = ubah ukuran
                    moveMode = when (bar) {
                        1 -> Math.abs(ev.y - v.height / 2f) < dp(56)
                        2 -> Math.abs(ev.x - v.width / 2f) < dp(56)
                        else -> false
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - tx).toInt(); val dy = (ev.rawY - ty).toInt()
                    if (moveMode) {
                        lp.x = sx + dx; lp.y = sy + dy; px = lp.x; py = lp.y
                        try { wm.updateViewLayout(pv, lp) } catch (e: Exception) { }
                        return@setOnTouchListener true
                    }
                    val minW = dp(170); val minH = dp(130)
                    var nx = sx; var ny = sy; var nw = sw; var nh = sh
                    if (r) nw = (sw + dx).coerceIn(minW, dm.widthPixels)
                    if (l) { nw = (sw - dx).coerceIn(minW, dm.widthPixels); nx = sx + (sw - nw) }
                    if (b) nh = (sh + dy).coerceIn(minH, dm.heightPixels)
                    if (t) { nh = (sh - dy).coerceIn(minH, dm.heightPixels); ny = sy + (sh - nh) }
                    lp.x = nx; lp.y = ny; lp.width = nw; lp.height = nh
                    px = nx; py = ny; pw = nw; ph = nh
                    try { wm.updateViewLayout(pv, lp) } catch (e: Exception) { }
                    true
                }
                else -> true
            }
        }
        return v
    }

    private fun render() {
        val l = list ?: return
        val items = Repo.detected.value.asReversed()
        updateLog()
        l.removeAllViews()
        if (items.isEmpty()) {
            l.addView(txt("Belum ada tautan. Buka video di browser/YouTube, atau tekan 📋 untuk scan clipboard.", 13f, 0xFFBDBDBD.toInt()).apply { setPadding(dp(8), dp(16), dp(8), dp(16)) })
            return
        }
        for (c in items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(6), dp(8))
                background = ColorDrawable(0xFF689F98.toInt())
            }
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val conv = needsConvert(c)
            val ttl = (if (conv) "❗ " else "") + (if (c.isAudio) "🎵 " else "🎞 ") + c.title
            info.addView(txt("", 14f).apply {
                val sp = android.text.SpannableString(ttl)
                if (conv) sp.setSpan(android.text.style.ForegroundColorSpan(Color.RED), 0, 1, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                text = sp
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END
            })
            info.addView(txt("${c.quality} • ${fmtSize(c.size)} • ${fmtDur(c.duration)}" + (if (conv) " • ${c.ext.uppercase()}→MP4" else "") + (if (c.source.isNotEmpty()) " • [${c.source}]" else ""), 12f, 0xFFE0F2F1.toInt()))
            info.setOnClickListener { closePanel(); openDialog(c) }
            top.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(txt("⋮", 24f) { if (!expanded.add(c.key)) expanded.remove(c.key); render() })
            row.addView(top)
            if (c.key in expanded) {
                val pr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                val pi = Resolver.previewInfo(c)
                if (!c.isAudio) pr.addView(txt("▶ Pratinjau Video", 13f, 0xFF1B1B1B.toInt()) { closePanel(); preview(c, false) })
                if (c.isAudio || !c.muted || pi.audio != null) pr.addView(txt("♪ Pratinjau Suara", 13f, 0xFF1B1B1B.toInt()) { closePanel(); preview(c, true) })
                row.addView(pr)
                row.addView(txt("Alamat: ${c.url}", 11f, 0xFFE0F2F1.toInt()).apply { maxLines = 4; ellipsize = TextUtils.TruncateAt.END })
                row.addView(txt("📋 Salin alamat video", 12f, 0xFF1B1B1B.toInt()) {
                    try {
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("url", c.url))
                        android.widget.Toast.makeText(this, "Alamat disalin", android.widget.Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) { }
                })
            }
            l.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(2) })
        }
    }

    private fun openDialog(c: Candidate) {
        startActivity(Intent(this, DownloadDialogActivity::class.java).putExtra("key", c.key)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun preview(c: Candidate, audioOnly: Boolean) {
        val pi = Resolver.previewInfo(c)
        startActivity(Intent(this, PreviewActivity::class.java).putExtra("url", pi.url)
            .putExtra("audio", pi.audio).putExtra("muted", pi.muted).putExtra("fallback", pi.fallback).putExtra("mode", if (audioOnly) "audio" else "video")
            .putExtra("ua", uaOf(c.formatSel)).putExtra("ref", c.referer).putExtra("title", c.title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onDestroy() {
        running = false
        inst = null
        hideDismiss()
        NetSniffer.stop()
        try { Repo.prefs().unregisterOnSharedPreferenceChangeListener(prefL) } catch (e: Exception) { }
        try { cm.removePrimaryClipChangedListener(clipListener) } catch (e: Exception) { }
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        scope.cancel()
        super.onDestroy()
    }
}
