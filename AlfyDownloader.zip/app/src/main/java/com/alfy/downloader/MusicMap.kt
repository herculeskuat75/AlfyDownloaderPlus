package com.alfy.downloader

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/** Gambar sampul per ID video YouTube (mis. dari halaman Spotify) agar cover asli yang dipasang. */
object CoverHint { val m = ConcurrentHashMap<String, String>() }

/** Situs musik berDRM/tanpa unduhan (Spotify, Apple Music, Deezer, Tidal, dll): baca judul+artis dari halaman, cari lagu yang sama di YouTube, lalu jalankan rantai alat YouTube. */
object MusicMap {
    private val hosts = listOf("spotify.com", "spotify.link", "music.apple.com", "deezer.com", "deezer.page.link", "tidal.com", "music.amazon", "napster.com", "qobuz.com", "pandora.com", "jiosaavn.com", "gaana.com", "joox.com", "anghami.com", "boomplay.com", "resso.com")
    fun matches(page: String): Boolean {
        val h = try { android.net.Uri.parse(page).host?.lowercase() ?: "" } catch (e: Exception) { "" }
        return hosts.any { h.endsWith(it) || h.contains(it) }
    }

    private fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 12000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0")
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        return try { c.inputStream.use { String(it.readBytes().let { b -> if (b.size > 600_000) b.copyOf(600_000) else b }, Charsets.UTF_8) } } finally { c.disconnect() }
    }

    private fun un(s: String) = s.replace("&amp;", "&").replace("&#039;", "'").replace("&#x27;", "'").replace("&quot;", "\"").replace("\u200E", "").trim()

    private fun meta(html: String, p: String): String {
        val r1 = Regex("<meta[^>]+(?:property|name)=[\"']$p[\"'][^>]*content=[\"']([^\"']*)", RegexOption.IGNORE_CASE)
        val r2 = Regex("<meta[^>]+content=[\"']([^\"']*)[\"'][^>]*(?:property|name)=[\"']$p[\"']", RegexOption.IGNORE_CASE)
        return un((r1.find(html) ?: r2.find(html))?.groupValues?.get(1) ?: "")
    }

    private fun nm(x: Any?): String = when (x) {
        is org.json.JSONObject -> x.optString("name")
        is org.json.JSONArray -> (0 until x.length()).map { nm(x.opt(it)) }.filter { it.isNotEmpty() }.joinToString(" ")
        is String -> x
        else -> ""
    }

    /** JSON-LD MusicRecording (Apple Music, Joox, dll): judul + artis. */
    private fun ld(html: String): Pair<String, String> {
        for (m in Regex("<script[^>]+application/ld\\+json[^>]*>(.*?)</script>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).findAll(html)) {
            try {
                val t = m.groupValues[1].trim()
                val arr = if (t.startsWith("[")) org.json.JSONArray(t) else org.json.JSONArray().put(org.json.JSONObject(t))
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    if (!o.opt("@type").toString().contains("MusicRecording", true)) continue
                    val n = un(o.optString("name"))
                    val a = un(nm(o.opt("byArtist")).ifEmpty { nm(o.opt("author")) }.ifEmpty { nm(o.opt("creator")) })
                    if (n.isNotEmpty() && a.isNotEmpty()) return n to a
                }
            } catch (e: Throwable) { }
        }
        return "" to ""
    }

    /** Metadata Matching: (judul lagu, nama artis) dari JSON-LD, og:title/description, atau <title>. */
    fun parse(html: String): Pair<String, String> {
        ld(html).let { if (it.first.isNotEmpty()) return it }
        val title = meta(html, "og:title")
        val desc = meta(html, "og:description")
        val pt = un(Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1) ?: "")
        val site = "(?:spotify|apple music|deezer|tidal|joox|jiosaavn|gaana|anghami|boomplay|resso|amazon music)"
        val by1 = Regex("^(.+?)\\s+[-–]\\s+(?:song|single|album|ep)(?:\\s+and\\s+lyrics)?\\s+by\\s+(.+?)(?:\\s*[|\\-–·]\\s*$site.*)?$", RegexOption.IGNORE_CASE)
        for (x in listOf(pt, title)) by1.find(x)?.let { return it.groupValues[1].trim() to it.groupValues[2].trim() }
        val by2 = Regex("^(.+?)\\s+by\\s+(.+?)(?:\\s+on\\s+$site)?(?:\\s*[|\\-–]\\s*$site.*)?$", RegexOption.IGNORE_CASE)
        for (x in listOf(title, pt)) by2.find(x)?.let { return it.groupValues[1].trim() to it.groupValues[2].trim() }
        val t = (title.ifEmpty { pt }).replace(Regex("(?i)\\s*[|\\-–]\\s*$site.*$"), "").trim()
        if (t.isEmpty()) return "" to ""
        val skip = Regex("^\\d{4}$|^(?i)(song|single|album|ep|lyrics|music)$")
        val parts = desc.replace(Regex("(?i)listen to .* on $site\\.?"), "").split("·", "|").map { it.trim() }
            .filter { it.isNotEmpty() && !it.equals(t, true) && !skip.matches(it) }
        if (parts.isNotEmpty() && desc.contains("·")) return t to parts.first()
        val dash = Regex("^(.+?)\\s+[-–]\\s+(.+)$").find(t)
        if (dash != null) return dash.groupValues[2].trim() to dash.groupValues[1].trim()   // "Artis - Judul"
        return t to parts.firstOrNull().orEmpty()
    }

    private fun ytdlpOne(search: String, vararg opts: String): String? {
        return try {
            Engine.await()
            val req = com.yausername.youtubedl_android.YoutubeDLRequest(search)
            for (o in opts) req.addOption(o)
            req.addOption("--no-playlist"); req.addOption("--no-warnings"); req.addOption("--force-ipv4"); req.addOption("--socket-timeout", "10")
            com.yausername.youtubedl_android.YoutubeDL.getInstance().execute(req).out.lineSequence().map { it.trim() }.firstOrNull { it.isNotEmpty() }
        } catch (e: Throwable) { null }
    }

    /** yt-dlp: cari "Artis + Judul" di YouTube (ID video 11 karakter). */
    private fun searchYt(q: String): String? {
        ytdlpOne("ytsearch1:$q", "--get-id")?.takeIf { it.length == 11 }?.let { return it }
        return try {
            Regex("\"videoId\":\"([\\w-]{11})\"").find(get("https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8")))?.groupValues?.get(1)
        } catch (e: Throwable) { null }
    }

    /** yt-dlp: cadangan, cari di SoundCloud. */
    private fun searchSc(q: String): String? = ytdlpOne("scsearch1:$q", "--print", "webpage_url")?.takeIf { it.startsWith("http") }

    /** Tandai audio hasil pencarian musik agar diunduh lalu dikonversi ke .mp3 (ffmpeg, lihat DownloadService.finishAudio). */
    @Volatile private var mp3Vid = ""
    fun wants(cv: String): Boolean { val v = mp3Vid; return v.isNotEmpty() && (v == cv || (v == "*" && ToolLog.tl.get() == "Spotify Match")) }

    private fun autoDownload(before: Set<String>, label: String) {
        val l = Repo.detected.value.filter { it.key !in before && it.isAudio && it.toMp3 }
        val c = l.firstOrNull { it.kind == Kind.YTDLP } ?: l.firstOrNull { it.ext.equals("m4a", true) } ?: l.firstOrNull() ?: return
        if (isDuplicateUrl(c.url)) return
        enqueue(Repo.app, c, safeName(label) + ".mp3", Paths.dirFor(true).path, false, true, true)
    }

    /** null = berhasil. */
    fun run(page: String): String? {
        val html = try { get(page) } catch (e: Throwable) { return "halaman musik tidak terbaca" }
        val (title, artist) = parse(html)
        if (title.isEmpty()) return "judul lagu tidak terbaca"
        val img = meta(html, "og:image")
        val q = (if (artist.isNotEmpty() && !title.contains(artist, true)) "$artist $title" else title).take(120)
        val label = if (artist.isNotEmpty()) "$artist - $title" else title
        val before = Repo.detected.value.map { it.key }.toHashSet()
        Resolver.diag = "Musik: '$q' → mencari di YouTube…"
        try {
            val id = searchYt("$q audio")
            if (id != null) {
                if (img.startsWith("http")) CoverHint.m[id] = img
                mp3Vid = id
                Resolver.diag = "Musik: '$q' → YouTube $id"
                Chain.run(id, "https://www.youtube.com/watch?v=$id")
                if (ToolLog.winner.isNotEmpty()) { autoDownload(before, label); return null }
            }
            if (!Tool.on("yt-dlp")) return if (id == null) "yt-dlp tidak ada di profil aktif" else "alat YouTube gagal untuk '$q'"
            val sc = searchSc(q) ?: return if (id == null) "lagu tidak ketemu di YouTube/SoundCloud" else "alat YouTube gagal untuk '$q'"
            mp3Vid = "*"
            Resolver.diag = "Musik: '$q' → SoundCloud"
            Resolver.ytdlpTool(sc, null)
            autoDownload(before, label)
            return null
        } catch (e: Throwable) {
            return Chain.reason(e)
        } finally { mp3Vid = "" }
    }
}
