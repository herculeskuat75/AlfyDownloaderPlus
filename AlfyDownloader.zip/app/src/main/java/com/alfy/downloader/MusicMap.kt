package com.alfy.downloader

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/** Gambar sampul per ID video YouTube (mis. dari halaman Spotify) agar cover asli yang dipasang. */
object CoverHint { val m = ConcurrentHashMap<String, String>() }

/** Situs musik berDRM/tanpa unduhan (Spotify, Apple Music, Deezer, Tidal, dll): baca judul+artis dari halaman, cari lagu yang sama di YouTube, lalu jalankan rantai alat YouTube. */
object MusicMap {
    private val hosts = listOf("spotify.com", "spotify.link", "music.apple.com", "deezer.com", "deezer.page.link", "tidal.com", "music.amazon", "napster.com", "qobuz.com", "pandora.com", "jiosaavn.com", "gaana.com", "joox.com", "anghami.com", "boomplay.com", "resso.com")
    fun matches(page: String): Boolean {
        val h = try { android.net.Uri.parse(page).host?.lowercase() ?: "" } catch (e: Exception) { "" }
        return hosts.any { h.endsWith(it) || h.contains(it) }
    }

    private fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 12000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0")
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        return try { c.inputStream.use { String(it.readBytes().let { b -> if (b.size > 600_000) b.copyOf(600_000) else b }, Charsets.UTF_8) } } finally { c.disconnect() }
    }

    private fun meta(html: String, p: String): String {
        val r1 = Regex("<meta[^>]+(?:property|name)=[\"']$p[\"'][^>]*content=[\"']([^\"']*)", RegexOption.IGNORE_CASE)
        val r2 = Regex("<meta[^>]+content=[\"']([^\"']*)[\"'][^>]*(?:property|name)=[\"']$p[\"']", RegexOption.IGNORE_CASE)
        return ((r1.find(html) ?: r2.find(html))?.groupValues?.get(1) ?: "").replace("&amp;", "&").replace("&#039;", "'").replace("&quot;", "\"").trim()
    }

    private fun searchId(q: String): String? {
        try {
            Engine.await()
            val req = com.yausername.youtubedl_android.YoutubeDLRequest("ytsearch1:$q")
            req.addOption("--get-id"); req.addOption("--no-playlist"); req.addOption("--no-warnings"); req.addOption("--force-ipv4"); req.addOption("--socket-timeout", "10")
            val id = com.yausername.youtubedl_android.YoutubeDL.getInstance().execute(req).out.lineSequence().map { it.trim() }.firstOrNull { it.length == 11 }
            if (id != null) return id
        } catch (e: Throwable) { }
        return try {
            Regex("\"videoId\":\"([\\w-]{11})\"").find(get("https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8")))?.groupValues?.get(1)
        } catch (e: Throwable) { null }
    }

    /** null = berhasil. */
    fun run(page: String): String? {
        val html = get(page)
        var title = meta(html, "og:title")
        val desc = meta(html, "og:description")
        val img = meta(html, "og:image")
        if (title.isEmpty()) return "judul lagu tidak terbaca"
        var q = title
        val extra = desc.replace(Regex("(?i)listen to .* on spotify\\.?"), "").split("·", "|", "-").map { it.trim() }
            .filter { it.isNotEmpty() && !it.equals(title, true) && !Regex("^\\d{4}$|^(?i)(song|single|album|ep)$").matches(it) }.take(2).joinToString(" ")
        if (extra.isNotEmpty() && !title.contains(extra, true)) q = "$title $extra"
        q = q.replace(Regex("(?i)\\s*[|\\-–]\\s*(spotify|apple music|deezer|tidal)$"), "").take(120)
        val id = searchId("$q audio") ?: return "lagu tidak ketemu di YouTube"
        if (img.startsWith("http")) CoverHint.m[id] = img
        Resolver.diag = "Musik: '$q' → YouTube $id"
        Chain.run(id, "https://www.youtube.com/watch?v=$id")
        return if (ToolLog.winner.isNotEmpty()) null else "alat YouTube gagal untuk '$q'"
    }
}
