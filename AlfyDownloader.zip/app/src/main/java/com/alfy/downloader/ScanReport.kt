package com.alfy.downloader

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

/** v1.21: scan maksimal semua alat + laporan log detail (bisa disalin) untuk alat yang gagal. */
object ScanReport {
    const val WAIT_MS = 25_000L

    fun start() {
        Scan.maxUntil = System.currentTimeMillis() + 60_000L
        try { AlfyAccessibilityService.inst?.scanNow() } catch (e: Exception) { }
        val pages = listOf(Resolver.lastPage, Resolver.mainPage).filter { it.startsWith("http") }.distinct()
        for (pg in pages) {
            try { Resolver.rescan(pg, null, "Manual 🔍 scan maksimal"); Resolver.sniff(pg, true) } catch (e: Exception) { }
        }
    }

    private fun failed(st: String): Boolean {
        if (st.startsWith("✓") || st.contains("lewati")) return false
        return st.contains("✗") || st.contains("gagal", true) || st.contains("error", true) || st.contains("mati", true) ||
            st.contains("berhenti") || st.contains("⏳") || st.contains("belum") || st.contains("tidak", true) || st.contains("–")
    }

    private val ROLE = mapOf(
        "fxtwitter" to "mengambil video dari link tweet X/Twitter lewat API fxtwitter",
        "Syndication" to "mengambil video tweet lewat API syndication Twitter",
        "yt-dlp" to "ekstraktor utama untuk ribuan situs (butuh URL halaman video yang didukung)",
        "yt-dlp+cookies" to "yt-dlp memakai cookies login (untuk video yang butuh login/bot-check)",
        "ytFast" to "pengambil cepat link YouTube",
        "NewPipe" to "ekstraktor NewPipe (YouTube/SoundCloud/dll)",
        "Piped/Invidious" to "mengambil link YouTube lewat server proksi Piped/Invidious",
        "HLS iOS/VR" to "mengambil stream HLS YouTube memakai klien iOS/VR",
        "WebView" to "memuat halaman di WebView lalu menyadap permintaan media",
        "HTML" to "membaca HTML halaman mencari file .mp4/.m3u8",
        "JWPlayer" to "membaca pemutar JWPlayer (jwplyr/vidoy/overfetch)",
        "OpenGraph" to "membaca meta og:video/JSON-LD memakai UA crawler (Facebook/Twitter/Google)",
        "Situs API" to "API khusus Vimeo, Dailymotion, Reddit, Streamable, TikTok, Facebook, Imgur",
        "JS Deep" to "membaca file JavaScript halaman mencari link media/manifest",
        "Iframe" to "menelusuri iframe/pemutar tertanam (2 tingkat) mencari media",
        "Manifest" to "mencari playlist .m3u8/.mpd dan config JSON pemutar",
        "WebView Pro" to "WebView tersembunyi dengan pengait fetch/XHR, play & scroll otomatis, sadap jaringan (CDN sulit/short-video)",
        "Host Pack" to "pembuka host streaming: Streamtape, Doodstream, Mixdrop, Rumble, OK.ru, VK, Bilibili, Instagram embed, Telegram",
        "Redirect" to "mengikuti link pendek/redirect ke tujuan akhir lalu memindainya",
        "Logcat root" to "membaca logcat (root) mencari link media",
        "tcpdump" to "menyadap lalu lintas jaringan (root)",
        "Media session" to "membaca info media yang sedang diputar aplikasi lain",
        "Clipboard root" to "memantau clipboard (root)",
        "Notifikasi" to "membaca notifikasi pemutar media",
        "Aksesibilitas" to "membaca teks/layar aplikasi lain",
        "Hook pemutar" to "modul LSPosed: menangkap link dari pemutar di dalam aplikasi (TikTok, IG, FB, dll.)",
        "ffmpeg" to "mesin penggabung/konversi (bukan pencari link)"
    )

    private fun cause(n: String, st: String): String {
        val x = st.lowercase()
        val c = ArrayList<String>()
        if ("dimatikan" in x || "dimatikan" in st) c.add("Alat dimatikan di ⚙ (kotak tidak dicentang) → centang lagi.")
        if ("scan dimatikan" in x) c.add("Scan otomatis dimatikan di ⚙ → nyalakan 'Scan otomatis'.")
        if ("login_required" in x || "sign in" in x || "bot" in x || "confirm you" in x) c.add("YouTube/situs menandai IP (VPN) sebagai bot atau meminta login → coba login lewat WebView, ganti server VPN, atau pakai yt-dlp+cookies.")
        if ("unsupported url" in x) c.add("Ekstraktor tidak mengenali URL ini: URL bukan halaman video, atau situsnya belum didukung / halaman embed.")
        if ("no service" in x) c.add("NewPipe tidak punya layanan untuk domain ini (hanya YouTube/SoundCloud/PeerTube dll).")
        if ("403" in x || "forbidden" in x) c.add("Server menolak (403): butuh Referer/cookies/User-Agent yang benar, atau link kedaluwarsa.")
        if ("404" in x || "not found" in x) c.add("Link sudah tidak ada/kedaluwarsa (404) → ambil ulang dari halaman.")
        if ("captcha" in x) c.add("Situs meminta CAPTCHA → selesaikan di browser Alfy lalu scan ulang.")
        if ("timeout" in x || "timed out" in x || "unable to resolve" in x || "unknownhost" in x) c.add("Koneksi lambat/terputus atau DNS gagal (cek VPN/sinyal).")
        if ("root" in x && ("tidak" in x || "ditolak" in x || "belum" in x)) c.add("Izin root belum diberikan/ditolak → beri izin di Magisk/KernelSU.")
        if (n == "Aksesibilitas" && "mati" in x) c.add("Layanan Aksesibilitas belum diaktifkan → aktifkan di Pengaturan > Aksesibilitas.")
        if (n == "Notifikasi" && ("belum" in x || "tidak" in x)) c.add("Akses Notifikasi belum diizinkan → izinkan di pengaturan Akses Notifikasi.")
        if (n == "tcpdump" && "berhenti" in x) c.add("tcpdump berhenti: tidak ada root, binary tidak ada, atau proses dimatikan sistem.")
        if (n == "Media session" && ("belum" in x || "tidak" in x)) c.add("Tidak ada media yang sedang DIPUTAR di aplikasi lain → putar videonya dulu.")
        if (n == "Logcat root" && ("0 link" in x)) c.add("Logcat tidak melihat link: aplikasi tidak mencatat URL di log, atau video belum diputar.")
        if ("⏳" in st && c.isEmpty()) c.add("Alat belum dipicu: tidak ada URL halaman/video yang cocok untuk alat ini di layar saat ini (mungkin memang bukan tugasnya).")
        if (c.isEmpty()) c.add("Tidak dikenali otomatis → lihat teks status di atas.")
        return c.joinToString("\n      ") { "- $it" }.removePrefix("- ").let { "- $it" }
    }

    fun build(): String {
        val sb = StringBuilder()
        val df = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
        sb.append("=== LAPORAN ALAT GAGAL — AlfyDownloader (app Android pengunduh video/audio, Kotlin) ===\n")
        sb.append("Tujuan app: mendeteksi link video/audio dari web/aplikasi lain. Di bawah ini alat yang GAGAL / belum menghasilkan link.\n\n")
        sb.append("[KONTEKS]\n")
        sb.append("Waktu: ").append(df.format(java.util.Date())).append('\n')
        sb.append("Aplikasi di depan: ").append(AlfyAccessibilityService.fgPkg.ifEmpty { "-" }).append('\n')
        sb.append("Halaman terakhir: ").append(Resolver.lastPage.ifEmpty { "-" }).append('\n')
        sb.append("Halaman utama: ").append(Resolver.mainPage.ifEmpty { "-" }).append('\n')
        sb.append("Mode scan: ").append(Scan.modeText()).append('\n')
        sb.append("Tautan terdeteksi: ").append(Repo.detected.value.size).append('\n')
        sb.append("Diagnosa app: ").append(Resolver.diag.ifEmpty { "-" }).append("\n\n")
        val names = ToolLog.chainAll + ToolLog.monAll
        val bad = names.filter { failed(ToolLog.statusOf(it)) }
        sb.append("[ALAT GAGAL: ${bad.size} dari ${names.size}]\n")
        bad.forEachIndexed { i, n ->
            val st = ToolLog.statusOf(n)
            sb.append("\n${i + 1}. ").append(n).append('\n')
            sb.append("   Tugas  : ").append(ROLE[n] ?: "-").append('\n')
            sb.append("   Status : ").append(st).append('\n')
            sb.append("   Kemungkinan penyebab:\n      ").append(cause(n, st)).append('\n')
        }
        if (bad.isEmpty()) sb.append("(semua alat berstatus OK)\n")
        val rj = Resolver.rejects.toList()
        sb.append("\n[PENOLAKAN LINK TERAKHIR]\n")
        if (rj.isEmpty()) sb.append("(tidak ada)\n") else rj.forEach { sb.append("- ").append(it).append('\n') }
        sb.append("\n[SISTEM]\n").append(RootGate.status).append('\n').append(NetSniffer.status).append('\n').append(VpnTool.status).append('\n')
        if (NetSniffer.lastHit.isNotEmpty()) sb.append("Link terakhir (logcat): ").append(NetSniffer.lastHit).append('\n')
        if (Resolver.captchaPage.isNotEmpty()) sb.append("Butuh CAPTCHA di: ").append(Resolver.captchaPage).append('\n')
        return sb.toString()
    }
}

class ReportActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private var tv: TextView? = null
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dm = resources.displayMetrics
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(8)); setBackgroundColor(0xFF262626.toInt()) }
        val title = TextView(this).apply { text = "⚡ Scan maksimal"; textSize = 16f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) }
        val body = TextView(this).apply { textSize = 12f; setTextColor(0xFFE0E0E0.toInt()); setTextIsSelectable(true); text = "Semua alat memindai maksimal… tunggu ${ScanReport.WAIT_MS / 1000} detik, laporan muncul otomatis." }
        tv = body
        val sc = ScrollView(this).apply { addView(body) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        fun btn(t: String, f: () -> Unit) = TextView(this).apply {
            text = t; textSize = 13f; setTextColor(0xFF80CBC4.toInt()); setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(dp(10), dp(12), dp(10), dp(12)); setOnClickListener { f() }
        }
        fun copy() {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("laporan", ScanReport.build()))
            Toast.makeText(this, "Log alat gagal disalin", Toast.LENGTH_SHORT).show()
        }
        row.addView(btn("SALIN LOG GAGAL") { copy() })
        row.addView(btn("ULANG") { h.removeCallbacksAndMessages(null); ScanReport.start(); body.text = "Memindai ulang…"; schedule() })
        row.addView(btn("TUTUP") { finish() })
        root.addView(title)
        root.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(row)
        setContentView(root, ViewGroup.LayoutParams((dm.widthPixels * 0.94).toInt(), (dm.heightPixels * 0.8).toInt()))
        window.setLayout((dm.widthPixels * 0.94).toInt(), (dm.heightPixels * 0.8).toInt())
        ScanReport.start()
        schedule()
    }

    private fun schedule() {
        h.postDelayed({ tv?.text = ScanReport.build() }, ScanReport.WAIT_MS)
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }
}
