package com.alfy.downloader

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

/** v1.21: scan maksimal semua alat. Laporan jujur & ringkas: singkat = hanya tool gagal + alasan; lengkap = tabel Nama | Status | Alasan. */
object ScanReport {
    const val WAIT_MS = 25_000L

    fun start() {
        Scan.maxUntil = System.currentTimeMillis() + 60_000L
        try { AlfyAccessibilityService.inst?.scanNow(true) } catch (e: Exception) { }
        val pages = listOf(Resolver.lastPage, Resolver.mainPage).filter { it.startsWith("http") }.distinct()
        for (pg in pages) {
            try { Resolver.rescan(pg, null, "Manual 🔍 scan maksimal"); Resolver.sniff(pg, true) } catch (e: Exception) { }
        }
    }

    /** Cakupan tool yang hanya berlaku untuk situs tertentu. */
    private val SCOPE: Map<String, String> = mapOf(
        "fxtwitter" to "Khusus X/Twitter", "Syndication" to "Khusus X/Twitter",
        "yt-dlp+cookies" to "Khusus YouTube", "ytFast" to "Khusus YouTube", "Piped/Invidious" to "Khusus YouTube", "HLS iOS/VR" to "Khusus YouTube",
        "Spotify Match" to "Khusus layanan musik", "JWPlayer" to "Khusus jwplyr/vidoy/overfetch"
    )

    private fun cls(n: String): String = when (ToolStatus.state(n)) {
        ToolStatus.St.OK -> "BERHASIL"
        ToolStatus.St.FAIL -> "GAGAL"
        ToolStatus.St.SCAN -> "SIAGA/BELUM SELESAI"
        ToolStatus.St.OFF -> if (!Tool.on(n)) "DINONAKTIFKAN PENGGUNA" else if (ToolLog.statusOf(n).contains("lewati")) "DILEWATI" else "MENUNGGU"
    }

    private fun siteKind(page: String): String {
        if (page.isEmpty() || page == "-") return "tidak diketahui (belum ada halaman terdeteksi)"
        val h = try { android.net.Uri.parse(page).host?.lowercase() ?: "" } catch (e: Exception) { "" }
        return when {
            h.contains("youtube.com") || h.contains("youtu.be") -> "YouTube (video/Shorts/musik)"
            h == "x.com" || h.endsWith(".x.com") || h.endsWith("twitter.com") -> "X/Twitter"
            h.endsWith("jwplyr.com") || h.endsWith("overfetch.video") || h.endsWith("vidoy.asia") || h.endsWith("vidoy.com") -> "situs stream JW Player (jwplyr/vidoy/overfetch; banyak iklan & CAPTCHA)"
            MusicMap.matches(page) -> "layanan musik berDRM (Spotify/Apple Music/Deezer dll)"
            else -> "situs/aplikasi lain (host: $h)"
        }
    }

    // ---------- v1.52: diagnosa sebab gagal PASTI (singkat) ----------
    private val ROOT_TOOLS = setOf("Logcat root", "tcpdump", "Media session", "Clipboard root")

    private fun svcEnabled(setting: String): Boolean = try {
        val v = android.provider.Settings.Secure.getString(Repo.app.contentResolver, setting) ?: ""
        v.contains(Repo.app.packageName)
    } catch (e: Throwable) { false }

    private fun vpnState(): String = try {
        val cm = Repo.app.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val nw = cm.activeNetwork
        val caps = if (nw != null) cm.getNetworkCapabilities(nw) else null
        if (caps == null) "TIDAK ADA jaringan"
        else (if (caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN)) "VPN aktif" else "tanpa VPN") +
            (if (caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)) ", internet OK" else ", internet BELUM tervalidasi")
    } catch (e: Throwable) { "tidak terbaca" }

    private fun notApplicable(n: String, page: String): String? {
        if (page.isEmpty()) return null
        val sc = SCOPE[n] ?: return null
        val kind = siteKind(page)
        return when {
            sc.startsWith("Khusus YouTube") && !kind.startsWith("YouTube") -> "tool khusus YouTube, target: $kind"
            sc.startsWith("Khusus X") && kind != "X/Twitter" -> "tool khusus X/Twitter, target: $kind"
            sc.startsWith("Khusus jwplyr") && !kind.startsWith("situs stream JW") -> "tool khusus jwplyr/vidoy, target: $kind"
            sc.startsWith("Khusus layanan musik") && !kind.startsWith("layanan musik") -> "tool khusus Spotify/Apple Music dll, target: $kind"
            else -> null
        }
    }

    private fun cut(s: String, n: Int): String { val t = s.replace("\n", " ").trim(); return if (t.length > n) t.substring(0, n) + "…" else t }

    // ================================================================
    // PENERJEMAH ERROR: log mentah -> kalimat jujur singkat
    // ================================================================
    private val R403 = Regex("\\b403\\b"); private val R404 = Regex("\\b404\\b"); private val R401 = Regex("\\b401\\b")
    private val R429 = Regex("\\b429\\b"); private val R5XX = Regex("\\b50[0-4]\\b")

    /** null = tidak dikenali. */
    fun translate(raw: String): String? {
        val x = raw.lowercase()
        if (x.isBlank()) return null
        return when {
            R403.containsMatchIn(x) || "forbidden" in x -> "Situs menolak akses (403)"
            R404.containsMatchIn(x) || "not found" in x || "kedaluwarsa" in x -> "Link sudah tidak ada/kedaluwarsa (404)"
            R401.containsMatchIn(x) || "unauthorized" in x -> "Situs minta login (401)"
            R429.containsMatchIn(x) || "too many requests" in x -> "Terlalu banyak permintaan (429)"
            R5XX.containsMatchIn(x) || "server bermasalah" in x -> "Server situs bermasalah (5xx)"
            "captcha" in x -> "Situs meminta CAPTCHA"
            "login_required" in x || "sign in" in x || "not a bot" in x || "confirm you" in x || "minta login" in x -> "Situs minta login / menandai sebagai bot"
            "timeout" in x || "timed out" in x || "koneksi lambat" in x -> "Koneksi lambat (timeout)"
            "unable to resolve" in x || "unknownhost" in x || "no address associated" in x || "dns" in x -> "Gagal menyambung ke server (DNS)"
            "connection reset" in x || "refused" in x || "ssl" in x || "handshake" in x || "unexpected end" in x || "eof" in x || "broken pipe" in x || "terputus" in x -> "Koneksi terputus"
            "unsupported url" in x || "tidak didukung" in x || "no service" in x -> "Situs/URL tidak didukung"
            "enospc" in x || "no space" in x || "penyimpanan penuh" in x -> "Penyimpanan penuh"
            "eacces" in x || "permission denied" in x || "izin ditolak" in x -> "Izin ditolak"
            "range" in x && ("support" in x || "didukung" in x) -> "Server tidak mendukung lanjut unduh"
            "ffmpeg" in x -> "Gagal memproses video (ffmpeg)"
            else -> null
        }
    }

    /** Selalu mengembalikan satu kalimat pendek (tidak pernah log mentah panjang). */
    fun honest(raw: String?): String {
        val r = (raw ?: "").trim()
        if (r.isEmpty()) return "Penyebab tidak diketahui"
        return translate(r) ?: cut(r.lineSequence().first(), 60)
    }

    /** Alasan jujur satu baris untuk satu tool, sesuai kondisi nyata app. */
    internal fun reason(n: String): String {
        val st = ToolLog.statusOf(n)
        val page = Resolver.lastPage.ifEmpty { Resolver.mainPage }
        return when (ToolStatus.state(n)) {
            ToolStatus.St.OK -> if (n in ToolLog.chainAll) "Video/musik ditemukan" else "Aktif"
            ToolStatus.St.SCAN -> "Masih memindai"
            ToolStatus.St.OFF -> if (!Tool.on(n)) "Dimatikan di pengaturan" else if (st.contains("lewati")) "Dilewati (video sudah ditemukan tool lain)" else "Menunggu (belum dipicu)"
            ToolStatus.St.FAIL -> failReason(n, st, page)
        }
    }

    private fun failReason(n: String, st: String, page: String): String {
        if (n in ToolLog.chainAll && !Scan.enabled()) return "Scan otomatis dimatikan"
        if (notApplicable(n, page) != null) return "Tidak berlaku untuk situs ini"
        if (n in ROOT_TOOLS) when (RootGate.state) {
            0 -> return "Izin root belum diminta"
            1 -> return "Menunggu jawaban izin root"
            3 -> return "Izin root ditolak"
        }
        if (n == "yt-dlp+cookies" && RootGate.state != 2) return "Izin root belum diberikan"
        if ((n == "yt-dlp" || n == "yt-dlp+cookies") && !Engine.ready) return "Mesin yt-dlp belum siap"
        when (n) {
            "Aksesibilitas" -> if (AlfyAccessibilityService.inst == null) return if (svcEnabled("enabled_accessibility_services")) "Layanan mati (dimatikan sistem)" else "Aksesibilitas belum diaktifkan"
            "Notifikasi" -> if (!AlfyNotifService.status.startsWith("✓")) return if (svcEnabled("enabled_notification_listeners")) "Layanan mati (dimatikan sistem)" else "Akses Notifikasi belum diizinkan"
            "tcpdump" -> {
                if (NetSniffer.dumpStat.contains("tidak ada")) return "Alat tcpdump tidak ada di HP"
                if (NetSniffer.dumpStat.contains("berhenti")) return "Proses tcpdump berhenti"
            }
            "Logcat root" -> if (NetSniffer.logStat.contains("berhenti")) return "Logcat terputus"
            "Clipboard root" -> if (NetSniffer.clipStat.contains("tidak mendukung")) return "ROM tidak mendukung baca clipboard"
            "ffmpeg" -> if (Engine.ffmpeg.startsWith("✗")) return "Mesin ffmpeg gagal dimuat"
            "Hook pemutar" -> if (NetSniffer.hookHits <= 0) return "Modul LSPosed belum aktif"
        }
        val net = vpnState()
        if (n in ToolLog.chainAll && (net.startsWith("TIDAK ADA") || net.contains("BELUM"))) return "Tidak ada internet"
        return translate(st) ?: "Tidak menemukan video di situs ini"
    }

    private fun statusWord(n: String): String = when (cls(n)) {
        "BERHASIL" -> "Berhasil"
        "GAGAL" -> "Gagal"
        "SIAGA/BELUM SELESAI" -> "Siaga"
        "DINONAKTIFKAN PENGGUNA" -> "Nonaktif"
        "DILEWATI" -> "Dilewati"
        else -> "Menunggu"
    }

    /**
     * all=false: laporan SINGKAT — hanya tool GAGAL, 1 baris per tool ("Nama: alasan").
     * all=true : laporan LENGKAP — tabel Nama Tool | Status | Alasan Jujur untuk semua tool.
     * only != null: hanya satu tool (📋 per tool).
     */
    fun build(all: Boolean = false, only: String? = null): String {
        val names = ToolLog.chainAll + ToolLog.monAll
        val sb = StringBuilder()
        if (all) {
            val w = names.maxOf { it.length }
            val sw = 8
            sb.append("Nama Tool".padEnd(w)).append(" | ").append("Status".padEnd(sw)).append(" | Alasan Jujur\n")
            sb.append("-".repeat(w)).append("-+-").append("-".repeat(sw)).append("-+-").append("-".repeat(20)).append('\n')
            for (n in names) sb.append(n.padEnd(w)).append(" | ").append(statusWord(n).padEnd(sw)).append(" | ").append(reason(n)).append('\n')
            return sb.toString()
        }
        if (only != null) {
            return if (cls(only) == "GAGAL") "$only: ${reason(only)}" else "$only tidak gagal (${statusWord(only)}: ${reason(only)})"
        }
        val failed = names.filter { cls(it) == "GAGAL" }
        if (failed.isEmpty()) return "Tidak ada tool yang gagal."
        for (n in failed) sb.append(n).append(": ").append(reason(n)).append('\n')
        return sb.toString().trimEnd()
    }
}

class ReportActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private var tv: TextView? = null
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dm = resources.displayMetrics
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(8)); setBackgroundColor(0xFF262626.toInt()) }
        val title = TextView(this).apply { text = "⚡ Scan maksimal"; textSize = 16f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) }
        val body = TextView(this).apply { typeface = android.graphics.Typeface.MONOSPACE; textSize = 11f; setTextColor(0xFFE0E0E0.toInt()); setTextIsSelectable(true); text = "Semua alat memindai maksimal… tunggu ${ScanReport.WAIT_MS / 1000} detik, laporan muncul otomatis." }
        tv = body
        val sc = ScrollView(this).apply { addView(body) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        fun btn(t: String, f: () -> Unit) = TextView(this).apply {
            text = t; textSize = 13f; setTextColor(0xFF80CBC4.toInt()); setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(dp(10), dp(12), dp(10), dp(12)); setOnClickListener { f() }
        }
        fun copy() {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("laporan semua alat", ScanReport.build(true)))
            Toast.makeText(this, "Laporan lengkap disalin", Toast.LENGTH_SHORT).show()
        }
        row.addView(btn("SALIN SEMUA LOG") { copy() })
        row.addView(btn("ULANG") { h.removeCallbacksAndMessages(null); ScanReport.start(); body.text = "Memindai ulang…"; schedule() })
        row.addView(btn("TUTUP") { finish() })
        root.addView(title)
        root.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(row)
        setContentView(root, ViewGroup.LayoutParams((dm.widthPixels * 0.94).toInt(), (dm.heightPixels * 0.8).toInt()))
        window.setLayout((dm.widthPixels * 0.94).toInt(), (dm.heightPixels * 0.8).toInt())
        ScanReport.start()
        schedule()
    }

    private fun schedule() {
        h.postDelayed({ tv?.text = ScanReport.build(true) }, ScanReport.WAIT_MS)
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }
}
