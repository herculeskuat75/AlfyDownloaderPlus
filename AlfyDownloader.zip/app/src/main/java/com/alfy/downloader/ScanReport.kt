package com.alfy.downloader

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

/** v1.21: scan maksimal semua alat. v1.50: laporan disusun sebagai prompt lengkap untuk AI (instruksi, profil app, lingkungan, katalog tool, detail gagal). */
object ScanReport {
    const val WAIT_MS = 25_000L

    fun start() {
        Scan.maxUntil = System.currentTimeMillis() + 60_000L
        try { AlfyAccessibilityService.inst?.scanNow() } catch (e: Exception) { }
        val pages = listOf(Resolver.lastPage, Resolver.mainPage).filter { it.startsWith("http") }.distinct()
        for (pg in pages) {
            try { Resolver.rescan(pg, null, "Manual 🔍 scan maksimal"); Resolver.sniff(pg, true) } catch (e: Exception) { }
        }
    }

    internal val ROLE = mapOf(
        "fxtwitter" to "mengambil video dari link tweet X/Twitter lewat API fxtwitter",
        "Syndication" to "mengambil video tweet lewat API syndication Twitter",
        "yt-dlp" to "ekstraktor utama untuk ribuan situs (butuh URL halaman video yang didukung)",
        "yt-dlp+cookies" to "yt-dlp memakai cookies login (untuk video yang butuh login/bot-check)",
        "ytFast" to "pengambil cepat link YouTube",
        "NewPipe" to "ekstraktor NewPipe (YouTube/SoundCloud/dll)",
        "Piped/Invidious" to "mengambil link YouTube lewat server proksi Piped/Invidious",
        "HLS iOS/VR" to "mengambil stream HLS YouTube memakai klien iOS/VR",
        "WebView" to "memuat halaman di WebView lalu menyadap permintaan media",
        "HTML" to "membaca HTML halaman mencari file .mp4/.m3u8",
        "JWPlayer" to "membaca pemutar JWPlayer (jwplyr/vidoy/overfetch)",
        "OpenGraph" to "membaca meta og:video/JSON-LD memakai UA crawler (Facebook/Twitter/Google)",
        "Situs API" to "API khusus Vimeo, Dailymotion, Reddit, Streamable, TikTok, Facebook, Imgur",
        "JS Deep" to "membaca file JavaScript halaman mencari link media/manifest",
        "Iframe" to "menelusuri iframe/pemutar tertanam (2 tingkat) mencari media",
        "Manifest" to "mencari playlist .m3u8/.mpd dan config JSON pemutar",
        "WebView Pro" to "WebView tersembunyi dengan pengait fetch/XHR, play & scroll otomatis, sadap jaringan (CDN sulit/short-video)",
        "Host Pack" to "pembuka host streaming: Streamtape, Doodstream, Mixdrop, Rumble, OK.ru, VK, Bilibili, Instagram embed, Telegram",
        "Redirect" to "mengikuti link pendek/redirect ke tujuan akhir lalu memindainya",
        "Logcat root" to "membaca logcat (root) mencari link media",
        "tcpdump" to "menyadap lalu lintas jaringan (root)",
        "Media session" to "membaca info media yang sedang diputar aplikasi lain",
        "Clipboard root" to "memantau clipboard (root)",
        "Notifikasi" to "membaca notifikasi pemutar media",
        "Aksesibilitas" to "membaca teks/layar aplikasi lain",
        "Hook pemutar" to "modul LSPosed: menangkap link dari pemutar di dalam aplikasi (TikTok, IG, FB, dll.)",
        "ffmpeg" to "mesin penggabung/konversi (bukan pencari link)",
        "Spotify Match" to "untuk link Spotify/Apple Music/Deezer/Tidal dll (berDRM): baca judul+artis dari halaman, cari lagu yang sama di YouTube, lalu jalankan rantai alat YouTube"
    )

    internal fun cause(n: String, st: String): String {
        val x = st.lowercase()
        val c = ArrayList<String>()
        if ("dimatikan" in x || "dimatikan" in st) c.add("Alat dimatikan di ⚙ (kotak tidak dicentang) → centang lagi.")
        if ("scan dimatikan" in x) c.add("Scan otomatis dimatikan di ⚙ → nyalakan 'Scan otomatis'.")
        if ("login_required" in x || "sign in" in x || "bot" in x || "confirm you" in x) c.add("YouTube/situs menandai IP (VPN) sebagai bot atau meminta login → coba login lewat WebView, ganti server VPN, atau pakai yt-dlp+cookies.")
        if ("unsupported url" in x) c.add("Ekstraktor tidak mengenali URL ini: URL bukan halaman video, atau situsnya belum didukung / halaman embed.")
        if ("no service" in x) c.add("NewPipe tidak punya layanan untuk domain ini (hanya YouTube/SoundCloud/PeerTube dll).")
        if ("403" in x || "forbidden" in x) c.add("Server menolak (403): butuh Referer/cookies/User-Agent yang benar, atau link kedaluwarsa.")
        if ("404" in x || "not found" in x) c.add("Link sudah tidak ada/kedaluwarsa (404) → ambil ulang dari halaman.")
        if ("captcha" in x) c.add("Situs meminta CAPTCHA → selesaikan di browser Alfy lalu scan ulang.")
        if ("timeout" in x || "timed out" in x || "unable to resolve" in x || "unknownhost" in x) c.add("Koneksi lambat/terputus atau DNS gagal (cek VPN/sinyal).")
        if ("root" in x && ("tidak" in x || "ditolak" in x || "belum" in x)) c.add("Izin root belum diberikan/ditolak → beri izin di Magisk/KernelSU.")
        if (n == "Aksesibilitas" && "mati" in x) c.add("Layanan Aksesibilitas belum diaktifkan → aktifkan di Pengaturan > Aksesibilitas.")
        if (n == "Notifikasi" && ("belum" in x || "tidak" in x)) c.add("Akses Notifikasi belum diizinkan → izinkan di pengaturan Akses Notifikasi.")
        if (n == "tcpdump" && "berhenti" in x) c.add("tcpdump berhenti: tidak ada root, binary tidak ada, atau proses dimatikan sistem.")
        if (n == "Media session" && ("belum" in x || "tidak" in x)) c.add("Tidak ada media yang sedang DIPUTAR di aplikasi lain → putar videonya dulu.")
        if (n == "Logcat root" && ("0 link" in x)) c.add("Logcat tidak melihat link: aplikasi tidak mencatat URL di log, atau video belum diputar.")
        if ("⏳" in st && c.isEmpty()) c.add("Alat belum dipicu: tidak ada URL halaman/video yang cocok untuk alat ini di layar saat ini (mungkin memang bukan tugasnya).")
        if (c.isEmpty()) c.add("Tidak dikenali otomatis → lihat teks status di atas.")
        return c.joinToString("\n      ") { "- $it" }.removePrefix("- ").let { "- $it" }
    }

    // ================================================================
    // v1.50: LAPORAN UNTUK AI (Claude) — prompt lengkap + konteks + katalog semua tool + detail tool gagal
    // ================================================================

    /** Rincian teknis per tool supaya AI penganalisis tahu persis kode mana yang harus diperiksa. */
    internal class Info(val impl: String, val trigger: String, val ok: String, val risk: String, val scope: String = "Semua situs yang cocok")

    internal val INFO: Map<String, Info> = mapOf(
        "fxtwitter" to Info(
            "SiteTool.xApi(page, 1) di SiteTool.kt; memanggil api.fxtwitter.com (cadangan api.vxtwitter.com)",
            "Halaman x.com/twitter.com atau ID tweet yang terbaca di logcat (Resolver.submitTweet)",
            "JSON memuat media.videos[].url dan link lolos uji (Resolver.addMediaChecked)",
            "Tweet tanpa video / dihapus / dilindungi; API pihak ketiga down, rate limit, atau diblokir; timeout API 4,5 dtk lewat VPN lambat",
            "Khusus X/Twitter"),
        "Syndication" to Info(
            "SiteTool.xApi(page, 2) di SiteTool.kt; memanggil cdn.syndication.twimg.com",
            "Halaman x.com/twitter.com",
            "Respons syndication memuat varian video mp4/m3u8 yang lolos uji",
            "Endpoint berubah/dibatasi; tweet sensitif/tanpa video; timeout lewat VPN",
            "Khusus X/Twitter"),
        "yt-dlp" to Info(
            "Resolver.ytdlpTool(page, null) di Resolver.kt; library youtubedl-android (yt-dlp, 6 klien YouTube, --force-ipv4); mesin diinisialisasi & diperbarui di AlfyApp (updateEngine)",
            "Setiap halaman video yang dipindai (YouTube selalu; situs lain lewat Chain.runGeneric)",
            "yt-dlp mengembalikan format dan Resolver menambahkannya sebagai kandidat",
            "LOGIN_REQUIRED / Sign in to confirm you're not a bot (IP VPN ditandai); Unsupported URL (bukan halaman video/embed); yt-dlp usang; mesin belum siap (Engine.ready); dibatalkan paksa pada batas 10 dtk (ScanLimit) lewat VPN lambat"),
        "yt-dlp+cookies" to Info(
            "Tools.kt: cookiesTool(page) + object Cookies (WebView login UA Firefox + cookies root dari Firefox/Chromium) lalu yt-dlp --cookies",
            "Halaman YouTube",
            "yt-dlp berhasil memakai cookies login",
            "Pengguna belum login lewat WebView; cookies kedaluwarsa/tidak ada; root ditolak (cookies Firefox/Chromium tak terbaca); DB cookies Chromium terenkripsi; akun/IP tetap kena bot-check",
            "Khusus YouTube"),
        "ytFast" to Info(
            "Resolver.ytFast(id, w) di Resolver.kt; API pemutar YouTube klien ANDROID_VR (1.62.27, 1.60.19) dan IOS dicoba serentak; tiap link diuji Resolver.probePlay (Range awal + potongan ~6MB)",
            "Halaman YouTube dengan ID video",
            "Minimal satu link audio+video yang lolos probePlay",
            "LOGIN_REQUIRED/bot-check karena IP VPN; versi klien iOS/VR usang; link butuh PO Token (lolos potongan pertama, 403 setelahnya); respons tanpa format (tanpa link)",
            "Khusus YouTube"),
        "NewPipe" to Info(
            "Tools.kt: object NP (NP.fetch(id) untuk YouTube, NP.fetchAny(page) untuk situs lain); NewPipeExtractor v0.26.5 via JitPack, dipanggil lewat refleksi",
            "Halaman YouTube / SoundCloud / PeerTube / situs yang didukung NewPipe",
            "Extractor mengembalikan stream video/audio yang diterima Resolver",
            "'no service' untuk domain tak didukung; extractor usang terhadap perubahan situs; bot-check/ReCaptcha; refleksi/proguard menghapus kelas; timeout 8/9 dtk"),
        "Piped/Invidious" to Info(
            "Tools.kt: object Inst (Inst.fetch(id)); daftar server Piped/Invidious diambil dinamis lalu dicoba paralel",
            "Halaman YouTube",
            "Satu server mengembalikan stream yang diproksikan",
            "Server publik mati/rate limit/diblokir; link proksi 403; daftar server tidak terunduh lewat VPN",
            "Khusus YouTube"),
        "HLS iOS/VR" to Info(
            "Resolver.youtubeFallback(id, page) di Resolver.kt; mengambil manifest HLS dari klien iOS/VR",
            "Halaman YouTube (cadangan; dilewati bila sudah ada hasil)",
            "Manifest m3u8 valid ditambahkan sebagai kandidat",
            "Bot-check; klien usang; manifest kosong/live-only",
            "Khusus YouTube"),
        "WebView" to Info(
            "Tools.kt: object WebTool (WebTool.grab(id) untuk YouTube; WebTool.grabPage(page) untuk situs lain); WebView tersembunyi menyadap request media",
            "Halaman YouTube atau situs apa pun yang dipindai",
            "Request media (googlevideo/videoplayback atau .mp4/.m3u8) tertangkap DAN lolos Resolver.addMediaChecked",
            "Halaman butuh interaksi/CAPTCHA/login; media dimuat setelah klik play; link iklan/host lain ditolak filter; googlevideo dengan dur= tidak cocok durasi video; batas waktu ScanLimit; getUrl() di thread jaringan (targetSdk 28)"),
        "HTML" to Info(
            "Resolver.sniffSync(page) di Resolver.kt; mengunduh HTML lalu mencari URL media (.mp4/.m3u8 dll)",
            "Mode agresif untuk YouTube; selalu untuk situs lain",
            "sniffSync > 0 (ada media di HTML)",
            "Situs dirender lewat JavaScript (HTML kosong); butuh Referer/cookies/UA tertentu; CAPTCHA; link dalam JSON terenkripsi"),
        "Spotify Match" to Info(
            "MusicMap.kt: MusicMap.matches(page) + MusicMap.run(page); membaca judul+artis dari meta halaman, mencari di YouTube, lalu menjalankan rantai YouTube",
            "Host Spotify/Apple Music/Deezer/Tidal/Amazon Music/dll",
            "Lagu yang sama ditemukan di YouTube dan rantai YouTube menghasilkan link",
            "Meta halaman tidak terbaca (halaman dirender JS); pencarian YouTube salah lagu/tidak ada; rantai YouTube sendiri kena bot-check",
            "Khusus layanan musik berDRM"),
        "JWPlayer" to Info(
            "SiteTool.jw(page) di SiteTool.kt; baca HTML + iframe /e/ID /v/ID, buka kemasan JS p,a,c,k,e,d dan base64, uji tiap kandidat",
            "Host jwplyr.com, *.overfetch.video, vidoy.asia/com (otomatis) atau mode agresif",
            "Ada URL video milik host situs (overfetch.video dll) yang lolos uji",
            "Halaman iklan 'Confirm you're not a robot' / CAPTCHA Cloudflare Turnstile; hanya menemukan gambar/HTML; link bertanda tangan & kedaluwarsa (/s/TOKEN/EXPIRE/i/ID); Referer salah (harus vidoy.asia/jwplyr.com); filter iklan terlalu ketat",
            "Khusus jwplyr/vidoy/overfetch"),
        "OpenGraph" to Info(
            "MoreTools.openGraph(page) di MoreTools.kt; membaca og:video / twitter:player / JSON-LD dengan UA crawler (Facebook/Twitter/Google)",
            "Situs non-YouTube",
            "Meta og:video atau JSON-LD VideoObject memuat URL media langsung",
            "Situs tidak menyediakan meta untuk crawler; URL meta berupa halaman embed, bukan file media; login wajib"),
        "Situs API" to Info(
            "MoreTools.siteApi(page) di MoreTools.kt; API khusus Vimeo, Dailymotion, Reddit, Streamable, TikTok, Facebook, Imgur",
            "Host yang dikenali saja",
            "API situs mengembalikan URL media",
            "Endpoint publik berubah/dibatasi; TikTok/Facebook butuh login/token; host tidak dikenali (tool tidak berlaku)",
            "Khusus host tertentu"),
        "JS Deep" to Info(
            "MoreTools.jsDeep(page) di MoreTools.kt; mengunduh file JavaScript halaman dan mencari link media/manifest",
            "Situs non-YouTube",
            "Ditemukan URL media/manifest di dalam JS",
            "URL dibentuk dinamis/dienkripsi; JS besar melebihi batas; file JS butuh Referer/cookies"),
        "Iframe" to Info(
            "MoreTools.iframe(page) di MoreTools.kt; menelusuri iframe/pemutar tertanam sampai 2 tingkat",
            "Situs non-YouTube",
            "Iframe turunan memuat URL media",
            "Iframe dimuat lewat JS setelah interaksi; iframe lintas-origin butuh Referer induk; lebih dari 2 tingkat"),
        "Manifest" to Info(
            "MoreTools.manifest(page) di MoreTools.kt; mencari .m3u8/.mpd dan config JSON pemutar",
            "Situs non-YouTube",
            "Manifest valid ditemukan dan lolos uji",
            "Manifest bertanda tangan/kedaluwarsa; butuh header khusus; DRM (tidak bisa diunduh)"),
        "Redirect" to Info(
            "MoreTools.redirect(page) di MoreTools.kt; mengikuti link pendek/redirect ke tujuan akhir lalu memindainya",
            "Link pendek (bit.ly, t.co, dll) atau halaman yang meredirect",
            "Tujuan akhir ditemukan lalu memicu pemindaian ulang",
            "Redirect lewat JavaScript/meta refresh; halaman interstitial iklan; tidak ada redirect (tool tidak berlaku)",
            "Khusus link pendek/redirect"),
        "WebView Pro" to Info(
            "MoreTools.webPro(page) di MoreTools.kt (+ extras/DocStartHook.kt: skrip suntik sebelum halaman jalan); WebView tersembunyi dengan pengait fetch/XHR, play & scroll otomatis",
            "Situs non-YouTube sulit (CDN sulit / short-video)",
            "Request media atau currentSrc video tertangkap dan lolos addMediaChecked",
            "CAPTCHA/login; autoplay diblokir; DocStartHook tidak didukung WebView perangkat (install() false); batas waktu ScanLimit"),
        "Host Pack" to Info(
            "MoreTools.hostPack(page) di MoreTools.kt; pembuka host Streamtape, Doodstream, Mixdrop, Rumble, OK.ru, VK, Bilibili, Instagram embed, Telegram",
            "Host yang dikenali saja",
            "Pembuka host mengembalikan URL media",
            "Pola host berubah; token sementara; host tidak dikenali (tool tidak berlaku)",
            "Khusus host tertentu"),
        "Logcat root" to Info(
            "NetSniffer.kt: pembaca logcat via root (RootGate); NetSniffer.feed memproses URL media",
            "Terus-menerus di latar belakang bila root diizinkan",
            "logStat '✓ aktif' dan penghitung link > 0",
            "Root ditolak/tidak tersedia; logcat putus; aplikasi tidak mencatat URL di log; Scan.ytLock membuang link saat YouTube di depan (mode normal)",
            "Pemantau latar (butuh root)"),
        "tcpdump" to Info(
            "NetSniffer.kt: dump HTTP polos lewat tcpdump (root)",
            "Terus-menerus bila binary tcpdump ada",
            "dumpStat '✓ aktif' dan penghitung permintaan > 0",
            "Binary tcpdump tidak ada di HP; root ditolak; HTTPS tidak terbaca (hanya HTTP polos); VPN mengenkripsi lalu lintas; proses dimatikan sistem",
            "Pemantau latar (butuh root)"),
        "Media session" to Info(
            "NetSniffer.kt: dumpsys media_session tiap 1 dtk (root); memicu AutoScan.onPlay(pkg)",
            "Saat aplikasi lain memutar media (state=3)",
            "mediaStat '✓ aktif • memutar: <paket>' lalu AutoScan berjalan",
            "Root ditolak; tidak ada media yang sedang diputar; format keluaran dumpsys berbeda di ROM ini",
            "Pemantau latar (butuh root)"),
        "Clipboard root" to Info(
            "NetSniffer.kt: baca clipboard lewat perintah root",
            "Saat ada tanda tautan disalin",
            "clipStat '✓ aktif' dan URL clipboard terbaca",
            "Perintah baca clipboard tidak didukung ROM/Android versi ini; root ditolak; Android 10+ membatasi akses clipboard latar",
            "Pemantau latar (butuh root)"),
        "Notifikasi" to Info(
            "AlfyNotifService.kt (NotificationListenerService); membaca notifikasi MediaSession (judul+channel) tanpa root",
            "Saat aplikasi pemutar menampilkan notifikasi media",
            "AlfyNotifService.status '✓' dan judul/channel terbaca",
            "Akses Notifikasi belum diizinkan; layanan dimatikan sistem (penghemat baterai); aplikasi tidak menampilkan notifikasi media",
            "Layanan Android"),
        "Aksesibilitas" to Info(
            "AlfyAccessibilityService.kt; membaca teks/layar semua aplikasi (URL, judul, tombol), autoPlay, scanNow",
            "Setiap perubahan layar (interval pindai ~800 ms)",
            "AlfyAccessibilityService.inst tidak null (✓ aktif)",
            "Layanan belum diaktifkan di Pengaturan > Aksesibilitas; dimatikan sistem/ROM; aplikasi memblokir pembacaan layar",
            "Layanan Android"),
        "ffmpeg" to Info(
            "AlfyApp.kt: FFmpeg.getInstance().init() (io.github.junkfood02.youtubedl-android:ffmpeg); dipakai DownloadService.remuxMp4 untuk HLS/m3u8",
            "Saat mengunduh HLS/m3u8 atau menggabung audio+video",
            "Engine.ffmpeg '✓ siap'",
            "Init gagal (binary/ABI tidak cocok); ruang penyimpanan; bukan alat pencari link sehingga status gagal tidak memengaruhi pendeteksian",
            "Mesin penggabung (bukan pencari link)"),
        "Hook pemutar" to Info(
            "hook/HookEntry.java (modul LSPosed, stub API di app/xposed-stub); menangkap link dari pemutar di dalam aplikasi (TikTok, IG, FB, dll)",
            "Aplikasi target yang dicentang di LSPosed dan dimulai ulang",
            "NetSniffer.hookHits > 0",
            "Modul belum diaktifkan di LSPosed / target belum dipilih / aplikasi belum dimulai ulang; ROM/LSPosed tidak kompatibel",
            "Modul LSPosed (opsional)")
    )

    private fun group(n: String): String = if (n in ToolLog.chainAll) "Pemindai link" else "Pemantau latar/layanan"

    private fun cls(n: String): String = when (ToolStatus.state(n)) {
        ToolStatus.St.OK -> "BERHASIL"
        ToolStatus.St.FAIL -> "GAGAL"
        ToolStatus.St.SCAN -> "SIAGA/BELUM SELESAI"
        ToolStatus.St.OFF -> if (!Tool.on(n)) "DINONAKTIFKAN PENGGUNA" else if (ToolLog.statusOf(n).contains("lewati")) "DILEWATI" else "MENUNGGU"
    }

    private fun siteKind(page: String): String {
        if (page.isEmpty() || page == "-") return "tidak diketahui (belum ada halaman terdeteksi)"
        val h = try { android.net.Uri.parse(page).host?.lowercase() ?: "" } catch (e: Exception) { "" }
        return when {
            h.contains("youtube.com") || h.contains("youtu.be") -> "YouTube (video/Shorts/musik)"
            h == "x.com" || h.endsWith(".x.com") || h.endsWith("twitter.com") -> "X/Twitter"
            h.endsWith("jwplyr.com") || h.endsWith("overfetch.video") || h.endsWith("vidoy.asia") || h.endsWith("vidoy.com") -> "situs stream JW Player (jwplyr/vidoy/overfetch; banyak iklan & CAPTCHA)"
            MusicMap.matches(page) -> "layanan musik berDRM (Spotify/Apple Music/Deezer dll)"
            else -> "situs/aplikasi lain (host: $h)"
        }
    }

    // ---------- v1.52: diagnosa sebab gagal PASTI (singkat) ----------
    private val ROOT_TOOLS = setOf("Logcat root", "tcpdump", "Media session", "Clipboard root")

    private fun svcEnabled(setting: String): Boolean = try {
        val v = android.provider.Settings.Secure.getString(Repo.app.contentResolver, setting) ?: ""
        v.contains(Repo.app.packageName)
    } catch (e: Throwable) { false }

    private fun vpnState(): String = try {
        val cm = Repo.app.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val nw = cm.activeNetwork
        val caps = if (nw != null) cm.getNetworkCapabilities(nw) else null
        if (caps == null) "TIDAK ADA jaringan"
        else (if (caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN)) "VPN aktif" else "tanpa VPN") +
            (if (caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)) ", internet OK" else ", internet BELUM tervalidasi")
    } catch (e: Throwable) { "tidak terbaca" }

    private fun notApplicable(n: String, page: String): String? {
        if (page.isEmpty()) return null
        val sc = INFO[n]?.scope ?: return null
        val kind = siteKind(page)
        return when {
            sc.startsWith("Khusus YouTube") && !kind.startsWith("YouTube") -> "tool khusus YouTube, target: $kind"
            sc.startsWith("Khusus X") && kind != "X/Twitter" -> "tool khusus X/Twitter, target: $kind"
            sc.startsWith("Khusus jwplyr") && !kind.startsWith("situs stream JW") -> "tool khusus jwplyr/vidoy, target: $kind"
            sc.startsWith("Khusus layanan musik") && !kind.startsWith("layanan musik") -> "tool khusus Spotify/Apple Music dll, target: $kind"
            else -> null
        }
    }

    /** Sebab gagal yang bisa DIPASTIKAN dari kondisi nyata app. Satu kalimat pendek per sebab. */
    internal fun diagnose(n: String): List<String> {
        val r = ArrayList<String>()
        val page = Resolver.lastPage.ifEmpty { Resolver.mainPage }
        if (!Tool.on(n)) r.add("PASTI: tool dimatikan user di ⚙ (tidak dicentang)")
        if (n in ToolLog.chainAll && !Scan.enabled()) r.add("PASTI: Scan otomatis dimatikan di ⚙")
        notApplicable(n, page)?.let { r.add("BUKAN KEGAGALAN: $it") }
        if (n in ROOT_TOOLS) {
            when (RootGate.state) {
                0 -> r.add("PASTI: izin root belum pernah diminta (RootGate.state=0)")
                1 -> r.add("PASTI: menunggu jawaban dialog root (state=1)")
                3 -> r.add("PASTI: root DITOLAK/tidak ada (state=3, ${RootGate.status}) → user beri izin di Magisk/KernelSU")
                else -> {}
            }
        }
        if (n == "yt-dlp+cookies" && RootGate.state != 2) r.add("root belum diizinkan (state=${RootGate.state}) → cookies browser via root tak terbaca")
        if ((n == "yt-dlp" || n == "yt-dlp+cookies") && !Engine.ready) r.add("PASTI: mesin yt-dlp belum siap (error=${Engine.error ?: "-"})")
        when (n) {
            "Aksesibilitas" -> if (AlfyAccessibilityService.inst == null) {
                if (svcEnabled("enabled_accessibility_services")) r.add("PASTI: aktif di Pengaturan tapi proses tidak berjalan (dimatikan sistem/baterai) → user matikan-nyalakan lagi")
                else r.add("PASTI: Aksesibilitas BELUM diaktifkan di Pengaturan")
            }
            "Notifikasi" -> if (!AlfyNotifService.status.startsWith("✓")) {
                if (svcEnabled("enabled_notification_listeners")) r.add("PASTI: izin ada tapi layanan tidak terhubung (dimatikan sistem) → user cabut-beri izin lagi")
                else r.add("PASTI: Akses Notifikasi BELUM diizinkan di Pengaturan")
            }
            "tcpdump" -> {
                if (NetSniffer.dumpStat.contains("tidak ada")) r.add("PASTI: binary tcpdump tidak ada di HP")
                if (NetSniffer.dumpStat.contains("berhenti")) r.add("PASTI: proses tcpdump berhenti")
            }
            "Logcat root" -> {
                if (NetSniffer.logStat.contains("berhenti")) r.add("PASTI: logcat putus")
                if (Scan.ytLock()) r.add("SENGAJA: mode normal + YouTube di depan → link logcat dibuang (Scan.ytLock)")
            }
            "Media session" -> if (NetSniffer.mediaStat.contains("belum ada media")) r.add("BUKAN KEGAGALAN: aktif, belum ada media diputar")
            "Clipboard root" -> if (NetSniffer.clipStat.contains("tidak mendukung")) r.add("PASTI: ROM tidak mendukung baca clipboard via root")
            "ffmpeg" -> {
                if (Engine.ffmpeg.startsWith("✗")) r.add("PASTI: init ffmpeg gagal: ${Engine.ffmpeg}")
                if (!Engine.ready) r.add("mesin unduh belum siap (error=${Engine.error ?: "-"})")
            }
            "Hook pemutar" -> if (NetSniffer.hookHits <= 0) r.add("PASTI: modul LSPosed belum aktif/target belum dicentang/dimulai ulang (opsional)")
        }
        val net = vpnState()
        if (n in ToolLog.chainAll && (net.startsWith("TIDAK ADA") || net.contains("BELUM"))) r.add("PASTI: jaringan bermasalah ($net)")
        if (ToolLog.statusOf(n).lowercase().contains("timeout")) r.add("PASTI: timeout (batas 10 dtk ScanLimit/HTTP; VPN lambat)")
        return r
    }

    private fun cut(s: String, n: Int): String { val t = s.replace("\n", " ").trim(); return if (t.length > n) t.substring(0, n) + "…" else t }

    private fun instruksi(only: String?): String {
        val sb = StringBuilder()
        sb.append("[0] PERINTAH — WAJIB HEMAT TOKEN (saya pakai Claude gratis): jawab sesingkat mungkin, tanpa basa-basi, tanpa mengulang laporan, tanpa kode di chat.\n")
        sb.append("Anda insinyur Android/Kotlin. AlfyDownloader.zip terlampir = proyek app pengunduh video/musik saya. Tool yang gagal ada di [3]. Tugas: cari saran perbaikan paling tepat lalu terapkan DI DALAM ZIP.\n")
        sb.append("ATURAN:\n")
        sb.append("1. Nilai tiap perbaikan: SANGAT DISARANKAN (bukti kuat di laporan + cara jelas), RAGU, atau TIDAK DISARANKAN.\n")
        sb.append("2. SANGAT DISARANKAN → LANGSUNG ganti/perbaiki bagian atau tool itu di zip, tanpa bertanya. Utamakan yang paling besar peluangnya menghasilkan link unduhan.\n")
        sb.append("3. RAGU → JANGAN ubah; tanya konfirmasi saya dulu dalam 1 baris. TIDAK DISARANKAN → jangan diubah, tidak perlu dibahas.\n")
        sb.append("4. Selain bagian yang SANGAT DISARANKAN, JANGAN ubah apa pun yang sudah ada (fitur, logika, UI, file lain). Tidak boleh refactor/rename/rapikan/bongkar. Patch sekecil mungkin.\n")
        sb.append("5. Sebab berlabel PASTI/SENGAJA/BUKAN KEGAGALAN = izin/pengaturan/lingkungan, BUKAN bug kode: jangan ubah kode untuk itu, cukup 1 baris langkah untuk saya.\n")
        sb.append("6. Bila ada perbaikan yang diterapkan: JANGAN naikkan versionCode/versionName (biarkan sama, agar APK menimpa versi lama dan login/data tetap). Tambah 1-2 baris di KONTEKS.md, lalu LANGSUNG kirim AlfyDownloader.zip sebagai file unduhan. Jangan ubah app/alfy-debug.keystore. Tidak ada cara pasti → jangan ubah apa pun.\n")
        sb.append("7. Saran/catatan maksimal 1 baris per tool. Balasan akhir hanya: daftar 'Tool: DIGANTI/TANYA/SKIP — alasan 1 baris' + file zip.\n")
        sb.append("8. Batas: Kotlin+Compose, minSdk 24, targetSdk 28, arm64-v8a, build GitHub Actions. Saya online hanya lewat VPN (jangan sarankan lepas VPN). Jangan tambah tcpdump-HTTPS/MITM/PO token/Node.\n")
        return sb.toString()
    }

    /**
     * Laporan RINGKAS untuk AI. all=false: daftar tool + detail tool GAGAL (📖). all=true: daftar dengan status mentah tiap tool.
     * only != null: laporan fokus satu tool (📋 per tool).
     */
    fun build(all: Boolean = false, only: String? = null): String {
        val sb = StringBuilder()
        val df = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
        val names = ToolLog.chainAll + ToolLog.monAll
        val failedNames = names.filter { cls(it) == "GAGAL" }
        val shown: List<String> = if (only != null) listOf(only) else failedNames
        val page = Resolver.lastPage.ifEmpty { Resolver.mainPage }

        sb.append("=== LAPORAN TOOL GAGAL — AlfyDownloader+ ")
        try { sb.append('v').append(Repo.app.packageManager.getPackageInfo(Repo.app.packageName, 0).versionName ?: "-") } catch (e: Throwable) { }
        sb.append(" • ").append(df.format(java.util.Date())).append(" ===\n")
        sb.append(instruksi(only)).append('\n')

        sb.append("[1] KONDISI\n")
        sb.append("App: pengunduh video/musik; ${names.size} tool mencari link serentak (Tools.kt Chain.run/runGeneric → Resolver.addMediaChecked).\n")
        sb.append("HP: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append(", Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")")
        sb.append(" | Jaringan: ").append(vpnState())
        sb.append(" | Root: state=").append(RootGate.state).append(" (0 belum diminta,1 menunggu,2 izin,3 ditolak)")
        sb.append(" | Aksesibilitas: ").append(if (AlfyAccessibilityService.inst != null) "berjalan" else if (svcEnabled("enabled_accessibility_services")) "aktif tapi tak berjalan" else "belum diaktifkan")
        sb.append(" | Notifikasi: ").append(if (svcEnabled("enabled_notification_listeners")) "diizinkan" else "belum diizinkan")
        sb.append(" | Scan: ").append(Scan.modeText())
        sb.append(" | yt-dlp: ").append(if (Engine.ready) "siap" else "belum siap").append(" | ffmpeg: ").append(Engine.ffmpeg).append('\n')
        sb.append("Aplikasi depan: ").append(AlfyAccessibilityService.fgPkg.ifEmpty { "-" })
        sb.append(" | Halaman: ").append(page.ifEmpty { "-" }).append(" (").append(siteKind(page)).append(')')
        val det = Repo.detected.value
        sb.append(" | Tautan terdeteksi: ").append(det.size)
        if (ToolLog.winner.isNotEmpty()) sb.append(" | Pemenang: ").append(ToolLog.winner)
        sb.append('\n')
        if (Resolver.diag.isNotEmpty()) sb.append("Diagnosa app: ").append(cut(Resolver.diag, 200)).append('\n')
        if (Resolver.captchaPage.isNotEmpty()) sb.append("Butuh CAPTCHA di: ").append(Resolver.captchaPage).append('\n')
        sb.append('\n')

        // [2] daftar semua tool (ringkas)
        sb.append("[2] SEMUA TOOL (${names.size}) — ✓ berhasil ✗ gagal ⏳ siaga • menunggu/dilewati ☐ dimatikan\n")
        if (all) {
            names.forEachIndexed { i, n -> sb.append("${i + 1}. ").append(n).append(" ").append(sym(n)).append(" ").append(cut(ToolLog.statusOf(n), 90)).append('\n') }
        } else {
            sb.append(names.mapIndexed { i, n -> "${i + 1} $n ${sym(n)}" }.joinToString(" | ")).append('\n')
        }
        val rj = try { Resolver.rejects.toList().takeLast(5) } catch (e: Exception) { emptyList() }
        if (rj.isNotEmpty()) { sb.append("Link ditolak terakhir: "); sb.append(rj.joinToString(" ; ") { cut(it, 110) }).append('\n') }
        sb.append('\n')

        // [3] detail gagal (ringkas)
        sb.append("[3] ").append(if (only != null) "TOOL DILAPORKAN" else "TOOL GAGAL (${failedNames.size})").append('\n')
        if (shown.isEmpty()) sb.append("(tidak ada tool berstatus GAGAL; tool ⏳/• hanya siaga/menunggu, bukan gagal)\n")
        shown.forEachIndexed { i, n ->
            val st = ToolLog.statusOf(n)
            val info = INFO[n]
            val dg = diagnose(n)
            sb.append("${i + 1}. ").append(n).append(" — kode: ").append(cut(info?.impl?.substringBefore(";") ?: "-", 120)).append('\n')
            sb.append("   Status: ").append(cut(st, 160)).append('\n')
            sb.append("   Sebab: ").append(if (dg.isEmpty()) "tidak ada sebab izin/pengaturan → kemungkinan situs/jaringan/kode" else dg.joinToString(" ; ")).append('\n')
            val certain = dg.any { it.startsWith("PASTI") || it.startsWith("SENGAJA") || it.startsWith("BUKAN") }
            if (!certain) {
                if (info != null) sb.append("   Risiko umum: ").append(cut(info.risk, 170)).append('\n')
                val cz = cause(n, st)
                if (!cz.contains("Tidak dikenali otomatis")) sb.append("   Dugaan: ").append(cut(cz.replace("\n      - ", " ; ").removePrefix("- "), 220)).append('\n')
            }
            val steps = ToolStatus.history(n).takeLast(3)
            if (steps.isNotEmpty()) sb.append("   Langkah terakhir: ").append(steps.joinToString(" > ") { cut(it, 90) }).append('\n')
        }
        sb.append("\nKerjakan sesuai [0]: SANGAT DISARANKAN langsung diganti di zip, RAGU tanya 1 baris, sisanya jangan diubah. Singkat, lalu kirim AlfyDownloader.zip.\n")
        return sb.toString()
    }

    private fun sym(n: String): String = when (cls(n)) {
        "BERHASIL" -> "✓"
        "GAGAL" -> "✗"
        "SIAGA/BELUM SELESAI" -> "⏳"
        "DINONAKTIFKAN PENGGUNA" -> "☐"
        else -> "•"
    }
}

class ReportActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private var tv: TextView? = null
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dm = resources.displayMetrics
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(8)); setBackgroundColor(0xFF262626.toInt()) }
        val title = TextView(this).apply { text = "⚡ Scan maksimal"; textSize = 16f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) }
        val body = TextView(this).apply { textSize = 12f; setTextColor(0xFFE0E0E0.toInt()); setTextIsSelectable(true); text = "Semua alat memindai maksimal… tunggu ${ScanReport.WAIT_MS / 1000} detik, laporan muncul otomatis." }
        tv = body
        val sc = ScrollView(this).apply { addView(body) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        fun btn(t: String, f: () -> Unit) = TextView(this).apply {
            text = t; textSize = 13f; setTextColor(0xFF80CBC4.toInt()); setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(dp(10), dp(12), dp(10), dp(12)); setOnClickListener { f() }
        }
        fun copy() {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("laporan semua alat", ScanReport.build(true)))
            Toast.makeText(this, "Laporan semua tool (untuk AI) disalin", Toast.LENGTH_SHORT).show()
        }
        row.addView(btn("SALIN SEMUA LOG") { copy() })
        row.addView(btn("ULANG") { h.removeCallbacksAndMessages(null); ScanReport.start(); body.text = "Memindai ulang…"; schedule() })
        row.addView(btn("TUTUP") { finish() })
        root.addView(title)
        root.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(row)
        setContentView(root, ViewGroup.LayoutParams((dm.widthPixels * 0.94).toInt(), (dm.heightPixels * 0.8).toInt()))
        window.setLayout((dm.widthPixels * 0.94).toInt(), (dm.heightPixels * 0.8).toInt())
        ScanReport.start()
        schedule()
    }

    private fun schedule() {
        h.postDelayed({ tv?.text = ScanReport.build(true) }, ScanReport.WAIT_MS)
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }
}
