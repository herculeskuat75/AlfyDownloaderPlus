package com.alfy.downloader

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

/** v1.21: scan maksimal semua alat. v1.50: laporan disusun sebagai prompt lengkap untuk AI (instruksi, profil app, lingkungan, katalog tool, detail gagal). */
object ScanReport {
    const val WAIT_MS = 25_000L

    fun start() {
        Scan.maxUntil = System.currentTimeMillis() + 60_000L
        try { AlfyAccessibilityService.inst?.scanNow() } catch (e: Exception) { }
        val pages = listOf(Resolver.lastPage, Resolver.mainPage).filter { it.startsWith("http") }.distinct()
        for (pg in pages) {
            try { Resolver.rescan(pg, null, "Manual 🔍 scan maksimal"); Resolver.sniff(pg, true) } catch (e: Exception) { }
        }
    }

    internal val ROLE = mapOf(
        "fxtwitter" to "mengambil video dari link tweet X/Twitter lewat API fxtwitter",
        "Syndication" to "mengambil video tweet lewat API syndication Twitter",
        "yt-dlp" to "ekstraktor utama untuk ribuan situs (butuh URL halaman video yang didukung)",
        "yt-dlp+cookies" to "yt-dlp memakai cookies login (untuk video yang butuh login/bot-check)",
        "ytFast" to "pengambil cepat link YouTube",
        "NewPipe" to "ekstraktor NewPipe (YouTube/SoundCloud/dll)",
        "Piped/Invidious" to "mengambil link YouTube lewat server proksi Piped/Invidious",
        "HLS iOS/VR" to "mengambil stream HLS YouTube memakai klien iOS/VR",
        "WebView" to "memuat halaman di WebView lalu menyadap permintaan media",
        "HTML" to "membaca HTML halaman mencari file .mp4/.m3u8",
        "JWPlayer" to "membaca pemutar JWPlayer (jwplyr/vidoy/overfetch)",
        "OpenGraph" to "membaca meta og:video/JSON-LD memakai UA crawler (Facebook/Twitter/Google)",
        "Situs API" to "API khusus Vimeo, Dailymotion, Reddit, Streamable, TikTok, Facebook, Imgur",
        "JS Deep" to "membaca file JavaScript halaman mencari link media/manifest",
        "Iframe" to "menelusuri iframe/pemutar tertanam (2 tingkat) mencari media",
        "Manifest" to "mencari playlist .m3u8/.mpd dan config JSON pemutar",
        "WebView Pro" to "WebView tersembunyi dengan pengait fetch/XHR, play & scroll otomatis, sadap jaringan (CDN sulit/short-video)",
        "Host Pack" to "pembuka host streaming: Streamtape, Doodstream, Mixdrop, Rumble, OK.ru, VK, Bilibili, Instagram embed, Telegram",
        "Redirect" to "mengikuti link pendek/redirect ke tujuan akhir lalu memindainya",
        "Logcat root" to "membaca logcat (root) mencari link media",
        "tcpdump" to "menyadap lalu lintas jaringan (root)",
        "Media session" to "membaca info media yang sedang diputar aplikasi lain",
        "Clipboard root" to "memantau clipboard (root)",
        "Notifikasi" to "membaca notifikasi pemutar media",
        "Aksesibilitas" to "membaca teks/layar aplikasi lain",
        "Hook pemutar" to "modul LSPosed: menangkap link dari pemutar di dalam aplikasi (TikTok, IG, FB, dll.)",
        "ffmpeg" to "mesin penggabung/konversi (bukan pencari link)",
        "Spotify Match" to "untuk link Spotify/Apple Music/Deezer/Tidal dll (berDRM): baca judul+artis dari halaman, cari lagu yang sama di YouTube, lalu jalankan rantai alat YouTube"
    )

    internal fun cause(n: String, st: String): String {
        val x = st.lowercase()
        val c = ArrayList<String>()
        if ("dimatikan" in x || "dimatikan" in st) c.add("Alat dimatikan di ⚙ (kotak tidak dicentang) → centang lagi.")
        if ("scan dimatikan" in x) c.add("Scan otomatis dimatikan di ⚙ → nyalakan 'Scan otomatis'.")
        if ("login_required" in x || "sign in" in x || "bot" in x || "confirm you" in x) c.add("YouTube/situs menandai IP (VPN) sebagai bot atau meminta login → coba login lewat WebView, ganti server VPN, atau pakai yt-dlp+cookies.")
        if ("unsupported url" in x) c.add("Ekstraktor tidak mengenali URL ini: URL bukan halaman video, atau situsnya belum didukung / halaman embed.")
        if ("no service" in x) c.add("NewPipe tidak punya layanan untuk domain ini (hanya YouTube/SoundCloud/PeerTube dll).")
        if ("403" in x || "forbidden" in x) c.add("Server menolak (403): butuh Referer/cookies/User-Agent yang benar, atau link kedaluwarsa.")
        if ("404" in x || "not found" in x) c.add("Link sudah tidak ada/kedaluwarsa (404) → ambil ulang dari halaman.")
        if ("captcha" in x) c.add("Situs meminta CAPTCHA → selesaikan di browser Alfy lalu scan ulang.")
        if ("timeout" in x || "timed out" in x || "unable to resolve" in x || "unknownhost" in x) c.add("Koneksi lambat/terputus atau DNS gagal (cek VPN/sinyal).")
        if ("root" in x && ("tidak" in x || "ditolak" in x || "belum" in x)) c.add("Izin root belum diberikan/ditolak → beri izin di Magisk/KernelSU.")
        if (n == "Aksesibilitas" && "mati" in x) c.add("Layanan Aksesibilitas belum diaktifkan → aktifkan di Pengaturan > Aksesibilitas.")
        if (n == "Notifikasi" && ("belum" in x || "tidak" in x)) c.add("Akses Notifikasi belum diizinkan → izinkan di pengaturan Akses Notifikasi.")
        if (n == "tcpdump" && "berhenti" in x) c.add("tcpdump berhenti: tidak ada root, binary tidak ada, atau proses dimatikan sistem.")
        if (n == "Media session" && ("belum" in x || "tidak" in x)) c.add("Tidak ada media yang sedang DIPUTAR di aplikasi lain → putar videonya dulu.")
        if (n == "Logcat root" && ("0 link" in x)) c.add("Logcat tidak melihat link: aplikasi tidak mencatat URL di log, atau video belum diputar.")
        if ("⏳" in st && c.isEmpty()) c.add("Alat belum dipicu: tidak ada URL halaman/video yang cocok untuk alat ini di layar saat ini (mungkin memang bukan tugasnya).")
        if (c.isEmpty()) c.add("Tidak dikenali otomatis → lihat teks status di atas.")
        return c.joinToString("\n      ") { "- $it" }.removePrefix("- ").let { "- $it" }
    }

    // ================================================================
    // v1.50: LAPORAN UNTUK AI (Claude) — prompt lengkap + konteks + katalog semua tool + detail tool gagal
    // ================================================================

    /** Rincian teknis per tool supaya AI penganalisis tahu persis kode mana yang harus diperiksa. */
    internal class Info(val impl: String, val trigger: String, val ok: String, val risk: String, val scope: String = "Semua situs yang cocok")

    internal val INFO: Map<String, Info> = mapOf(
        "fxtwitter" to Info(
            "SiteTool.xApi(page, 1) di SiteTool.kt; memanggil api.fxtwitter.com (cadangan api.vxtwitter.com)",
            "Halaman x.com/twitter.com atau ID tweet yang terbaca di logcat (Resolver.submitTweet)",
            "JSON memuat media.videos[].url dan link lolos uji (Resolver.addMediaChecked)",
            "Tweet tanpa video / dihapus / dilindungi; API pihak ketiga down, rate limit, atau diblokir; timeout API 4,5 dtk lewat VPN lambat",
            "Khusus X/Twitter"),
        "Syndication" to Info(
            "SiteTool.xApi(page, 2) di SiteTool.kt; memanggil cdn.syndication.twimg.com",
            "Halaman x.com/twitter.com",
            "Respons syndication memuat varian video mp4/m3u8 yang lolos uji",
            "Endpoint berubah/dibatasi; tweet sensitif/tanpa video; timeout lewat VPN",
            "Khusus X/Twitter"),
        "yt-dlp" to Info(
            "Resolver.ytdlpTool(page, null) di Resolver.kt; library youtubedl-android (yt-dlp, 6 klien YouTube, --force-ipv4); mesin diinisialisasi & diperbarui di AlfyApp (updateEngine)",
            "Setiap halaman video yang dipindai (YouTube selalu; situs lain lewat Chain.runGeneric)",
            "yt-dlp mengembalikan format dan Resolver menambahkannya sebagai kandidat",
            "LOGIN_REQUIRED / Sign in to confirm you're not a bot (IP VPN ditandai); Unsupported URL (bukan halaman video/embed); yt-dlp usang; mesin belum siap (Engine.ready); dibatalkan paksa pada batas 10 dtk (ScanLimit) lewat VPN lambat"),
        "yt-dlp+cookies" to Info(
            "Tools.kt: cookiesTool(page) + object Cookies (WebView login UA Firefox + cookies root dari Firefox/Chromium) lalu yt-dlp --cookies",
            "Halaman YouTube",
            "yt-dlp berhasil memakai cookies login",
            "Pengguna belum login lewat WebView; cookies kedaluwarsa/tidak ada; root ditolak (cookies Firefox/Chromium tak terbaca); DB cookies Chromium terenkripsi; akun/IP tetap kena bot-check",
            "Khusus YouTube"),
        "ytFast" to Info(
            "Resolver.ytFast(id, w) di Resolver.kt; API pemutar YouTube klien ANDROID_VR (1.62.27, 1.60.19) dan IOS dicoba serentak; tiap link diuji Resolver.probePlay (Range awal + potongan ~6MB)",
            "Halaman YouTube dengan ID video",
            "Minimal satu link audio+video yang lolos probePlay",
            "LOGIN_REQUIRED/bot-check karena IP VPN; versi klien iOS/VR usang; link butuh PO Token (lolos potongan pertama, 403 setelahnya); respons tanpa format (tanpa link)",
            "Khusus YouTube"),
        "NewPipe" to Info(
            "Tools.kt: object NP (NP.fetch(id) untuk YouTube, NP.fetchAny(page) untuk situs lain); NewPipeExtractor v0.26.5 via JitPack, dipanggil lewat refleksi",
            "Halaman YouTube / SoundCloud / PeerTube / situs yang didukung NewPipe",
            "Extractor mengembalikan stream video/audio yang diterima Resolver",
            "'no service' untuk domain tak didukung; extractor usang terhadap perubahan situs; bot-check/ReCaptcha; refleksi/proguard menghapus kelas; timeout 8/9 dtk"),
        "Piped/Invidious" to Info(
            "Tools.kt: object Inst (Inst.fetch(id)); daftar server Piped/Invidious diambil dinamis lalu dicoba paralel",
            "Halaman YouTube",
            "Satu server mengembalikan stream yang diproksikan",
            "Server publik mati/rate limit/diblokir; link proksi 403; daftar server tidak terunduh lewat VPN",
            "Khusus YouTube"),
        "HLS iOS/VR" to Info(
            "Resolver.youtubeFallback(id, page) di Resolver.kt; mengambil manifest HLS dari klien iOS/VR",
            "Halaman YouTube (cadangan; dilewati bila sudah ada hasil)",
            "Manifest m3u8 valid ditambahkan sebagai kandidat",
            "Bot-check; klien usang; manifest kosong/live-only",
            "Khusus YouTube"),
        "WebView" to Info(
            "Tools.kt: object WebTool (WebTool.grab(id) untuk YouTube; WebTool.grabPage(page) untuk situs lain); WebView tersembunyi menyadap request media",
            "Halaman YouTube atau situs apa pun yang dipindai",
            "Request media (googlevideo/videoplayback atau .mp4/.m3u8) tertangkap DAN lolos Resolver.addMediaChecked",
            "Halaman butuh interaksi/CAPTCHA/login; media dimuat setelah klik play; link iklan/host lain ditolak filter; googlevideo dengan dur= tidak cocok durasi video; batas waktu ScanLimit; getUrl() di thread jaringan (targetSdk 28)"),
        "HTML" to Info(
            "Resolver.sniffSync(page) di Resolver.kt; mengunduh HTML lalu mencari URL media (.mp4/.m3u8 dll)",
            "Mode agresif untuk YouTube; selalu untuk situs lain",
            "sniffSync > 0 (ada media di HTML)",
            "Situs dirender lewat JavaScript (HTML kosong); butuh Referer/cookies/UA tertentu; CAPTCHA; link dalam JSON terenkripsi"),
        "Spotify Match" to Info(
            "MusicMap.kt: MusicMap.matches(page) + MusicMap.run(page); membaca judul+artis dari meta halaman, mencari di YouTube, lalu menjalankan rantai YouTube",
            "Host Spotify/Apple Music/Deezer/Tidal/Amazon Music/dll",
            "Lagu yang sama ditemukan di YouTube dan rantai YouTube menghasilkan link",
            "Meta halaman tidak terbaca (halaman dirender JS); pencarian YouTube salah lagu/tidak ada; rantai YouTube sendiri kena bot-check",
            "Khusus layanan musik berDRM"),
        "JWPlayer" to Info(
            "SiteTool.jw(page) di SiteTool.kt; baca HTML + iframe /e/ID /v/ID, buka kemasan JS p,a,c,k,e,d dan base64, uji tiap kandidat",
            "Host jwplyr.com, *.overfetch.video, vidoy.asia/com (otomatis) atau mode agresif",
            "Ada URL video milik host situs (overfetch.video dll) yang lolos uji",
            "Halaman iklan 'Confirm you're not a robot' / CAPTCHA Cloudflare Turnstile; hanya menemukan gambar/HTML; link bertanda tangan & kedaluwarsa (/s/TOKEN/EXPIRE/i/ID); Referer salah (harus vidoy.asia/jwplyr.com); filter iklan terlalu ketat",
            "Khusus jwplyr/vidoy/overfetch"),
        "OpenGraph" to Info(
            "MoreTools.openGraph(page) di MoreTools.kt; membaca og:video / twitter:player / JSON-LD dengan UA crawler (Facebook/Twitter/Google)",
            "Situs non-YouTube",
            "Meta og:video atau JSON-LD VideoObject memuat URL media langsung",
            "Situs tidak menyediakan meta untuk crawler; URL meta berupa halaman embed, bukan file media; login wajib"),
        "Situs API" to Info(
            "MoreTools.siteApi(page) di MoreTools.kt; API khusus Vimeo, Dailymotion, Reddit, Streamable, TikTok, Facebook, Imgur",
            "Host yang dikenali saja",
            "API situs mengembalikan URL media",
            "Endpoint publik berubah/dibatasi; TikTok/Facebook butuh login/token; host tidak dikenali (tool tidak berlaku)",
            "Khusus host tertentu"),
        "JS Deep" to Info(
            "MoreTools.jsDeep(page) di MoreTools.kt; mengunduh file JavaScript halaman dan mencari link media/manifest",
            "Situs non-YouTube",
            "Ditemukan URL media/manifest di dalam JS",
            "URL dibentuk dinamis/dienkripsi; JS besar melebihi batas; file JS butuh Referer/cookies"),
        "Iframe" to Info(
            "MoreTools.iframe(page) di MoreTools.kt; menelusuri iframe/pemutar tertanam sampai 2 tingkat",
            "Situs non-YouTube",
            "Iframe turunan memuat URL media",
            "Iframe dimuat lewat JS setelah interaksi; iframe lintas-origin butuh Referer induk; lebih dari 2 tingkat"),
        "Manifest" to Info(
            "MoreTools.manifest(page) di MoreTools.kt; mencari .m3u8/.mpd dan config JSON pemutar",
            "Situs non-YouTube",
            "Manifest valid ditemukan dan lolos uji",
            "Manifest bertanda tangan/kedaluwarsa; butuh header khusus; DRM (tidak bisa diunduh)"),
        "Redirect" to Info(
            "MoreTools.redirect(page) di MoreTools.kt; mengikuti link pendek/redirect ke tujuan akhir lalu memindainya",
            "Link pendek (bit.ly, t.co, dll) atau halaman yang meredirect",
            "Tujuan akhir ditemukan lalu memicu pemindaian ulang",
            "Redirect lewat JavaScript/meta refresh; halaman interstitial iklan; tidak ada redirect (tool tidak berlaku)",
            "Khusus link pendek/redirect"),
        "WebView Pro" to Info(
            "MoreTools.webPro(page) di MoreTools.kt (+ extras/DocStartHook.kt: skrip suntik sebelum halaman jalan); WebView tersembunyi dengan pengait fetch/XHR, play & scroll otomatis",
            "Situs non-YouTube sulit (CDN sulit / short-video)",
            "Request media atau currentSrc video tertangkap dan lolos addMediaChecked",
            "CAPTCHA/login; autoplay diblokir; DocStartHook tidak didukung WebView perangkat (install() false); batas waktu ScanLimit"),
        "Host Pack" to Info(
            "MoreTools.hostPack(page) di MoreTools.kt; pembuka host Streamtape, Doodstream, Mixdrop, Rumble, OK.ru, VK, Bilibili, Instagram embed, Telegram",
            "Host yang dikenali saja",
            "Pembuka host mengembalikan URL media",
            "Pola host berubah; token sementara; host tidak dikenali (tool tidak berlaku)",
            "Khusus host tertentu"),
        "Logcat root" to Info(
            "NetSniffer.kt: pembaca logcat via root (RootGate); NetSniffer.feed memproses URL media",
            "Terus-menerus di latar belakang bila root diizinkan",
            "logStat '✓ aktif' dan penghitung link > 0",
            "Root ditolak/tidak tersedia; logcat putus; aplikasi tidak mencatat URL di log; Scan.ytLock membuang link saat YouTube di depan (mode normal)",
            "Pemantau latar (butuh root)"),
        "tcpdump" to Info(
            "NetSniffer.kt: dump HTTP polos lewat tcpdump (root)",
            "Terus-menerus bila binary tcpdump ada",
            "dumpStat '✓ aktif' dan penghitung permintaan > 0",
            "Binary tcpdump tidak ada di HP; root ditolak; HTTPS tidak terbaca (hanya HTTP polos); VPN mengenkripsi lalu lintas; proses dimatikan sistem",
            "Pemantau latar (butuh root)"),
        "Media session" to Info(
            "NetSniffer.kt: dumpsys media_session tiap 1 dtk (root); memicu AutoScan.onPlay(pkg)",
            "Saat aplikasi lain memutar media (state=3)",
            "mediaStat '✓ aktif • memutar: <paket>' lalu AutoScan berjalan",
            "Root ditolak; tidak ada media yang sedang diputar; format keluaran dumpsys berbeda di ROM ini",
            "Pemantau latar (butuh root)"),
        "Clipboard root" to Info(
            "NetSniffer.kt: baca clipboard lewat perintah root",
            "Saat ada tanda tautan disalin",
            "clipStat '✓ aktif' dan URL clipboard terbaca",
            "Perintah baca clipboard tidak didukung ROM/Android versi ini; root ditolak; Android 10+ membatasi akses clipboard latar",
            "Pemantau latar (butuh root)"),
        "Notifikasi" to Info(
            "AlfyNotifService.kt (NotificationListenerService); membaca notifikasi MediaSession (judul+channel) tanpa root",
            "Saat aplikasi pemutar menampilkan notifikasi media",
            "AlfyNotifService.status '✓' dan judul/channel terbaca",
            "Akses Notifikasi belum diizinkan; layanan dimatikan sistem (penghemat baterai); aplikasi tidak menampilkan notifikasi media",
            "Layanan Android"),
        "Aksesibilitas" to Info(
            "AlfyAccessibilityService.kt; membaca teks/layar semua aplikasi (URL, judul, tombol), autoPlay, scanNow",
            "Setiap perubahan layar (interval pindai ~800 ms)",
            "AlfyAccessibilityService.inst tidak null (✓ aktif)",
            "Layanan belum diaktifkan di Pengaturan > Aksesibilitas; dimatikan sistem/ROM; aplikasi memblokir pembacaan layar",
            "Layanan Android"),
        "ffmpeg" to Info(
            "AlfyApp.kt: FFmpeg.getInstance().init() (io.github.junkfood02.youtubedl-android:ffmpeg); dipakai DownloadService.remuxMp4 untuk HLS/m3u8",
            "Saat mengunduh HLS/m3u8 atau menggabung audio+video",
            "Engine.ffmpeg '✓ siap'",
            "Init gagal (binary/ABI tidak cocok); ruang penyimpanan; bukan alat pencari link sehingga status gagal tidak memengaruhi pendeteksian",
            "Mesin penggabung (bukan pencari link)"),
        "Hook pemutar" to Info(
            "hook/HookEntry.java (modul LSPosed, stub API di app/xposed-stub); menangkap link dari pemutar di dalam aplikasi (TikTok, IG, FB, dll)",
            "Aplikasi target yang dicentang di LSPosed dan dimulai ulang",
            "NetSniffer.hookHits > 0",
            "Modul belum diaktifkan di LSPosed / target belum dipilih / aplikasi belum dimulai ulang; ROM/LSPosed tidak kompatibel",
            "Modul LSPosed (opsional)")
    )

    private fun group(n: String): String = if (n in ToolLog.chainAll) "Pemindai link" else "Pemantau latar/layanan"

    private fun cls(n: String): String = when (ToolStatus.state(n)) {
        ToolStatus.St.OK -> "BERHASIL"
        ToolStatus.St.FAIL -> "GAGAL"
        ToolStatus.St.SCAN -> "SIAGA/BELUM SELESAI"
        ToolStatus.St.OFF -> if (!Tool.on(n)) "DINONAKTIFKAN PENGGUNA" else if (ToolLog.statusOf(n).contains("lewati")) "DILEWATI" else "MENUNGGU"
    }

    private fun siteKind(page: String): String {
        if (page.isEmpty() || page == "-") return "tidak diketahui (belum ada halaman terdeteksi)"
        val h = try { android.net.Uri.parse(page).host?.lowercase() ?: "" } catch (e: Exception) { "" }
        return when {
            h.contains("youtube.com") || h.contains("youtu.be") -> "YouTube (video/Shorts/musik)"
            h == "x.com" || h.endsWith(".x.com") || h.endsWith("twitter.com") -> "X/Twitter"
            h.endsWith("jwplyr.com") || h.endsWith("overfetch.video") || h.endsWith("vidoy.asia") || h.endsWith("vidoy.com") -> "situs stream JW Player (jwplyr/vidoy/overfetch; banyak iklan & CAPTCHA)"
            MusicMap.matches(page) -> "layanan musik berDRM (Spotify/Apple Music/Deezer dll)"
            else -> "situs/aplikasi lain (host: $h)"
        }
    }

    private fun instruksi(all: Boolean, only: String?, nFail: Int): String {
        val sb = StringBuilder()
        sb.append("[0] INSTRUKSI UNTUK AI (baca dulu)\n")
        sb.append("Anda adalah insinyur Android senior (Kotlin, Jetpack Compose, WebView, jaringan/HTTP, ekstraksi media, yt-dlp/NewPipe). ")
        sb.append("Saya pemilik aplikasi Android bernama AlfyDownloader+ (profil lengkap di [1]). Tugas aplikasi: mendeteksi lalu mengekstrak link unduhan video & musik dari situs/aplikasi lain. ")
        sb.append("Pekerjaan itu dilakukan oleh banyak 'tool' yang berjalan serentak (daftar lengkap di [4]). Laporan ini dibuat otomatis oleh tombol salin log di aplikasi: ")
        sb.append(if (only != null) "isinya laporan khusus untuk tool \"$only\"" else if (all) "isinya status SEMUA tool beserta detailnya" else "isinya detail tool yang GAGAL (jumlah gagal saat ini: $nFail)")
        sb.append(", lengkap dengan tugas, cara kerja (file/fungsi), riwayat langkah, dan konteks perangkat.\n\n")
        sb.append("TOLONG KERJAKAN:\n")
        sb.append("1. Untuk SETIAP tool yang dilaporkan di [6], tentukan akar masalah paling mungkin dan golongkan: (a) bug/kelemahan kode aplikasi, (b) batasan lingkungan (IP VPN ditandai bot, tanpa login/cookies, izin root/aksesibilitas/notifikasi belum diberikan), (c) perubahan di sisi situs/API/pustaka (usang), (d) tool memang tidak berlaku untuk situs ini (lihat kolom 'Cakupan' — itu BUKAN kegagalan), (e) data log belum cukup.\n")
        sb.append("2. Sebutkan tingkat keyakinan (tinggi/sedang/rendah) dan kutip baris log yang menjadi buktinya.\n")
        sb.append("3. Berikan perbaikan konkret: nama file + fungsi (pakai kolom 'Implementasi'), potongan kode Kotlin/patch yang siap tempel, dan cara memverifikasi hasilnya di HP.\n")
        sb.append("4. Bila tidak bisa diperbaiki, beri alternatif yang realistis untuk kondisi saya (online hanya lewat VPN, HP root).\n")
        sb.append("5. Urutkan prioritas: perbaikan yang paling besar peluangnya menghasilkan link unduhan di situs/aplikasi pada [3] dikerjakan paling dulu. Cari juga akar masalah BERSAMA yang membuat banyak tool gagal sekaligus (mis. bot-check IP VPN, root ditolak).\n")
        sb.append("6. Bila data di laporan kurang, sebutkan persis log/data tambahan yang harus saya kirim dan cara mengambilnya.\n\n")
        sb.append("BATASAN: jawab dalam bahasa Indonesia. Aplikasi dibangun lewat GitHub Actions (tanpa Android Studio/Gradle lokal), jadi kode harus aman dikompilasi: Kotlin + Compose yang sudah ada, minSdk 24, targetSdk 28, arm64-v8a saja. Jangan merusak tool lain. ")
        sb.append("Jangan sarankan hal yang sengaja tidak dipasang (tcpdump untuk HTTPS, sniffer VPN lokal, MITM, PO token/bgutil yang butuh Node). Jangan menyarankan 'lepas VPN' sebagai solusi utama: pengguna hanya bisa online lewat VPN.\n\n")
        sb.append("FORMAT JAWABAN: (i) ringkasan 3-5 baris; (ii) akar masalah bersama; (iii) tabel per tool: Tool | Golongan (a-e) | Akar masalah | Keyakinan | Perbaikan; (iv) patch kode per file; (v) langkah uji; (vi) data tambahan yang diperlukan (jika ada).\n")
        return sb.toString()
    }

    private fun profil(): String {
        val sb = StringBuilder()
        sb.append("[1] PROFIL APLIKASI\n")
        sb.append("- Nama/tujuan: AlfyDownloader+ — aplikasi Android (Kotlin, Compose) pengunduh video & musik. Tombol mengambang yang bisa digeser mendeteksi link video/musik otomatis di semua aplikasi/situs di latar belakang lalu mengunduhnya. Build lewat GitHub Actions, rilis di tab Releases.\n")
        sb.append("- Pengguna: HP Android root, memakai ReVanced YouTube (app.revanced.android.youtube), HANYA bisa online lewat VPN (DarkTunnel, HTTP Custom). Prioritas utama: scan otomatis di belakang layar harus menghasilkan link yang bisa diunduh/diputar.\n")
        sb.append("- Arsitektur dua tahap: (1) DETEKSI video lewat Aksesibilitas, media_session + logcat + clipboard (root), Notifikasi MediaSession, menu Share; (2) RESOLVE: Chain.run() (YouTube) / Chain.runGeneric() (situs lain) di Tools.kt menjalankan banyak tool SERENTAK; hasilnya masuk Resolver.addMediaChecked() yang menguji link (HEAD/Range) sebelum masuk daftar. Batas waktu per tool 10 dtk (ScanLimit); status per tool di ToolLog (tampil di panel mengambang).\n")
        sb.append("- Fakta uji lapangan: IP VPN sering ditandai bot oleh YouTube (LOGIN_REQUIRED); halaman jwplyr/vidoy penuh iklan & CAPTCHA; deteksi video lewat Akses Notifikasi biasanya berhasil (judul + channel terbaca); link googlevideo terikat klien pembuatnya (parameter c=) dan IP/expire.\n")
        sb.append("- Arti status: ✓ berhasil (link benar-benar masuk daftar) • ✗ gagal • ⏳ siaga/sedang memindai • – dilewati/dimatikan • • menunggu. Tool 'siaga' belum dipicu: BUKAN kegagalan.\n")
        return sb.toString()
    }

    /**
     * Laporan untuk AI. all=false: hanya tool GAGAL (tombol 📖). all=true: SEMUA tool (⚡ SCAN MAKSIMAL + LAPORAN).
     * only != null: laporan fokus satu tool (tombol 📋 per tool).
     */
    fun build(all: Boolean = false, only: String? = null): String {
        val sb = StringBuilder()
        val df = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
        val names = ToolLog.chainAll + ToolLog.monAll
        val failedNames = names.filter { cls(it) == "GAGAL" }
        val shown: List<String> = if (only != null) listOf(only) else if (all) names else failedNames
        val page = Resolver.lastPage.ifEmpty { Resolver.mainPage }

        sb.append("=== LAPORAN KEGAGALAN TOOL — AlfyDownloader+ ")
        sb.append(if (only != null) "(tool: $only)" else if (all) "(semua tool)" else "(tool gagal)")
        sb.append(" ===\n")
        sb.append("Salin seluruh teks ini ke AI. Bagian [0] adalah instruksi untuk Anda.\n\n")
        sb.append(instruksi(all, only, failedNames.size)).append('\n')
        sb.append(profil()).append('\n')

        // [2] lingkungan
        sb.append("[2] LINGKUNGAN & KONDISI SAAT LAPORAN\n")
        sb.append("Waktu laporan     : ").append(df.format(java.util.Date())).append('\n')
        try {
            val pi = Repo.app.packageManager.getPackageInfo(Repo.app.packageName, 0)
            sb.append("Versi aplikasi    : ").append(pi.versionName ?: "-").append('\n')
        } catch (e: Throwable) { }
        sb.append("Perangkat         : ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append(" • Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
        sb.append("Mode scan         : ").append(Scan.modeText()).append('\n')
        sb.append("Aplikasi di depan : ").append(AlfyAccessibilityService.fgPkg.ifEmpty { "-" }).append('\n')
        sb.append("Mesin unduh       : ").append(if (Engine.ready) "siap" else (Engine.error ?: "memuat…")).append(" • ffmpeg: ").append(Engine.ffmpeg).append('\n')
        sb.append(RootGate.status).append('\n').append(NetSniffer.status).append('\n').append(VpnTool.status).append('\n')
        if (NetSniffer.lastHit.isNotEmpty()) sb.append("Link terakhir (logcat): ").append(NetSniffer.lastHit).append('\n')
        sb.append('\n')

        // [3] target
        sb.append("[3] TARGET SCAN SAAT INI\n")
        sb.append("Halaman terakhir  : ").append(Resolver.lastPage.ifEmpty { "-" }).append('\n')
        sb.append("Halaman utama     : ").append(Resolver.mainPage.ifEmpty { "-" }).append('\n')
        sb.append("Jenis situs       : ").append(siteKind(page)).append('\n')
        if (ToolLog.vid.isNotEmpty()) sb.append("ID video rantai   : ").append(ToolLog.vid).append('\n')
        val det = Repo.detected.value
        sb.append("Tautan terdeteksi : ").append(det.size)
        if (det.isNotEmpty()) sb.append("  (per sumber: ").append(det.groupBy { it.source.ifEmpty { "tanpa label" } }.entries.joinToString { it.key + "=" + it.value.size }).append(')')
        sb.append('\n')
        if (ToolLog.winner.isNotEmpty()) sb.append("Tool pemenang     : ").append(ToolLog.winner).append('\n')
        sb.append("Diagnosa app      : ").append(Resolver.diag.ifEmpty { "-" }).append('\n')
        if (Resolver.captchaPage.isNotEmpty()) sb.append("Butuh CAPTCHA di  : ").append(Resolver.captchaPage).append('\n')
        sb.append('\n')

        // [4] katalog semua tool
        val cnt = names.groupingBy { cls(it) }.eachCount()
        sb.append("[4] DAFTAR SEMUA TOOL (${names.size}) & STATUS — ringkasan: ")
        sb.append(cnt.entries.joinToString(" • ") { it.key + "=" + it.value }).append('\n')
        names.forEachIndexed { i, n ->
            sb.append("${i + 1}. ").append(n).append(" [").append(group(n)).append("] — ").append(cls(n)).append(" — ").append(ToolLog.statusOf(n).replace("\n", " ")).append('\n')
            sb.append("     Tugas: ").append(ROLE[n] ?: "-").append('\n')
        }
        sb.append('\n')

        // [5] penolakan link
        val rj = try { Resolver.rejects.toList() } catch (e: Exception) { emptyList() }
        sb.append("[5] PENOLAKAN LINK TERAKHIR (alasan link kandidat dibuang oleh uji Resolver — bukti penting)\n")
        if (rj.isEmpty()) sb.append("(tidak ada)\n") else rj.forEach { sb.append("- ").append(it).append('\n') }
        sb.append('\n')

        // [6] detail
        val title = if (only != null) "DETAIL TOOL YANG DILAPORKAN" else if (all) "DETAIL SEMUA TOOL" else "DETAIL TOOL YANG GAGAL (${failedNames.size} dari ${names.size})"
        sb.append("[6] ").append(title).append('\n')
        if (shown.isEmpty()) sb.append("(tidak ada tool berstatus GAGAL saat ini; lihat [4] untuk tool siaga/menunggu)\n")
        shown.forEachIndexed { i, n ->
            val st = ToolLog.statusOf(n)
            val info = INFO[n]
            sb.append("\n--- ${i + 1}. ").append(n).append(" ---\n")
            sb.append("Golongan        : ").append(group(n)).append('\n')
            sb.append("Hasil           : ").append(cls(n)).append('\n')
            sb.append("Status mentah   : ").append(st.replace("\n", " ")).append('\n')
            sb.append("Dinyalakan user : ").append(if (Tool.on(n)) "ya" else "tidak (dimatikan lewat ⚙)").append('\n')
            sb.append("Tugas           : ").append(ROLE[n] ?: "-").append('\n')
            if (info != null) {
                sb.append("Cakupan         : ").append(info.scope).append('\n')
                sb.append("Implementasi    : ").append(info.impl).append('\n')
                sb.append("Dipicu saat     : ").append(info.trigger).append('\n')
                sb.append("Tanda sukses    : ").append(info.ok).append('\n')
                sb.append("Risiko gagal umum: ").append(info.risk).append('\n')
            }
            val steps = ToolStatus.history(n)
            sb.append("Riwayat langkah (terbaru di bawah, maks 40):\n")
            if (steps.isEmpty()) sb.append("   (belum ada langkah tercatat sejak aplikasi dibuka)\n") else steps.forEach { sb.append("   - ").append(it).append('\n') }
            sb.append("Indikasi penyebab (tebakan otomatis dari teks status; verifikasi sendiri):\n      ").append(cause(n, st)).append('\n')
        }
        sb.append('\n')

        // [7] penutup
        sb.append("[7] PERMINTAAN AKHIR\n")
        sb.append("Berdasarkan [1]-[6], analisa akar masalah setiap tool yang dilaporkan, beri perbaikan kode konkret (file + fungsi + patch) atau saran alternatif, urutkan prioritas, dan sebutkan data tambahan yang Anda perlukan. Jawab dalam bahasa Indonesia sesuai format di [0].\n")
        return sb.toString()
    }
}

class ReportActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private var tv: TextView? = null
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dm = resources.displayMetrics
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(8)); setBackgroundColor(0xFF262626.toInt()) }
        val title = TextView(this).apply { text = "⚡ Scan maksimal"; textSize = 16f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) }
        val body = TextView(this).apply { textSize = 12f; setTextColor(0xFFE0E0E0.toInt()); setTextIsSelectable(true); text = "Semua alat memindai maksimal… tunggu ${ScanReport.WAIT_MS / 1000} detik, laporan muncul otomatis." }
        tv = body
        val sc = ScrollView(this).apply { addView(body) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        fun btn(t: String, f: () -> Unit) = TextView(this).apply {
            text = t; textSize = 13f; setTextColor(0xFF80CBC4.toInt()); setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(dp(10), dp(12), dp(10), dp(12)); setOnClickListener { f() }
        }
        fun copy() {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("laporan semua alat", ScanReport.build(true)))
            Toast.makeText(this, "Laporan semua tool (untuk AI) disalin", Toast.LENGTH_SHORT).show()
        }
        row.addView(btn("SALIN SEMUA LOG") { copy() })
        row.addView(btn("ULANG") { h.removeCallbacksAndMessages(null); ScanReport.start(); body.text = "Memindai ulang…"; schedule() })
        row.addView(btn("TUTUP") { finish() })
        root.addView(title)
        root.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(row)
        setContentView(root, ViewGroup.LayoutParams((dm.widthPixels * 0.94).toInt(), (dm.heightPixels * 0.8).toInt()))
        window.setLayout((dm.widthPixels * 0.94).toInt(), (dm.heightPixels * 0.8).toInt())
        ScanReport.start()
        schedule()
    }

    private fun schedule() {
        h.postDelayed({ tv?.text = ScanReport.build(true) }, ScanReport.WAIT_MS)
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }
}
