package com.alfy.downloader.part3.scan

import com.alfy.downloader.part3.core.CaptureHub
import com.alfy.downloader.part3.core.Source
import com.alfy.downloader.part3.core.AppHeuristics
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Receives hostnames seen by the sniffers and pre-fetches the homepage JSON/HTML metadata. */
object HostWatcher {
    private val ignoreSuffix = listOf(
        "google.com", "googleapis.com", "gstatic.com", "googleusercontent.com", "gvt1.com", "gvt2.com",
        "doubleclick.net", "googlesyndication.com", "google-analytics.com", "android.com", "facebook.com",
        "fbcdn.net", "microsoft.com", "windowsupdate.com", "apple.com", "icloud.com", "cloudflare.com",
        "amazonaws.com", "crashlytics.com", "firebaseio.com", "app-measurement.com", "whatsapp.net",
        "whatsapp.com", "mozilla.org", "mozilla.com", "ocsp.digicert.com", "xiaomi.com", "miui.com",
        "samsung.com", "samsungapps.com", "ggpht.com", "youtube.com", "ytimg.com", "googlevideo.com"
    )
    private val ignoreWords = listOf("ads", "analytics", "track", "telemetry", "metrics", "beacon", "pixel", "stats", "log.")

    private val seen = ConcurrentHashMap<String, Long>()

    /** Debounce: returns true only if [key] was not seen within [ms]; keeps the cache bounded. */
    private fun debounce(key: String, ms: Long): Boolean {
        val now = System.currentTimeMillis()
        val last = seen[key]
        if (last != null && now - last < ms) return false
        if (seen.size > 800) {
            seen.entries.removeIf { now - it.value > ms }
            if (seen.size > 800) seen.clear()
        }
        seen[key] = now
        return true
    }

    /** Host extracted from a TLS ClientHello (SNI). Known stream CDNs raise a hint immediately. */
    fun onSni(host: String) {
        if (CaptureHub.throttled) return
        val label = AppHeuristics.streamLabel(host)
        if (label != null && debounce("sni:$label", 45_000)) {
            CaptureHub.hint("Stream $label terdeteksi (HTTPS terenkripsi). Mencoba mengenali otomatis; jika gagal salin link lalu Paste / Scan Layar.")
            CaptureHub.onEncryptedStream(label)
        }
        onHost(host)
    }

    fun onHost(host: String) {
        if (CaptureHub.throttled) return
        val h = host.lowercase(Locale.ROOT).trim('.')
        if (!debounce("h:$h", 15_000)) return
        if (h.isEmpty() || !h.contains('.')) return
        if (h.endsWith(".arpa") || h.endsWith(".local")) return
        if (ignoreSuffix.any { h == it || h.endsWith(".$it") }) return
        if (ignoreWords.any { h.startsWith(it) || h.contains(".$it") }) return
        CaptureHub.prefetchPage("https://$h/", Source.NETWORK)
    }
}
