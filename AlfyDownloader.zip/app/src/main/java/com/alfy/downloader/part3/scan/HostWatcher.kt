package com.alfy.downloader.part3.scan

import com.alfy.downloader.part3.core.CaptureHub
import com.alfy.downloader.part3.core.Source
import java.util.Locale

/** Receives hostnames seen by the sniffers and pre-fetches the homepage JSON/HTML metadata. */
object HostWatcher {
    private val ignoreSuffix = listOf(
        "google.com", "googleapis.com", "gstatic.com", "googleusercontent.com", "gvt1.com", "gvt2.com",
        "doubleclick.net", "googlesyndication.com", "google-analytics.com", "android.com", "facebook.com",
        "fbcdn.net", "microsoft.com", "windowsupdate.com", "apple.com", "icloud.com", "cloudflare.com",
        "amazonaws.com", "crashlytics.com", "firebaseio.com", "app-measurement.com", "whatsapp.net",
        "whatsapp.com", "mozilla.org", "mozilla.com", "ocsp.digicert.com", "xiaomi.com", "miui.com",
        "samsung.com", "samsungapps.com", "ggpht.com", "youtube.com", "ytimg.com", "googlevideo.com"
    )
    private val ignoreWords = listOf("ads", "analytics", "track", "telemetry", "metrics", "beacon", "pixel", "stats", "log.")

    fun onHost(host: String) {
        val h = host.lowercase(Locale.ROOT).trim('.')
        if (h.isEmpty() || !h.contains('.')) return
        if (h.endsWith(".arpa") || h.endsWith(".local")) return
        if (ignoreSuffix.any { h == it || h.endsWith(".$it") }) return
        if (ignoreWords.any { h.startsWith(it) || h.contains(".$it") }) return
        CaptureHub.prefetchPage("https://$h/", Source.NETWORK)
    }
}
