package com.alfy.downloader

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/** Log status tiap alat pemindai (tampil di panel menu mengambang dan di dalam aplikasi). */
object ToolLog {
    /** Nama alat yang sedang berjalan di thread ini; dipakai untuk label sumber tiap link. */
    val tl = ThreadLocal<String>()
    val ytNames = listOf("ytFast", "NewPipe", "yt-dlp", "yt-dlp+cookies", "Piped/Invidious", "HLS iOS/VR", "WebView")
    val siteNames = listOf("yt-dlp", "NewPipe", "WebView", "HTML")
    @Volatile var names: List<String> = ytNames
    private val st = ConcurrentHashMap<String, String>()
    @Volatile var vid = ""
    @Volatile var winner = ""

    fun begin(id: String, nm: List<String> = ytNames) { vid = id; winner = ""; names = nm; st.clear() }
    fun set(tool: String, s: String) { st[tool] = s }

    /** Satu baris ringkas per alat (untuk panel dua kolom). */
    fun lines(): List<String> = names.mapIndexed { i, n ->
        val s = (st[n] ?: "• menunggu").replace("– tidak perlu (sudah ada hasil)", "– lewati")
        "${i + 1}. $n  $s"
    }

    fun text(): String {
        val sb = StringBuilder()
        if (vid.isNotEmpty()) sb.append("Video $vid\n")
        names.forEachIndexed { i, n -> sb.append("${i + 1}. ").append(n.padEnd(16)).append(st[n] ?: "• menunggu").append('\n') }
        sb.append(AlfyNotifService.status)
        if (winner.isNotEmpty()) sb.append("\n→ Link dibuat oleh: ").append(winner)
        return sb.toString()
    }
}

/** Rantai alat pengambil link YouTube: jalan bersamaan (bertahap), berhenti memulai alat berat bila sudah ada hasil. */
object Chain {
    private val lastFail = ConcurrentHashMap<String, Long>()
    private val running = ConcurrentHashMap.newKeySet<String>()
    private val retried = ConcurrentHashMap.newKeySet<String>()
    private const val COOLDOWN = 60_000L

    private class Spec(val name: String, val delayMs: Long, val skipIfWon: Boolean, val fn: () -> String?)

    fun reason(e: Throwable): String {
        val m = e.message ?: e.javaClass.simpleName
        return when {
            m.contains("Sign in to confirm", true) || (m.contains("not a bot", true)) -> "bot check"
            m.contains("LOGIN_REQUIRED") -> "LOGIN_REQUIRED"
            m.contains("429") -> "429 dibatasi"
            m.contains("403") -> "403 ditolak"
            m.contains("timed out", true) || m.contains("timeout", true) -> "timeout"
            m.contains("Unable to resolve host", true) || m.contains("UnknownHost", true) -> "tidak ada internet"
            m.contains("Mesin unduh belum siap", true) -> "mesin yt-dlp belum siap"
            else -> (m.lineSequence().map { it.trim() }.lastOrNull { it.isNotEmpty() } ?: "gagal").take(70)
        }
    }

    fun run(id: String, page: String) {
        val now = SystemClock.elapsedRealtime()
        val lf = lastFail[id]
        if (lf != null && now - lf < COOLDOWN) {
            Resolver.diag = "YouTube: semua alat gagal, jeda ${(COOLDOWN - (now - lf)) / 1000} dtk sebelum coba lagi"
            Resolver.seen.remove(page)
            return
        }
        if (!running.add(id)) return
        ToolLog.begin(id)
        VpnTool.reapply()
        val ok = AtomicBoolean(false)
        try {
            Resolver.diag = "YouTube: memindai dengan 6 alat…"
            val specs = listOf(
                Spec("ytFast", 0L, false) { val w = StringBuilder(); if (Resolver.ytFast(id, w)) null else w.toString().trim().ifEmpty { "tanpa link" } },
                Spec("NewPipe", 0L, false) { NP.fetch(id) },
                Spec("yt-dlp", 0L, false) { Resolver.ytdlpTool(page, null); null },
                Spec("yt-dlp+cookies", 0L, false) { cookiesTool(page) },
                Spec("Piped/Invidious", 0L, false) { Inst.fetch(id) },
                Spec("HLS iOS/VR", 3000L, true) { if (Resolver.youtubeFallback(id, page)) null else "HLS iOS, VR: tanpa hasil" },
                Spec("WebView", 5000L, true) { WebTool.grab(id) }
            )
            runBlocking {
                val jobs = specs.map { sp ->
                    launch(Dispatchers.IO) {
                        if (sp.delayMs > 0) delay(sp.delayMs)
                        if (sp.skipIfWon && ok.get()) { ToolLog.set(sp.name, "– tidak perlu (sudah ada hasil)"); return@launch }
                        ToolLog.set(sp.name, "⏳ berjalan…")
                        ToolLog.tl.set(sp.name)
                        val r: String? = try { sp.fn() } catch (e: Throwable) { reason(e) }
                        ToolLog.tl.remove()
                        if (r == null) {
                            ok.set(true)
                            if (ToolLog.winner.isEmpty()) { ToolLog.winner = sp.name; Resolver.diag = "YouTube: link dari ${sp.name} ✓" }
                            ToolLog.set(sp.name, "✓ berhasil")
                        } else ToolLog.set(sp.name, "✗ $r")
                    }
                }
                jobs.joinAll()
            }
        } finally { running.remove(id) }
        if (ok.get()) {
            lastFail.remove(id)
            Resolver.diag = "YouTube: link dibuat oleh ${ToolLog.winner} ✓"
        } else {
            lastFail[id] = SystemClock.elapsedRealtime()
            Resolver.seen.remove(page)
            Resolver.diag = "YouTube: semua alat gagal (jeda 60 dtk)" + (if (!Cookies.hasLogin) ". SOLUSI: buka 📖 → LOGIN YOUTUBE" else "")
            if (retried.add(id)) Resolver.scope.launch {
                delay(COOLDOWN + 1000)
                Resolver.seen.remove(page)
                Resolver.submit(page, null, true)
            }
        }
    }

    /** Situs non-YouTube (TikTok, Instagram, Facebook, X, Vimeo, browser, dll): alat berjalan bersamaan. */
    fun runGeneric(page: String) {
        val now = SystemClock.elapsedRealtime()
        val lf = lastFail[page]
        if (lf != null && now - lf < COOLDOWN) { Resolver.seen.remove(page); return }
        if (!running.add(page)) return
        val host = try { android.net.Uri.parse(page).host ?: page } catch (e: Exception) { page }
        val hl = host.lowercase()
        val isJw = hl.endsWith("jwplyr.com") || hl.endsWith("overfetch.video") || hl.endsWith("vidoy.asia") || hl.endsWith("vidoy.com")
        val isX = hl == "x.com" || hl.endsWith(".x.com") || hl.endsWith("twitter.com")
        // alat khusus situs ditaruh paling atas (jalan paling dulu); alat umum tetap ikut berjalan bersamaan
        val specs = ArrayList<Spec>()
        if (isJw) specs.add(Spec("JWPlayer", 0L, false) { SiteTool.jw(page) })
        if (isX) specs.add(Spec("X-API", 0L, false) { SiteTool.xApi(page) })
        specs.add(Spec("yt-dlp", 0L, false) { Resolver.ytdlpTool(page, null); null })
        specs.add(Spec("NewPipe", 0L, false) { NP.fetchAny(page) })
        specs.add(Spec("WebView", if (isJw) 1500L else 2500L, true) { WebTool.grabPage(page) })
        specs.add(Spec("HTML", 0L, false) { if (Resolver.sniffSync(page) > 0) null else "tanpa media di halaman" })
        ToolLog.begin("Situs $host", specs.map { it.name })
        val ok = AtomicBoolean(false)
        try {
            Resolver.diag = "Situs $host: memindai dengan ${specs.size} alat…"
            runBlocking {
                val jobs = specs.map { sp ->
                    launch(Dispatchers.IO) {
                        if (sp.delayMs > 0) delay(sp.delayMs)
                        if (sp.skipIfWon && ok.get()) { ToolLog.set(sp.name, "– tidak perlu (sudah ada hasil)"); return@launch }
                        ToolLog.set(sp.name, "⏳ berjalan…")
                        ToolLog.tl.set(sp.name)
                        val r: String? = try { sp.fn() } catch (e: Throwable) { reason(e) }
                        ToolLog.tl.remove()
                        if (r == null) {
                            ok.set(true)
                            if (ToolLog.winner.isEmpty()) ToolLog.winner = sp.name
                            ToolLog.set(sp.name, "✓ berhasil")
                        } else ToolLog.set(sp.name, "✗ $r")
                    }
                }
                jobs.joinAll()
            }
        } finally { running.remove(page) }
        if (ok.get()) {
            lastFail.remove(page)
            Resolver.diag = "Situs $host: link dibuat oleh ${ToolLog.winner} ✓"
        } else {
            lastFail[page] = SystemClock.elapsedRealtime()
            Resolver.seen.remove(page)
            Resolver.diag = if (Resolver.captchaPage == page) "Situs $host: butuh CAPTCHA → ketuk 🌐 di panel, selesaikan, link akan terdeteksi"
                else "Situs $host: semua alat gagal (jeda 60 dtk)"
        }
    }

    private fun cookiesTool(page: String): String? {
        val f = Cookies.file() ?: return Cookies.why
        Resolver.ytdlpTool(page, f)
        return null
    }
}

/** NewPipeExtractor: peniru pemutar web YouTube (termasuk memecahkan kode pengaman link). Memakai refleksi agar tahan perubahan nama method. */
object NP {
    @Volatile private var inited = false

    class Dl : Downloader() {
        override fun execute(request: Request): Response {
            val c = URL(request.url()).openConnection() as HttpURLConnection
            c.requestMethod = request.httpMethod()
            c.connectTimeout = 15000; c.readTimeout = 20000
            c.instanceFollowRedirects = true
            var hasUa = false
            for ((k, vs) in request.headers()) {
                if (k.equals("Accept-Encoding", true)) continue   // biarkan HttpURLConnection mengurus gzip
                if (k.equals("User-Agent", true)) hasUa = true
                c.setRequestProperty(k, vs.joinToString(", "))
            }
            if (!hasUa) c.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0")
            val data = request.dataToSend()
            if (data != null) { c.doOutput = true; c.outputStream.use { it.write(data) } }
            val code = c.responseCode
            if (code == 429) { c.disconnect(); throw ReCaptchaException("reCaptcha/429 dari YouTube", request.url()) }
            val stream = if (code >= 400) c.errorStream else c.inputStream
            val body = try { stream?.bufferedReader()?.readText() ?: "" } catch (e: Exception) { "" }
            val hm = LinkedHashMap<String, List<String>>()
            for ((k, v) in c.headerFields) if (k != null) hm[k] = v
            val latest = c.url.toString()
            val msg = c.responseMessage ?: ""
            c.disconnect()
            return Response(code, msg, hm, body, latest)
        }
    }

    @Synchronized private fun init() {
        if (inited) return
        NewPipe.init(Dl())
        inited = true
    }

    private fun g(o: Any?, m: String): Any? = try { o?.javaClass?.getMethod(m)?.invoke(o) } catch (e: Exception) { null }

    /** Situs selain YouTube yang didukung NewPipe (SoundCloud, Bandcamp, PeerTube, dll). null = berhasil. */
    fun fetchAny(url: String): String? {
        init()
        val info: Any? = try {
            Class.forName("org.schabi.newpipe.extractor.stream.StreamInfo").getMethod("getInfo", String::class.java).invoke(null, url)
        } catch (e: java.lang.reflect.InvocationTargetException) { throw e.targetException ?: e }
        if (info == null) return "tanpa info"
        val title = ((g(info, "getName") as? String) ?: "").ifBlank { "Video" }
        val dur = (g(info, "getDuration") as? Long) ?: 0L
        val out = ArrayList<Candidate>()
        for ((k, audio) in listOf("getAudioStreams" to true, "getVideoStreams" to false)) {
            val l = (g(info, k) as? List<*>) ?: continue
            for (x in l) {
                if (x == null) continue
                val u = ((g(x, "getContent") as? String) ?: (g(x, "getUrl") as? String) ?: "")
                if (!u.startsWith("http")) continue
                val ext = Resolver.extOf(u).ifEmpty { if (audio) "m4a" else "mp4" }
                out.add(Candidate(key = "NP" + u.take(150), url = u, title = title,
                    kind = if (ext == "m3u8") Kind.HLS else Kind.DIRECT, isAudio = audio, ext = ext, size = -1,
                    quality = if (audio) "audio" else "video", duration = dur, formatSel = null, previewUrl = u, referer = url,
                    audioUrl = if (audio) u else null))
                if (out.size >= 6) break
            }
        }
        if (out.isEmpty()) return "tanpa stream"
        Repo.addCandidates(out)
        return null
    }

    /** null = berhasil, selain itu alasan gagal. */
    fun fetch(id: String): String? {
        init()
        val url = "https://www.youtube.com/watch?v=$id"
        val info: Any? = try {
            Class.forName("org.schabi.newpipe.extractor.stream.StreamInfo").getMethod("getInfo", String::class.java).invoke(null, url)
        } catch (e: java.lang.reflect.InvocationTargetException) { throw e.targetException ?: e }
        if (info == null) return "tanpa info"
        val title = (g(info, "getName") as? String) ?: ""
        val streams = ArrayList<Any>()
        for (k in listOf("getAudioStreams", "getVideoStreams", "getVideoOnlyStreams"))
            (g(info, k) as? List<*>)?.forEach { if (it != null) streams.add(it) }
        if (streams.isEmpty()) return "tanpa stream"
        var n = 0
        for (s in streams) {
            val u = ((g(s, "getContent") as? String) ?: (g(s, "getUrl") as? String) ?: "")
            if (!u.startsWith("http")) continue
            if (Resolver.isGv(u)) { Resolver.gv(u, null, title); n++ }
        }
        return if (n > 0) null else "stream bukan link googlevideo"
    }
}

/** WebView tersembunyi: memutar halaman YouTube asli lalu menangkap request googlevideo.com/videoplayback. */
object WebTool {
    private val adRe = Regex("doubleclick|googlesyndication|googleads|imasdk|adservice|/vast|adsystem|pubads|adnxs|popads|histats", RegexOption.IGNORE_CASE)
    private val assetExt = setOf("js", "css", "png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "woff", "woff2", "ttf", "otf", "json", "html", "htm", "map", "php", "txt", "xml", "ts")

    /** Apakah request ini kemungkinan file media? (ekstensi media, host file video, atau permintaan Range/Accept video dari elemen <video>). */
    internal fun looksMedia(u: String, r: WebResourceRequest): Boolean {
        if (adRe.containsMatchIn(u) || Resolver.isGv(u)) return false
        val ext = Resolver.extOf(u)
        if (ext == "ts") return false
        if (Resolver.isMedia(u)) return true
        if (r.isForMainFrame || ext in assetExt) return false
        val h = r.requestHeaders ?: return false
        return h["Range"] != null || (h["Accept"]?.startsWith("video/") == true)
    }

    /**
     * Halaman situs apa pun: tangkap request media. v1.3: sebuah link baru dihitung berhasil bila BENAR-BENAR masuk
     * daftar (sebelumnya semua request dihitung sehingga log ✓ tetapi daftar kosong); request diperiksa di thread alat,
     * deteksi CAPTCHA, dan klik tombol play JW Player otomatis. null = berhasil.
     */
    fun grabPage(page: String): String? {
        val found = AtomicInteger(0)
        val cap = AtomicBoolean(false)
        // v1.4: situs embed ber-iklan (jwplyr/vidoy/overfetch): hanya video dari host milik situs yang diterima, iklan & popup diblokir
        val strict = Resolver.isJwPage(page)
        val ads = AtomicInteger(0)
        val q = java.util.concurrent.ConcurrentLinkedQueue<Pair<String, String>>()
        val h = Handler(Looper.getMainLooper())
        var wv: WebView? = null
        val maxWait = if (strict) 30000 else 18000
        // JS: ambil alamat video langsung dari pemutar (JW Player playlist / <video> / <source>), lalu coba putar & klik tombol play
        val probeJs = "(function(){var o=[];try{if(window.jwplayer){var p=jwplayer().getPlaylist()||[];" +
            "p.forEach(function(it){if(it.file)o.push(it.file);(it.sources||[]).forEach(function(s){if(s.file)o.push(s.file);});});}}catch(e){}" +
            "try{document.querySelectorAll('video,source').forEach(function(v){if(v.currentSrc)o.push(v.currentSrc);if(v.src)o.push(v.src);});}catch(e){}" +
            "try{var v=document.querySelector('video');if(v){v.muted=true;v.play();}if(window.jwplayer){jwplayer().play();}}catch(e){}" +
            "try{var b=document.querySelector('.jw-icon-display,.jw-display-icon-container,.jw-icon-playback,.vjs-big-play-button,.plyr__control--overlaid,.fp-play');if(b)b.click();}catch(e){}" +
            "try{if(window.__alfy)o=o.concat(window.__alfy);}catch(e){}" +
            "return o.join('\\n');})()"
        // v1.5: pasang pengait fetch/XHR: link overfetch bertanda tangan (/s/TOKEN/EXPIRE/i/ID) sering diminta lewat API setelah halaman dibuka
        val hookJs = """(function(){if(window.__alfyH)return;window.__alfyH=1;window.__alfy=[];
function sc(t){try{var m=String(t).split('\\/').join('/').match(/https?:\/\/[^"'\s<>\\]*overfetch\.video[^"'\s<>\\]*/g);if(m)m.forEach(function(x){window.__alfy.push(x);});}catch(e){}}
var of=window.fetch;if(of)window.fetch=function(){var p=of.apply(this,arguments);try{p.then(function(r){try{r.clone().text().then(sc);}catch(e){}});}catch(e){}return p;};
var xs=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.send=function(){try{this.addEventListener('load',function(){try{sc(this.responseText);}catch(e){}});}catch(e){}return xs.apply(this,arguments);};})();"""
        h.post {
            try {
                val w = WebView(Repo.app)
                wv = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.mediaPlaybackRequiresUserGesture = false
                w.settings.userAgentString = Resolver.UA
                if (strict) { w.settings.setSupportMultipleWindows(false); w.settings.javaScriptCanOpenWindowsAutomatically = false }
                try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(w, true) } catch (e: Throwable) { }
                w.webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) { if (strict) view.evaluateJavascript(hookJs, null) }
                    override fun onPageCommitVisible(view: WebView, url: String) { if (strict) view.evaluateJavascript(hookJs, null) }
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        // iklan sering memindahkan halaman ke situs lain: tahan semua perpindahan keluar dari situs video
                        return strict && request.isForMainFrame && !Resolver.jwMediaOk(request.url.toString())
                    }
                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                        val u = request.url.toString()
                        if (strict && !Resolver.jwMediaOk(u)) {
                            val ext = Resolver.extOf(u)
                            if (adRe.containsMatchIn(u) || ext == "mp4" || ext == "webm" || ext == "m3u8" || looksMedia(u, request)) {
                                // video/skrip iklan: jangan dimuat sama sekali (lebih cepat, dan tidak masuk daftar)
                                if (ext == "mp4" || ext == "webm" || ext == "m3u8" || looksMedia(u, request)) ads.incrementAndGet()
                                return WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0)))
                            }
                            return null
                        }
                        if (looksMedia(u, request)) q.add(Pair(u, request.requestHeaders?.get("Referer") ?: page))
                        return null
                    }
                    override fun onPageFinished(view: WebView, url: String) {
                        if (strict) view.evaluateJavascript(hookJs, null)
                        view.evaluateJavascript(
                            "(function(){var t=0;var i=setInterval(function(){var v=document.querySelector('video');" +
                                "if(v){v.muted=true;try{v.play();}catch(e){}}" +
                                "var b=document.querySelector('.jw-icon-display,.jw-display-icon-container,.jw-icon-playback,.vjs-big-play-button,.plyr__control--overlaid,.fp-play');" +
                                "if(b&&t%4==0){try{b.click();}catch(e){}}if(++t>50)clearInterval(i);},500);})();", null)
                        view.evaluateJavascript(
                            "(function(){var b=document.body?document.body.innerText.slice(0,4000):'';" +
                                "if(document.documentElement.innerHTML.indexOf('turnstile')>=0)b+=' turnstile';return b;})()") { r ->
                            if (r != null && SiteTool.captchaRe.containsMatchIn(r)) cap.set(true)
                        }
                    }
                }
                if (strict) w.loadUrl(page, mapOf("Referer" to "https://vidoy.asia/")) else w.loadUrl(page)
            } catch (e: Throwable) { }
        }
        var waited = 0
        var firstAt = -1
        val tried = HashSet<String>()
        while (waited < maxWait) {
            // v1.4: tiap ~1,5 dtk tanya pemutar halaman langsung (alamat video sering sudah ada sebelum diputar)
            if (strict && waited % 1500 == 0 && waited >= 1500) h.post {
                try {
                    wv?.evaluateJavascript(probeJs) { r ->
                        if (r != null && r.length > 2) {
                            val t = r.trim('"').replace("\\n", "\n").replace("\\/", "/").replace("\\u0026", "&")
                            for (x in t.split('\n')) if (x.startsWith("http") && Resolver.jwMediaOk(x)) q.add(Pair(x, page))
                        }
                    }
                } catch (e: Throwable) { }
            }
            var p = q.poll()
            while (p != null) {
                if (tried.add(p.first)) {
                    ToolLog.tl.set("WebView")
                    val ok = try { Resolver.addMediaChecked(p.first, p.second, "", true) } catch (e: Exception) { false }
                    ToolLog.tl.remove()
                    if (ok) { found.incrementAndGet(); if (firstAt < 0) firstAt = waited }
                }
                p = q.poll()
            }
            if (firstAt >= 0 && waited - firstAt >= 1500) break          // sudah dapat link: beri 1,5 dtk untuk kualitas lain
            if (cap.get() && found.get() == 0 && waited >= 8000) break   // CAPTCHA: tidak ada gunanya menunggu lebih lama
            Thread.sleep(300); waited += 300
        }
        h.post { try { wv?.stopLoading(); wv?.destroy() } catch (e: Throwable) { }; wv = null }
        if (found.get() > 0) return null
        if (cap.get()) { Resolver.captchaPage = page; return "butuh CAPTCHA → ketuk 🌐 di panel" }
        val adNote = if (ads.get() > 0) ", ${ads.get()} video iklan diblokir" else ""
        return if (tried.isEmpty()) "tidak ada video milik situs$adNote" else "${tried.size} request media, semua ditolak$adNote"
    }

    fun grab(id: String): String? {
        val found = AtomicInteger(0)
        val h = Handler(Looper.getMainLooper())
        var wv: WebView? = null
        h.post {
            try {
                val w = WebView(Repo.app)
                wv = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.mediaPlaybackRequiresUserGesture = false
                w.settings.userAgentString = Resolver.UA
                w.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                        val u = request.url.toString()
                        if (Resolver.isGv(u)) {
                            ToolLog.tl.set("WebView")
                            try { Resolver.gv(u, null, ""); found.incrementAndGet() } catch (e: Exception) { }
                            ToolLog.tl.remove()
                        }
                        return null
                    }
                    override fun onPageFinished(view: WebView, url: String) {
                        view.evaluateJavascript(
                            "(function(){var t=0;var i=setInterval(function(){var v=document.querySelector('video');" +
                                "if(v){v.muted=true;try{v.play();}catch(e){}}if(++t>40)clearInterval(i);},500);})();", null)
                    }
                }
                w.loadUrl("https://m.youtube.com/watch?v=$id")
            } catch (e: Throwable) { }
        }
        var waited = 0
        while (waited < 25000 && found.get() < 2) { Thread.sleep(500); waited += 500 }
        h.post { try { wv?.stopLoading(); wv?.destroy() } catch (e: Throwable) { }; wv = null }
        return if (found.get() > 0) null else "tidak ada request googlevideo"
    }
}

/** Muat halaman situs apa pun di WebView tersembunyi lalu tangkap request file media (mp4/m3u8/mp3/dll). */
/** Cookies login YouTube: dari WebView (login di Browser aplikasi) dan, bila root, dari database Firefox. */
object Cookies {
    @Volatile var why = "belum ada cookies login: buka 📖 → LOGIN YOUTUBE"
    @Volatile var hasLogin = false

    private fun line(host: String, path: String, secure: Boolean, exp: Long, name: String, value: String) =
        host + "\t" + (if (host.startsWith(".")) "TRUE" else "FALSE") + "\t" + path + "\t" + (if (secure) "TRUE" else "FALSE") + "\t" + exp + "\t" + name + "\t" + value

    private fun webViewLines(): List<String> {
        val out = ArrayList<String>()
        try {
            val cm = android.webkit.CookieManager.getInstance()
            val exp = System.currentTimeMillis() / 1000 + 180L * 86400
            for (d in listOf("https://www.youtube.com", "https://accounts.google.com", "https://www.google.com")) {
                val raw = cm.getCookie(d) ?: continue
                val host = "." + (Uri.parse(d).host ?: continue).removePrefix("www.")
                for (part in raw.split(";")) {
                    val i = part.indexOf('=')
                    if (i <= 0) continue
                    out.add(line(host, "/", true, exp, part.substring(0, i).trim(), part.substring(i + 1).trim()))
                }
            }
        } catch (e: Throwable) { }
        return out
    }

    @Volatile private var browserCache: List<String> = emptyList()
    @Volatile private var browserAt = 0L

    /** Root: salin database cookies Firefox dan browser Chromium (Chrome, Brave, Kiwi, Edge, dll) lalu baca cookies YouTube/Google. */
    private fun browserLines(): List<String> {
        if (System.currentTimeMillis() - browserAt < 60_000) return browserCache
        val out = ArrayList<String>()
        try {
            val tmp = File(Repo.app.cacheDir, "ffc")
            tmp.deleteRecursively(); tmp.mkdirs()
            val d = "\$"
            val cmd = "i=0; for f in /data/data/*/app_*/Default/Cookies /data/data/*/app_*/Default/Network/Cookies " +
                "/data/data/org.mozilla.*/files/mozilla/*/cookies.sqlite; do [ -f \"${d}f\" ] || continue; i=${d}((i+1)); " +
                "cp \"${d}f\" ${tmp.path}/c${d}i.db 2>/dev/null; [ -f \"${d}f-wal\" ] && cp \"${d}f-wal\" ${tmp.path}/c${d}i.db-wal; done; chmod -R 777 ${tmp.path}"
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            p.inputStream.readBytes(); p.waitFor()
            var encrypted = 0
            for (db in (tmp.listFiles() ?: emptyArray()).filter { it.name.endsWith(".db") }) {
                try {
                    val sq = android.database.sqlite.SQLiteDatabase.openDatabase(db.path, null, android.database.sqlite.SQLiteDatabase.OPEN_READWRITE)
                    try {
                        val names = ArrayList<String>()
                        val t = sq.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null)
                        while (t.moveToNext()) names.add(t.getString(0))
                        t.close()
                        if ("moz_cookies" in names) {
                            val c = sq.rawQuery("SELECT host, path, isSecure, expiry, name, value FROM moz_cookies WHERE host LIKE '%youtube.com' OR host LIKE '%google.com'", null)
                            while (c.moveToNext()) {
                                var exp = c.getLong(3)
                                if (exp > 100000000000L) exp /= 1000
                                out.add(line(c.getString(0), c.getString(1), c.getInt(2) != 0, exp, c.getString(4), c.getString(5)))
                            }
                            c.close()
                        } else if ("cookies" in names) {
                            val c = sq.rawQuery("SELECT host_key, path, is_secure, expires_utc, name, value, length(encrypted_value) FROM cookies WHERE host_key LIKE '%youtube.com' OR host_key LIKE '%google.com'", null)
                            while (c.moveToNext()) {
                                val v = c.getString(5) ?: ""
                                if (v.isEmpty()) { if (c.getInt(6) > 0) encrypted++; continue }
                                var exp = c.getLong(3) / 1000000 - 11644473600L
                                if (exp < 0) exp = System.currentTimeMillis() / 1000 + 86400L * 30
                                out.add(line(c.getString(0), c.getString(1), c.getInt(2) != 0, exp, c.getString(4), v))
                            }
                            c.close()
                        }
                    } finally { sq.close() }
                } catch (e: Throwable) { }
            }
            if (encrypted > 0 && out.isEmpty()) why = "cookies browser terenkripsi; login lewat tombol LOGIN YOUTUBE di 📖"
            tmp.deleteRecursively()
        } catch (e: Throwable) { }
        browserCache = out; browserAt = System.currentTimeMillis()
        return out
    }

    /** Path file cookies format Netscape (untuk yt-dlp --cookies) atau null bila belum ada cookies login. */
    fun file(): String? {
        val lines = LinkedHashMap<String, String>()
        for (l in webViewLines() + browserLines()) {
            val f = l.split("\t")
            if (f.size >= 7) lines[f[0] + "|" + f[5]] = l
        }
        val names = lines.keys.map { it.substringAfter('|') }.toSet()
        if (names.none { it == "SID" || it == "__Secure-3PSID" || it == "LOGIN_INFO" }) {
            if (!why.startsWith("cookies browser")) why = "belum ada cookies login: buka 📖 → LOGIN YOUTUBE"
            hasLogin = false
            return null
        }
        hasLogin = true
        val f = File(Repo.app.filesDir, "cookies.txt")
        f.writeText("# Netscape HTTP Cookie File\n" + lines.values.joinToString("\n") + "\n")
        return f.path
    }
}

/** Keluarkan AlfyDownloader dari VPN agar IP yang dipakai YouTube = IP asli jaringan (tanpa root: bind jaringan; dengan root: aturan routing). */
object VpnTool {
    @Volatile var status = "Lepas VPN: mati"

    fun enabled() = Repo.prefs().getBoolean("noVpn", false)

    fun reapply() { if (enabled()) bind(true) }

    private fun bind(on: Boolean): String {
        return try {
            val cm = Repo.app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            if (!on) { cm.bindProcessToNetwork(null); return "bind dilepas" }
            var pick: android.net.Network? = null
            @Suppress("DEPRECATION")
            for (n in cm.allNetworks) {
                val c = cm.getNetworkCapabilities(n) ?: continue
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                if (pick == null || c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) pick = n
            }
            if (pick == null) "tidak ada jaringan non-VPN" else { cm.bindProcessToNetwork(pick); "bind ke jaringan asli ✓" }
        } catch (e: Throwable) { "bind gagal: ${e.message}" }
    }

    private fun rootRule(on: Boolean): String {
        return try {
            val uid = android.os.Process.myUid()
            val d = "\$"
            val cmd = if (!on) "ip rule del uidrange $uid-$uid priority 9000 2>/dev/null; echo ok"
            else "t=${d}(ip -4 route show table all | grep '^default' | grep -v -E 'dev (tun|ppp|tap|wg)' | grep -o 'table [^ ]*' | head -1 | cut -d' ' -f2); " +
                "[ -n \"${d}t\" ] || { echo notable; exit 3; }; " +
                "ip rule del uidrange $uid-$uid priority 9000 2>/dev/null; " +
                "ip rule add uidrange $uid-$uid lookup ${d}t priority 9000 && echo ok || echo fail"
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val o = p.inputStream.bufferedReader().readText().trim()
            p.waitFor()
            when {
                o.endsWith("ok") -> "rute root ✓"
                o.contains("notable") -> "rute root: tabel jaringan asli tidak ketemu"
                else -> "rute root gagal"
            }
        } catch (e: Throwable) { "root tidak tersedia" }
    }

    fun set(on: Boolean) {
        Repo.prefs().edit().putBoolean("noVpn", on).apply()
        status = if (on) "Lepas VPN: memproses…" else "Lepas VPN: mati"
        Thread {
            val a = bind(on)
            val b = rootRule(on)
            status = if (on) "Lepas VPN: aktif ($a; $b)" else "Lepas VPN: mati"
        }.start()
    }
}


/** Server publik Piped / Invidious (daftar diambil otomatis). Link-nya diproksikan lewat server itu, jadi tidak terikat IP VPN-mu. */
object Inst {
    @Volatile private var piped: List<String> = emptyList()
    @Volatile private var inv: List<String> = emptyList()
    @Volatile private var at = 0L
    private val staticPiped = listOf("https://pipedapi.kavin.rocks", "https://api.piped.private.coffee", "https://pipedapi.adminforge.de", "https://pipedapi.leptons.xyz", "https://pipedapi.nosebs.ru")
    private val staticInv = listOf("https://yewtu.be", "https://inv.nadeko.net", "https://invidious.nerdvpn.de", "https://invidious.privacyredirect.com")

    @Synchronized private fun load() {
        if (System.currentTimeMillis() - at < 600_000 && (piped.isNotEmpty() || inv.isNotEmpty())) return
        val p = ArrayList<String>(); val v = ArrayList<String>()
        try {
            val a = org.json.JSONArray(Resolver.getText("https://piped-instances.kavin.rocks/", null))
            for (i in 0 until a.length()) { val u = a.optJSONObject(i)?.optString("api_url", "") ?: ""; if (u.startsWith("http")) p.add(u.trimEnd('/')) }
        } catch (e: Throwable) { }
        try {
            val a = org.json.JSONArray(Resolver.getText("https://api.invidious.io/instances.json?sort_by=health", null))
            for (i in 0 until a.length()) {
                val o = a.optJSONArray(i)?.optJSONObject(1) ?: continue
                if (o.optString("type") == "https" && o.optBoolean("api", false)) { val u = o.optString("uri", ""); if (u.startsWith("http")) v.add(u.trimEnd('/')) }
            }
        } catch (e: Throwable) { }
        piped = (p.take(8) + staticPiped).distinct()
        inv = (v.take(8) + staticInv).distinct()
        at = System.currentTimeMillis()
    }

    private fun addPiped(base: String, id: String): Int {
        val j = org.json.JSONObject(Resolver.getText("$base/streams/$id", null))
        val title = j.optString("title", "YouTube $id"); val dur = j.optLong("duration", 0L)
        var best: org.json.JSONObject? = null
        val aus = j.optJSONArray("audioStreams")
        if (aus != null) for (i in 0 until aus.length()) {
            val o = aus.optJSONObject(i) ?: continue
            if (o.optString("url").isEmpty() || !o.optString("mimeType").startsWith("audio/mp4")) continue
            if (best == null || o.optLong("bitrate") > best.optLong("bitrate")) best = o
        }
        val out = ArrayList<Candidate>()
        val vs = j.optJSONArray("videoStreams")
        if (vs != null) for (i in 0 until vs.length()) {
            val o = vs.optJSONObject(i) ?: continue
            val u = o.optString("url"); if (u.isEmpty()) continue
            val q = o.optString("quality", "-")
            val vOnly = o.optBoolean("videoOnly", true)
            val isMp4 = o.optString("mimeType").startsWith("video/mp4") && o.optString("codec").startsWith("avc")
            if (!vOnly) out.add(Candidate(key = "PP$id|$q|m", url = u, title = title, kind = Kind.DIRECT, isAudio = false, ext = "mp4",
                size = o.optLong("contentLength", -1), quality = q, duration = dur, formatSel = null, previewUrl = u, referer = null))
            else if (isMp4 && best != null) { val au = best.getString("url")
                out.add(Candidate(key = "PP$id|$q|v", url = u, title = title, kind = Kind.DIRECT, isAudio = false, ext = "mp4",
                    size = o.optLong("contentLength", -1), quality = q, duration = dur, formatSel = "MERGE:$au\n", previewUrl = u, referer = null, audioUrl = au, muted = true)) }
        }
        best?.let { o -> out.add(Candidate(key = "PP$id|a", url = o.getString("url"), title = title, kind = Kind.DIRECT, isAudio = true, ext = "m4a",
            size = o.optLong("contentLength", -1), quality = "audio", duration = dur, formatSel = null, previewUrl = o.getString("url"), referer = null, audioUrl = o.getString("url"))) }
        if (out.isNotEmpty()) Repo.addCandidates(out)
        return out.size
    }

    private fun addInv(base: String, id: String): Int {
        val j = org.json.JSONObject(Resolver.getText("$base/api/v1/videos/$id?local=true&fields=title,lengthSeconds,formatStreams,adaptiveFormats", null))
        val title = j.optString("title", "YouTube $id"); val dur = j.optLong("lengthSeconds", 0L)
        val out = ArrayList<Candidate>()
        val fs = j.optJSONArray("formatStreams")
        if (fs != null) for (i in 0 until fs.length()) {
            val o = fs.optJSONObject(i) ?: continue
            val u = o.optString("url"); if (u.isEmpty()) continue
            out.add(Candidate(key = "IV$id|${o.optString("itag")}", url = u, title = title, kind = Kind.DIRECT, isAudio = false, ext = "mp4",
                size = -1, quality = o.optString("qualityLabel", o.optString("quality", "-")), duration = dur, formatSel = null, previewUrl = u, referer = null))
        }
        val af = j.optJSONArray("adaptiveFormats")
        var best: org.json.JSONObject? = null
        if (af != null) for (i in 0 until af.length()) {
            val o = af.optJSONObject(i) ?: continue
            if (o.optString("type").startsWith("audio/mp4") && o.optString("url").isNotEmpty() &&
                (best == null || o.optString("bitrate").toLongOrNull() ?: 0L > (best.optString("bitrate").toLongOrNull() ?: 0L))) best = o
        }
        best?.let { o -> out.add(Candidate(key = "IV$id|a", url = o.getString("url"), title = title, kind = Kind.DIRECT, isAudio = true, ext = "m4a",
            size = o.optString("clen").toLongOrNull() ?: -1, quality = "audio", duration = dur, formatSel = null, previewUrl = o.getString("url"), referer = null, audioUrl = o.getString("url"))) }
        if (out.isNotEmpty()) Repo.addCandidates(out)
        return out.size
    }

    /** null = berhasil. Mencoba banyak server sekaligus; yang pertama berhasil menang. */
    fun fetch(id: String): String? {
        load()
        val tag = ToolLog.tl.get() ?: "Piped/Invidious"
        val jobs = piped.take(8).map { b -> Pair("P", b) } + inv.take(8).map { b -> Pair("I", b) }
        if (jobs.isEmpty()) return "daftar server kosong"
        val ex = java.util.concurrent.Executors.newFixedThreadPool(8)
        try {
            val cs = java.util.concurrent.ExecutorCompletionService<Int>(ex)
            for ((kind, base) in jobs) cs.submit {
                ToolLog.tl.set(tag)
                try { if (kind == "P") addPiped(base, id) else addInv(base, id) } catch (e: Throwable) { 0 } finally { ToolLog.tl.remove() }
            }
            var done = 0
            while (done < jobs.size) {
                val fut = try { cs.poll(40, java.util.concurrent.TimeUnit.SECONDS) } catch (e: Throwable) { null }
                if (fut == null) break
                done++
                val r = try { fut.get() } catch (e: Throwable) { 0 }
                if (r > 0) return null
            }
            return "${jobs.size} server publik: tidak ada hasil"
        } finally { ex.shutdownNow() }
    }
}
