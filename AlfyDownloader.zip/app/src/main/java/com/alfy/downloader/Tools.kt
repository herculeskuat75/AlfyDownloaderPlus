package com.alfy.downloader

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/** Log status tiap alat pemindai (tampil di panel menu mengambang dan di dalam aplikasi). */
object ToolLog {
    /** Nama alat yang sedang berjalan di thread ini; dipakai untuk label sumber tiap link. */
    val tl = ThreadLocal<String>()
    val names = listOf("ytFast", "NewPipe", "yt-dlp", "HLS/Piped", "WebView", "yt-dlp+cookies")
    private val st = ConcurrentHashMap<String, String>()
    @Volatile var vid = ""
    @Volatile var winner = ""

    fun begin(id: String) { vid = id; winner = ""; st.clear() }
    fun set(tool: String, s: String) { st[tool] = s }

    fun text(): String {
        val sb = StringBuilder()
        if (vid.isNotEmpty()) sb.append("Video $vid\n")
        for (n in names) sb.append(n.padEnd(15)).append(st[n] ?: "• menunggu").append('\n')
        sb.append(AlfyNotifService.status)
        if (winner.isNotEmpty()) sb.append("\n→ Link dibuat oleh: ").append(winner)
        return sb.toString()
    }
}

/** Rantai alat pengambil link YouTube: jalan bersamaan (bertahap), berhenti memulai alat berat bila sudah ada hasil. */
object Chain {
    private val lastFail = ConcurrentHashMap<String, Long>()
    private val running = ConcurrentHashMap.newKeySet<String>()
    private val retried = ConcurrentHashMap.newKeySet<String>()
    private const val COOLDOWN = 60_000L

    private class Spec(val name: String, val delayMs: Long, val skipIfWon: Boolean, val fn: () -> String?)

    fun reason(e: Throwable): String {
        val m = e.message ?: e.javaClass.simpleName
        return when {
            m.contains("Sign in to confirm", true) || (m.contains("not a bot", true)) -> "bot check"
            m.contains("LOGIN_REQUIRED") -> "LOGIN_REQUIRED"
            m.contains("429") -> "429 dibatasi"
            m.contains("403") -> "403 ditolak"
            m.contains("timed out", true) || m.contains("timeout", true) -> "timeout"
            m.contains("Unable to resolve host", true) || m.contains("UnknownHost", true) -> "tidak ada internet"
            m.contains("Mesin unduh belum siap", true) -> "mesin yt-dlp belum siap"
            else -> (m.lineSequence().map { it.trim() }.lastOrNull { it.isNotEmpty() } ?: "gagal").take(70)
        }
    }

    fun run(id: String, page: String) {
        val now = SystemClock.elapsedRealtime()
        val lf = lastFail[id]
        if (lf != null && now - lf < COOLDOWN) {
            Resolver.diag = "YouTube: semua alat gagal, jeda ${(COOLDOWN - (now - lf)) / 1000} dtk sebelum coba lagi"
            Resolver.seen.remove(page)
            return
        }
        if (!running.add(id)) return
        ToolLog.begin(id)
        VpnTool.reapply()
        val ok = AtomicBoolean(false)
        try {
            Resolver.diag = "YouTube: memindai dengan 6 alat…"
            val specs = listOf(
                Spec("ytFast", 0L, false) { val w = StringBuilder(); if (Resolver.ytFast(id, w)) null else w.toString().trim().ifEmpty { "tanpa link" } },
                Spec("NewPipe", 0L, false) { NP.fetch(id) },
                Spec("yt-dlp", 0L, false) { Resolver.ytdlpTool(page, null); null },
                Spec("HLS/Piped", 4000L, true) { if (Resolver.youtubeFallback(id, page)) null else "HLS iOS, VR, Piped: tanpa hasil" },
                Spec("yt-dlp+cookies", 6000L, true) { cookiesTool(page) },
                Spec("WebView", 8000L, true) { WebTool.grab(id) }
            )
            runBlocking {
                val jobs = specs.map { sp ->
                    launch(Dispatchers.IO) {
                        if (sp.delayMs > 0) delay(sp.delayMs)
                        if (sp.skipIfWon && ok.get()) { ToolLog.set(sp.name, "– tidak perlu (sudah ada hasil)"); return@launch }
                        ToolLog.set(sp.name, "⏳ berjalan…")
                        ToolLog.tl.set(sp.name)
                        val r: String? = try { sp.fn() } catch (e: Throwable) { reason(e) }
                        ToolLog.tl.remove()
                        if (r == null) {
                            ok.set(true)
                            if (ToolLog.winner.isEmpty()) { ToolLog.winner = sp.name; Resolver.diag = "YouTube: link dari ${sp.name} ✓" }
                            ToolLog.set(sp.name, "✓ berhasil")
                        } else ToolLog.set(sp.name, "✗ $r")
                    }
                }
                jobs.joinAll()
            }
        } finally { running.remove(id) }
        if (ok.get()) {
            lastFail.remove(id)
            Resolver.diag = "YouTube: link dibuat oleh ${ToolLog.winner} ✓"
        } else {
            lastFail[id] = SystemClock.elapsedRealtime()
            Resolver.seen.remove(page)
            Resolver.diag = "YouTube: semua alat gagal (jeda 60 dtk, lihat log di atas)"
            if (retried.add(id)) Resolver.scope.launch {
                delay(COOLDOWN + 1000)
                Resolver.seen.remove(page)
                Resolver.submit(page, null, true)
            }
        }
    }

    private fun cookiesTool(page: String): String? {
        val f = Cookies.file() ?: return Cookies.why
        Resolver.ytdlpTool(page, f)
        return null
    }
}

/** NewPipeExtractor: peniru pemutar web YouTube (termasuk memecahkan kode pengaman link). Memakai refleksi agar tahan perubahan nama method. */
object NP {
    @Volatile private var inited = false

    class Dl : Downloader() {
        override fun execute(request: Request): Response {
            val c = URL(request.url()).openConnection() as HttpURLConnection
            c.requestMethod = request.httpMethod()
            c.connectTimeout = 15000; c.readTimeout = 20000
            c.instanceFollowRedirects = true
            var hasUa = false
            for ((k, vs) in request.headers()) {
                if (k.equals("Accept-Encoding", true)) continue   // biarkan HttpURLConnection mengurus gzip
                if (k.equals("User-Agent", true)) hasUa = true
                c.setRequestProperty(k, vs.joinToString(", "))
            }
            if (!hasUa) c.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0")
            val data = request.dataToSend()
            if (data != null) { c.doOutput = true; c.outputStream.use { it.write(data) } }
            val code = c.responseCode
            if (code == 429) { c.disconnect(); throw ReCaptchaException("reCaptcha/429 dari YouTube", request.url()) }
            val stream = if (code >= 400) c.errorStream else c.inputStream
            val body = try { stream?.bufferedReader()?.readText() ?: "" } catch (e: Exception) { "" }
            val hm = LinkedHashMap<String, List<String>>()
            for ((k, v) in c.headerFields) if (k != null) hm[k] = v
            val latest = c.url.toString()
            val msg = c.responseMessage ?: ""
            c.disconnect()
            return Response(code, msg, hm, body, latest)
        }
    }

    @Synchronized private fun init() {
        if (inited) return
        NewPipe.init(Dl())
        inited = true
    }

    private fun g(o: Any?, m: String): Any? = try { o?.javaClass?.getMethod(m)?.invoke(o) } catch (e: Exception) { null }

    /** null = berhasil, selain itu alasan gagal. */
    fun fetch(id: String): String? {
        init()
        val url = "https://www.youtube.com/watch?v=$id"
        val info: Any? = try {
            Class.forName("org.schabi.newpipe.extractor.stream.StreamInfo").getMethod("getInfo", String::class.java).invoke(null, url)
        } catch (e: java.lang.reflect.InvocationTargetException) { throw e.targetException ?: e }
        if (info == null) return "tanpa info"
        val title = (g(info, "getName") as? String) ?: ""
        val streams = ArrayList<Any>()
        for (k in listOf("getAudioStreams", "getVideoStreams", "getVideoOnlyStreams"))
            (g(info, k) as? List<*>)?.forEach { if (it != null) streams.add(it) }
        if (streams.isEmpty()) return "tanpa stream"
        var n = 0
        for (s in streams) {
            val u = ((g(s, "getContent") as? String) ?: (g(s, "getUrl") as? String) ?: "")
            if (!u.startsWith("http")) continue
            if (Resolver.isGv(u)) { Resolver.gv(u, null, title); n++ }
        }
        return if (n > 0) null else "stream bukan link googlevideo"
    }
}

/** WebView tersembunyi: memutar halaman YouTube asli lalu menangkap request googlevideo.com/videoplayback. */
object WebTool {
    fun grab(id: String): String? {
        val found = AtomicInteger(0)
        val h = Handler(Looper.getMainLooper())
        var wv: WebView? = null
        h.post {
            try {
                val w = WebView(Repo.app)
                wv = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.mediaPlaybackRequiresUserGesture = false
                w.settings.userAgentString = Resolver.UA
                w.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                        val u = request.url.toString()
                        if (Resolver.isGv(u)) {
                            ToolLog.tl.set("WebView")
                            try { Resolver.gv(u, null, ""); found.incrementAndGet() } catch (e: Exception) { }
                            ToolLog.tl.remove()
                        }
                        return null
                    }
                    override fun onPageFinished(view: WebView, url: String) {
                        view.evaluateJavascript(
                            "(function(){var t=0;var i=setInterval(function(){var v=document.querySelector('video');" +
                                "if(v){v.muted=true;try{v.play();}catch(e){}}if(++t>40)clearInterval(i);},500);})();", null)
                    }
                }
                w.loadUrl("https://m.youtube.com/watch?v=$id")
            } catch (e: Throwable) { }
        }
        var waited = 0
        while (waited < 25000 && found.get() < 2) { Thread.sleep(500); waited += 500 }
        h.post { try { wv?.stopLoading(); wv?.destroy() } catch (e: Throwable) { }; wv = null }
        return if (found.get() > 0) null else "tidak ada request googlevideo"
    }
}

/** Cookies login YouTube: dari WebView (login di Browser aplikasi) dan, bila root, dari database Firefox. */
object Cookies {
    @Volatile var why = "belum ada cookies login (login YouTube di Browser aplikasi, atau Firefox + root)"

    private fun line(host: String, path: String, secure: Boolean, exp: Long, name: String, value: String) =
        host + "\t" + (if (host.startsWith(".")) "TRUE" else "FALSE") + "\t" + path + "\t" + (if (secure) "TRUE" else "FALSE") + "\t" + exp + "\t" + name + "\t" + value

    private fun webViewLines(): List<String> {
        val out = ArrayList<String>()
        try {
            val cm = android.webkit.CookieManager.getInstance()
            val exp = System.currentTimeMillis() / 1000 + 180L * 86400
            for (d in listOf("https://www.youtube.com", "https://accounts.google.com", "https://www.google.com")) {
                val raw = cm.getCookie(d) ?: continue
                val host = "." + (Uri.parse(d).host ?: continue).removePrefix("www.")
                for (part in raw.split(";")) {
                    val i = part.indexOf('=')
                    if (i <= 0) continue
                    out.add(line(host, "/", true, exp, part.substring(0, i).trim(), part.substring(i + 1).trim()))
                }
            }
        } catch (e: Throwable) { }
        return out
    }

    private fun firefoxLines(): List<String> {
        val out = ArrayList<String>()
        try {
            val tmp = File(Repo.app.cacheDir, "ffc")
            tmp.deleteRecursively(); tmp.mkdirs()
            val d = "\$"
            val cmd = "for p in /data/data/org.mozilla.*/files/mozilla/*; do [ -f ${d}p/cookies.sqlite ] && cp ${d}p/cookies.sqlite* ${tmp.path}/ && break; done; chmod -R 777 ${tmp.path}"
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            p.inputStream.readBytes(); p.waitFor()
            val db = File(tmp, "cookies.sqlite")
            if (!db.exists()) return out
            val sq = android.database.sqlite.SQLiteDatabase.openDatabase(db.path, null, android.database.sqlite.SQLiteDatabase.OPEN_READWRITE)
            try {
                val c = sq.rawQuery("SELECT host, path, isSecure, expiry, name, value FROM moz_cookies WHERE host LIKE '%youtube.com' OR host LIKE '%google.com'", null)
                while (c.moveToNext()) {
                    var exp = c.getLong(3)
                    if (exp > 100000000000L) exp /= 1000
                    out.add(line(c.getString(0), c.getString(1), c.getInt(2) != 0, exp, c.getString(4), c.getString(5)))
                }
                c.close()
            } finally { sq.close() }
            tmp.deleteRecursively()
        } catch (e: Throwable) { }
        return out
    }

    /** Path file cookies format Netscape (untuk yt-dlp --cookies) atau null bila belum ada cookies login. */
    fun file(): String? {
        val lines = LinkedHashMap<String, String>()
        for (l in webViewLines() + firefoxLines()) {
            val f = l.split("\t")
            if (f.size >= 7) lines[f[0] + "|" + f[5]] = l
        }
        val names = lines.keys.map { it.substringAfter('|') }.toSet()
        if (names.none { it == "SID" || it == "__Secure-3PSID" || it == "LOGIN_INFO" }) {
            why = "belum ada cookies login (login YouTube di Browser aplikasi, atau Firefox + root)"
            return null
        }
        val f = File(Repo.app.filesDir, "cookies.txt")
        f.writeText("# Netscape HTTP Cookie File\n" + lines.values.joinToString("\n") + "\n")
        return f.path
    }
}

/** Keluarkan AlfyDownloader dari VPN agar IP yang dipakai YouTube = IP asli jaringan (tanpa root: bind jaringan; dengan root: aturan routing). */
object VpnTool {
    @Volatile var status = "Lepas VPN: mati"

    fun enabled() = Repo.prefs().getBoolean("noVpn", false)

    fun reapply() { if (enabled()) bind(true) }

    private fun bind(on: Boolean): String {
        return try {
            val cm = Repo.app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            if (!on) { cm.bindProcessToNetwork(null); return "bind dilepas" }
            var pick: android.net.Network? = null
            @Suppress("DEPRECATION")
            for (n in cm.allNetworks) {
                val c = cm.getNetworkCapabilities(n) ?: continue
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                if (pick == null || c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) pick = n
            }
            if (pick == null) "tidak ada jaringan non-VPN" else { cm.bindProcessToNetwork(pick); "bind ke jaringan asli ✓" }
        } catch (e: Throwable) { "bind gagal: ${e.message}" }
    }

    private fun rootRule(on: Boolean): String {
        return try {
            val uid = android.os.Process.myUid()
            val d = "\$"
            val cmd = if (!on) "ip rule del uidrange $uid-$uid priority 9000 2>/dev/null; echo ok"
            else "t=${d}(ip -4 route show table all | grep '^default' | grep -v -E 'dev (tun|ppp|tap|wg)' | grep -o 'table [^ ]*' | head -1 | cut -d' ' -f2); " +
                "[ -n \"${d}t\" ] || { echo notable; exit 3; }; " +
                "ip rule del uidrange $uid-$uid priority 9000 2>/dev/null; " +
                "ip rule add uidrange $uid-$uid lookup ${d}t priority 9000 && echo ok || echo fail"
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val o = p.inputStream.bufferedReader().readText().trim()
            p.waitFor()
            when {
                o.endsWith("ok") -> "rute root ✓"
                o.contains("notable") -> "rute root: tabel jaringan asli tidak ketemu"
                else -> "rute root gagal"
            }
        } catch (e: Throwable) { "root tidak tersedia" }
    }

    fun set(on: Boolean) {
        Repo.prefs().edit().putBoolean("noVpn", on).apply()
        status = if (on) "Lepas VPN: memproses…" else "Lepas VPN: mati"
        Thread {
            val a = bind(on)
            val b = rootRule(on)
            status = if (on) "Lepas VPN: aktif ($a; $b)" else "Lepas VPN: mati"
        }.start()
    }
}
