package com.alfy.downloader

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.asContextElement
import kotlinx.coroutines.runBlocking
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/** Log status tiap alat pemindai (tampil di panel menu mengambang dan di dalam aplikasi). */
object ToolLog {
    /** Nama alat yang sedang berjalan di thread ini; dipakai untuk label sumber tiap link. */
    val tl = ThreadLocal<String>()
    val ytNames = listOf("ytFast", "NewPipe", "yt-dlp", "yt-dlp+cookies", "Piped/Invidious", "HLS iOS/VR", "WebView")
    val siteNames = listOf("yt-dlp", "NewPipe", "WebView", "HTML")
    /** v1.8: SEMUA alat pemindai (selalu tampil di panel, urutan tetap). */
    val chainAll = listOf("fxtwitter", "Syndication", "yt-dlp", "yt-dlp+cookies", "ytFast", "NewPipe", "Piped/Invidious", "HLS iOS/VR", "WebView", "HTML", "Spotify Match", "JWPlayer", "OpenGraph", "Situs API", "JS Deep", "Iframe", "Manifest", "Redirect", "WebView Pro", "Host Pack")
    /** v1.8: pemantau latar belakang (root + layanan Android) - tampil di panel bersama alat pemindai. */
    val monAll = listOf("Logcat root", "tcpdump", "Media session", "Clipboard root", "Notifikasi", "Aksesibilitas", "ffmpeg", "Hook pemutar")
    @Volatile var names: List<String> = ytNames
    private val st = ConcurrentHashMap<String, String>()
    private val sideSt = ConcurrentHashMap<String, String>()
    @Volatile var vid = ""
    @Volatile var winner = ""
    /** v1.59: pemicu scan terakhir (Paste / Play / Manual / Bar alamat / Scan) untuk log kolaborasi. */
    @Volatile var via = ""
    fun viaOf(src: String): String = when {
        src.startsWith("Clipboard", true) -> "Paste"
        src.startsWith("Auto media", true) -> "Play"
        src.startsWith("Manual", true) -> "Manual"
        src.startsWith("Aksesibilitas", true) -> "Bar alamat"
        else -> "Scan"
    }

    fun begin(id: String, nm: List<String> = ytNames) { vid = id; winner = ""; names = nm; st.clear() }
    fun set(tool: String, s: String) { st[tool] = s; ToolStatus.note(tool, s) }
    /** Status alat yang dipanggil di luar rantai (mis. fxtwitter dari pemantau logcat). */
    fun side(tool: String, s: String) { sideSt[tool] = s; ToolStatus.note(tool, s) }

    private fun monStatus(n: String): String = when (n) {
        "Logcat root" -> NetSniffer.logStat + (if (NetSniffer.logStat.startsWith("✓")) " • ${NetSniffer.logLines} baris • ${NetSniffer.logHits} link" else "")
        "tcpdump" -> NetSniffer.dumpStat + (if (NetSniffer.dumpStat.startsWith("✓")) " • ${NetSniffer.dumpHits} permintaan" else "")
        "Media session" -> NetSniffer.mediaStat
        "Clipboard root" -> NetSniffer.clipStat
        "Notifikasi" -> AlfyNotifService.status
        "Aksesibilitas" -> if (AlfyAccessibilityService.inst != null) "✓ aktif" else "✗ mati (aktifkan di 📖)"
        "ffmpeg" -> Engine.ffmpeg
        "Hook pemutar" -> if (NetSniffer.hookHits > 0) "✓ Aktif • ${NetSniffer.hookHits} link dari hook" else if (HookStatus.active()) "✓ Aktif/Siap (modul terdeteksi)" else "• menunggu (aktifkan modul di LSPosed, centang AlfyDownloader + app target, mulai ulang)"
        else -> "•"
    }

    /** Status satu alat pemindai: dari rantai yang sedang/terakhir jalan, atau dari jalur samping. */
    private fun chainStatus(n: String): String {
        // v1.11: semua alat selalu tampil MEMINDAI otomatis (siaga) bila scan aktif; hasil rantai terakhir tetap tampil bila ada
        val idle = if (Scan.enabled()) "⏳ memindai otomatis (siaga)" else "– scan dimatikan (⚙)"
        val s = if (n in names) (st[n] ?: "⏳ menunggu giliran") else (sideSt[n] ?: idle)
        return s.replace("– tidak perlu (sudah ada hasil)", "– lewati")
    }

    /** v1.12: status satu tool untuk panel & dialog ⚙ (☐ = dimatikan lewat ⚙). */
    fun statusOf(n: String): String =
        if (!Tool.on(n)) "– dimatikan (☐)" else if (n in chainAll) chainStatus(n) else monStatus(n)

    /** Daftar BERNOMOR semua alat (pemindai + pemantau) untuk panel dua kolom. */
    fun allLines(): List<String> {
        val all = chainAll + monAll
        return all.mapIndexed { i, n -> "${i + 1}. $n  " + statusOf(n) }
    }

    /** Satu baris ringkas per alat rantai yang aktif. */
    fun lines(): List<String> = names.mapIndexed { i, n ->
        val s = (st[n] ?: "• menunggu").replace("– tidak perlu (sudah ada hasil)", "– lewati")
        "${i + 1}. $n  $s"
    }

    fun text(): String {
        val sb = StringBuilder()
        if (vid.isNotEmpty()) sb.append("Video $vid\n")
        allLines().forEach { sb.append(it).append('\n') }
        sb.append(RootGate.status)
        if (winner.isNotEmpty()) sb.append("\n→ Link dibuat oleh: ").append(winner)
        return sb.toString()
    }
}

/** Rantai alat pengambil link YouTube: jalan bersamaan (bertahap), berhenti memulai alat berat bila sudah ada hasil. */
/** Batas waktu scan: minimal 5 dtk sebelum dinyatakan gagal, paksa berhenti di 10 dtk. */
object ScanLimit {
    const val MIN_MS = 5_000L
    const val MAX_MS = 5_000L
    class Run { val threads = java.util.concurrent.CopyOnWriteArrayList<Thread>(); val pids = java.util.concurrent.CopyOnWriteArrayList<String>(); @Volatile var expired = false; @Volatile var cancelled = false; @Volatile var early = false }
    val active: MutableSet<Run> = ConcurrentHashMap.newKeySet()
    /** id proses yt-dlp milik thread alat yang sedang berjalan (null = di luar scan berbatas). */
    val pid = ThreadLocal<String>()
    /** Batas tunggu loop internal tiap alat (ms), selalu di bawah 10 dtk. */
    fun cap(ms: Int): Int = minOf(ms, 4_500)
    fun stopped(): Boolean = Thread.currentThread().isInterrupted
    /** Dipakai saat semua tools dimatikan: hentikan paksa scan yang sedang berjalan. */
    fun cancelAll() {
        for (r in active) {
            r.cancelled = true
            for (t in r.threads) { try { t.interrupt() } catch (e: Throwable) { } }
            for (id in r.pids) { try { com.yausername.youtubedl_android.YoutubeDL.getInstance().destroyProcessById(id) } catch (e: Throwable) { } }
        }
    }
}

object Chain {
    private val lastFail = ConcurrentHashMap<String, Long>()
    private val running = ConcurrentHashMap.newKeySet<String>()
    private val retried = ConcurrentHashMap.newKeySet<String>()
    private const val COOLDOWN = 60_000L
    private fun cool() = if (Scan.aggr()) 20_000L else COOLDOWN   // v1.11: mode agresif = coba ulang lebih cepat
    fun busy(): Boolean = running.isNotEmpty()
    /** v1.61: kosongkan antrean/riwayat gagal saat pindah situs/aplikasi. */
    fun resetQueue() { lastFail.clear(); retried.clear() }
    /** v77: 🔍 manual = abaikan jeda gagal & penanda 'sedang jalan' supaya link yang sama bisa dipindai ulang. */
    fun resetForManual() { lastFail.clear(); retried.clear(); running.clear() }
    fun runningCount(): Int = running.size
    @Volatile private var retryJobs = java.util.concurrent.CopyOnWriteArrayList<kotlinx.coroutines.Job>()
    /** Hentikan semua scan (thread + proses yt-dlp) dan batalkan semua coroutine di Resolver.scope (dipanggil saat bubble ditutup). */
    fun cancelAll() {
        try { ScanLimit.cancelAll() } catch (e: Throwable) { }
        try { for (j in retryJobs) j.cancel(); retryJobs.clear() } catch (e: Throwable) { }
        try { Resolver.scope.coroutineContext[kotlinx.coroutines.Job]?.children?.forEach { it.cancel() } } catch (e: Throwable) { }
        try { YtThumbScan.stop() } catch (e: Throwable) { }
        try { XHomeScan.stop() } catch (e: Throwable) { }
        running.clear(); lastFail.clear(); retried.clear()
    }

    private class Spec(val name: String, val delayMs: Long, val skipIfWon: Boolean, val fn: () -> String?)
    /** Mode non-root: hanya alat ini yang dijalankan. */
    private val NON_ROOT_TOOLS = setOf("WebView", "yt-dlp", "ytFast", "NewPipe")

    /** Scan per proses: semua alat paralel; gagal tidak dinyatakan sebelum 5 dtk, dibatalkan paksa di 10 dtk. */
    private fun runLimited(specs: List<Spec>, ok: AtomicBoolean, onWin: (String) -> Unit) {
        val t0 = SystemClock.elapsedRealtime()
        val run = ScanLimit.Run()
        ScanLimit.active.add(run)
        val left = java.util.concurrent.CountDownLatch(specs.size)
        val fin = ConcurrentHashMap.newKeySet<String>()
        val prio = setOf("yt-dlp", "WebView", "Syndication")
        val prioNeed = minOf(3, specs.count { it.name in prio })
        var prioWon = 0
        try {
            for (sp in specs) {
                val pid = "scan-" + System.nanoTime() + "-" + sp.name
                run.pids.add(pid)
                val th = Thread({
                    try {
                        if (sp.delayMs > 0) { try { Thread.sleep(sp.delayMs) } catch (e: InterruptedException) { } }
                        if (sp.skipIfWon && ok.get()) { ToolLog.set(sp.name, "– tidak perlu (sudah ada hasil)"); fin.add(sp.name) }
                        else {
                            ToolLog.set(sp.name, "⏳ berjalan…")
                            ToolLog.tl.set(sp.name)
                            ScanLimit.pid.set(pid)
                            val r: String? = try { sp.fn() } catch (e: Throwable) { reason(e) }
                            ToolLog.tl.remove(); ScanLimit.pid.remove()
                            synchronized(run) {
                                if (!run.expired) {
                                    fin.add(sp.name)
                                    if (r == null) {
                                        ok.set(true); onWin(sp.name); ToolLog.set(sp.name, "✓ berhasil")
                                        if (sp.name in prio && ++prioWon >= prioNeed && prioNeed > 0) run.early = true   // early exit
                                    }
                                    else ToolLog.set(sp.name, "✗ $r")
                                }
                            }
                        }
                    } finally { left.countDown() }
                }, "scan-" + sp.name)
                th.isDaemon = true; run.threads.add(th); th.start()
            }
            val end = t0 + ScanLimit.MAX_MS
            while (left.count > 0L && !run.cancelled && !run.early) {
                val rem = end - SystemClock.elapsedRealtime()
                if (rem <= 0) break
                try { left.await(minOf(rem, 250L), java.util.concurrent.TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { break }
            }
            if (left.count > 0L) {
                synchronized(run) { run.expired = true }
                val msg = if (run.early) "– dihentikan (early exit)" else if (run.cancelled) "✗ dibatalkan (tools OFF)" else "✗ timeout ${ScanLimit.MAX_MS / 1000} dtk (dibatalkan)"
                for (sp in specs) if (sp.name !in fin) ToolLog.set(sp.name, msg)
                for (th in run.threads) { try { th.interrupt() } catch (e: Throwable) { } }
                for (id in run.pids) { try { com.yausername.youtubedl_android.YoutubeDL.getInstance().destroyProcessById(id) } catch (e: Throwable) { } }
            }
            if (!ok.get() && !run.cancelled) {
                val rem = t0 + ScanLimit.MIN_MS - SystemClock.elapsedRealtime()
                if (rem > 0) { try { Thread.sleep(rem) } catch (e: InterruptedException) { } }
            }
        } finally { ScanLimit.active.remove(run) }
    }

    fun reason(e: Throwable): String {
        val m = e.message ?: e.javaClass.simpleName
        return when {
            m.contains("Sign in to confirm", true) || (m.contains("not a bot", true)) -> "bot check"
            m.contains("LOGIN_REQUIRED") -> "LOGIN_REQUIRED"
            m.contains("429") -> "429 dibatasi"
            m.contains("403") -> "403 ditolak"
            m.contains("timed out", true) || m.contains("timeout", true) -> "timeout"
            m.contains("Unable to resolve host", true) || m.contains("UnknownHost", true) -> "tidak ada internet"
            m.contains("Mesin unduh belum siap", true) -> "mesin yt-dlp belum siap"
            else -> (m.lineSequence().map { it.trim() }.lastOrNull { it.isNotEmpty() } ?: "gagal").take(70)
        }
    }

    fun run(id: String, page: String) {
        if (Block.isBlocked(page)) return   // v1.12: daftar 🚫
        if (Resolver.isXNonStatus(page)) return   // X: hanya x.com/.../status/[ID]
        val now = SystemClock.elapsedRealtime()
        val lf = lastFail[id]
        if (lf != null && now - lf < cool()) {
            Resolver.diag = "YouTube: semua alat gagal, jeda ${(cool() - (now - lf)) / 1000} dtk sebelum coba lagi"
            Resolver.seen.remove(page)
            return
        }
        if (!running.add(id)) return
        ToolLog.begin(id, if (Scan.aggr()) ToolLog.ytNames + "HTML" else ToolLog.ytNames)
        VpnTool.reapply()
        val ok = AtomicBoolean(false)
        try {
            Resolver.diag = "YouTube: memindai dengan ${if (Scan.aggr()) 8 else 7} alat serentak…"
            val specs = arrayListOf(
                Spec("ytFast", 0L, false) { val w = StringBuilder(); if (Resolver.ytFast(id, w)) null else w.toString().trim().ifEmpty { "tanpa link" } },
                Spec("NewPipe", 0L, false) { NP.fetch(id) },
                Spec("yt-dlp", 0L, false) { Resolver.ytdlpTool(page, null); null },
                Spec("yt-dlp+cookies", 0L, false) { cookiesTool(page) },
                Spec("Piped/Invidious", 0L, false) { Inst.fetch(id) },
                Spec("HLS iOS/VR", 0L, false) { if (Resolver.youtubeFallback(id, page)) null else "HLS iOS, VR: tanpa hasil" },
                Spec("WebView", 0L, false) { WebTool.grab(id) }
            )
            // v1.11 mode agresif: baca juga HTML halaman tonton (metode tambahan)
            if (Scan.aggr()) specs.add(Spec("HTML", 0L, false) { if (Resolver.sniffSync(page) > 0) null else "tanpa media di halaman" })
            // v1.12: hanya tool yang dicentang di ⚙ yang berjalan
            specs.removeAll { !Tool.on(it.name) }
            if (!AppPreferences.isRooted) specs.retainAll { it.name in NON_ROOT_TOOLS }
            if (specs.isEmpty()) { Resolver.diag = "YouTube: semua tool dimatikan (⚙)"; Resolver.seen.remove(page); return }
            ToolLog.names = specs.map { it.name }
            runLimited(specs, ok) { n -> if (ToolLog.winner.isEmpty()) { ToolLog.winner = n; Resolver.diag = "YouTube: link dari $n ✓" } }
        } finally { running.remove(id) }
        if (ok.get()) {
            lastFail.remove(id)
            Resolver.diag = "YouTube: link dibuat oleh ${ToolLog.winner} ✓"
        } else {
            lastFail[id] = SystemClock.elapsedRealtime()
            Resolver.seen.remove(page)
            Resolver.diag = "YouTube: semua alat gagal (jeda 60 dtk)" + (if (!Cookies.hasLogin) ". SOLUSI: buka 📖 → LOGIN YOUTUBE" else "")
            if (retried.add(id)) {
                val j = Resolver.scope.launch {
                    delay(cool() + 1000)
                    Resolver.seen.remove(page)
                    Resolver.submit(page, null, true)
                }
                retryJobs.add(j); j.invokeOnCompletion { retryJobs.remove(j) }
            }
        }
    }

    /** Situs non-YouTube (TikTok, Instagram, Facebook, X, Vimeo, browser, dll): alat berjalan bersamaan. */
    fun runGeneric(page: String) {
        if (Block.isBlocked(page)) return   // v1.12: daftar 🚫
        val now = SystemClock.elapsedRealtime()
        val lf = lastFail[page]
        val xPage = Regex("^https?://(?:[\\w-]+\\.)?(?:x|twitter)\\.com(?:/|$)", RegexOption.IGNORE_CASE).containsMatchIn(page)
        if (lf != null && now - lf < (if (xPage) 8_000L else cool())) { Resolver.seen.remove(page); return }
        if (!running.add(page)) return
        val host = try { android.net.Uri.parse(page).host ?: page } catch (e: Exception) { page }
        val hl = host.lowercase()
        val isJw = hl.endsWith("jwplyr.com") || hl.endsWith("overfetch.video") || hl.endsWith("vidoy.asia") || hl.endsWith("vidoy.com") || hl.endsWith("vldey.mom")
        val isX = hl == "x.com" || hl.endsWith(".x.com") || hl.endsWith("twitter.com")
        // alat khusus situs ditaruh paling atas (jalan paling dulu); alat umum tetap ikut berjalan bersamaan
        val specs = ArrayList<Spec>()
        if (isX) {
            // v1.9: X/Twitter - TANPA yt-dlp: fxtwitter, syndication, NewPipe, WebView, HTML serentak; link dari pemutar ditangkap pemantau root (cara v1.1).
            // Pemantau root (logcat/tcpdump) berjalan terus di latar belakang dan ikut memasukkan link dari pemutar.
            specs.add(Spec("fxtwitter", 0L, false) { SiteTool.xApi(page, 1) })
            specs.add(Spec("Syndication", 0L, false) { SiteTool.xApi(page, 2) })
            specs.add(Spec("NewPipe", 0L, false) { NP.fetchAny(page) })
            specs.add(Spec("WebView", 0L, false) { WebTool.grabPage(page) })
            specs.add(Spec("HTML", 0L, false) { if (Resolver.sniffSync(page) > 0) null else "tanpa media di halaman" })
            specs.add(Spec("yt-dlp+cookies", 0L, false) { val cf = Cookies.fileFor(page); if (cf == null) "belum login X (Browser Alfy / browser root)" else { Resolver.ytdlpTool(page, cf); null } })
            // v1.11 mode agresif: yt-dlp ikut dipakai juga untuk X
            if (Scan.aggr()) specs.add(Spec("yt-dlp", 0L, false) { Resolver.ytdlpTool(page, null); null })
        } else {
            if (MusicMap.matches(page)) specs.add(Spec("Spotify Match", 0L, false) { MusicMap.run(page) })
            if (isJw || Scan.aggr()) specs.add(Spec("JWPlayer", 0L, false) { SiteTool.jw(page) })
            specs.add(Spec("yt-dlp", 0L, false) { Resolver.ytdlpTool(page, null); null })
            if (hl.endsWith("instagram.com")) specs.add(Spec("yt-dlp+cookies", 0L, false) { val cf = Cookies.fileFor(page); if (cf == null) "belum login Instagram (Browser Alfy / browser root)" else { Resolver.ytdlpTool(page, cf); null } })
            specs.add(Spec("NewPipe", 0L, false) { NP.fetchAny(page) })
            specs.add(Spec("WebView", 0L, false) { WebTool.grabPage(page) })
            specs.add(Spec("HTML", 0L, false) { if (Resolver.sniffSync(page) > 0) null else "tanpa media di halaman" })
            // v1.25: alat tambahan
            specs.add(Spec("Situs API", 0L, false) { MoreTools.siteApi(page) })
            specs.add(Spec("OpenGraph", 0L, false) { MoreTools.openGraph(page) })
            specs.add(Spec("Iframe", 0L, false) { MoreTools.iframe(page) })
            specs.add(Spec("JS Deep", 0L, false) { MoreTools.jsDeep(page) })
            specs.add(Spec("Manifest", 0L, false) { MoreTools.manifest(page) })
            specs.add(Spec("Redirect", 0L, false) { MoreTools.redirect(page) })
            specs.add(Spec("Host Pack", 0L, false) { MoreTools.hostPack(page) })
            specs.add(Spec("WebView Pro", 0L, false) { MoreTools.webPro(page) })
        }
        // v1.12: hanya tool yang dicentang di ⚙ yang berjalan
        specs.removeAll { !Tool.on(it.name) }
        if (!AppPreferences.isRooted) specs.retainAll { it.name in NON_ROOT_TOOLS }
        if (specs.isEmpty()) { Resolver.diag = "Situs ${Resolver.shortAddr(page)}: semua tool dimatikan (⚙)"; Resolver.seen.remove(page); running.remove(page); return }
        ToolLog.begin("Situs ${Resolver.shortAddr(page)}", specs.map { it.name })
        val ok = AtomicBoolean(false)
        try {
            Resolver.diag = "Situs ${Resolver.shortAddr(page)}: memindai dengan ${specs.size} alat…"
            runLimited(specs, ok) { n -> if (ToolLog.winner.isEmpty()) ToolLog.winner = n }
        } finally { running.remove(page) }
        if (ok.get()) {
            lastFail.remove(page)
            Resolver.diag = "Situs ${Resolver.shortAddr(page)}: link dibuat oleh ${ToolLog.winner} ✓"
        } else {
            lastFail[page] = SystemClock.elapsedRealtime()
            Resolver.seen.remove(page)
            Resolver.diag = if (Resolver.captchaPage == page) "Situs ${Resolver.shortAddr(page)}: butuh CAPTCHA → ketuk 🌐 di panel, selesaikan, link akan terdeteksi"
                else "Situs ${Resolver.shortAddr(page)}: semua alat gagal (jeda 60 dtk)"
        }
    }

    private fun cookiesTool(page: String): String? {
        val f = Cookies.file() ?: return Cookies.why
        Resolver.ytdlpTool(page, f)
        return null
    }
}

/**
 * v1.7: pemindaian OTOMATIS saat media apa pun diputar di latar belakang (terdeteksi lewat root media_session atau Akses Notifikasi).
 * Semua alat jalan sendiri: pindai layar, pindai ulang halaman terakhir, baca clipboard, dan pantau logcat root; hasilnya muncul di daftar Tautan.
 */
object AutoScan {
    private val last = ConcurrentHashMap<String, Long>()

    fun onPlay(pkg: String, force: Boolean = false) {
        if (!Scan.enabled()) return
        if (pkg.contains("youtube", true) || pkg == Repo.app.packageName) return
        // v1.61: hanya aplikasi/situs yang sedang aktif
        if (pkg.startsWith("web:")) { if (Resolver.activeHost.isNotEmpty() && !Resolver.hostInScope("https://" + pkg.removePrefix("web:"))) return }
        else if (!Resolver.pkgActive(pkg)) return
        val now = SystemClock.elapsedRealtime()
        val prev = last[pkg]
        if (prev != null && now - prev < (if (force) 8_000L else 20_000L)) return
        last[pkg] = now
        if (Chain.busy()) return
        Resolver.scope.launch(Resolver.tEpoch.asContextElement(Resolver.epoch)) { try { run(pkg) } catch (e: Throwable) { } }
    }

    private fun run(pkg: String) {
        val label = pkg.substringAfterLast('.').substringAfterLast(':').take(18).ifEmpty { "media" }
        // v1.8: AutoScan TIDAK lagi mengganti log alat (daftar alat di panel tetap utuh); statusnya lewat diag + status pemantau
        Resolver.diag = "Media diputar ($label): semua alat memindai otomatis…"
        val before = Repo.detected.value.size
        val acc = AlfyAccessibilityService.inst
        if (acc != null) acc.scanNow()
        val pg = Resolver.lastPage
        val fresh = System.currentTimeMillis() - Resolver.lastPageAt < 600_000L
        if (pg.isNotEmpty() && fresh && Resolver.isJwPage(pg)) { Resolver.diag = "Auto $label: situs video, memindai + menunggu link dari root"; Resolver.rescan(pg, null, "Auto media") }
        else if (pg.isNotEmpty() && fresh && Resolver.isPage(pg)) Resolver.rescan(pg, null, "Auto media")
        else if (pg.isNotEmpty() && fresh && pg.startsWith("http")) Resolver.rescan(pg, null, "Aksesibilitas (bar alamat)")   // v1.54: non-root, situs apa pun
        if (NetSniffer.clipRoot) NetSniffer.readClipRootOnce()
        var waited = 0
        while (waited < ScanLimit.cap(20_000)) {
            Thread.sleep(500); waited += 500
            val n = Repo.detected.value.size - before
            if (n > 0) {
                if (ToolLog.winner.isEmpty()) ToolLog.winner = "pemantau otomatis"
                Resolver.diag = "Auto $label: $n link masuk ✓"
                return
            }
        }
        Resolver.diag = "Auto $label: belum ada link (putar videonya sampai mulai)"
    }
}

/** NewPipeExtractor: peniru pemutar web YouTube (termasuk memecahkan kode pengaman link). Memakai refleksi agar tahan perubahan nama method. */
object NP {
    @Volatile private var inited = false

    class Dl : Downloader() {
        override fun execute(request: Request): Response {
            val c = URL(request.url()).openConnection() as HttpURLConnection
            c.requestMethod = request.httpMethod()
            c.connectTimeout = 8000; c.readTimeout = 9000
            c.instanceFollowRedirects = true
            var hasUa = false
            for ((k, vs) in request.headers()) {
                if (k.equals("Accept-Encoding", true)) continue   // biarkan HttpURLConnection mengurus gzip
                if (k.equals("User-Agent", true)) hasUa = true
                c.setRequestProperty(k, vs.joinToString(", "))
            }
            if (!hasUa) c.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0")
            val data = request.dataToSend()
            if (data != null) { c.doOutput = true; c.outputStream.use { it.write(data) } }
            val code = c.responseCode
            if (code == 429) { c.disconnect(); throw ReCaptchaException("reCaptcha/429 dari YouTube", request.url()) }
            val stream = if (code >= 400) c.errorStream else c.inputStream
            val body = try { stream?.bufferedReader()?.readText() ?: "" } catch (e: Exception) { "" }
            val hm = LinkedHashMap<String, List<String>>()
            for ((k, v) in c.headerFields) if (k != null) hm[k] = v
            val latest = c.url.toString()
            val msg = c.responseMessage ?: ""
            c.disconnect()
            return Response(code, msg, hm, body, latest)
        }
    }

    @Synchronized private fun init() {
        if (inited) return
        NewPipe.init(Dl())
        inited = true
    }

    private fun g(o: Any?, m: String): Any? = try { o?.javaClass?.getMethod(m)?.invoke(o) } catch (e: Exception) { null }

    /** Situs selain YouTube yang didukung NewPipe (SoundCloud, Bandcamp, PeerTube, dll). null = berhasil. */
    fun fetchAny(url: String): String? {
        init()
        val info: Any? = try {
            Class.forName("org.schabi.newpipe.extractor.stream.StreamInfo").getMethod("getInfo", String::class.java).invoke(null, url)
        } catch (e: java.lang.reflect.InvocationTargetException) { throw e.targetException ?: e }
        if (info == null) return "tanpa info"
        val title = ((g(info, "getName") as? String) ?: "").ifBlank { "Video" }
        val dur = (g(info, "getDuration") as? Long) ?: 0L
        val out = ArrayList<Candidate>()
        val imgU = try { ((g(info, "getThumbnails") as? List<*>)?.mapNotNull { g(it, "getUrl") as? String }?.lastOrNull { it.startsWith("http") }) ?: "" } catch (e: Throwable) { "" }
        for ((k, audio) in listOf("getAudioStreams" to true, "getVideoStreams" to false)) {
            val l = (g(info, k) as? List<*>) ?: continue
            for (x in l) {
                if (x == null) continue
                val u = ((g(x, "getContent") as? String) ?: (g(x, "getUrl") as? String) ?: "")
                if (!u.startsWith("http")) continue
                val ext = Resolver.extOf(u).ifEmpty { if (audio) "m4a" else "mp4" }
                out.add(Candidate(key = "NP" + u.take(150), url = u, title = title,
                    kind = if (ext == "m3u8") Kind.HLS else Kind.DIRECT, isAudio = audio, ext = ext, size = -1,
                    quality = if (audio) "audio" else "video", duration = dur, formatSel = null, previewUrl = u, referer = url,
                    audioUrl = if (audio) u else null, img = imgU))
                if (out.size >= 6) break
            }
        }
        if (out.isEmpty()) return "tanpa stream"
        Repo.addCandidates(out)
        return null
    }

    /** null = berhasil, selain itu alasan gagal. */
    fun fetch(id: String): String? {
        init()
        val url = "https://www.youtube.com/watch?v=$id"
        val info: Any? = try {
            Class.forName("org.schabi.newpipe.extractor.stream.StreamInfo").getMethod("getInfo", String::class.java).invoke(null, url)
        } catch (e: java.lang.reflect.InvocationTargetException) { throw e.targetException ?: e }
        if (info == null) return "tanpa info"
        val title = (g(info, "getName") as? String) ?: ""
        val streams = ArrayList<Any>()
        for (k in listOf("getAudioStreams", "getVideoStreams", "getVideoOnlyStreams"))
            (g(info, k) as? List<*>)?.forEach {
                if (it == null) return@forEach
                // v1.11: trek audio hasil dubbing / deskripsi (getAudioTrackType != ORIGINAL) dibuang -> pratinjau memakai suara asli
                if (k == "getAudioStreams") {
                    val tt = g(it, "getAudioTrackType")?.toString()?.uppercase() ?: ""
                    if (tt.isNotEmpty() && tt != "ORIGINAL") return@forEach
                }
                streams.add(it)
            }
        if (streams.isEmpty()) return "tanpa stream"
        var n = 0
        for (s in streams) {
            val u = ((g(s, "getContent") as? String) ?: (g(s, "getUrl") as? String) ?: "")
            if (!u.startsWith("http")) continue
            if (Resolver.isGv(u)) { Resolver.gv(u, null, title); n++ }
        }
        return if (n > 0) null else "stream bukan link googlevideo"
    }
}

/** WebView tersembunyi: memutar halaman YouTube asli lalu menangkap request googlevideo.com/videoplayback. */
object WebTool {
    private val adRe = Regex("doubleclick|googlesyndication|googleads|imasdk|adservice|/vast|adsystem|pubads|adnxs|popads|histats", RegexOption.IGNORE_CASE)
    private val assetExt = setOf("js", "css", "png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "woff", "woff2", "ttf", "otf", "json", "html", "htm", "map", "php", "txt", "xml", "ts")

    /** Apakah request ini kemungkinan file media? (ekstensi media, host file video, atau permintaan Range/Accept video dari elemen <video>). */
    internal fun looksMedia(u: String, r: WebResourceRequest): Boolean {
        if (adRe.containsMatchIn(u) || Resolver.isXAd(u) || Resolver.isGv(u)) return false
        val ext = Resolver.extOf(u)
        if (ext == "ts") return false
        if (Resolver.isMedia(u)) return true
        if (r.isForMainFrame || ext in assetExt) return false
        val h = r.requestHeaders ?: return false
        return h["Range"] != null || (h["Accept"]?.startsWith("video/") == true)
    }

    /**
     * Halaman situs apa pun: tangkap request media. v1.3: sebuah link baru dihitung berhasil bila BENAR-BENAR masuk
     * daftar (sebelumnya semua request dihitung sehingga log ✓ tetapi daftar kosong); request diperiksa di thread alat,
     * deteksi CAPTCHA, dan klik tombol play JW Player otomatis. null = berhasil.
     */
    fun grabPage(page: String): String? {
        val found = AtomicInteger(0)
        val cap = AtomicBoolean(false)
        // v1.4: situs embed ber-iklan (jwplyr/vidoy/overfetch): hanya video dari host milik situs yang diterima, iklan & popup diblokir
        val strict = Resolver.isJwPage(page)
        val ads = AtomicInteger(0)
        val q = java.util.concurrent.ConcurrentLinkedQueue<Pair<String, String>>()
        val h = Handler(Looper.getMainLooper())
        var wv: WebView? = null
        val maxWait = if (strict) 30000 else 18000
        // JS: ambil alamat video langsung dari pemutar (JW Player playlist / <video> / <source>), lalu coba putar & klik tombol play
        val probeJs = "(function(){var o=[];try{if(window.jwplayer){var p=jwplayer().getPlaylist()||[];" +
            "p.forEach(function(it){if(it.file)o.push(it.file);(it.sources||[]).forEach(function(s){if(s.file)o.push(s.file);});});}}catch(e){}" +
            "try{document.querySelectorAll('video,source').forEach(function(v){if(v.currentSrc)o.push(v.currentSrc);if(v.src)o.push(v.src);});}catch(e){}" +
            "try{var v=document.querySelector('video');if(v){v.muted=true;v.play();}if(window.jwplayer){jwplayer().play();}}catch(e){}" +
            "try{var b=document.querySelector('.jw-icon-display,.jw-display-icon-container,.jw-icon-playback,.vjs-big-play-button,.plyr__control--overlaid,.fp-play');if(b)b.click();}catch(e){}" +
            "try{if(window.__alfy)o=o.concat(window.__alfy);}catch(e){}" +
            "return o.join('\\n');})()"
        // v1.5: pasang pengait fetch/XHR: link overfetch bertanda tangan (/s/TOKEN/EXPIRE/i/ID) sering diminta lewat API setelah halaman dibuka
        val hookJs = """(function(){if(window.__alfyH)return;window.__alfyH=1;window.__alfy=[];
function sc(t){try{var m=String(t).split('\\/').join('/').match(/https?:\/\/[^"'\s<>\\]*overfetch\.video[^"'\s<>\\]*/g);if(m)m.forEach(function(x){window.__alfy.push(x);});}catch(e){}}
var of=window.fetch;if(of)window.fetch=function(){var p=of.apply(this,arguments);try{p.then(function(r){try{r.clone().text().then(sc);}catch(e){}});}catch(e){}return p;};
var xs=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.send=function(){try{this.addEventListener('load',function(){try{sc(this.responseText);}catch(e){}});}catch(e){}return xs.apply(this,arguments);};})();"""
        h.post {
            try {
                val w = WebView(Repo.app)
                wv = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.mediaPlaybackRequiresUserGesture = false
                w.settings.userAgentString = Resolver.UA
                if (strict) { w.settings.setSupportMultipleWindows(false); w.settings.javaScriptCanOpenWindowsAutomatically = false }
                try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(w, true) } catch (e: Throwable) { }
                w.webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) { if (strict) view.evaluateJavascript(hookJs, null) }
                    override fun onPageCommitVisible(view: WebView, url: String) { if (strict) view.evaluateJavascript(hookJs, null) }
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        // iklan sering memindahkan halaman ke situs lain: tahan semua perpindahan keluar dari situs video
                        return strict && request.isForMainFrame && !Resolver.jwMediaOk(request.url.toString())
                    }
                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                        val u = request.url.toString()
                        if (u.contains(".m3u8", true)) Resolver.noteHls(u, request.requestHeaders?.get("Referer") ?: page)   // v1.63
                        if (strict && !Resolver.jwMediaOk(u)) {
                            val ext = Resolver.extOf(u)
                            if (adRe.containsMatchIn(u) || ext == "mp4" || ext == "webm" || ext == "m3u8" || looksMedia(u, request)) {
                                // video/skrip iklan: jangan dimuat sama sekali (lebih cepat, dan tidak masuk daftar)
                                if (ext == "mp4" || ext == "webm" || ext == "m3u8" || looksMedia(u, request)) ads.incrementAndGet()
                                return WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0)))
                            }
                            return null
                        }
                        if (looksMedia(u, request)) q.add(Pair(u, request.requestHeaders?.get("Referer") ?: page))
                        return null
                    }
                    override fun onPageFinished(view: WebView, url: String) {
                        if (strict) view.evaluateJavascript(hookJs, null)
                        view.evaluateJavascript(
                            "(function(){var t=0;var i=setInterval(function(){var v=document.querySelector('video');" +
                                "if(v){v.muted=true;try{v.play();}catch(e){}}" +
                                "var b=document.querySelector('.jw-icon-display,.jw-display-icon-container,.jw-icon-playback,.vjs-big-play-button,.plyr__control--overlaid,.fp-play');" +
                                "if(b&&t%4==0){try{b.click();}catch(e){}}if(++t>50)clearInterval(i);},500);})();", null)
                        view.evaluateJavascript(
                            "(function(){var b=document.body?document.body.innerText.slice(0,4000):'';" +
                                "if(document.documentElement.innerHTML.indexOf('turnstile')>=0)b+=' turnstile';return b;})()") { r ->
                            if (r != null && SiteTool.captchaRe.containsMatchIn(r)) cap.set(true)
                        }
                    }
                }
                if (strict) w.loadUrl(page, mapOf("Referer" to Resolver.jwRef(page))) else w.loadUrl(page)
            } catch (e: Throwable) { }
        }
        var waited = 0
        var firstAt = -1
        val tried = HashSet<String>()
        while (waited < ScanLimit.cap(maxWait)) {
            // v1.4: tiap ~1,5 dtk tanya pemutar halaman langsung (alamat video sering sudah ada sebelum diputar)
            if (strict && waited % 1500 == 0 && waited >= 1500) h.post {
                try {
                    wv?.evaluateJavascript(probeJs) { r ->
                        if (r != null && r.length > 2) {
                            val t = r.trim('"').replace("\\n", "\n").replace("\\/", "/").replace("\\u0026", "&")
                            for (x in t.split('\n')) if (x.startsWith("http") && Resolver.jwMediaOk(x)) q.add(Pair(x, page))
                        }
                    }
                } catch (e: Throwable) { }
            }
            var p = q.poll()
            while (p != null) {
                if (tried.add(p.first)) {
                    ToolLog.tl.set("WebView")
                    val ok = try { Resolver.addMediaChecked(p.first, p.second, "", true) } catch (e: Exception) { false }
                    ToolLog.tl.remove()
                    if (ok) { found.incrementAndGet(); if (firstAt < 0) firstAt = waited }
                }
                p = q.poll()
            }
            if (firstAt >= 0 && waited - firstAt >= 1500) break          // sudah dapat link: beri 1,5 dtk untuk kualitas lain
            if (cap.get() && found.get() == 0 && waited >= 8000) break   // CAPTCHA: tidak ada gunanya menunggu lebih lama
            Thread.sleep(300); waited += 300
        }
        h.post { try { wv?.stopLoading(); wv?.destroy() } catch (e: Throwable) { }; wv = null }
        if (found.get() > 0) return null
        if (cap.get()) { Resolver.captchaPage = page; return "butuh CAPTCHA → ketuk 🌐 di panel" }
        val adNote = if (ads.get() > 0) ", ${ads.get()} video iklan diblokir" else ""
        return if (tried.isEmpty()) "tidak ada video milik situs$adNote" else "${tried.size} request media, semua ditolak$adNote"
    }

    fun grab(id: String): String? {
        // v1.11: dulu SEMUA request googlevideo diterima -> saat sudah login, autoplay video berikutnya/iklan/video acak ikut masuk daftar.
        // Kini hanya link yang durasinya (parameter dur=) cocok dengan video yang dibuka (dibaca dari ytInitialPlayerResponse) yang diterima;
        // bila durasi tak terbaca, kunci ke ID googlevideo pertama.
        val found = AtomicInteger(0)
        val q = java.util.concurrent.ConcurrentLinkedQueue<String>()
        val exp = DoubleArray(1).also { it[0] = -1.0 }
        val h = Handler(Looper.getMainLooper())
        var wv: WebView? = null
        h.post {
            try {
                val w = WebView(Repo.app)
                wv = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.mediaPlaybackRequiresUserGesture = false
                w.settings.userAgentString = Resolver.UA
                w.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                        val u = request.url.toString()
                        if (Resolver.isGv(u)) q.add(u)
                        return null
                    }
                    override fun onPageFinished(view: WebView, url: String) {
                        view.evaluateJavascript(
                            "(function(){var t=0;var i=setInterval(function(){var v=document.querySelector('video');" +
                                "if(v){v.muted=true;try{v.play();}catch(e){}}if(++t>40)clearInterval(i);},500);})();", null)
                    }
                }
                w.loadUrl("https://m.youtube.com/watch?v=$id")
            } catch (e: Throwable) { }
        }
        var waited = 0
        var lockId = ""
        while (waited < ScanLimit.cap(25000) && found.get() < 2) {
            if (exp[0] <= 0 && waited % 1000 == 0) h.post {
                try {
                    wv?.evaluateJavascript("(function(){try{var r=window.ytInitialPlayerResponse;return (r&&r.videoDetails&&r.videoDetails.videoId==='$id')?r.videoDetails.lengthSeconds:''}catch(e){return ''}})()") { r ->
                        val d = r?.trim('"')?.toDoubleOrNull()
                        if (d != null && d > 0) exp[0] = d
                    }
                } catch (e: Throwable) { }
            }
            var u = q.poll()
            while (u != null) {
                val dur = Resolver.qp(u, "dur").toDoubleOrNull() ?: -1.0
                val gid = Resolver.qp(u, "id")
                val ed = exp[0]
                val ok: Boolean? = if (ed > 0 && dur > 0) Math.abs(dur - ed) <= 3.0
                    else if (ed > 0) false
                    else if (waited >= 5000) (lockId.isEmpty() || lockId == gid)
                    else { q.add(u); null }   // durasi belum diketahui: tahan sebentar
                if (ok == null) break
                if (ok) {
                    if (lockId.isEmpty()) lockId = gid
                    ToolLog.tl.set("WebView")
                    try { Resolver.gv(u, null, ""); found.incrementAndGet() } catch (e: Exception) { }
                    ToolLog.tl.remove()
                }
                u = q.poll()
            }
            Thread.sleep(250); waited += 250
        }
        h.post { try { wv?.stopLoading(); wv?.destroy() } catch (e: Throwable) { }; wv = null }
        return if (found.get() > 0) null else "tidak ada request googlevideo untuk video ini"
    }
}

/** Muat halaman situs apa pun di WebView tersembunyi lalu tangkap request file media (mp4/m3u8/mp3/dll). */
/** Cookies login YouTube: dari WebView (login di Browser aplikasi) dan, bila root, dari database Firefox. */
object Cookies {
    @Volatile var why = "belum ada cookies login: buka 📖 → LOGIN YOUTUBE"
    @Volatile var hasLogin = false

    private fun line(host: String, path: String, secure: Boolean, exp: Long, name: String, value: String) =
        host + "\t" + (if (host.startsWith(".")) "TRUE" else "FALSE") + "\t" + path + "\t" + (if (secure) "TRUE" else "FALSE") + "\t" + exp + "\t" + name + "\t" + value

    private fun webViewLines(domains: List<String> = listOf("https://www.youtube.com", "https://accounts.google.com", "https://www.google.com")): List<String> {
        val out = ArrayList<String>()
        try {
            val cm = android.webkit.CookieManager.getInstance()
            val exp = System.currentTimeMillis() / 1000 + 180L * 86400
            for (d in domains) {
                val raw = cm.getCookie(d) ?: continue
                val host = "." + (Uri.parse(d).host ?: continue).removePrefix("www.")
                for (part in raw.split(";")) {
                    val i = part.indexOf('=')
                    if (i <= 0) continue
                    out.add(line(host, "/", true, exp, part.substring(0, i).trim(), part.substring(i + 1).trim()))
                }
            }
        } catch (e: Throwable) { }
        return out
    }

    @Volatile private var browserCache: List<String> = emptyList()
    @Volatile private var browserAt = 0L

    /** Root: salin database cookies Firefox dan browser Chromium (Chrome, Brave, Kiwi, Edge, dll) lalu baca cookies YouTube/Google. */
    private fun browserLines(): List<String> {
        if (System.currentTimeMillis() - browserAt < 60_000) return browserCache
        val out = ArrayList<String>()
        try {
            val tmp = File(Repo.app.cacheDir, "ffc")
            tmp.deleteRecursively(); tmp.mkdirs()
            val d = "\$"
            val cmd = "i=0; for f in /data/data/*/app_*/Default/Cookies /data/data/*/app_*/Default/Network/Cookies " +
                "/data/data/org.mozilla.*/files/mozilla/*/cookies.sqlite; do [ -f \"${d}f\" ] || continue; i=${d}((i+1)); " +
                "cp \"${d}f\" ${tmp.path}/c${d}i.db 2>/dev/null; [ -f \"${d}f-wal\" ] && cp \"${d}f-wal\" ${tmp.path}/c${d}i.db-wal; done; chmod -R 777 ${tmp.path}"
            if (!RootGate.ensure()) return out   // v1.8: izin root satu pintu (diminta di awal)
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            p.inputStream.readBytes(); p.waitFor()
            var encrypted = 0
            for (db in (tmp.listFiles() ?: emptyArray()).filter { it.name.endsWith(".db") }) {
                try {
                    val sq = android.database.sqlite.SQLiteDatabase.openDatabase(db.path, null, android.database.sqlite.SQLiteDatabase.OPEN_READWRITE)
                    try {
                        val names = ArrayList<String>()
                        val t = sq.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null)
                        while (t.moveToNext()) names.add(t.getString(0))
                        t.close()
                        if ("moz_cookies" in names) {
                            val c = sq.rawQuery("SELECT host, path, isSecure, expiry, name, value FROM moz_cookies WHERE host LIKE '%youtube.com' OR host LIKE '%google.com' OR host LIKE '%instagram.com' OR host LIKE '%x.com' OR host LIKE '%twitter.com'", null)
                            while (c.moveToNext()) {
                                var exp = c.getLong(3)
                                if (exp > 100000000000L) exp /= 1000
                                out.add(line(c.getString(0), c.getString(1), c.getInt(2) != 0, exp, c.getString(4), c.getString(5)))
                            }
                            c.close()
                        } else if ("cookies" in names) {
                            val c = sq.rawQuery("SELECT host_key, path, is_secure, expires_utc, name, value, length(encrypted_value) FROM cookies WHERE host_key LIKE '%youtube.com' OR host_key LIKE '%google.com' OR host_key LIKE '%instagram.com' OR host_key LIKE '%x.com' OR host_key LIKE '%twitter.com'", null)
                            while (c.moveToNext()) {
                                val v = c.getString(5) ?: ""
                                if (v.isEmpty()) { if (c.getInt(6) > 0) encrypted++; continue }
                                var exp = c.getLong(3) / 1000000 - 11644473600L
                                if (exp < 0) exp = System.currentTimeMillis() / 1000 + 86400L * 30
                                out.add(line(c.getString(0), c.getString(1), c.getInt(2) != 0, exp, c.getString(4), v))
                            }
                            c.close()
                        }
                    } finally { sq.close() }
                } catch (e: Throwable) { }
            }
            if (encrypted > 0 && out.isEmpty()) why = "cookies browser terenkripsi; login lewat tombol LOGIN YOUTUBE di 📖"
            tmp.deleteRecursively()
        } catch (e: Throwable) { }
        browserCache = out; browserAt = System.currentTimeMillis()
        return out
    }

    /** v1.55: cookies login Instagram / X (Browser Alfy atau browser root) untuk yt-dlp. null bila belum login. */
    fun fileFor(page: String): String? {
        val h = try { Uri.parse(page).host?.lowercase() ?: "" } catch (e: Throwable) { "" }
        val doms = when { h.endsWith("instagram.com") -> listOf("instagram.com"); h.endsWith("x.com") || h.endsWith("twitter.com") -> listOf("x.com", "twitter.com"); else -> return null }
        val key = if (doms[0] == "instagram.com") "sessionid" else "auth_token"
        val lines = LinkedHashMap<String, String>()
        for (l in webViewLines(doms.map { "https://www.$it" }) + browserLines()) {
            val f = l.split("\t")
            if (f.size < 7) continue
            val hh = f[0].removePrefix(".")
            if (doms.any { hh == it || hh.endsWith(".$it") }) lines[f[0] + "|" + f[5]] = l
        }
        if (lines.keys.none { it.endsWith("|$key") }) return null
        val f = File(Repo.app.filesDir, "cookies_" + doms[0] + ".txt")
        f.writeText("# Netscape HTTP Cookie File\n" + lines.values.joinToString("\n") + "\n")
        return f.path
    }

    /** Path file cookies format Netscape (untuk yt-dlp --cookies) atau null bila belum ada cookies login. */
    fun file(): String? {
        val lines = LinkedHashMap<String, String>()
        for (l in webViewLines() + browserLines()) {
            val f = l.split("\t")
            if (f.size >= 7 && (f[0].contains("google") || f[0].contains("youtube"))) lines[f[0] + "|" + f[5]] = l
        }
        val names = lines.keys.map { it.substringAfter('|') }.toSet()
        if (names.none { it == "SID" || it == "__Secure-3PSID" || it == "LOGIN_INFO" }) {
            if (!why.startsWith("cookies browser")) why = "belum ada cookies login: buka 📖 → LOGIN YOUTUBE"
            hasLogin = false
            return null
        }
        hasLogin = true
        val f = File(Repo.app.filesDir, "cookies.txt")
        f.writeText("# Netscape HTTP Cookie File\n" + lines.values.joinToString("\n") + "\n")
        return f.path
    }
}

/** Keluarkan AlfyDownloader dari VPN agar IP yang dipakai YouTube = IP asli jaringan (tanpa root: bind jaringan; dengan root: aturan routing). */
object VpnTool {
    /** Detail mekanisme lepas VPN (internal). Status untuk tampilan ada di [status]. */
    @Volatile private var detail = "mati"
    @Volatile private var watching = false
    @Volatile private var vpnCache = false
    private var netCb: ConnectivityManager.NetworkCallback? = null

    /** Cek kondisi nyata: apakah jaringan aktif memakai VPN. */
    fun vpnActive(): Boolean {
        return try {
            val cm = Repo.app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val an = cm.activeNetwork
            val ac = if (an != null) cm.getNetworkCapabilities(an) else null
            if (ac != null && (ac.hasTransport(NetworkCapabilities.TRANSPORT_VPN) || !ac.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN))) return true
            @Suppress("DEPRECATION")
            for (n in cm.allNetworks) {
                val c = cm.getNetworkCapabilities(n) ?: continue
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return true
            }
            false
        } catch (e: Throwable) { false }
    }

    /** Status tampilan: mengikuti kondisi VPN nyata, ditambah detail fitur Lepas VPN bila dinyalakan. */
    val status: String
        get() {
            val v = if (watching) vpnCache else vpnActive()
            val base = if (v) "VPN terdeteksi" else "Tidak memakai VPN"
            return if (enabled()) "$base · Lepas VPN: $detail" else base
        }

    /** Mulai pantau perubahan VPN (panggil saat menu dibuka). Aman dipanggil berulang. */
    @Synchronized fun startWatch() {
        if (netCb != null) return
        vpnCache = vpnActive()
        try {
            val cm = Repo.app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: android.net.Network) { vpnCache = vpnActive() }
                override fun onLost(network: android.net.Network) { vpnCache = vpnActive() }
                override fun onCapabilitiesChanged(network: android.net.Network, nc: NetworkCapabilities) { vpnCache = vpnActive() }
            }
            cm.registerDefaultNetworkCallback(cb)
            netCb = cb
            watching = true
        } catch (e: Throwable) { watching = false; netCb = null }
    }

    /** Hentikan pantauan (panggil saat menu ditutup). */
    @Synchronized fun stopWatch() {
        watching = false
        val cb = netCb ?: return
        netCb = null
        try {
            val cm = Repo.app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.unregisterNetworkCallback(cb)
        } catch (e: Throwable) { }
    }

    fun enabled() = Repo.prefs().getBoolean("noVpn", false)

    fun reapply() { if (enabled()) bind(true) }

    private fun bind(on: Boolean): String {
        return try {
            val cm = Repo.app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            if (!on) { cm.bindProcessToNetwork(null); return "bind dilepas" }
            var pick: android.net.Network? = null
            @Suppress("DEPRECATION")
            for (n in cm.allNetworks) {
                val c = cm.getNetworkCapabilities(n) ?: continue
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                if (pick == null || c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) pick = n
            }
            if (pick == null) "tidak ada jaringan non-VPN" else { cm.bindProcessToNetwork(pick); "bind ke jaringan asli ✓" }
        } catch (e: Throwable) { "bind gagal: ${e.message}" }
    }

    private fun rootRule(on: Boolean): String {
        return try {
            val uid = android.os.Process.myUid()
            val d = "\$"
            val cmd = if (!on) "ip rule del uidrange $uid-$uid priority 9000 2>/dev/null; echo ok"
            else "t=${d}(ip -4 route show table all | grep '^default' | grep -v -E 'dev (tun|ppp|tap|wg)' | grep -o 'table [^ ]*' | head -1 | cut -d' ' -f2); " +
                "[ -n \"${d}t\" ] || { echo notable; exit 3; }; " +
                "ip rule del uidrange $uid-$uid priority 9000 2>/dev/null; " +
                "ip rule add uidrange $uid-$uid lookup ${d}t priority 9000 && echo ok || echo fail"
            if (!RootGate.ensure()) return "root ditolak"   // v1.8: izin root satu pintu (diminta di awal)
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val o = p.inputStream.bufferedReader().readText().trim()
            p.waitFor()
            when {
                o.endsWith("ok") -> "rute root ✓"
                o.contains("notable") -> "rute root: tabel jaringan asli tidak ketemu"
                else -> "rute root gagal"
            }
        } catch (e: Throwable) { "root tidak tersedia" }
    }

    fun set(on: Boolean) {
        Repo.prefs().edit().putBoolean("noVpn", on).apply()
        detail = if (on) "memproses…" else "mati"
        Thread {
            val a = bind(on)
            val b = rootRule(on)
            detail = if (on) "aktif ($a; $b)" else "mati"
        }.start()
    }
}


/** Server publik Piped / Invidious (daftar diambil otomatis). Link-nya diproksikan lewat server itu, jadi tidak terikat IP VPN-mu. */
object Inst {
    @Volatile private var piped: List<String> = emptyList()
    @Volatile private var inv: List<String> = emptyList()
    @Volatile private var at = 0L
    private val staticPiped = listOf("https://pipedapi.kavin.rocks", "https://api.piped.private.coffee", "https://pipedapi.adminforge.de", "https://pipedapi.reallyaweso.me", "https://api.piped.yt", "https://pipedapi.darkness.services", "https://pipedapi.drgns.space", "https://piped-api.privacy.com.de", "https://pipedapi.leptons.xyz", "https://pipedapi.nosebs.ru")
    private val staticInv = listOf("https://yewtu.be", "https://inv.nadeko.net", "https://invidious.nerdvpn.de", "https://invidious.privacyredirect.com", "https://invidious.f5.si", "https://inv.tux.pizza", "https://invidious.materialio.us", "https://iv.melmac.space")

    @Synchronized private fun load() {
        if (System.currentTimeMillis() - at < 600_000 && (piped.isNotEmpty() || inv.isNotEmpty())) return
        val p = ArrayList<String>(); val v = ArrayList<String>()
        try {
            val a = org.json.JSONArray(Resolver.getText("https://piped-instances.kavin.rocks/", null))
            for (i in 0 until a.length()) { val u = a.optJSONObject(i)?.optString("api_url", "") ?: ""; if (u.startsWith("http")) p.add(u.trimEnd('/')) }
        } catch (e: Throwable) { }
        try {
            val a = org.json.JSONArray(Resolver.getText("https://api.invidious.io/instances.json?sort_by=health", null))
            for (i in 0 until a.length()) {
                val o = a.optJSONArray(i)?.optJSONObject(1) ?: continue
                if (o.optString("type") == "https" && o.optBoolean("api", false)) { val u = o.optString("uri", ""); if (u.startsWith("http")) v.add(u.trimEnd('/')) }
            }
        } catch (e: Throwable) { }
        piped = (p.take(6) + staticPiped).distinct()
        inv = (v.take(6) + staticInv).distinct()
        at = System.currentTimeMillis()
    }

    private fun addPiped(base: String, id: String): Int {
        val j = org.json.JSONObject(Resolver.getText("$base/streams/$id", null))
        val title = j.optString("title", "YouTube $id"); val dur = j.optLong("duration", 0L)
        var best: org.json.JSONObject? = null
        val aus = j.optJSONArray("audioStreams")
        if (aus != null) for (i in 0 until aus.length()) {
            val o = aus.optJSONObject(i) ?: continue
            if (o.optString("url").isEmpty() || !o.optString("mimeType").startsWith("audio/mp4")) continue
            val att = o.optString("audioTrackType", "")
            if (att.isNotEmpty() && !att.equals("ORIGINAL", true)) continue   // v1.11: bukan suara asli
            if (!Resolver.isOrigAudio(o.optString("url"))) continue
            if (best == null || o.optLong("bitrate") > best.optLong("bitrate")) best = o
        }
        val out = ArrayList<Candidate>()
        val vs = j.optJSONArray("videoStreams")
        if (vs != null) for (i in 0 until vs.length()) {
            val o = vs.optJSONObject(i) ?: continue
            val u = o.optString("url"); if (u.isEmpty()) continue
            val q = o.optString("quality", "-")
            val vOnly = o.optBoolean("videoOnly", true)
            val isMp4 = o.optString("mimeType").startsWith("video/mp4") && o.optString("codec").startsWith("avc")
            if (!vOnly) out.add(Candidate(key = "PP$id|$q|m", url = u, title = title, kind = Kind.DIRECT, isAudio = false, ext = "mp4",
                size = o.optLong("contentLength", -1), quality = q, duration = dur, formatSel = null, previewUrl = u, referer = null))
            else if (isMp4 && best != null) { val au = best.getString("url")
                out.add(Candidate(key = "PP$id|$q|v", url = u, title = title, kind = Kind.DIRECT, isAudio = false, ext = "mp4",
                    size = o.optLong("contentLength", -1), quality = q, duration = dur, formatSel = "MERGE:$au\n", previewUrl = u, referer = null, audioUrl = au, muted = true)) }
        }
        best?.let { o -> out.add(Candidate(key = "PP$id|a", url = o.getString("url"), title = title, kind = Kind.DIRECT, isAudio = true, ext = "m4a",
            size = o.optLong("contentLength", -1), quality = "audio", duration = dur, formatSel = null, previewUrl = o.getString("url"), referer = null, audioUrl = o.getString("url"))) }
        if (out.isNotEmpty()) Repo.addCandidates(out)
        return out.size
    }

    private fun addInv(base: String, id: String): Int {
        val j = org.json.JSONObject(Resolver.getText("$base/api/v1/videos/$id?local=true&fields=title,lengthSeconds,formatStreams,adaptiveFormats", null))
        val title = j.optString("title", "YouTube $id"); val dur = j.optLong("lengthSeconds", 0L)
        val out = ArrayList<Candidate>()
        val fs = j.optJSONArray("formatStreams")
        if (fs != null) for (i in 0 until fs.length()) {
            val o = fs.optJSONObject(i) ?: continue
            val u = o.optString("url"); if (u.isEmpty()) continue
            out.add(Candidate(key = "IV$id|${o.optString("itag")}", url = u, title = title, kind = Kind.DIRECT, isAudio = false, ext = "mp4",
                size = -1, quality = o.optString("qualityLabel", o.optString("quality", "-")), duration = dur, formatSel = null, previewUrl = u, referer = null))
        }
        val af = j.optJSONArray("adaptiveFormats")
        var best: org.json.JSONObject? = null
        if (af != null) for (i in 0 until af.length()) {
            val o = af.optJSONObject(i) ?: continue
            if (o.optString("type").startsWith("audio/mp4") && o.optString("url").isNotEmpty() && Resolver.isOrigAudio(o.optString("url")) &&
                (best == null || o.optString("bitrate").toLongOrNull() ?: 0L > (best.optString("bitrate").toLongOrNull() ?: 0L))) best = o
        }
        best?.let { o -> out.add(Candidate(key = "IV$id|a", url = o.getString("url"), title = title, kind = Kind.DIRECT, isAudio = true, ext = "m4a",
            size = o.optString("clen").toLongOrNull() ?: -1, quality = "audio", duration = dur, formatSel = null, previewUrl = o.getString("url"), referer = null, audioUrl = o.getString("url"))) }
        if (out.isNotEmpty()) Repo.addCandidates(out)
        return out.size
    }

    /** null = berhasil. Mencoba banyak server sekaligus; yang pertama berhasil menang. */
    fun fetch(id: String): String? {
        load()
        val tag = ToolLog.tl.get() ?: "Piped/Invidious"
        val jobs = piped.take(10).map { b -> Pair("P", b) } + inv.take(8).map { b -> Pair("I", b) }
        if (jobs.isEmpty()) return "daftar server kosong"
        val deadline = System.currentTimeMillis() + 20_000L   // batas total: tidak menggantung
        val ex = java.util.concurrent.Executors.newFixedThreadPool(10)
        try {
            val cs = java.util.concurrent.ExecutorCompletionService<Int>(ex)
            for ((kind, base) in jobs) cs.submit {
                ToolLog.tl.set(tag)
                try { if (kind == "P") addPiped(base, id) else addInv(base, id) } catch (e: Throwable) { 0 } finally { ToolLog.tl.remove() }
            }
            var done = 0
            while (done < jobs.size) {
                val left = deadline - System.currentTimeMillis()
                if (left <= 0) break
                val fut = try { cs.poll(left, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (e: Throwable) { null }
                if (fut == null) break
                done++
                val r = try { fut.get() } catch (e: Throwable) { 0 }
                if (r > 0) return null
            }
            return "${jobs.size} server publik: tidak ada hasil/timeout"
        } finally { ex.shutdownNow() }
    }
}
