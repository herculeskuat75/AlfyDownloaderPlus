package com.alfy.downloader

import java.net.HttpURLConnection
import java.net.URL

/** Tool cadangan Tier 2 YouTube: InnerTube /player dengan client ANDROID_VR. */
object InnerTubeTool {
    private val EP: String get() = AppPreferences.innerTubeUrl
    private const val VER = "1.60.19"
    private const val UA = "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"

    fun matches(page: String): Boolean {
        val h = try { android.net.Uri.parse(page).host?.lowercase() ?: "" } catch (e: Exception) { "" }
        return h.endsWith("youtube.com") || h == "youtu.be"
    }

    private fun post(body: String): String {
        val c = URL(EP).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 9000
            c.doOutput = true
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("X-YouTube-Client-Name", "28")
            c.setRequestProperty("X-YouTube-Client-Version", VER)
            c.setRequestProperty("Origin", "https://www.youtube.com")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code >= 400) throw RuntimeException("HTTP $code")
            return c.inputStream.bufferedReader().readText()
        } finally { try { c.disconnect() } catch (e: Throwable) { } }
    }

    /** null = berhasil, selain itu alasan gagal. */
    fun fetch(id: String): String? {
        val client = org.json.JSONObject().put("clientName", "ANDROID_VR").put("clientVersion", VER)
            .put("deviceMake", "Oculus").put("deviceModel", "Quest 3").put("osName", "Android").put("osVersion", "12L")
            .put("androidSdkVersion", 32).put("hl", "en").put("gl", "US")
        val body = org.json.JSONObject().put("context", org.json.JSONObject().put("client", client))
            .put("videoId", id).put("contentCheckOk", true).put("racyCheckOk", true)
        val j = org.json.JSONObject(post(body.toString()))
        val ps = j.optJSONObject("playabilityStatus")
        val st = ps?.optString("status", "") ?: ""
        if (st.isNotEmpty() && st != "OK") return (st + " " + (ps?.optString("reason", "") ?: "")).trim().take(70)
        val sd = j.optJSONObject("streamingData") ?: return "tanpa streamingData"
        val title = j.optJSONObject("videoDetails")?.optString("title", "")?.ifBlank { null } ?: "YouTube $id"
        val dur = j.optJSONObject("videoDetails")?.optString("lengthSeconds", "0")?.toLongOrNull() ?: 0L
        val out = ArrayList<Candidate>()
        var bestAu: org.json.JSONObject? = null
        val ad = sd.optJSONArray("adaptiveFormats")
        if (ad != null) for (i in 0 until ad.length()) {
            val o = ad.optJSONObject(i) ?: continue
            if (o.optString("url").isEmpty() || !o.optString("mimeType").startsWith("audio/mp4")) continue
            val at = o.optJSONObject("audioTrack")?.optString("id", "") ?: ""
            if (at.isNotEmpty() && !at.contains("original", true) && !at.contains(".4")) continue
            if (bestAu == null || o.optLong("bitrate") > bestAu.optLong("bitrate")) bestAu = o
        }
        val fm = sd.optJSONArray("formats")
        if (fm != null) for (i in 0 until fm.length()) {
            val o = fm.optJSONObject(i) ?: continue
            val u = o.optString("url"); if (u.isEmpty()) continue
            val q = o.optString("qualityLabel", o.optString("quality", "-"))
            out.add(Candidate(key = "IT$id|${o.optInt("itag")}", url = u, title = title, kind = Kind.DIRECT, isAudio = false, ext = "mp4",
                size = o.optString("contentLength").toLongOrNull() ?: -1, quality = q, duration = dur, formatSel = null, previewUrl = u, referer = null))
        }
        if (ad != null) for (i in 0 until ad.length()) {
            val o = ad.optJSONObject(i) ?: continue
            val u = o.optString("url"); val mt = o.optString("mimeType")
            if (u.isEmpty() || !mt.startsWith("video/mp4") || bestAu == null) continue
            val au = bestAu.getString("url")
            val q = o.optString("qualityLabel", "-")
            out.add(Candidate(key = "IT$id|${o.optInt("itag")}|v", url = u, title = title, kind = Kind.DIRECT, isAudio = false, ext = "mp4",
                size = o.optString("contentLength").toLongOrNull() ?: -1, quality = q, duration = dur, formatSel = "MERGE:$au\n", previewUrl = u, referer = null, audioUrl = au, muted = true))
        }
        bestAu?.let { o -> val u = o.getString("url")
            out.add(Candidate(key = "IT$id|a", url = u, title = title, kind = Kind.DIRECT, isAudio = true, ext = "m4a",
                size = o.optString("contentLength").toLongOrNull() ?: -1, quality = "audio", duration = dur, formatSel = null, previewUrl = u, referer = null, audioUrl = u)) }
        if (out.isEmpty()) return "tanpa link di streamingData"
        Repo.addCandidates(out)
        return null
    }
}
