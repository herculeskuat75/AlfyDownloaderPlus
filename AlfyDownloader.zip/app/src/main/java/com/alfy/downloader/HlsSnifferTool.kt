package com.alfy.downloader

import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Tool Tier 2 "HLS Sniffer": menyadap request WebView (shouldInterceptRequest); URL berakhiran .m3u8 (HLS) atau .mpd (DASH)
 * otomatis masuk daftar download. Dipakai pasif oleh Browser Alfy / WebView pemindai ([onRequest]) dan aktif lewat rantai tool ([grab]).
 */
object HlsSnifferTool {
    @Volatile var hits = 0
    @Volatile var last = ""
    private val seen = ConcurrentHashMap.newKeySet<String>()
    private val adRe = Regex("doubleclick|googlesyndication|googleads|imasdk|adservice|/vast|adsystem|pubads|adnxs|popads|histats", RegexOption.IGNORE_CASE)

    /** Status singkat untuk panel tool. */
    fun status(): String = if (hits > 0) "✓ $hits stream tertangkap • $last" else "⏳ siaga menyadap .m3u8/.mpd"

    /** "m3u8" / "mpd" bila URL (tanpa query) berakhiran ekstensi itu, selain itu "". */
    fun kindOf(u: String): String {
        val p = u.substringBefore('#').substringBefore('?').lowercase()
        return when { p.endsWith(".m3u8") -> "m3u8"; p.endsWith(".mpd") -> "mpd"; else -> "" }
    }

    fun clear() { seen.clear() }

    /** Dipanggil dari shouldInterceptRequest. true = URL baru yang diterima sebagai stream. */
    fun onRequest(u: String, referer: String?, page: String?, src: String = "HLS Sniffer"): Boolean {
        val k = kindOf(u)
        if (k.isEmpty() || !u.startsWith("http") || adRe.containsMatchIn(u)) return false
        if (!Tool.on("HLS Sniffer") || Block.isBlocked(u)) return false
        if (!seen.add(u)) return false
        hits++; last = k + " • " + u.substringAfter("://").substringBefore('/').take(28)
        val ref = referer ?: page
        ToolLog.side("HLS Sniffer", "✓ $hits stream ($k)")
        if (k == "m3u8") Resolver.submitMedia(u, ref, src)
        else Repo.addCandidates(listOf(Candidate(
            key = "SNF" + u.take(150), url = u, title = Resolver.nameOf(u).ifBlank { "Stream DASH" }, kind = Kind.YTDLP,
            isAudio = false, ext = "mp4", size = -1, quality = "DASH (.mpd)", duration = 0, formatSel = null,
            previewUrl = u, referer = ref, source = src)))
        return true
    }

    /** Tool rantai: muat halaman di WebView tersembunyi, sadap request .m3u8/.mpd. null = berhasil. */
    fun grab(page: String): String? {
        val found = AtomicInteger(0)
        val h = Handler(Looper.getMainLooper())
        var wv: WebView? = null
        h.post {
            try {
                val w = WebView(Repo.app)
                wv = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.mediaPlaybackRequiresUserGesture = false
                w.settings.userAgentString = Resolver.UA
                try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(w, true) } catch (e: Throwable) { }
                w.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                        if (onRequest(request.url.toString(), request.requestHeaders?.get("Referer"), page)) found.incrementAndGet()
                        return null
                    }
                    override fun onPageFinished(view: WebView, url: String) {
                        view.evaluateJavascript("(function(){var t=0;var i=setInterval(function(){var v=document.querySelector('video');" +
                            "if(v){v.muted=true;try{v.play();}catch(e){}}" +
                            "var b=document.querySelector('.jw-icon-display,.jw-display-icon-container,.vjs-big-play-button,.plyr__control--overlaid,.fp-play');" +
                            "if(b&&t%4==0){try{b.click();}catch(e){}}if(++t>40)clearInterval(i);},500);})();", null)
                    }
                }
                w.loadUrl(page)
            } catch (e: Throwable) { }
        }
        var waited = 0
        var firstAt = -1
        while (waited < ScanLimit.cap(9_000)) {
            if (found.get() > 0 && firstAt < 0) firstAt = waited
            if (firstAt >= 0 && waited - firstAt >= 1200) break
            try { Thread.sleep(250) } catch (e: InterruptedException) { break }
            waited += 250
        }
        h.post { try { wv?.stopLoading(); wv?.destroy() } catch (e: Throwable) { }; wv = null }
        return if (found.get() > 0) null else "tidak ada request .m3u8/.mpd"
    }
}
