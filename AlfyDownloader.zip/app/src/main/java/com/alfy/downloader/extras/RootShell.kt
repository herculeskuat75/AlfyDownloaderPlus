package com.alfy.downloader.extras

import com.topjohnwu.superuser.Shell

/** Pembungkus tipis libsu untuk pemantau root (logcat, dumpsys media_session, clipboard). Belum dipanggil kode lama. */
object RootShell {
    fun granted(): Boolean = try { Shell.getShell().isRoot } catch (e: Throwable) { false }
    fun run(vararg cmd: String): List<String> = try { Shell.cmd(*cmd).exec().out } catch (e: Throwable) { emptyList() }
    fun ok(vararg cmd: String): Boolean = try { Shell.cmd(*cmd).exec().isSuccess } catch (e: Throwable) { false }
}
