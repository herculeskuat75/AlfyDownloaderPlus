package com.alfy.downloader.extras

import com.topjohnwu.superuser.Shell

/** Pembungkus tipis libsu untuk pemantau root (logcat, dumpsys media_session, clipboard). Belum dipanggil kode lama. */
object RootShell {
    fun granted(): Boolean = try { Shell.getShell().isRoot } catch (e: Throwable) { false }
    fun run(vararg cmd: String): List<String> = try { Shell.cmd(*cmd).exec().out } catch (e: Throwable) { emptyList() }
    fun ok(vararg cmd: String): Boolean = try { Shell.cmd(*cmd).exec().isSuccess } catch (e: Throwable) { false }

    /** Auto-grant via root: izin runtime + layanan aksesibilitas aktif otomatis (mis. setelah restore Swift Backup). */
    fun autoGrant(pkg: String) {
        try {
            val svc = "$pkg/$pkg.AlfyAccessibilityService"
            val cmds = ArrayList<String>()
            for (p in listOf("android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.POST_NOTIFICATIONS", "android.permission.READ_LOGS", "android.permission.SYSTEM_ALERT_WINDOW"))
                cmds.add("pm grant $pkg $p")
            cmds.add("appops set $pkg SYSTEM_ALERT_WINDOW allow")
            cmds.add("appops set $pkg MANAGE_EXTERNAL_STORAGE allow")
            cmds.add("dumpsys deviceidle whitelist +$pkg")
            val cur = run("settings get secure enabled_accessibility_services").firstOrNull()?.trim() ?: ""
            if (!cur.split(":").contains(svc)) {
                val nv = if (cur.isEmpty() || cur == "null") svc else "$cur:$svc"
                cmds.add("settings put secure enabled_accessibility_services $nv")
            }
            cmds.add("settings put secure accessibility_enabled 1")
            for (c in cmds) ok(c)
        } catch (e: Throwable) { }
    }
}
