package com.alfy.downloader.part3.convert

import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

/** Native FFmpegKit engine: TS/M3U8 segments -> MP4 (stream copy, then re-encode fallback) and video -> MP3. */
object FfmpegConverter {

    private suspend fun run(args: List<String>, durationSec: Double, onProgress: (Float) -> Unit): Boolean =
        suspendCancellableCoroutine { cont ->
            val session = FFmpegKit.executeWithArgumentsAsync(
                args.toTypedArray(),
                { s -> if (cont.isActive) cont.resume(ReturnCode.isSuccess(s.returnCode)) },
                { },
                { st ->
                    if (durationSec > 0) onProgress(((st.time / 1000.0) / durationSec).coerceIn(0.0, 1.0).toFloat())
                }
            )
            cont.invokeOnCancellation { FFmpegKit.cancel(session.sessionId) }
        }

    suspend fun duration(file: File): Double = withContext(Dispatchers.IO) {
        try {
            FFprobeKit.getMediaInformation(file.absolutePath).mediaInformation?.duration?.toDoubleOrNull() ?: 0.0
        } catch (e: Exception) { 0.0 }
    }

    /** Integrity check of the produced file via ffprobe. */
    suspend fun verify(file: File, requireDuration: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        try {
            if (!file.exists() || file.length() <= 0) return@withContext false
            val mi = FFprobeKit.getMediaInformation(file.absolutePath).mediaInformation ?: return@withContext false
            val hasStreams = !mi.streams.isNullOrEmpty()
            hasStreams && (!requireDuration || (mi.duration?.toDoubleOrNull() ?: 0.0) > 0.0)
        } catch (e: Exception) { false }
    }

    suspend fun remuxToMp4(input: File, output: File, onProgress: (Float) -> Unit = {}): Boolean {
        val dur = duration(input)
        output.delete()
        val copy = listOf(
            "-y", "-fflags", "+genpts+discardcorrupt", "-i", input.absolutePath,
            "-map", "0:v:0?", "-map", "0:a:0?", "-c", "copy",
            "-avoid_negative_ts", "make_zero", "-f", "mp4", "-movflags", "+faststart", output.absolutePath
        )
        if (run(copy, dur, onProgress) && verify(output, true)) return true
        output.delete()
        val enc = listOf(
            "-y", "-fflags", "+genpts+discardcorrupt", "-i", input.absolutePath,
            "-map", "0:v:0?", "-map", "0:a:0?",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "128k", "-f", "mp4", "-movflags", "+faststart", output.absolutePath
        )
        if (run(enc, dur, onProgress) && verify(output, true)) return true
        output.delete()
        return false
    }

    suspend fun toMp3(input: File, output: File, onProgress: (Float) -> Unit = {}): Boolean {
        val dur = duration(input)
        output.delete()
        val args = listOf(
            "-y", "-i", input.absolutePath, "-vn", "-map", "0:a:0",
            "-c:a", "libmp3lame", "-q:a", "2", "-f", "mp3", output.absolutePath
        )
        if (run(args, dur, onProgress) && verify(output)) return true
        output.delete()
        return false
    }

    private fun containerOf(ext: String) = when (ext.lowercase()) {
        "mkv" -> "matroska"; "webm" -> "webm"; "m4a", "aac" -> "ipod"; "mp3" -> "mp3"; else -> "mp4"
    }

    private fun move(src: File, out: File) {
        out.delete()
        if (!src.renameTo(out)) { src.copyTo(out, overwrite = true); src.delete() }
    }

    /** Merges separate video + audio streams (yt-dlp DASH downloads) into [out]; copy first, then safer fallbacks. */
    suspend fun mergeAv(
        video: File, audio: File, out: File, target: String, durationSec: Double, onProgress: (Float) -> Unit = {}
    ): Boolean {
        val fmt = containerOf(target).let { if (it == "ipod" || it == "mp3") "mp4" else it }
        val base = listOf("-y", "-i", video.absolutePath, "-i", audio.absolutePath, "-map", "0:v:0", "-map", "1:a:0")
        val mov = if (fmt == "mp4") listOf("-movflags", "+faststart") else emptyList()
        out.delete()
        if (run(base + listOf("-c", "copy", "-f", fmt) + mov + out.absolutePath, durationSec, onProgress) && verify(out, true)) return true
        out.delete()
        if (fmt != "webm") {
            val a = base + listOf("-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-f", fmt) + mov + out.absolutePath
            if (run(a, durationSec, onProgress) && verify(out, true)) return true
            out.delete()
            val e = base + listOf(
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-b:a", "192k", "-f", fmt
            ) + mov + out.absolutePath
            if (run(e, durationSec, onProgress) && verify(out, true)) return true
            out.delete()
        }
        return false
    }

    /** Makes a single downloaded file match the wanted container / audio format. */
    suspend fun conform(
        src: File, target: String, music: Boolean, out: File, durationSec: Double, onProgress: (Float) -> Unit = {}
    ): Boolean {
        val e = src.extension.lowercase()
        val t = target.lowercase()
        out.delete()
        if (e == t) { move(src, out); return verify(out) }
        if (music) {
            if (t == "mp3") return toMp3(src, out, onProgress)
            val args = listOf(
                "-y", "-i", src.absolutePath, "-vn", "-map", "0:a:0", "-c:a", "aac", "-b:a", "192k",
                "-f", containerOf(t), out.absolutePath
            )
            if (run(args, durationSec, onProgress) && verify(out)) return true
            out.delete()
            return false
        }
        val fmt = containerOf(t)
        if (fmt == "mp4") return remuxToMp4(src, out, onProgress)
        val args = listOf(
            "-y", "-i", src.absolutePath, "-map", "0:v:0?", "-map", "0:a:0?", "-c", "copy", "-f", fmt, out.absolutePath
        )
        if (run(args, durationSec, onProgress) && verify(out, true)) return true
        out.delete()
        return false
    }
}
