package com.alfy.downloader.part3.ytdlp

import android.app.Application
import android.content.Context
import com.alfy.downloader.AppConfig
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject

/** Thin, crash-proof wrapper around the yt-dlp runtime (Python + extractors). */
object YtDlp {
    private const val KEY_LAST_UPDATE = "ytdlp_last_update"
    const val KEY_AUTO_UPDATE = "ytdlp_autoupdate"
    private const val UPDATE_EVERY_MS = 12L * 3600_000L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val ready = CompletableDeferred<Boolean>()
    @Volatile private var started = false
    @Volatile var initError: String? = null
        private set

    /** Non-blocking: extracts the runtime on a background thread, then self-updates the extractors. */
    @Synchronized
    fun init(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        scope.launch {
            try {
                YoutubeDL.getInstance().init(app as Application)
                ready.complete(true)
            } catch (e: Throwable) {
                initError = e.message ?: e.javaClass.simpleName
                ready.complete(false)
                return@launch
            }
            maybeUpdate(app)
        }
    }

    suspend fun await(): Boolean = withTimeoutOrNull(120_000L) { ready.await() } ?: false

    /** Forces an extractor update now (Settings button). Returns true when the call went through. */
    fun updateNow(ctx: Context): Boolean {
        val app = ctx.applicationContext
        val ok = runUpdate(app)
        if (ok) app.getSharedPreferences(AppConfig.PREFS, Context.MODE_PRIVATE)
            .edit().putLong(KEY_LAST_UPDATE, System.currentTimeMillis()).apply()
        return ok
    }

    private fun maybeUpdate(app: Context) {
        val p = app.getSharedPreferences(AppConfig.PREFS, Context.MODE_PRIVATE)
        if (!p.getBoolean(KEY_AUTO_UPDATE, true)) return
        val last = p.getLong(KEY_LAST_UPDATE, 0L)
        if (System.currentTimeMillis() - last < UPDATE_EVERY_MS) return
        if (runUpdate(app)) p.edit().putLong(KEY_LAST_UPDATE, System.currentTimeMillis()).apply()
    }

    /** Reflection keeps this independent from the exact UpdateChannel API of the library version. */
    private fun runUpdate(app: Context): Boolean {
        val yd = YoutubeDL.getInstance()
        val methods = yd.javaClass.methods.filter { it.name == "updateYoutubeDL" }.sortedBy { it.parameterTypes.size }
        for (m in methods) {
            try {
                val pt = m.parameterTypes
                val args: Array<Any?> = when (pt.size) {
                    1 -> arrayOf(app)
                    2 -> arrayOf(app, channelOf(pt[1]) ?: continue)
                    else -> continue
                }
                m.invoke(yd, *args)
                return true
            } catch (ignored: Throwable) { }
        }
        return false
    }

    private fun channelOf(cls: Class<*>): Any? {
        try {
            for (n in listOf("_STABLE", "STABLE")) {
                try {
                    val f = cls.getField(n)
                    val v = f.get(null)
                    if (v != null) return v
                } catch (ignored: Throwable) { }
            }
            cls.enumConstants?.firstOrNull { it.toString().contains("STABLE", true) }?.let { return it }
            for (inner in cls.declaredClasses) {
                if (inner.simpleName.equals("STABLE", true)) {
                    return inner.getField("INSTANCE").get(null)
                }
            }
            val comp = cls.declaredClasses.firstOrNull { it.simpleName == "Companion" }
            if (comp != null) {
                val inst = cls.getField("Companion").get(null)
                val g = comp.methods.firstOrNull { it.name.contains("STABLE", true) && it.parameterTypes.isEmpty() }
                if (g != null) return g.invoke(inst)
            }
        } catch (ignored: Throwable) { }
        return null
    }

    /** Options that keep yt-dlp stable behind tunnelling VPNs (IPv4, generous timeouts, retries). */
    fun baseOptions(req: YoutubeDLRequest, referer: String?, userAgent: String?) {
        req.addOption("--ignore-config")
        req.addOption("--no-playlist")
        req.addOption("--force-ipv4")
        req.addOption("--no-warnings")
        req.addOption("--socket-timeout", "25")
        req.addOption("--retries", "10")
        req.addOption("--fragment-retries", "10")
        req.addOption("--extractor-retries", "3")
        if (!referer.isNullOrBlank()) req.addOption("--referer", referer)
        if (!userAgent.isNullOrBlank()) req.addOption("--user-agent", userAgent)
    }

    /** Runs `-J` and returns the parsed JSON (first playlist entry list is kept under "entries"). */
    fun dumpJson(target: String, referer: String?, userAgent: String?): JSONObject? {
        val req = YoutubeDLRequest(target)
        baseOptions(req, referer, userAgent)
        req.addOption("--dump-single-json")
        req.addOption("--skip-download")
        req.addOption("--playlist-end", "5")
        val out = YoutubeDL.getInstance().execute(req).out ?: return null
        val i = out.indexOf('{')
        val j = out.lastIndexOf('}')
        if (i < 0 || j <= i) return null
        return JSONObject(out.substring(i, j + 1))
    }

    /**
     * Fast search (flat playlist: no format extraction) used by the accessibility detector to turn a title seen on
     * screen into a video ID. Returns entries with id / title / channel / duration; empty list on any failure.
     */
    fun searchFlat(query: String, count: Int = 5): List<JSONObject> {
        val req = YoutubeDLRequest("ytsearch$count:$query")
        baseOptions(req, null, null)
        req.addOption("--flat-playlist")
        req.addOption("--dump-single-json")
        req.addOption("--skip-download")
        val out = YoutubeDL.getInstance().execute(req).out ?: return emptyList()
        val i = out.indexOf('{')
        val j = out.lastIndexOf('}')
        if (i < 0 || j <= i) return emptyList()
        val arr = JSONObject(out.substring(i, j + 1)).optJSONArray("entries") ?: return emptyList()
        val res = ArrayList<JSONObject>()
        for (k in 0 until arr.length()) arr.optJSONObject(k)?.let { res += it }
        return res
    }

    fun cancel(processId: String) {
        try { YoutubeDL.getInstance().destroyProcessById(processId) } catch (ignored: Throwable) { }
    }
}
