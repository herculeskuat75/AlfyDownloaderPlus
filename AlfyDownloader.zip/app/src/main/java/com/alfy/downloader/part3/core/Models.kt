package com.alfy.downloader.part3.core

import okhttp3.OkHttpClient
import org.json.JSONObject
import java.net.URI
import java.util.concurrent.TimeUnit

enum class Source { CLIPBOARD, BROWSER, OCR, SHARE, NETWORK, MANUAL }
enum class Category { VIDEO, MUSIC }

object Http {
    const val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    fun originOf(url: String): String? = try {
        val u = URI(url)
        if (u.scheme == null || u.host == null) null
        else "${u.scheme}://${u.host}${if (u.port != -1) ":${u.port}" else ""}"
    } catch (e: Exception) { null }

    fun headersFor(ua: String, referer: String?): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        m["User-Agent"] = ua
        if (!referer.isNullOrBlank()) {
            m["Referer"] = referer
            originOf(referer)?.let { m["Origin"] = it }
        }
        return m
    }

    fun ffHeaderString(h: Map<String, String>): String =
        h.filterKeys { !it.equals("User-Agent", true) }.entries.joinToString("") { "${it.key}: ${it.value}\r\n" }
}

data class MediaCandidate(
    val url: String,
    val key: String,
    val title: String,
    val category: Category,
    val referer: String?,
    val userAgent: String,
    val width: Int,
    val height: Int,
    val durationSec: Double,
    val sizeBytes: Long,
    val isHls: Boolean,
    val hlsProgram: Int,
    val ext: String,
    val source: Source,
    val foundAt: Long = System.currentTimeMillis()
) {
    val qualityLabel: String
        get() {
            if (category == Category.MUSIC) return "Audio"
            val side = if (width > 0 && height > 0) minOf(width, height) else height
            return if (side > 0) "${side}p" else "?"
        }

    fun toJson(): JSONObject = JSONObject().apply {
        put("url", url); put("key", key); put("title", title); put("category", category.name)
        put("referer", referer ?: JSONObject.NULL); put("ua", userAgent)
        put("w", width); put("h", height); put("dur", durationSec); put("size", sizeBytes)
        put("hls", isHls); put("prog", hlsProgram); put("ext", ext); put("src", source.name); put("t", foundAt)
    }

    companion object {
        fun fromJson(o: JSONObject) = MediaCandidate(
            url = o.getString("url"), key = o.getString("key"), title = o.getString("title"),
            category = Category.valueOf(o.getString("category")),
            referer = if (o.isNull("referer")) null else o.getString("referer"),
            userAgent = o.getString("ua"), width = o.optInt("w"), height = o.optInt("h"),
            durationSec = o.optDouble("dur", 0.0), sizeBytes = o.optLong("size", 0),
            isHls = o.optBoolean("hls"), hlsProgram = o.optInt("prog", -1), ext = o.optString("ext", "mp4"),
            source = Source.valueOf(o.optString("src", "MANUAL")), foundAt = o.optLong("t")
        )
    }
}
