package com.alfy.downloader

import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

class DownloadService : Service() {
    companion object {
        private val jobs = ConcurrentHashMap<String, Job>()
        private val sem = Semaphore(3)
        fun cmd(c: Context, action: String, id: String) {
            val i = Intent(c, DownloadService::class.java).setAction(action).putExtra("id", id)
            ContextCompat.startForegroundService(c, i)
        }
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        scope.launch {
            while (true) {
                delay(1000)
                if (jobs.isEmpty()) continue
                val act = Repo.downloads.value.filter { it.status == Status.DOWNLOADING }
                if (act.isEmpty()) continue
                val sp = act.sumOf { it.speed }
                val pr = act.map { it.progress }.average().toInt()
                val txt = "${act.size} unduhan • ${fmtSize(sp)}/s • $pr%\n" + act.first().name
                postNotif(this@DownloadService, 2, makeNotif(this@DownloadService, txt, "Mengunduh…", pr))
            }
        }
    }

    /** Daftarkan file ke MediaStore agar pemutar musik/notifikasi media memuat cover (album art). */
    private fun scanMedia(f: File) {
        try { android.media.MediaScannerConnection.scanFile(applicationContext, arrayOf(f.path), null, null) } catch (e: Throwable) { }
    }

    private fun notifyDone(name: String, size: Long) {
        postNotif(this, 1000 + (name.hashCode() and 0xFFFF),
            makeNotif(this, "$name • ${fmtSize(size)}", "Unduhan selesai ✓", -1, false, true))
    }

    private fun notifyFail(name: String, err: String) {
        postNotif(this, 1000 + (name.hashCode() and 0xFFFF),
            makeNotif(this, "$name • $err", "Unduhan gagal ✗", -1, false, true, android.R.drawable.stat_notify_error))
    }

    override fun onStartCommand(i: Intent?, f: Int, sid: Int): Int {
        startForeground(2, makeNotif(this, "Menyiapkan unduhan…", "Mengunduh…"))
        val id = i?.getStringExtra("id")
        if (id != null) when (i?.action) {
            "start" -> begin(id)
            "pause" -> pause(id, false)
            "cancel" -> pause(id, true)
        }
        checkStop()
        return START_NOT_STICKY
    }

    private fun checkStop() {
        if (jobs.isEmpty()) { stopForeground(true); stopSelf() }
    }

    private fun begin(id: String) {
        if (jobs.containsKey(id)) return
        Repo.update(id) { it.copy(status = Status.QUEUED, error = "") }
        val j = scope.launch(start = CoroutineStart.LAZY) { sem.withPermit { runItem(id) } }
        jobs[id] = j
        j.invokeOnCompletion { jobs.remove(id); Repo.save(); checkStop() }
        j.start()
    }

    private fun pause(id: String, cancel: Boolean) {
        if (!cancel) Repo.update(id) { it.copy(status = Status.PAUSED, speed = 0) }
        jobs[id]?.cancel()
        try { YoutubeDL.getInstance().destroyProcessById(id) } catch (e: Exception) { }
        Repo.save()
    }

    private fun onWifi(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        @Suppress("DEPRECATION")
        return cm.activeNetworkInfo?.type == ConnectivityManager.TYPE_WIFI
    }

    private suspend fun runItem(id: String) {
        var attempts = 0
        while (true) {
            val item = Repo.get(id) ?: return
            if (item.wifiOnly && !onWifi()) {
                Repo.update(id) { it.copy(status = Status.PAUSED, error = "Menunggu WiFi") }; return
            }
            Repo.update(id) { it.copy(status = Status.DOWNLOADING) }
            try {
                if (item.kind == Kind.DIRECT) direct(item) else ytdl(item)
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val cur = Repo.get(id)
                if (cur == null || cur.status == Status.PAUSED) return
                attempts++
                if (item.retry && attempts < 3) { delay(2500); continue }
                Repo.update(id) { it.copy(status = Status.ERROR, error = e.message ?: "Gagal", speed = 0) }
                notifyFail(item.name, e.message ?: "Gagal")
                return
            }
        }
    }

    private class Spec(val ua: String?, val mergeUrl: String?, val mergeUa: String?)
    private fun spec(s: String?): Spec {
        var ua: String? = null; var m: String? = null; var mu: String? = null
        s?.lines()?.forEach { l ->
            when {
                l.startsWith("UA:") -> ua = l.substring(3)
                l.startsWith("MERGE:") -> m = l.substring(6)
                l.startsWith("AUA:") -> mu = l.substring(4)
            }
        }
        return Spec(ua, m, mu)
    }

    /** Unduh cepat: 4 koneksi paralel, potongan 4MB (menghindari throttle googlevideo). */
    private suspend fun fetch(url: String, ua: String?, ref: String?, dest: File, itemId: String, base: Long, grand: Long): Long {
        fun conn(range: String): HttpURLConnection {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 20000
            c.setRequestProperty("User-Agent", ua ?: Resolver.UA)
            ref?.let { c.setRequestProperty("Referer", it) }
            // v1.30: cookie WebView untuk host ini (CDN bertanda tangan sering menuntutnya)
            try { val ck = android.webkit.CookieManager.getInstance().getCookie(url); if (!ck.isNullOrBlank()) c.setRequestProperty("Cookie", ck) } catch (e: Throwable) { }
            c.setRequestProperty("Range", range)
            return c
        }
        val probe = conn("bytes=0-0")
        val code = probe.responseCode
        if (code !in 200..299) {
            probe.disconnect()
            // v1.30: link CDN kedaluwarsa/ditolak -> pindai ulang halaman asal agar link baru muncul di daftar
            if ((code == 401 || code == 403 || code == 404 || code == 410) && ref != null && ref.startsWith("http")) {
                try { Resolver.seen.remove(ref); Resolver.submit(ref, null, true, "Segarkan link") } catch (e: Throwable) { }
                throw IOException("HTTP $code (link kedaluwarsa, halaman dipindai ulang - pilih link baru di daftar)")
            }
            throw IOException("HTTP $code (link ditolak server)")
        }
        val cr = probe.getHeaderField("Content-Range")
        probe.disconnect()
        val size = cr?.substringAfterLast('/')?.toLongOrNull() ?: -1L
        if (size <= 0) throw IOException("ukuran file tidak diketahui")
        java.io.RandomAccessFile(dest, "rw").use { it.setLength(size) }
        val next = java.util.concurrent.atomic.AtomicLong(0)
        val got = java.util.concurrent.atomic.AtomicLong(0)
        val chunk = 4L * 1024 * 1024
        coroutineScope {
            val rep = launch {
                var lastB = 0L; var lastT = System.currentTimeMillis()
                while (true) {
                    delay(700)
                    val now = System.currentTimeMillis()
                    val g = got.get()
                    val sp = (g - lastB) * 1000 / maxOf(1L, now - lastT)
                    lastB = g; lastT = now
                    val tot = if (grand > 0) grand else size
                    val dn = base + g
                    Repo.update(itemId) { it.copy(done = dn, total = tot, speed = sp, progress = (dn * 100 / tot).toInt().coerceIn(0, 100)) }
                }
            }
            (1..4).map {
                async(Dispatchers.IO) {
                    java.io.RandomAccessFile(dest, "rw").use { raf ->
                        val buf = ByteArray(65536)
                        while (true) {
                            val s = next.getAndAdd(chunk)
                            if (s >= size) break
                            val e = minOf(s + chunk - 1, size - 1)
                            var tries = 0
                            while (true) {
                                try {
                                    val c = conn("bytes=$s-$e")
                                    val cd = c.responseCode
                                    if (cd !in 200..299) { c.disconnect(); throw IOException("HTTP $cd") }
                                    raf.seek(s)
                                    c.inputStream.use { ins ->
                                        while (true) {
                                            val n = ins.read(buf)
                                            if (n < 0) break
                                            raf.write(buf, 0, n)
                                            got.addAndGet(n.toLong())
                                            currentCoroutineContext().ensureActive()
                                        }
                                    }
                                    c.disconnect()
                                    break
                                } catch (ex: IOException) {
                                    if (++tries >= 3) throw ex
                                }
                            }
                        }
                    }
                }
            }.awaitAll()
            rep.cancel()
        }
        return size
    }

    private fun mux(video: File, audio: File, out: File) {
        val vx = android.media.MediaExtractor(); vx.setDataSource(video.path)
        val ax = android.media.MediaExtractor(); ax.setDataSource(audio.path)
        fun pick(e: android.media.MediaExtractor, p: String): Int {
            for (i in 0 until e.trackCount) if (e.getTrackFormat(i).getString(android.media.MediaFormat.KEY_MIME)?.startsWith(p) == true) return i
            return -1
        }
        val vi = pick(vx, "video/"); val ai = pick(ax, "audio/")
        if (vi < 0 || ai < 0) throw IOException("track video/audio tidak ditemukan")
        vx.selectTrack(vi); ax.selectTrack(ai)
        val mx = android.media.MediaMuxer(out.path, android.media.MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val vt = mx.addTrack(vx.getTrackFormat(vi)); val at = mx.addTrack(ax.getTrackFormat(ai))
        mx.start()
        val buf = java.nio.ByteBuffer.allocate(4 * 1024 * 1024)
        val info = android.media.MediaCodec.BufferInfo()
        for ((ex, tr) in listOf(Pair(vx, vt), Pair(ax, at))) {
            while (true) {
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                val key = if (ex.sampleFlags and android.media.MediaExtractor.SAMPLE_FLAG_SYNC != 0) android.media.MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                info.set(0, n, ex.sampleTime, key)
                mx.writeSampleData(tr, buf, info)
                ex.advance()
            }
        }
        mx.stop(); mx.release(); vx.release(); ax.release()
    }

    private suspend fun fastDirect(item: DlItem, sp: Spec) {
        val dir = File(item.dir).apply { mkdirs() }
        val v = File(dir, item.name + ".v.part")
        val vSize = fetch(item.url, sp.ua, item.referer, v, item.id, 0L, if (sp.mergeUrl != null) item.total else 0L)
        var f: File
        if (sp.mergeUrl != null) {
            val a = File(dir, item.name + ".a.part")
            fetch(sp.mergeUrl, sp.mergeUa, null, a, item.id, vSize, item.total)
            Repo.update(item.id) { it.copy(progress = 100, speed = 0, error = "Menggabungkan video + suara…") }
            f = uniqueFile(dir, item.name)
            try { mux(v, a, f) } finally { v.delete(); a.delete() }
        } else {
            f = uniqueFile(dir, item.name)
            v.renameTo(f)
        }
        if (item.isAudio) f = embedCover(f, item)
        Repo.update(item.id) {
            it.copy(status = Status.DONE, progress = 100, path = f.path, name = f.name,
                total = f.length(), done = f.length(), speed = 0, error = "")
        }
        Repo.save()
        scanMedia(f); notifyDone(f.name, f.length())
    }

    private suspend fun direct(item: DlItem) {
        val sp = spec(item.formatSel)
        if (sp.mergeUrl != null || item.url.contains("googlevideo.com")) { fastDirect(item, sp); return }
        val dir = File(item.dir).apply { mkdirs() }
        val part = File(dir, item.name + ".part")
        var existing = if (part.exists()) part.length() else 0L
        val c = URL(item.url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 20000
        c.setRequestProperty("User-Agent", Resolver.UA)
        item.referer?.let { c.setRequestProperty("Referer", it) }
        if (existing > 0) c.setRequestProperty("Range", "bytes=$existing-")
        val code = c.responseCode
        if (code !in 200..299) {
            c.disconnect()
            if (code == 416) part.delete()
            throw IOException("HTTP $code")
        }
        val append = existing > 0 && code == 206
        if (!append) existing = 0
        val len = c.contentLengthLong
        val total = if (len > 0) len + existing else 0L
        val acc = code == 206 || (c.getHeaderField("Accept-Ranges")?.contains("bytes", true) == true)
        Repo.update(item.id) { it.copy(total = total, resumable = acc) }
        var done = existing
        var lastT = System.currentTimeMillis()
        var lastB = done
        c.inputStream.use { ins ->
            FileOutputStream(part, append).use { out ->
                val buf = ByteArray(65536)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    currentCoroutineContext().ensureActive()
                    val now = System.currentTimeMillis()
                    if (now - lastT >= 700) {
                        val sp = (done - lastB) * 1000 / (now - lastT)
                        lastT = now; lastB = done
                        val d = done
                        Repo.update(item.id) {
                            it.copy(done = d, speed = sp, progress = if (total > 0) (d * 100 / total).toInt() else 0)
                        }
                    }
                }
            }
        }
        c.disconnect()
        val f = uniqueFile(dir, item.name)
        part.renameTo(f)
        val fin = if (item.isAudio) embedCover(f, item) else f
        Repo.update(item.id) {
            it.copy(status = Status.DONE, progress = 100, path = fin.path, name = fin.name,
                total = fin.length(), done = fin.length(), speed = 0, error = "")
        }
        Repo.save()
        scanMedia(fin); notifyDone(fin.name, fin.length())
    }

    /** v1.10: file valid MP4 punya "ftyp" di byte 4-8; hasil HLS (MPEG-TS) tidak bisa diputar sebelum dikonversi. */
    private fun isMp4(f: File): Boolean = try {
        f.inputStream().use { s -> val b = ByteArray(12); val n = s.read(b); n >= 12 && String(b, 4, 4, Charsets.ISO_8859_1) in listOf("ftyp", "moov", "mdat", "free", "wide") }
    } catch (e: Exception) { true }

    /** Cari og:image / twitter:image dari halaman sumber (untuk situs non-YouTube). */
    private fun ogImage(page: String): String? = try {
        val c = URL(page).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 10000
        c.setRequestProperty("User-Agent", Resolver.UA)
        val html = c.inputStream.use { ins -> String(ins.readBytes().let { if (it.size > 400_000) it.copyOf(400_000) else it }, Charsets.UTF_8) }
        c.disconnect()
        val r1 = Regex("<meta[^>]+(?:property|name)=[\"'](?:og:image(?::secure_url)?|twitter:image)[\"'][^>]*content=[\"']([^\"']+)", RegexOption.IGNORE_CASE)
        val r2 = Regex("<meta[^>]+content=[\"']([^\"']+)[\"'][^>]*(?:property|name)=[\"'](?:og:image|twitter:image)[\"']", RegexOption.IGNORE_CASE)
        val u = (r1.find(html) ?: r2.find(html))?.groupValues?.get(1)?.replace("&amp;", "&")
        if (u != null && u.startsWith("//")) "https:$u" else if (u != null && u.startsWith("http")) u else null
    } catch (e: Throwable) { null }

    private fun findFfmpeg(): File? {
        val roots = listOfNotNull(Repo.app.noBackupFilesDir, Repo.app.filesDir, File(Repo.app.applicationInfo.nativeLibraryDir))
        for (r in roots) {
            val hit = r.walkTopDown().maxDepth(8).firstOrNull { it.isFile && (it.name == "libffmpeg.so" || it.name == "ffmpeg") && it.length() > 100_000 }
            if (hit != null) { try { hit.setExecutable(true) } catch (e: Exception) { }; return hit }
        }
        return null
    }

    // v1.35: helper ffmpeg khusus cover (findFfmpeg lama tidak diubah, dipakai remuxMp4)
    private fun ffmpegEnv(pb: ProcessBuilder, bin: File) {
        val extra = File(Repo.app.noBackupFilesDir, "youtubedl-android/packages/ffmpeg/usr/lib")
        val libs = listOfNotNull(bin.parentFile, bin.parentFile?.parentFile?.let { File(it, "lib") }, extra).filter { it.isDirectory }.joinToString(":") { it.path }
        pb.environment()["LD_LIBRARY_PATH"] = libs + ":" + (System.getenv("LD_LIBRARY_PATH") ?: "")
    }

    private fun runFfmpeg(bin: File, args: List<String>): Pair<Int, String> {
        val pb = ProcessBuilder(listOf(bin.path) + args)
        pb.redirectErrorStream(true)
        ffmpegEnv(pb, bin)
        val p = pb.start()
        val out = p.inputStream.readBytes().toString(Charsets.UTF_8)
        return Pair(p.waitFor(), out)
    }

    /** Pilih binary ffmpeg yang benar-benar bisa jalan (libffmpeg.so di nativeLibraryDir dulu, lalu hasil findFfmpeg). */
    private fun pickFfmpeg(): File? {
        val cands = ArrayList<File>()
        try { cands.add(File(Repo.app.applicationInfo.nativeLibraryDir, "libffmpeg.so")) } catch (e: Throwable) { }
        try { findFfmpeg()?.let { cands.add(it) } } catch (e: Throwable) { android.util.Log.w("AlfyCover", "findFfmpeg error", e) }
        for (c in cands.distinctBy { it.path }) {
            if (!c.exists()) { android.util.Log.w("AlfyCover", "ffmpeg tidak ada: ${c.path}"); continue }
            try { c.setExecutable(true) } catch (e: Exception) { }
            try {
                val r = runFfmpeg(c, listOf("-version"))
                if (r.first == 0) { android.util.Log.i("AlfyCover", "ffmpeg dipakai: ${c.path}"); return c }
                android.util.Log.w("AlfyCover", "ffmpeg ${c.path} keluar kode ${r.first}: ${r.second.take(200)}")
            } catch (e: Throwable) { android.util.Log.w("AlfyCover", "ffmpeg ${c.path} gagal dijalankan", e) }
        }
        android.util.Log.e("AlfyCover", "Tidak ada binary ffmpeg yang bisa dijalankan -> cover dilewati")
        return null
    }

    /** v1.34: pasang thumbnail video YouTube sebagai album art (cover) pada file audio lewat ffmpeg bawaan. v1.35: log jelas, webm/opus YouTube -> m4a, webp -> jpg. Gagal = file asli dibiarkan (unduhan tidak gagal). */
    private fun embedCover(src: File, item: DlItem): File {
        val tag = "AlfyCover"
        try {
            val ext = src.extension.lowercase()
            val vid = YtCover.idOf(item.thumb.ifEmpty { null }, item.url, item.referer)
            val needM4a = vid != null && (ext == "webm" || ext == "opus" || ext == "ogg" || ext == "weba")
            if (ext != "m4a" && ext != "mp3" && ext != "mp4" && ext != "flac" && !needM4a) {
                android.util.Log.i(tag, "format .$ext tidak didukung untuk cover (${src.name})"); return src
            }
            android.util.Log.i(tag, "mulai: file=${src.name} ext=$ext idVideo=$vid")
            val bin = pickFfmpeg() ?: return src
            Repo.update(item.id) { it.copy(progress = 100, speed = 0, error = "Memasang cover…") }
            val img = File(src.parentFile, "." + src.nameWithoutExtension + ".cover.jpg")
            val urls = ArrayList<String>()
            // YouTube: gambar sesuai ID video didahulukan, fallback resolusi turun
            if (vid != null) for (q in listOf("maxresdefault", "sddefault", "hqdefault", "mqdefault")) urls.add("https://i.ytimg.com/vi/$vid/$q.jpg")
            if (item.img.startsWith("http")) urls.add(item.img)
            var ok = false
            var og = false
            var i = 0
            while (!ok) {
                if (i >= urls.size) {
                    if (og) break
                    og = true
                    val ref = item.referer
                    if (vid == null && ref != null && ref.startsWith("http") && !ref.contains("googlevideo")) { val u = ogImage(ref); if (u != null) urls.add(u) }
                    if (i >= urls.size) break
                }
                val u = urls[i++]
                try {
                    val c = URL(u).openConnection() as HttpURLConnection
                    c.connectTimeout = 8000; c.readTimeout = 10000
                    c.setRequestProperty("User-Agent", Resolver.UA)
                    item.referer?.let { c.setRequestProperty("Referer", it) }
                    val rc = c.responseCode
                    if (rc == 200) {
                        c.inputStream.use { ins -> FileOutputStream(img).use { o -> ins.copyTo(o) } }
                        val hd = ByteArray(12)
                        try { img.inputStream().use { it.read(hd) } } catch (e: Exception) { }
                        val isJpg = hd[0] == 0xFF.toByte() && hd[1] == 0xD8.toByte()
                        val isPng = hd[0] == 0x89.toByte() && hd[1] == 'P'.code.toByte()
                        val isWebp = hd[0] == 'R'.code.toByte() && hd[1] == 'I'.code.toByte() && hd[8] == 'W'.code.toByte() && hd[9] == 'E'.code.toByte()
                        if (img.length() > 2048 && isWebp) {
                            val jp = File(img.parentFile, img.name + ".jpg")
                            val r = runFfmpeg(bin, listOf("-y", "-i", img.path, "-frames:v", "1", "-q:v", "2", jp.path))
                            if (r.first == 0 && jp.length() > 2048) { img.delete(); jp.renameTo(img); ok = true }
                            else { jp.delete(); android.util.Log.w(tag, "konversi webp->jpg gagal: ${r.second.takeLast(200)}") }
                        } else if (img.length() > 2048 && (isJpg || isPng)) ok = true
                        else android.util.Log.w(tag, "gambar tidak valid dari $u (ukuran=${img.length()})")
                    } else android.util.Log.w(tag, "HTTP $rc untuk $u -> coba fallback berikutnya")
                    c.disconnect()
                } catch (e: Exception) { android.util.Log.w(tag, "gagal ambil $u: ${e.javaClass.simpleName} ${e.message}") }
            }
            if (!ok) { img.delete(); android.util.Log.w(tag, "tidak ada gambar yang bisa diambil, audio tanpa cover (${src.name})"); return src }
            val tmpExt = if (needM4a) "m4a" else ext
            val tmp = File(src.parentFile, "." + src.nameWithoutExtension + ".cov." + tmpExt)
            tmp.delete()
            val cmd = ArrayList<String>(listOf("-y", "-i", src.path, "-i", img.path, "-map", "0:a", "-map", "1:v"))
            if (needM4a) cmd.addAll(listOf("-c:a", "aac", "-b:a", "192k", "-c:v", "copy")) else cmd.addAll(listOf("-c", "copy"))
            cmd.addAll(listOf("-disposition:v:0", "attached_pic"))
            if (ext == "mp3") cmd.addAll(listOf("-id3v2_version", "3", "-metadata:s:v", "title=Album cover", "-metadata:s:v", "comment=Cover (front)"))
            cmd.add(tmp.path)
            val r = runFfmpeg(bin, cmd)
            img.delete()
            val minOk = if (needM4a) 1024L else src.length() / 2
            if (r.first != 0 || !tmp.exists() || tmp.length() < minOk) {
                android.util.Log.e(tag, "ffmpeg gagal pasang cover (kode ${r.first}): ${r.second.takeLast(300)}")
                tmp.delete(); return src
            }
            val dest = if (needM4a) File(src.parentFile, src.nameWithoutExtension + ".m4a") else File(src.path)
            if (needM4a && dest.exists()) { android.util.Log.w(tag, "${dest.name} sudah ada, cover tidak dipasang"); tmp.delete(); return src }
            val res = if (src.delete() && tmp.renameTo(dest)) dest else if (dest.exists()) dest else tmp
            android.util.Log.i(tag, "cover terpasang: ${res.name}")
            try { scanMedia(res) } catch (e: Throwable) { }
            return res
        } catch (e: Throwable) { android.util.Log.e("AlfyCover", "embedCover error (unduhan tetap disimpan)", e); return src }
    }

    /** Konversi (tanpa encode ulang) MPEG-TS/HLS -> MP4 dengan ffmpeg bawaan. Gagal = file asli dibiarkan. */
    private fun remuxMp4(src: File, base: String): File {
        try {
            val bin = findFfmpeg() ?: return src
            val tmp = File(src.parentFile, "$base.fix.mp4")
            tmp.delete()
            val pb = ProcessBuilder(bin.path, "-y", "-i", src.path, "-c", "copy", "-bsf:a", "aac_adtstoasc", "-movflags", "+faststart", tmp.path)
            pb.redirectErrorStream(true)
            val libs = listOfNotNull(bin.parentFile, bin.parentFile?.parentFile?.let { File(it, "lib") }).filter { it.isDirectory }.joinToString(":") { it.path }
            pb.environment()["LD_LIBRARY_PATH"] = libs + ":" + (System.getenv("LD_LIBRARY_PATH") ?: "")
            val p = pb.start()
            p.inputStream.readBytes()
            val code = p.waitFor()
            if (code != 0 || !tmp.exists() || tmp.length() < 1024) { tmp.delete(); return src }
            val dest = File(src.parentFile, "$base.mp4")
            src.delete()
            dest.delete()
            return if (tmp.renameTo(dest)) dest else tmp
        } catch (e: Throwable) { return src }
    }

    private fun ytdl(item: DlItem) {
        Engine.await()
        val dir = File(item.dir).apply { mkdirs() }
        val base = item.name.substringBeforeLast('.').replace("%", "")
        val isYt = item.url.contains("youtu") && !item.url.contains("googlevideo")
        val clients: List<String?> = if (isYt) (listOfNotNull(Resolver.ytArgs) + Resolver.YT_CLIENTS).distinct() else listOf(null)
        var lastE: Exception? = null
        var okRun = false
        Repo.update(item.id) { it.copy(resumable = true) }
        for (c in clients) {
            val req = YoutubeDLRequest(item.url)
            req.addOption("--no-playlist")
            req.addOption("--no-mtime")
            req.addOption("--concurrent-fragments", "4")
            req.addOption("-o", "${dir.path}/$base.%(ext)s")
            item.referer?.let { req.addOption("--referer", it) }
            if (c != null) req.addOption("--extractor-args", c)
            req.addOption("-f", item.formatSel ?: (if (item.isAudio) (if (isYt) "bestaudio[ext=m4a]/bestaudio/best" else "bestaudio/best") else "best"))
            try {
                YoutubeDL.getInstance().execute(req, item.id) { p, _, line ->
                    val sp = parseSpeed(line ?: "")
                    Repo.update(item.id) { it.copy(progress = p.toInt().coerceIn(0, 100), speed = if (sp > 0) sp else it.speed) }
                }
                okRun = true
                Resolver.ytArgs = c
                break
            } catch (e: Exception) {
                val cur = Repo.get(item.id)
                if (cur == null || cur.status == Status.PAUSED) throw e
                lastE = e
                Repo.update(item.id) { it.copy(error = "Mencoba cara lain…") }
            }
        }
        if (!okRun) throw lastE ?: IOException("Unduhan gagal")
        var f = dir.listFiles { x -> x.name.startsWith("$base.") && !x.name.endsWith(".part") && !x.name.endsWith(".ytdl") }
            ?.maxByOrNull { it.lastModified() } ?: throw IOException("File hasil tidak ditemukan")
        if (!item.isAudio && !isMp4(f) && Tool.on("ffmpeg")) {
            Repo.update(item.id) { it.copy(progress = 100, error = "Mengonversi ke MP4…") }
            f = remuxMp4(f, base)
        }
        if (item.isAudio) f = embedCover(f, item)
        Repo.update(item.id) {
            it.copy(status = Status.DONE, progress = 100, path = f.path, name = f.name,
                total = f.length(), done = f.length(), speed = 0, error = "")
        }
        Repo.save()
        scanMedia(f); notifyDone(f.name, f.length())
    }
}

/** Ambil ID video YouTube (11 karakter) dari ID langsung atau dari tautan watch/youtu.be/shorts/embed/live. */
object YtCover {
    private val RE = Regex("(?:youtu\\.be/|youtube(?:-nocookie)?\\.com/(?:watch/?\\?(?:[^#]*&)?v=|shorts/|embed/|live/|v/)|ytimg\\.com/vi(?:_webp)?/)([\\w-]{11})")
    private val ID = Regex("^[\\w-]{11}$")
    fun idOf(vararg s: String?): String? {
        for (x in s) {
            if (x.isNullOrEmpty()) continue
            if (ID.matches(x)) return x
            RE.find(x)?.let { return it.groupValues[1] }
        }
        return null
    }
}
