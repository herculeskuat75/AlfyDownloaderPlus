package com.alfy.downloader

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private val Teal = Color(0xFF80CBC4)

/** Drawer Bookmark: meluncur dari kanan (80% layar), bisa diseret untuk menutup, ada tombol + untuk menambah URL aktif. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BookmarkDrawerUi(
    open: Boolean, bms: List<PageItem>, onClose: () -> Unit, onHidden: () -> Unit,
    onAdd: () -> Unit, onOpen: (PageItem) -> Unit, onMenu: (PageItem) -> Unit
) {
    val cfg = LocalConfiguration.current
    val wDp = (cfg.screenWidthDp * 0.8f).dp
    val wPx = with(LocalDensity.current) { wDp.toPx() }
    val off = remember { Animatable(wPx) }
    val scope = rememberCoroutineScope()
    val hidden = rememberUpdatedState(onHidden)
    LaunchedEffect(open) {
        if (open) off.animateTo(0f, tween(240)) else { off.animateTo(wPx, tween(200)); hidden.value() }
    }
    val frac = (1f - off.value / wPx).coerceIn(0f, 1f)
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f * frac))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() }
        )
        Surface(
            color = Color(0xFF303030),
            modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(wDp)
                .offset { IntOffset(off.value.roundToInt(), 0) }
                .draggable(
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { d -> scope.launch { off.snapTo((off.value + d).coerceIn(0f, wPx)) } },
                    onDragStopped = { v -> if (off.value > wPx * 0.35f || v > 1500f) onClose() else scope.launch { off.animateTo(0f, tween(180)) } }
                )
        ) {
            Box(Modifier.fillMaxSize()) {
                Column(Modifier.fillMaxSize()) {
                    Row(
                        Modifier.fillMaxWidth().background(Color(0xFF5A5A5A)).padding(start = 16.dp, end = 8.dp, top = 14.dp, bottom = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Icons.get("bm_head"), color = Color.White, fontSize = 24.sp)
                        Spacer(Modifier.width(12.dp))
                        Text("Bookmark", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("TUTUP", color = Teal, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { onClose() }.padding(12.dp))
                    }
                    if (bms.isEmpty()) {
                        Text("Belum ada bookmark. Ketuk tombol + untuk menyimpan halaman aktif.", color = Color(0xFFBDBDBD), fontSize = 13.sp,
                            modifier = Modifier.padding(16.dp))
                    }
                    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 96.dp)) {
                        items(bms) { p ->
                            Row(
                                Modifier.fillMaxWidth().combinedClickable(onClick = { onOpen(p) }, onLongClick = { onMenu(p) })
                                    .padding(start = 16.dp, top = 10.dp, bottom = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(if (p.fav) Icons.get("bm_fav") else Icons.get("bm_item"), color = if (p.fav) Teal else Color.White,
                                    fontSize = 22.sp, textAlign = TextAlign.Center, modifier = Modifier.width(36.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.title, color = Color.White, fontSize = 17.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text(p.url, color = Teal, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Text("⋮", color = Color.White, fontSize = 22.sp,
                                    modifier = Modifier.clickable { onMenu(p) }.padding(horizontal = 14.dp, vertical = 6.dp))
                            }
                        }
                    }
                }
                FloatingActionButton(
                    onClick = onAdd, containerColor = Teal, contentColor = Color.Black,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
                ) { Text("+", fontSize = 28.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

/** Strip judul tab: HorizontalPager, geser kiri/kanan untuk pindah tab. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TabPagerStrip(titles: List<String>, cur: Int, onPage: (Int) -> Unit) {
    val curS = rememberUpdatedState(cur)
    val cb = rememberUpdatedState(onPage)
    val nS = rememberUpdatedState(titles.size)
    val state = rememberPagerState(initialPage = cur.coerceIn(0, maxOf(0, titles.size - 1))) { titles.size }
    LaunchedEffect(cur, titles.size) {
        if (cur in titles.indices && state.currentPage != cur) state.animateScrollToPage(cur)
    }
    LaunchedEffect(state) {
        snapshotFlow { state.settledPage }.collect { p -> if (p != curS.value && p in 0 until nS.value) cb.value(p) }
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF2B2B2B))) {
        HorizontalPager(state = state, modifier = Modifier.fillMaxSize()) { page ->
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("‹  ${page + 1}/${titles.size}  ${titles.getOrElse(page) { "" }}  ›", color = Color.White, fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 16.dp))
            }
        }
    }
}
