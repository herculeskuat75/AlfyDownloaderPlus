package com.alfy.downloader.util

import android.content.Context
import java.util.Locale

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "—"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = bytes.toDouble(); var i = 0
    while (v >= 1024 && i < units.size - 1) { v /= 1024; i++ }
    return if (i == 0) "$bytes B" else String.format(Locale.US, "%.1f %s", v, units[i])
}

fun formatDuration(ms: Long): String {
    if (ms <= 0) return "—"
    val s = ms / 1000
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%d:%02d", m, sec)
}

/** Maps any pixel height to the nearest supported label: 240p/360p/480p/720p/1080p. */
fun qualityFromHeight(h: Int): String = when {
    h <= 0 -> "Auto"
    h <= 300 -> "240p"
    h <= 420 -> "360p"
    h <= 600 -> "480p"
    h <= 900 -> "720p"
    else -> "1080p"
}

private val QUALITY_REGEX = Regex("(?<!\\d)(240|360|480|720|1080)p", RegexOption.IGNORE_CASE)

fun qualityHint(text: String?): String =
    text?.let { QUALITY_REGEX.find(it)?.groupValues?.get(1)?.let { v -> "${v}p" } } ?: "Auto"
