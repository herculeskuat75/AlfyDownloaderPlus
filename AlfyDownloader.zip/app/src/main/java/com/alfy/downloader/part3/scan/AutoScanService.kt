package com.alfy.downloader.part3.scan

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.Process
import android.widget.Toast
import com.alfy.downloader.part3.Part3
import com.alfy.downloader.part3.util.Notifs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/**
 * Smart hybrid auto-scan.
 *  - No other VPN active  -> local VpnService that only routes a fake DNS address (traffic is never tunnelled,
 *    so speed is unaffected). Every DNS query reveals the visited host; its homepage JSON/HTML is pre-fetched.
 *  - Another VPN injector (Dark Tunnel / HTTP Custom) active -> the VPN slot is NOT taken (their tunnel stays up);
 *    root iptables NAT redirect + loopback relay is used to read plain-HTTP URLs.
 *  - Neither possible -> service stops and asks the user to use manual capture methods.
 */
class AutoScanService : VpnService() {
    enum class Mode { NONE, LOCAL_VPN, IPTABLES }

    companion object {
        const val ACTION_START = "alfyd.scan.START"
        private const val CH = "alfyd_scan"
        private const val NID = 4702
        private const val FAKE_DNS = "10.77.0.2"
        private const val UPSTREAM_DNS = "1.1.1.1"

        val state = MutableStateFlow(false)
        val mode = MutableStateFlow(Mode.NONE)

        fun start(ctx: Context) {
            val i = Intent(ctx, AutoScanService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, AutoScanService::class.java)) }

        @Suppress("DEPRECATION")
        fun otherVpnActive(ctx: Context): Boolean {
            val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false
            return cm.allNetworks.any { n ->
                cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tun: ParcelFileDescriptor? = null
    private var loop: Job? = null
    private var sniffer: IptablesSniffer? = null
    private val outLock = Any()

    private fun fg(text: String) {
        val n = Notifs.build(this, CH, "AlfyD+ Auto-Scan", text)
        if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(NID, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Part3.init(this)
        fg("Memulai pemindaian…")
        if (state.value) return START_STICKY

        if (otherVpnActive(this)) {
            val s = IptablesSniffer(Process.myUid())
            if (s.start()) {
                sniffer = s
                mode.value = Mode.IPTABLES
                state.value = true
                fg("Mode iptables (VPN lain aktif) — memindai HTTP")
            } else {
                Toast.makeText(this, "VPN lain aktif & root tidak tersedia. Gunakan clipboard/OCR/browser.", Toast.LENGTH_LONG).show()
                stopSelf()
                return START_NOT_STICKY
            }
        } else {
            if (!startLocalVpn()) {
                Toast.makeText(this, "Izin VPN belum diberikan.", Toast.LENGTH_LONG).show()
                stopSelf()
                return START_NOT_STICKY
            }
            mode.value = Mode.LOCAL_VPN
            state.value = true
            fg("Mode VPN lokal — memindai host yang dikunjungi")
        }
        return START_STICKY
    }

    private fun startLocalVpn(): Boolean {
        if (prepare(this) != null) return false
        val b = Builder()
            .setSession("AlfyD+ Scan")
            .addAddress("10.77.0.1", 32)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)
            .setMtu(8192)
            .setBlocking(true)
        try { b.addDisallowedApplication(packageName) } catch (ignored: Exception) { }
        val pfd = try { b.establish() } catch (e: Exception) { null } ?: return false
        tun = pfd
        loop = scope.launch { dnsLoop(pfd) }
        return true
    }

    private fun dnsLoop(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                if (n < 28) continue
                handlePacket(buf.copyOf(n), output)
            }
        } catch (ignored: Exception) { }
    }

    private fun handlePacket(pkt: ByteArray, output: FileOutputStream) {
        if ((pkt[0].toInt() shr 4) != 4) return
        val ihl = (pkt[0].toInt() and 0x0F) * 4
        if (pkt[9].toInt() != 17 || pkt.size < ihl + 8) return
        if (u16(pkt, ihl + 2) != 53) return
        val udpLen = u16(pkt, ihl + 4)
        val off = ihl + 8
        val plen = udpLen - 8
        if (plen <= 12 || off + plen > pkt.size) return
        val query = pkt.copyOfRange(off, off + plen)
        val srcIp = pkt.copyOfRange(12, 16)
        val dstIp = pkt.copyOfRange(16, 20)
        val srcPort = u16(pkt, ihl)
        scope.launch {
            parseQName(query)?.let { HostWatcher.onHost(it) }
            val resp = forwardDns(query) ?: return@launch
            val reply = buildReply(resp, dstIp, srcIp, srcPort)
            synchronized(outLock) { try { output.write(reply) } catch (ignored: Exception) { } }
        }
    }

    private fun forwardDns(q: ByteArray): ByteArray? = try {
        DatagramSocket().use { s ->
            protect(s)
            s.soTimeout = 4000
            s.send(DatagramPacket(q, q.size, InetAddress.getByName(UPSTREAM_DNS), 53))
            val buf = ByteArray(4096)
            val r = DatagramPacket(buf, buf.size)
            s.receive(r)
            buf.copyOf(r.length)
        }
    } catch (e: Exception) { null }

    private fun parseQName(q: ByteArray): String? {
        var i = 12
        val sb = StringBuilder()
        while (i < q.size) {
            val len = q[i].toInt() and 0xFF
            if (len == 0) break
            if (len > 63 || i + 1 + len > q.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(q, i + 1, len, Charsets.US_ASCII))
            i += len + 1
        }
        return sb.toString().ifEmpty { null }
    }

    private fun buildReply(resp: ByteArray, fakeDns: ByteArray, client: ByteArray, clientPort: Int): ByteArray {
        val total = 28 + resp.size
        val p = ByteArray(total)
        p[0] = 0x45
        put16(p, 2, total)
        put16(p, 6, 0x4000)
        p[8] = 64
        p[9] = 17
        System.arraycopy(fakeDns, 0, p, 12, 4)
        System.arraycopy(client, 0, p, 16, 4)
        put16(p, 10, checksum(p, 0, 20))
        put16(p, 20, 53)
        put16(p, 22, clientPort)
        put16(p, 24, 8 + resp.size)
        put16(p, 26, 0)
        System.arraycopy(resp, 0, p, 28, resp.size)
        return p
    }

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
    private fun put16(b: ByteArray, o: Int, v: Int) { b[o] = (v shr 8).toByte(); b[o + 1] = v.toByte() }
    private fun checksum(b: ByteArray, off: Int, len: Int): Int {
        var sum = 0L
        var i = off
        while (i < off + len - 1) { sum += u16(b, i); i += 2 }
        if (len % 2 == 1) sum += (b[off + len - 1].toInt() and 0xFF) shl 8
        while ((sum shr 16) != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    private fun shutdown() {
        state.value = false
        mode.value = Mode.NONE
        loop?.cancel()
        try { tun?.close() } catch (ignored: Exception) { }
        tun = null
        sniffer?.stop()
        sniffer = null
    }

    override fun onRevoke() { shutdown(); stopSelf() }

    override fun onDestroy() {
        shutdown()
        scope.cancel()
        super.onDestroy()
    }
}
