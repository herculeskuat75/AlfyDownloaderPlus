package com.alfy.downloader.part3.scan

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import android.os.Process
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.alfy.downloader.part3.Part3
import com.alfy.downloader.part3.core.AppHeuristics
import com.alfy.downloader.part3.core.CaptureHub
import com.alfy.downloader.permissions.RootChecker
import com.alfy.downloader.part3.util.Notifs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/**
 * Dual-mode auto-scan.
 *  - Root mode (default when root is granted): iptables NAT redirect + loopback relay reads plain-HTTP URLs and the
 *    TLS SNI of streaming apps (no decryption). No VpnService is used, so ANY tunnel VPN stays untouched.
 *  - Non-root mode: manual ingestion (paste / share / screen scan). Optional local DNS VpnService (opt-in, off by
 *    default, never started while another VPN is active).
 */
class AutoScanService : VpnService() {
    enum class Mode { NONE, LOCAL_VPN, IPTABLES }

    companion object {
        const val ACTION_START = "alfyd.scan.START"
        private const val CH = "alfyd_scan"
        private const val NID = 4702
        private const val FAKE_DNS = "10.77.0.2"
        private const val UPSTREAM_DNS = "1.1.1.1"

        val state = MutableStateFlow(false)
        val mode = MutableStateFlow(Mode.NONE)

        fun start(ctx: Context) {
            val i = Intent(ctx, AutoScanService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, AutoScanService::class.java)) }

        @Suppress("DEPRECATION")
        fun otherVpnActive(ctx: Context): Boolean {
            val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false
            return cm.allNetworks.any { n ->
                cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tun: ParcelFileDescriptor? = null
    private var loop: Job? = null
    private var sniffer: IptablesSniffer? = null
    private val outLock = Any()

    private fun fg(text: String) {
        val n = Notifs.build(this, CH, "AlfyD+ Auto-Scan", text)
        if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(NID, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Part3.init(this)
        fg("Memulai pemindaian…")
        if (state.value) return START_STICKY

        when (SniffSettings.effective(this)) {
            SniffMode.ROOT -> {
                // Root mode never touches the VPN slot, so HTTP Custom / Dark Tunnel / any tunnel keeps working.
                val s = IptablesSniffer(Process.myUid(), tlsUids(), VpnApps.uids(this))
                if (s.start()) {
                    sniffer = s
                    mode.value = Mode.IPTABLES
                    state.value = true
                    val vpn = if (otherVpnActive(this)) " • VPN aktif aman" else ""
                    fg("Mode Root — sniffing real-time (HTTP + SNI)$vpn")
                    ForegroundWatcher.start()
                    registerScreenReceiver()
                    return START_STICKY
                }
                Toast.makeText(this, "Root tidak tersedia — beralih ke mode manual (Paste / Bagikan / Scan Layar).", Toast.LENGTH_LONG).show()
            }
            SniffMode.MANUAL -> Unit
        }

        // Non-root fallback. The optional local DNS VPN is opt-in and never used while another VPN is active.
        if (SniffSettings.localVpn(this) && !otherVpnActive(this) && startLocalVpn()) {
            mode.value = Mode.LOCAL_VPN
            state.value = true
            fg("Mode non-root — VPN DNS lokal (opsional)")
            registerScreenReceiver()
            return START_STICKY
        }
        Toast.makeText(
            this, "Mode manual aktif: gunakan Paste, Bagikan (Share) ke AlfyD+, atau Scan Layar.", Toast.LENGTH_LONG
        ).show()
        stopSelf()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun tlsUids(): List<Int> = AppHeuristics.packages().mapNotNull { pkg ->
        try { packageManager.getPackageUid(pkg, 0) } catch (e: Exception) { null }
    }.distinct()

    private var screenReceiver: BroadcastReceiver? = null

    /** Smart battery throttling: screen off = idle (rules removed, captures ignored, foreground polling stopped). */
    private fun registerScreenReceiver() {
        if (screenReceiver != null) return
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                when (i?.action) {
                    Intent.ACTION_SCREEN_OFF -> {
                        CaptureHub.setThrottled(true)
                        ForegroundWatcher.stop()
                        sniffer?.pause()
                    }
                    Intent.ACTION_SCREEN_ON -> {
                        CaptureHub.setThrottled(false)
                        if (sniffer != null) ForegroundWatcher.start()
                        sniffer?.resume()
                    }
                }
            }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(this, r, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        screenReceiver = r
        val pm = getSystemService(PowerManager::class.java)
        if (pm != null && !pm.isInteractive) {
            CaptureHub.setThrottled(true)
            ForegroundWatcher.stop()
            sniffer?.pause()
        }
    }

    private fun startLocalVpn(): Boolean {
        if (prepare(this) != null) return false
        val b = Builder()
            .setSession("AlfyD+ Scan")
            .addAddress("10.77.0.1", 32)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)
            .setMtu(8192)
            .setBlocking(true)
        try { b.addDisallowedApplication(packageName) } catch (ignored: Exception) { }
        val pfd = try { b.establish() } catch (e: Exception) { null } ?: return false
        tun = pfd
        loop = scope.launch { dnsLoop(pfd) }
        return true
    }

    private fun dnsLoop(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                if (n < 28) continue
                handlePacket(buf.copyOf(n), output)
            }
        } catch (ignored: Exception) { }
    }

    private fun handlePacket(pkt: ByteArray, output: FileOutputStream) {
        if ((pkt[0].toInt() shr 4) != 4) return
        val ihl = (pkt[0].toInt() and 0x0F) * 4
        if (pkt[9].toInt() != 17 || pkt.size < ihl + 8) return
        if (u16(pkt, ihl + 2) != 53) return
        val udpLen = u16(pkt, ihl + 4)
        val off = ihl + 8
        val plen = udpLen - 8
        if (plen <= 12 || off + plen > pkt.size) return
        val query = pkt.copyOfRange(off, off + plen)
        val srcIp = pkt.copyOfRange(12, 16)
        val dstIp = pkt.copyOfRange(16, 20)
        val srcPort = u16(pkt, ihl)
        scope.launch {
            parseQName(query)?.let { HostWatcher.onHost(it) }
            val resp = forwardDns(query) ?: return@launch
            val reply = buildReply(resp, dstIp, srcIp, srcPort)
            synchronized(outLock) { try { output.write(reply) } catch (ignored: Exception) { } }
        }
    }

    private fun forwardDns(q: ByteArray): ByteArray? = try {
        DatagramSocket().use { s ->
            protect(s)
            s.soTimeout = 4000
            s.send(DatagramPacket(q, q.size, InetAddress.getByName(UPSTREAM_DNS), 53))
            val buf = ByteArray(4096)
            val r = DatagramPacket(buf, buf.size)
            s.receive(r)
            buf.copyOf(r.length)
        }
    } catch (e: Exception) { null }

    private fun parseQName(q: ByteArray): String? {
        var i = 12
        val sb = StringBuilder()
        while (i < q.size) {
            val len = q[i].toInt() and 0xFF
            if (len == 0) break
            if (len > 63 || i + 1 + len > q.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(q, i + 1, len, Charsets.US_ASCII))
            i += len + 1
        }
        return sb.toString().ifEmpty { null }
    }

    private fun buildReply(resp: ByteArray, fakeDns: ByteArray, client: ByteArray, clientPort: Int): ByteArray {
        val total = 28 + resp.size
        val p = ByteArray(total)
        p[0] = 0x45
        put16(p, 2, total)
        put16(p, 6, 0x4000)
        p[8] = 64
        p[9] = 17
        System.arraycopy(fakeDns, 0, p, 12, 4)
        System.arraycopy(client, 0, p, 16, 4)
        put16(p, 10, checksum(p, 0, 20))
        put16(p, 20, 53)
        put16(p, 22, clientPort)
        put16(p, 24, 8 + resp.size)
        put16(p, 26, 0)
        System.arraycopy(resp, 0, p, 28, resp.size)
        return p
    }

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
    private fun put16(b: ByteArray, o: Int, v: Int) { b[o] = (v shr 8).toByte(); b[o + 1] = v.toByte() }
    private fun checksum(b: ByteArray, off: Int, len: Int): Int {
        var sum = 0L
        var i = off
        while (i < off + len - 1) { sum += u16(b, i); i += 2 }
        if (len % 2 == 1) sum += (b[off + len - 1].toInt() and 0xFF) shl 8
        while ((sum shr 16) != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    private fun shutdown() {
        state.value = false
        mode.value = Mode.NONE
        loop?.cancel()
        try { tun?.close() } catch (ignored: Exception) { }
        tun = null
        sniffer?.stop()
        sniffer = null
        ForegroundWatcher.stop()
        CaptureHub.setThrottled(false)
        screenReceiver?.let { try { unregisterReceiver(it) } catch (ignored: Exception) { } }
        screenReceiver = null
    }

    override fun onRevoke() { shutdown(); stopSelf() }

    override fun onDestroy() {
        shutdown()
        scope.cancel()
        super.onDestroy()
    }
}
