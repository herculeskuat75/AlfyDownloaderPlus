package com.alfy.downloader.part3.scan

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.alfy.downloader.AppConfig
import com.alfy.downloader.permissions.RootChecker

enum class SniffPref { AUTO, ROOT, MANUAL }
enum class SniffMode { ROOT, MANUAL }

/** Dual-mode switch: root = real-time background sniffing, manual = paste / share / screen scan. */
object SniffSettings {
    private const val K_MODE = "sniff_mode"
    private const val K_AUTOSTART = "sniff_autostart"
    private const val K_LOCAL_VPN = "local_vpn_dns"

    private fun p(ctx: Context) = ctx.getSharedPreferences(AppConfig.PREFS, Context.MODE_PRIVATE)

    fun pref(ctx: Context): SniffPref =
        runCatching { SniffPref.valueOf(p(ctx).getString(K_MODE, SniffPref.AUTO.name)!!) }.getOrDefault(SniffPref.AUTO)

    fun setPref(ctx: Context, v: SniffPref) { p(ctx).edit().putString(K_MODE, v.name).apply() }

    fun autoStart(ctx: Context) = p(ctx).getBoolean(K_AUTOSTART, true)
    fun setAutoStart(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean(K_AUTOSTART, v).apply() }

    /** Opt-in (non-root only): local DNS VPN. Off by default because it occupies the single VPN slot. */
    fun localVpn(ctx: Context) = p(ctx).getBoolean(K_LOCAL_VPN, false)
    fun setLocalVpn(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean(K_LOCAL_VPN, v).apply() }

    fun effective(ctx: Context): SniffMode = when (pref(ctx)) {
        SniffPref.MANUAL -> SniffMode.MANUAL
        SniffPref.ROOT -> SniffMode.ROOT
        SniffPref.AUTO -> if (RootChecker.isGranted) SniffMode.ROOT else SniffMode.MANUAL
    }

    /** Starts background sniffing at app launch when root mode is effective. */
    fun autoStartIfNeeded(ctx: Context) {
        if (!autoStart(ctx) || effective(ctx) != SniffMode.ROOT) return
        if (!AutoScanService.state.value) AutoScanService.start(ctx)
    }
}

/** Finds installed VPN / tunnel apps (HTTP Custom, Dark Tunnel, ...) so root rules never touch their sockets. */
object VpnApps {
    @Suppress("DEPRECATION")
    fun uids(ctx: Context): List<Int> = try {
        val pm = ctx.packageManager
        pm.queryIntentServices(Intent("android.net.VpnService"), 0)
            .mapNotNull { it.serviceInfo?.applicationInfo }
            .filter { it.packageName != ctx.packageName }
            .map { it.uid }
            .distinct()
    } catch (e: Exception) { emptyList() }
}
