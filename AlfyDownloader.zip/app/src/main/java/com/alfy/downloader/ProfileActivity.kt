package com.alfy.downloader

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.widget.*

/** Kelola Profil Tools: buat/ubah/hapus profil (NamaProfil -> tool yang aktif). "Default" selalu ada & tidak bisa dihapus. */
class ProfileActivity : Activity() {
    private lateinit var root: LinearLayout
    private var editing: String? = null   // null = profil baru
    private var formOpen = true
    private var nameEt: EditText? = null
    private val picked = HashSet<String>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sc = ScrollView(this).apply { setBackgroundColor(0xFF202020.toInt()) }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(20), dp(16), dp(20)) }
        sc.addView(root)
        setContentView(sc)
        picked.addAll(Tool.all.filter { Tool.manualOn(it) })
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(t: String, sp: Float, c: Int = Color.WHITE, bold: Boolean = false, click: (() -> Unit)? = null) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c)
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        if (click != null) { setPadding(dp(8), dp(10), dp(8), dp(10)); setOnClickListener { click() } }
    }

    private fun render() {
        root.removeAllViews()
        root.addView(tv("⚙ Kelola Profil Tools", 18f, bold = true))
        root.addView(tv("Profil khusus: hanya tool yang dicentang di profil itu yang berjalan saat scan.", 12f, 0xFFBDBDBD.toInt()).apply { setPadding(0, dp(4), 0, dp(10)) })
        val act = AppPreferences.activeProfile
        for (nm in AppPreferences.profileNames()) {
            val isDef = nm == AppPreferences.DEFAULT_PROFILE
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
            row.addView(tv((if (nm == act) "● " else "○ ") + nm + (if (isDef) "  (tetap ada)" else ""), 15f) {
                AppPreferences.activeProfile = nm; Tool.syncAll(); Chain.resetQueue(); render()
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            if (!isDef) {
                row.addView(tv("Ubah", 13f, 0xFF80CBC4.toInt(), true) { openForm(nm) })
                row.addView(tv("Hapus", 13f, 0xFFEF9A9A.toInt(), true) {
                    AppPreferences.deleteProfile(nm); if (editing == nm) { editing = null; picked.clear(); picked.addAll(Tool.all.filter { Tool.manualOn(it) }) }; render()
                })
            }
            root.addView(row)
        }
        root.addView(tv("+ Profil baru", 14f, 0xFF80CBC4.toInt(), true) { openForm(null) })
        // Status tool profil aktif: jelas mana yang AKTIF (jalan saat scan) dan mana NONAKTIF (dilewati)
        val allT = Tool.all
        val onN = allT.count { Tool.on(it) }
        root.addView(tv("Profil aktif: $act — $onN dari ${allT.size} tool aktif", 13f, 0xFFFFE082.toInt(), true).apply { setPadding(0, dp(12), 0, dp(4)) })
        allT.forEachIndexed { i, n ->
            val on = Tool.on(n)
            root.addView(tv((if (on) "● AKTIF   " else "○ NONAKTIF   ") + "${i + 1}. $n ${ToolStatus.category(n)}\n    " + ToolStatus.label(n), 12f,
                if (on) ToolStatus.color(ToolStatus.state(n)) else 0xFF9E9E9E.toInt()))
        }
        if (formOpen) renderForm()
        root.addView(tv("TUTUP", 13f, 0xFF80CBC4.toInt(), true) { finish() }.apply { gravity = android.view.Gravity.END })
    }

    private fun openForm(name: String?) {
        editing = name; formOpen = true
        picked.clear()
        if (name != null) picked.addAll(AppPreferences.profileTools(name) ?: emptySet())
        else picked.addAll(Tool.all.filter { Tool.manualOn(it) })
        render()
    }

    private fun renderForm() {
        root.addView(tv(if (editing == null) "Profil baru" else "Ubah profil", 15f, 0xFF80CBC4.toInt(), true).apply { setPadding(0, dp(12), 0, dp(4)) })
        nameEt = EditText(this).apply {
            hint = "Nama profil (mis. Profil YouTube)"; setText(editing ?: ""); setTextColor(Color.WHITE); setHintTextColor(0xFF9E9E9E.toInt())
            setSingleLine(true)
        }
        val nameRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        nameRow.addView(nameEt, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        nameRow.addView(Button(this).apply { text = "Simpan"; setOnClickListener { save() } })
        root.addView(nameRow)
        root.addView(tv("Centang tool yang aktif di profil ini:", 12f, 0xFFBDBDBD.toInt()).apply { setPadding(0, dp(6), 0, dp(2)) })
        Tool.all.forEachIndexed { i, n ->
            root.addView(CheckBox(this).apply {
                text = "${i + 1}. $n ${ToolStatus.category(n)}"; textSize = 13f; setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
                isChecked = n in picked
                setOnCheckedChangeListener { _, v -> if (v) picked.add(n) else picked.remove(n) }
            })
        }
    }

    private fun save() {
        val nm = nameEt?.text?.toString()?.trim().orEmpty()
        if (nm.isEmpty()) { Toast.makeText(this, "Nama profil kosong", Toast.LENGTH_SHORT).show(); return }
        if (nm.equals(AppPreferences.DEFAULT_PROFILE, true)) { Toast.makeText(this, "Nama \"Default\" dipakai & tidak bisa diubah", Toast.LENGTH_SHORT).show(); return }
        val clash = AppPreferences.customProfiles().keys.any { it.equals(nm, true) && it != editing }
        if (clash) { Toast.makeText(this, "Nama sudah dipakai", Toast.LENGTH_SHORT).show(); return }
        val old = editing
        if (old != null && old != nm) AppPreferences.renameProfile(old, nm, Tool.all.filter { it in picked })
        else AppPreferences.saveProfile(nm, Tool.all.filter { it in picked })
        editing = null; picked.clear(); picked.addAll(Tool.all.filter { Tool.manualOn(it) })
        formOpen = false
        Toast.makeText(this, "Profil disimpan", Toast.LENGTH_SHORT).show()
        render()
    }
}
