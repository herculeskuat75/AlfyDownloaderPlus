package com.alfy.downloader

import android.content.Context
import android.graphics.*
import android.view.Choreographer
import android.view.View

/** Cincin warna-warni berputar di sisi tombol mengambang + percikan api (makin cepat = makin banyak & panjang). */
class RingView(ctx: Context, private val inner: Int) : View(ctx) {
    private class P(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val max: Float, val color: Int)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private var shader: SweepGradient? = null
    private val m = Matrix()
    private var angle = 0f
    private val ps = ArrayList<P>()
    private val rnd = java.util.Random()
    private val dens = ctx.resources.displayMetrics.density
    private var last = 0L
    private var acc = 0f
    private var looping = false
    var speed = 0.5f
        set(v) { field = v; refresh() }

    private fun rps(): Float = if (speed <= 0.01f) 0f else 0.25f + 19.75f * speed * speed

    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            step(t)
            if (running()) Choreographer.getInstance().postFrameCallback(this) else looping = false
        }
    }
    private fun running() = isAttachedToWindow && visibility == VISIBLE && (speed > 0.01f || ps.isNotEmpty())

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        ring.strokeWidth = inner * 0.09f
        shader = SweepGradient(w / 2f, h / 2f, intArrayOf(0xFFFF1744.toInt(), 0xFFFFEA00.toInt(), 0xFF00E676.toInt(), 0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFFD500F9.toInt(), 0xFFFF1744.toInt()), null)
        ring.shader = shader
        sp.strokeWidth = 2f * dens
    }

    private fun spawn() {
        if (ps.size > 400) return
        val th = rnd.nextFloat() * 6.2831855f
        val c = Math.cos(th.toDouble()).toFloat(); val s = Math.sin(th.toDouble()).toFloat()
        val r = inner / 2f
        val v = (120f + 520f * speed) * dens * (0.6f + 0.8f * rnd.nextFloat())
        val j = (rnd.nextFloat() - 0.5f) * 0.4f * v
        val life = 0.25f + 0.35f * rnd.nextFloat()
        val hue = ((th * 57.29578f) + angle) % 360f
        ps.add(P(width / 2f + c * r, height / 2f + s * r, -s * v + c * v * 0.35f + j, c * v + s * v * 0.35f + j, life, life, Color.HSVToColor(floatArrayOf(hue, 0.85f, 1f))))
    }

    private fun step(t: Long) {
        val dt = if (last == 0L) 0.016f else ((t - last) / 1e9f).coerceIn(0.001f, 0.05f)
        last = t
        angle = (angle + rps() * 360f * dt) % 360f
        if (speed > 0.01f) {
            acc += dt * speed * 180f
            while (acc >= 1f) { spawn(); acc -= 1f }
        }
        val it = ps.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 220f * dens * dt; p.life -= dt
            if (p.life <= 0f) it.remove()
        }
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        m.setRotate(angle, w / 2f, h / 2f); shader?.setLocalMatrix(m)
        c.drawCircle(w / 2f, h / 2f, inner / 2f - ring.strokeWidth / 2f, ring)
        val tail = 0.05f * (1f + speed * 1.5f)
        for (p in ps) {
            sp.color = p.color; sp.alpha = (255 * (p.life / p.max)).toInt().coerceIn(0, 255)
            c.drawLine(p.x, p.y, p.x - p.vx * tail, p.y - p.vy * tail, sp)
        }
    }

    fun refresh() {
        if (!looping && running()) { looping = true; last = 0L; Choreographer.getInstance().postFrameCallback(cb) }
        invalidate()
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); refresh() }
    override fun onDetachedFromWindow() { Choreographer.getInstance().removeFrameCallback(cb); looping = false; super.onDetachedFromWindow() }
    override fun onVisibilityChanged(v: View, vis: Int) { super.onVisibilityChanged(v, vis); refresh() }
}
