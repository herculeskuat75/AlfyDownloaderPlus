package com.alfy.downloader

import android.content.Context
import android.graphics.*
import android.view.Choreographer
import android.view.View

/** Cincin warna-warni berputar di sisi tombol mengambang + percikan api (makin cepat = makin banyak & panjang). */
class RingView(ctx: Context, inner0: Int) : View(ctx) {
    var inner = inner0
        set(v) { field = v; if (width > 0) onSizeChanged(width, height, width, height); invalidate() }
    private class F(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val max: Float, val r: Float, val col: Int, val swirl: Boolean)
    private val fl = ArrayList<F>()
    private val fp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private var acc2 = 0f
    private var clock = 0f
    var flame = true
        set(v) { field = v; refresh() }
    var flameSize = 1f
    var flameColor = 0xFF1E88FF.toInt()
    var rainbow = false
    var swirl = false
    private class P(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val max: Float, val burst: Boolean, val big: Float)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private var shader: SweepGradient? = null
    private val m = Matrix()
    private var angle = 0f
    private val ps = ArrayList<P>()
    private val rnd = java.util.Random()
    private val dens = ctx.resources.displayMetrics.density
    private var last = 0L
    private var acc = 0f
    private var looping = false
    var speed = 0.5f
        set(v) { field = v; refresh() }

    private fun rps(): Float = if (speed <= 0.01f) 0f else 0.25f + 19.75f * speed * speed

    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            step(t)
            if (running()) Choreographer.getInstance().postFrameCallback(this) else looping = false
        }
    }
    private fun running() = isAttachedToWindow && visibility == VISIBLE && (speed > 0.01f || ps.isNotEmpty() || flame || fl.isNotEmpty())

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        ring.strokeWidth = inner * 0.09f
        shader = SweepGradient(w / 2f, h / 2f, intArrayOf(0xFFFF1744.toInt(), 0xFFFFEA00.toInt(), 0xFF00E676.toInt(), 0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFFD500F9.toInt(), 0xFFFF1744.toInt()), null)
        ring.shader = shader
        sp.strokeWidth = 2f * dens
    }

    private fun spawn() {
        if (ps.size > 500) return
        val th = rnd.nextFloat() * 6.2831855f
        val c = Math.cos(th.toDouble()).toFloat(); val s = Math.sin(th.toDouble()).toFloat()
        val r = inner / 2f
        val v = (140f + 560f * speed) * dens * (0.5f + 0.9f * rnd.nextFloat()) * (inner / (62f * dens)).coerceIn(0.6f, 3f)
        val j = (rnd.nextFloat() - 0.5f) * 0.5f * v
        val life = 0.3f + 0.45f * rnd.nextFloat()
        ps.add(P(width / 2f + c * r, height / 2f + s * r, -s * v + c * v * 0.25f + j, c * v + s * v * 0.25f + j, life, life, rnd.nextFloat() < 0.3f, 1f))
    }
    private fun burst(p: P, out: MutableList<P>) {
        for (i in 0 until 4) {
            val a = rnd.nextFloat() * 6.2831855f; val v = (60f + 140f * rnd.nextFloat()) * dens
            val l = 0.15f + 0.2f * rnd.nextFloat()
            out.add(P(p.x, p.y, p.vx * 0.3f + Math.cos(a.toDouble()).toFloat() * v, p.vy * 0.3f + Math.sin(a.toDouble()).toFloat() * v, l, l, false, 0.6f))
        }
    }

    private fun step(t: Long) {
        val dt = if (last == 0L) 0.016f else ((t - last) / 1e9f).coerceIn(0.001f, 0.05f)
        last = t
        angle = (angle + rps() * 360f * dt) % 360f
        clock += dt
        val k = inner / (62f * dens)
        val fs = flameSize
        if (flame) {
            acc2 += dt * 170f * fs
            while (acc2 >= 1f) {
                acc2 -= 1f
                if (fl.size > 900) break
                val th = rnd.nextFloat() * 6.2831855f
                val ct = Math.cos(th.toDouble()).toFloat(); val st = Math.sin(th.toDouble()).toFloat()
                val l = (0.45f + 0.5f * rnd.nextFloat()) * (0.7f + 0.3f * fs)
                val col = if (rainbow) Color.HSVToColor(floatArrayOf(((th * 57.29578f) + clock * 60f) % 360f, 0.9f, 1f)) else flameColor
                val rad = inner * (0.10f + 0.10f * rnd.nextFloat()) * fs
                if (swirl) {
                    val rr = inner / 2f * (0.04f + 1.0f * Math.sqrt(rnd.nextDouble()).toFloat())
                    fl.add(F(width / 2f + ct * rr, height / 2f + st * rr, 0f, -(30f + 80f * rnd.nextFloat()) * dens * k * fs, l, l, rad, col, true))
                } else {
                    val rr = inner / 2f * (0.35f + 0.65f * Math.sqrt(rnd.nextDouble()).toFloat())
                    fl.add(F(width / 2f + ct * rr, height / 2f + st * rr, (rnd.nextFloat() - 0.5f) * 40f * dens * k, -(70f + 150f * rnd.nextFloat()) * dens * k * fs, l, l, rad, col, false))
                }
            }
        }
        val om = Math.min(Math.max(rps(), 0.3f), 6f) * 6.2831855f * dt
        val co = Math.cos(om.toDouble()).toFloat(); val so = Math.sin(om.toDouble()).toFloat()
        val fi = fl.iterator()
        while (fi.hasNext()) {
            val f = fi.next()
            if (f.swirl) {
                val dx = f.x - width / 2f; val dy = f.y - height / 2f
                val len = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat().coerceAtLeast(1f)
                val nx = dx * co - dy * so; val ny = dx * so + dy * co
                val out = 45f * dens * k * fs * dt / len
                f.x = width / 2f + nx * (1f + out); f.y = height / 2f + ny * (1f + out) + f.vy * 0.3f * dt
            } else {
                f.x += (f.vx + Math.sin((clock * 9f + f.y * 0.05f).toDouble()).toFloat() * 25f * dens) * dt; f.y += f.vy * dt
            }
            f.life -= dt
            if (f.life <= 0f) fi.remove()
        }
        if (speed > 0.01f) {
            acc += dt * speed * 180f
            while (acc >= 1f) { spawn(); acc -= 1f }
        }
        val born = ArrayList<P>()
        val it = ps.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 520f * dens * dt; p.vx *= (1f - 0.8f * dt); p.life -= dt
            if (p.life <= 0f) { it.remove(); if (p.burst) burst(p, born) }
        }
        ps.addAll(born)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        m.setRotate(angle, w / 2f, h / 2f); shader?.setLocalMatrix(m)
        for (f in fl) {
            val a = (f.life / f.max).coerceIn(0f, 1f)
            fp.color = if (a > 0.7f) androidx.core.graphics.ColorUtils.blendARGB(f.col, Color.WHITE, 0.75f)
                else if (a > 0.45f) androidx.core.graphics.ColorUtils.blendARGB(f.col, Color.WHITE, 0.25f)
                else if (a > 0.2f) f.col else androidx.core.graphics.ColorUtils.blendARGB(f.col, Color.BLACK, 0.55f)
            fp.alpha = (a * 150f).toInt().coerceIn(0, 255)
            c.drawCircle(f.x, f.y, f.r * (0.3f + 0.7f * a), fp)
        }
        c.drawCircle(w / 2f, h / 2f, inner / 2f - ring.strokeWidth / 2f, ring)
        val tail = 0.035f * (1f + speed * 1.8f)
        for (p in ps) {
            val f = p.life / p.max
            val x2 = p.x - p.vx * tail; val y2 = p.y - p.vy * tail
            val core = if (f > 0.6f) 0xFFFFF8E1.toInt() else if (f > 0.3f) 0xFFFFC107.toInt() else 0xFFFF5722.toInt()
            val al = (255 * f.coerceIn(0f, 1f)).toInt()
            sp.strokeWidth = 3.2f * dens * p.big; sp.color = 0xFFFF6D00.toInt(); sp.alpha = al / 3
            c.drawLine(p.x, p.y, x2, y2, sp)
            sp.strokeWidth = 1.3f * dens * p.big; sp.color = core; sp.alpha = al
            c.drawLine(p.x, p.y, x2, y2, sp)
        }
    }

    fun refresh() {
        if (!looping && running()) { looping = true; last = 0L; Choreographer.getInstance().postFrameCallback(cb) }
        invalidate()
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); refresh() }
    override fun onDetachedFromWindow() { Choreographer.getInstance().removeFrameCallback(cb); looping = false; super.onDetachedFromWindow() }
    override fun onVisibilityChanged(v: View, vis: Int) { super.onVisibilityChanged(v, vis); refresh() }
}
