package com.alfy.downloader

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator

/** Cincin warna-warni di sisi tombol mengambang; berputar seperti roda bila spin = true. */
class RingView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private var shader: SweepGradient? = null
    private val m = Matrix()
    private var angle = 0f
    private var anim: ValueAnimator? = null
    var speed = 0.5f
        set(v) { field = v; refresh() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        paint.strokeWidth = w * 0.09f
        shader = SweepGradient(w / 2f, h / 2f, intArrayOf(0xFFFF1744.toInt(), 0xFFFFEA00.toInt(), 0xFF00E676.toInt(), 0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFFD500F9.toInt(), 0xFFFF1744.toInt()), null)
        paint.shader = shader
    }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        m.setRotate(angle, w / 2f, h / 2f); shader?.setLocalMatrix(m)
        c.drawCircle(w / 2f, h / 2f, w / 2f - paint.strokeWidth / 2f, paint)
    }
    fun refresh() {
        anim?.cancel(); anim = null
        if (speed > 0.01f && isAttachedToWindow && visibility == VISIBLE) {
            anim = ValueAnimator.ofFloat(0f, 360f).apply {
                duration = (4000 - 3600 * speed).toLong().coerceAtLeast(400); repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
                addUpdateListener { angle = it.animatedValue as Float; invalidate() }
                start()
            }
        } else invalidate()
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); refresh() }
    override fun onDetachedFromWindow() { anim?.cancel(); anim = null; super.onDetachedFromWindow() }
    override fun onVisibilityChanged(v: View, vis: Int) { super.onVisibilityChanged(v, vis); refresh() }
}
