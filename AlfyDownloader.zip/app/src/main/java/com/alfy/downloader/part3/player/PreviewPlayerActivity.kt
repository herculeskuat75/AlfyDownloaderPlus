package com.alfy.downloader.part3.player

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.alfy.downloader.part3.core.Http

/**
 * Mini preview player (Media3 / ExoPlayer).
 *  - User-Agent + Referer (+ Origin) are injected into every HTTP/HLS request to avoid 403.
 *  - YouTube-style controls: play/pause, seek bar, buffering indicator, speed/track menu (built-in settings),
 *    plus mute toggle, Video / Audio-only toggle and a "more" menu (speed, loop, copy URL).
 */
@UnstableApi
class PreviewPlayerActivity : ComponentActivity() {
    companion object {
        private const val E_URL = "url"
        private const val E_REF = "ref"
        private const val E_UA = "ua"
        private const val E_TITLE = "title"
        private const val E_AUDIO = "audio"

        fun intent(
            ctx: Context, url: String, referer: String?, ua: String, title: String?, audioOnly: Boolean = false
        ): Intent =
            Intent(ctx, PreviewPlayerActivity::class.java)
                .putExtra(E_URL, url).putExtra(E_REF, referer).putExtra(E_UA, ua)
                .putExtra(E_TITLE, title).putExtra(E_AUDIO, audioOnly)
    }

    private var player: ExoPlayer? = null
    private var audioOnly = false
    private var muted = false
    private var loop = false
    private var srcUrl = ""
    private lateinit var audioBadge: TextView
    private lateinit var modeBtn: TextView
    private lateinit var muteBtn: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun topButton(label: String, onClick: (View) -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8))
        setBackgroundColor(0x66000000)
        setOnClickListener { onClick(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra(E_URL)
        if (url.isNullOrBlank()) { finish(); return }
        srcUrl = url
        val referer = intent.getStringExtra(E_REF)
        val ua = intent.getStringExtra(E_UA) ?: Http.UA
        val title = intent.getStringExtra(E_TITLE)
        audioOnly = intent.getBooleanExtra(E_AUDIO, false)

        val w = resources.displayMetrics.widthPixels
        val h = (w * 9f / 16f).toInt()

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutParams = ViewGroup.LayoutParams(w, h)
        }
        val pv = PlayerView(this).apply {
            useController = true
            controllerShowTimeoutMs = 3000
            setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
        }
        root.addView(pv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        audioBadge = TextView(this).apply {
            text = "🎧"; textSize = 48f; gravity = Gravity.CENTER
            visibility = if (audioOnly) View.VISIBLE else View.GONE
        }
        root.addView(audioBadge, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        if (!title.isNullOrBlank()) {
            val tv = TextView(this).apply {
                text = title; textSize = 12f; maxLines = 1; setTextColor(Color.WHITE)
                setPadding(dp(10), dp(8), dp(10), dp(8))
                setBackgroundColor(0x66000000)
            }
            root.addView(tv, FrameLayout.LayoutParams(dp(140), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        }

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modeBtn = topButton(if (audioOnly) "🎧" else "🎬") { toggleMode() }
        muteBtn = topButton("🔊") { toggleMute() }
        bar.addView(modeBtn)
        bar.addView(muteBtn)
        bar.addView(topButton("⋮") { showMenu(it) })
        bar.addView(topButton("✕") { finish() })
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END))

        val err = TextView(this).apply {
            textSize = 13f; setTextColor(Color.WHITE); setBackgroundColor(0xCCB00020.toInt())
            setPadding(dp(10), dp(6), dp(10), dp(6))
            visibility = View.GONE
        }
        root.addView(err, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        setContentView(root)
        window.setLayout(w, h)
        window.setGravity(Gravity.BOTTOM)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))

        val props = HashMap<String, String>()
        if (!referer.isNullOrBlank()) {
            props["Referer"] = referer
            Http.originOf(referer)?.let { props["Origin"] = it }
        }
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setDefaultRequestProperties(props)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
        val dataSource = DefaultDataSource.Factory(this, http)

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSource))
            .build()
        player = p
        pv.player = p

        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val code = (error.cause as? HttpDataSource.InvalidResponseCodeException)?.responseCode
                err.text = if (code != null) "Gagal memutar: HTTP $code" else "Gagal memutar: ${error.errorCodeName}"
                err.visibility = View.VISIBLE
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) err.visibility = View.GONE
            }
        })

        val item = MediaItem.Builder().setUri(url).apply {
            if (url.contains(".m3u8", true)) setMimeType(MimeTypes.APPLICATION_M3U8)
        }.build()
        p.setMediaItem(item)
        applyMode()
        p.prepare()
        p.playWhenReady = true
    }

    private fun applyMode() {
        val p = player ?: return
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, audioOnly)
            .build()
        audioBadge.visibility = if (audioOnly) View.VISIBLE else View.GONE
        modeBtn.text = if (audioOnly) "🎧" else "🎬"
    }

    private fun toggleMode() {
        audioOnly = !audioOnly
        applyMode()
    }

    private fun toggleMute() {
        muted = !muted
        player?.volume = if (muted) 0f else 1f
        muteBtn.text = if (muted) "🔇" else "🔊"
    }

    private fun showMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        speeds.forEachIndexed { i, s -> m.menu.add(0, i, i, "Kecepatan ${s}x") }
        m.menu.add(0, 100, 100, if (loop) "Ulang: nyala" else "Ulang: mati")
        m.menu.add(0, 101, 101, "Salin URL")
        m.setOnMenuItemClickListener { item ->
            when {
                item.itemId in speeds.indices -> player?.setPlaybackSpeed(speeds[item.itemId])
                item.itemId == 100 -> {
                    loop = !loop
                    player?.repeatMode = if (loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                }
                item.itemId == 101 -> {
                    getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("url", srcUrl))
                    Toast.makeText(this, "URL disalin", Toast.LENGTH_SHORT).show()
                }
            }
            true
        }
        m.show()
    }

    override fun onStop() {
        player?.pause()
        super.onStop()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
