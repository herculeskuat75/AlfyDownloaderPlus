package com.alfy.downloader.part3.player

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.alfy.downloader.part3.core.Http

/** Modern mini preview player. Injects User-Agent + Referer (+ Origin) into every HTTP/HLS request to avoid 403. */
@UnstableApi
class PreviewPlayerActivity : ComponentActivity() {
    companion object {
        private const val E_URL = "url"
        private const val E_REF = "ref"
        private const val E_UA = "ua"
        private const val E_TITLE = "title"

        fun intent(ctx: Context, url: String, referer: String?, ua: String, title: String?): Intent =
            Intent(ctx, PreviewPlayerActivity::class.java)
                .putExtra(E_URL, url).putExtra(E_REF, referer).putExtra(E_UA, ua).putExtra(E_TITLE, title)
    }

    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra(E_URL)
        if (url.isNullOrBlank()) { finish(); return }
        val referer = intent.getStringExtra(E_REF)
        val ua = intent.getStringExtra(E_UA) ?: Http.UA
        val title = intent.getStringExtra(E_TITLE)

        val w = resources.displayMetrics.widthPixels
        val h = (w * 9f / 16f).toInt()
        val d = resources.displayMetrics.density

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutParams = ViewGroup.LayoutParams(w, h)
        }
        val pv = PlayerView(this).apply { useController = true }
        root.addView(pv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val close = TextView(this).apply {
            text = "✕"; textSize = 20f; setTextColor(Color.WHITE)
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            setBackgroundColor(0x66000000)
            setOnClickListener { finish() }
        }
        root.addView(close, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END))

        if (!title.isNullOrBlank()) {
            val tv = TextView(this).apply {
                text = title; textSize = 12f; maxLines = 1; setTextColor(Color.WHITE)
                setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
                setBackgroundColor(0x66000000)
            }
            root.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        }

        val err = TextView(this).apply {
            textSize = 13f; setTextColor(Color.WHITE); setBackgroundColor(0xCCB00020.toInt())
            setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
            visibility = View.GONE
        }
        root.addView(err, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        setContentView(root)
        window.setLayout(w, h)
        window.setGravity(Gravity.BOTTOM)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))

        val props = HashMap<String, String>()
        if (!referer.isNullOrBlank()) {
            props["Referer"] = referer
            Http.originOf(referer)?.let { props["Origin"] = it }
        }
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setDefaultRequestProperties(props)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
        val dataSource = DefaultDataSource.Factory(this, http)

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSource))
            .build()
        player = p
        pv.player = p

        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val code = (error.cause as? HttpDataSource.InvalidResponseCodeException)?.responseCode
                err.text = if (code != null) "Gagal memutar: HTTP $code" else "Gagal memutar: ${error.errorCodeName}"
                err.visibility = View.VISIBLE
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) err.visibility = View.GONE
            }
        })

        val item = MediaItem.Builder().setUri(url).apply {
            if (url.contains(".m3u8", true)) setMimeType(MimeTypes.APPLICATION_M3U8)
        }.build()
        p.setMediaItem(item)
        p.prepare()
        p.playWhenReady = true
    }

    override fun onStop() {
        player?.pause()
        super.onStop()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
