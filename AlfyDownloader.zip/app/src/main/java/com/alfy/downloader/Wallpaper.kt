package com.alfy.downloader

import android.util.Base64
import com.alfy.downloader.extras.AlfyHttp
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Wallpaper halaman awal (New Tab): unduh gambar HD acak, simpan di cache, tampil via CSS background-image. */
object Wallpaper {
    const val BASE = "https://alfy.newtab/"
    const val NEWTAB = BASE
    /** Isi dengan Access Key Unsplash. Bila kosong/placeholder, otomatis memakai picsum.photos (tanpa kunci). */
    private const val UNSPLASH_KEY = "YOUR_ACCESS_KEY"
    @Volatile private var busy = false

    private fun dir() = Repo.app.cacheDir
    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    fun isNewTab(u: String?) = u != null && u.startsWith(BASE)
    private fun current(): File? = dir().listFiles { f -> f.name.startsWith("wallpaper_") && f.name.endsWith(".jpg") }?.maxByOrNull { it.lastModified() }

    private fun imageUrl(): String {
        if (UNSPLASH_KEY != "YOUR_ACCESS_KEY" && UNSPLASH_KEY.isNotBlank()) {
            try {
                val j = AlfyHttp.get("https://api.unsplash.com/photos/random?orientation=portrait&client_id=$UNSPLASH_KEY")
                val u = JSONObject(j ?: "").getJSONObject("urls").optString("regular")
                if (u.isNotEmpty()) return u
            } catch (e: Throwable) { }
        }
        return "https://picsum.photos/1080/1920?random=" + System.currentTimeMillis()
    }

    /** Unduh gambar baru, hapus gambar lama, perbarui tanggal. cb dipanggil di thread latar. */
    fun refresh(cb: (Boolean) -> Unit = {}) {
        if (busy) return
        busy = true
        Thread {
            var ok = false
            try {
                val tmp = File(dir(), "wallpaper_tmp.part")
                AlfyHttp.client.newCall(Request.Builder().url(imageUrl()).build()).execute().use { r ->
                    if (r.isSuccessful) r.body?.byteStream()?.use { ins -> tmp.outputStream().use { ins.copyTo(it) } }
                }
                if (tmp.length() > 1024) {
                    val old = dir().listFiles { f -> f.name.startsWith("wallpaper_") && f.name.endsWith(".jpg") }
                    val nf = File(dir(), "wallpaper_${System.currentTimeMillis()}.jpg")
                    if (tmp.renameTo(nf)) { old?.forEach { it.delete() }; AppPreferences.wallpaperLastDate = today(); ok = true }
                } else tmp.delete()
            } catch (e: Throwable) { }
            busy = false
            cb(ok)
        }.start()
    }

    /** URL JSON katalog tema: [{"id","name","preview","url"}] atau {"themes":[...]}. Kosong/gagal -> daftar bawaan. */
    const val CATALOG_URL = "https://raw.githubusercontent.com/herculeskuat75/AlfyDownloader/main/themes.json"
    data class ThemeItem(val id: String, val name: String, val preview: String, val url: String)

    fun catalog(): List<ThemeItem> {
        try {
            val t = AlfyHttp.get(CATALOG_URL)?.trim() ?: ""
            if (t.isNotEmpty()) {
                val arr = if (t.startsWith("[")) org.json.JSONArray(t) else JSONObject(t).optJSONArray("themes")
                val out = ArrayList<ThemeItem>()
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val u = o.optString("url"); if (u.isEmpty()) continue
                    val pv = o.optString("preview").ifEmpty { u }
                    out.add(ThemeItem(o.optString("id").ifEmpty { u }, o.optString("name").ifEmpty { "Tema ${i + 1}" }, pv, u))
                }
                if (out.isNotEmpty()) return out
            }
        } catch (e: Throwable) { }
        return (1..12).map { ThemeItem("pic$it", "Tema $it", "https://picsum.photos/seed/alfy$it/400/600", "https://picsum.photos/seed/alfy$it/1080/1920") }
    }

    private fun installedSet(): MutableSet<String> = HashSet(Repo.prefs().getStringSet("themeInstalledIds", emptySet()) ?: emptySet())
    fun isInstalled(id: String) = Repo.prefs().getString("themeCurrentId", "") == id
    private fun saveFrom(tmp: File, id: String): Boolean {
        if (tmp.length() <= 1024) { tmp.delete(); return false }
        val old = dir().listFiles { f -> f.name.startsWith("wallpaper_") && f.name.endsWith(".jpg") }
        val nf = File(dir(), "wallpaper_${System.currentTimeMillis()}.jpg")
        if (!tmp.renameTo(nf)) return false
        old?.forEach { it.delete() }
        Repo.prefs().edit().putString("themeCurrentId", id).apply()
        AppPreferences.wallpaperLastDate = today()
        return true
    }
    /** Pasang tema dari URL (thread latar); cb(ok) di thread latar. */
    fun applyUrl(id: String, url: String, cb: (Boolean) -> Unit) {
        Thread {
            var ok = false
            try {
                val tmp = File(dir(), "wallpaper_tmp2.part")
                AlfyHttp.client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    if (r.isSuccessful) r.body?.byteStream()?.use { ins -> tmp.outputStream().use { ins.copyTo(it) } }
                }
                ok = saveFrom(tmp, id)
            } catch (e: Throwable) { }
            cb(ok)
        }.start()
    }
    /** Pasang tema dari file HP (Uri). */
    fun applyUri(uri: android.net.Uri, cb: (Boolean) -> Unit) {
        Thread {
            var ok = false
            try {
                val tmp = File(dir(), "wallpaper_tmp3.part")
                Repo.app.contentResolver.openInputStream(uri)?.use { ins -> tmp.outputStream().use { ins.copyTo(it) } }
                ok = saveFrom(tmp, "file:$uri")
            } catch (e: Throwable) { }
            cb(ok)
        }.start()
    }

    fun needsDaily() = AppPreferences.wallpaperAuto && AppPreferences.wallpaperLastDate != today()

    fun html(): String {
        val f = current()
        val bg = if (f != null) try {
            "url(data:image/jpeg;base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP) + ")"
        } catch (e: Throwable) { "none" } else "none"
        return "<!DOCTYPE html><html><head><meta name=viewport content='width=device-width,initial-scale=1'><title>Tab baru</title><style>" +
            "html,body{height:100%;margin:0}body{background:#1b2a41 $bg center/cover no-repeat fixed;display:flex;align-items:center;justify-content:center}" +
            "form{width:86%;max-width:480px}input{width:100%;box-sizing:border-box;padding:14px 18px;border:0;border-radius:28px;font-size:16px;background:rgba(255,255,255,.88);outline:0}" +
            "</style></head><body><form action='https://www.google.com/search'><input name=q placeholder='Cari di Google' autocomplete=off></form></body></html>"
    }

    /** Muat ulang semua tab New Tab (panggil di main thread). */
    fun reloadTabs() {
        for (t in BrowserTabs.tabs) try {
            if (isNewTab(t.url) || isNewTab(t.wv.url)) t.wv.loadDataWithBaseURL(BASE, html(), "text/html", "utf-8", null)
        } catch (e: Throwable) { }
    }

    fun load(w: android.webkit.WebView) {
        if (current() == null) refresh { android.os.Handler(android.os.Looper.getMainLooper()).post { reloadTabs() } }
        w.loadDataWithBaseURL(BASE, html(), "text/html", "utf-8", null)
    }
}
