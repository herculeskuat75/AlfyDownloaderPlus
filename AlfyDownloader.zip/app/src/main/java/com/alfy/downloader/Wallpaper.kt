package com.alfy.downloader

import android.util.Base64
import com.alfy.downloader.extras.AlfyHttp
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Wallpaper halaman awal (New Tab): unduh gambar HD acak, simpan di cache, tampil via CSS background-image. */
object Wallpaper {
    const val BASE = "https://alfy.newtab/"
    const val NEWTAB = BASE
    /** Isi dengan Access Key Unsplash. Bila kosong/placeholder, otomatis memakai picsum.photos (tanpa kunci). */
    private const val UNSPLASH_KEY = "YOUR_ACCESS_KEY"
    @Volatile private var busy = false

    /** Gaya UI: "dynamic" (warna dari Palette) atau "transparent" (efek kaca). Sumber: "online" / "gallery". */
    val colorTick = androidx.compose.runtime.mutableStateOf(0)
    private const val DARK = 0xFF212121.toInt()
    fun isTransparent() = AppPreferences.themeStyle == "transparent"
    private fun pref(k: String) = Repo.prefs().getInt(k, 0)
    private fun darker(c: Int, k: Float) = android.graphics.Color.rgb(
        (android.graphics.Color.red(c) * k).toInt(), (android.graphics.Color.green(c) * k).toInt(), (android.graphics.Color.blue(c) * k).toInt())
    /** Background: DarkMuted (fallback gelap). Transparan: dasar gelap di bawah gambar. */
    fun uiColor(): Int {
        if (isTransparent()) return DARK
        val d = pref("palDarkMuted"); if (d != 0) return d
        return Repo.prefs().getInt("themeColor", DARK)
    }
    /** Drawer/surface: Muted (fallback gelap). Transparan: hitam 60%. */
    fun uiColor2(): Int {
        if (isTransparent()) return 0x99000000.toInt()
        val m = pref("palMuted"); if (m != 0) return m
        val c = uiColor(); return android.graphics.Color.rgb(
            Math.min(255, android.graphics.Color.red(c) + 18), Math.min(255, android.graphics.Color.green(c) + 18), Math.min(255, android.graphics.Color.blue(c) + 18))
    }
    /** TopAppBar / bar atas: Vibrant (fallback gelap). Transparan: hitam 60%. */
    fun barColor(): Int {
        if (isTransparent()) return 0x99000000.toInt()
        val v = pref("palVibrant"); return if (v != 0) v else uiColor2()
    }
    /** Warna teks/ikon (putih/hitam) yang kontras terhadap latar [c]. Transparan selalu putih. */
    fun onColor(c: Int): Int =
        if (isTransparent() || androidx.core.graphics.ColorUtils.calculateLuminance(c or 0xFF000000.toInt()) < 0.5) android.graphics.Color.WHITE else android.graphics.Color.BLACK
    fun imageFile(): File? { val tf = themeFile(); return if (tf != null && !tf.name.endsWith(".css")) tf else current() }
    /** Latar gambar (untuk gaya transparan) sebagai Drawable; null bila tidak ada gambar. */
    fun bgDrawable(): android.graphics.drawable.Drawable? = try {
        val f = imageFile() ?: return null
        val o = android.graphics.BitmapFactory.Options().apply { inSampleSize = 2 }
        android.graphics.BitmapFactory.decodeFile(f.absolutePath, o)?.let { android.graphics.drawable.BitmapDrawable(Repo.app.resources, it) }
    } catch (e: Throwable) { null }
    /** Warnai TextView polos (tanpa background, bukan Button) di pohon view agar kontras dengan latar. */
    fun tintTree(v: android.view.View, color: Int) {
        if (v is android.widget.TextView && v !is android.widget.Button && v.background == null) v.setTextColor(color)
        if (v is android.view.ViewGroup) for (i in 0 until v.childCount) tintTree(v.getChildAt(i), color)
    }
    fun setSource(src: String, path: String) { Repo.prefs().edit().putString("themeSource", src).putString("themeImagePath", path).apply() }
    fun setStyle(st: String) { AppPreferences.themeStyle = st; colorTick.value = colorTick.value + 1 }
    /** Ekstrak Palette dari gambar aktif; gagal -> palet dikosongkan (fallback gelap). */
    private fun saveColor(f: File) {
        var vib = 0; var mut = 0; var dm = 0
        try {
            val o = android.graphics.BitmapFactory.Options().apply { inSampleSize = 4 }
            val b = android.graphics.BitmapFactory.decodeFile(f.absolutePath, o)
            if (b != null) {
                val pal = androidx.palette.graphics.Palette.from(b).maximumColorCount(24).generate()
                vib = pal.vibrantSwatch?.rgb ?: 0; mut = pal.mutedSwatch?.rgb ?: 0; dm = pal.darkMutedSwatch?.rgb ?: 0
                b.recycle()
            }
        } catch (e: Throwable) { }
        Repo.prefs().edit().putInt("palVibrant", vib).putInt("palMuted", mut).putInt("palDarkMuted", dm)
            .putInt("themeColor", if (dm != 0) dm else DARK).apply()
        colorTick.value = colorTick.value + 1
    }

    private fun dir() = Repo.app.cacheDir
    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    fun isNewTab(u: String?) = u != null && u.startsWith(BASE)
    private fun current(): File? = dir().listFiles { f -> f.name.startsWith("wallpaper_") && f.name.endsWith(".jpg") }?.maxByOrNull { it.lastModified() }

    private fun imageUrl(): String {
        if (UNSPLASH_KEY != "YOUR_ACCESS_KEY" && UNSPLASH_KEY.isNotBlank()) {
            try {
                val j = AlfyHttp.get("https://api.unsplash.com/photos/random?orientation=portrait&client_id=$UNSPLASH_KEY")
                val u = JSONObject(j ?: "").getJSONObject("urls").optString("regular")
                if (u.isNotEmpty()) return u
            } catch (e: Throwable) { }
        }
        return "https://picsum.photos/1080/1920?random=" + System.currentTimeMillis()
    }

    /** Unduh gambar baru, hapus gambar lama, perbarui tanggal. cb dipanggil di thread latar. */
    fun refresh(cb: (Boolean) -> Unit = {}) {
        if (busy) return
        busy = true
        Thread {
            var ok = false
            try {
                val tmp = File(dir(), "wallpaper_tmp.part")
                AlfyHttp.client.newCall(Request.Builder().url(imageUrl()).build()).execute().use { r ->
                    if (r.isSuccessful) r.body?.byteStream()?.use { ins -> tmp.outputStream().use { ins.copyTo(it) } }
                }
                if (tmp.length() > 1024) {
                    val old = dir().listFiles { f -> f.name.startsWith("wallpaper_") && f.name.endsWith(".jpg") }
                    val nf = File(dir(), "wallpaper_${System.currentTimeMillis()}.jpg")
                    if (tmp.renameTo(nf)) { old?.forEach { it.delete() }; Repo.prefs().edit().remove("themeCurrentFile").apply(); AppPreferences.wallpaperLastDate = today(); setSource("online", "random"); saveColor(nf); ok = true }
                } else tmp.delete()
            } catch (e: Throwable) { }
            busy = false
            cb(ok)
        }.start()
    }

    /** URL JSON katalog tema: [{"id","nama","url_css","preview"?}] atau {"themes":[...]}. Kosong/gagal -> daftar bawaan. */
    const val CATALOG_URL = "https://raw.githubusercontent.com/herculeskuat75/AlfyDownloader/main/themes.json"
    data class ThemeItem(val id: String, val name: String, val preview: String, val url: String)

    fun catalog(): List<ThemeItem> {
        try {
            val t = AlfyHttp.get(AppPreferences.themeCatalogUrl)?.trim() ?: ""
            if (t.isNotEmpty()) {
                val arr = if (t.startsWith("[")) org.json.JSONArray(t) else JSONObject(t).optJSONArray("themes")
                val out = ArrayList<ThemeItem>()
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val u = o.optString("url_css").ifEmpty { o.optString("url") }; if (u.isEmpty()) continue
                    val pv = o.optString("preview").ifEmpty { if (u.contains(".css", true)) "" else u }
                    val nm = o.optString("nama").ifEmpty { o.optString("name") }.ifEmpty { "Tema ${i + 1}" }
                    out.add(ThemeItem(o.optString("id").ifEmpty { u }, nm, pv, u))
                }
                if (out.isNotEmpty()) return out
            }
        } catch (e: Throwable) { }
        return (1..12).map { ThemeItem("pic$it", "Tema $it", "https://picsum.photos/seed/alfy$it/400/600", "https://picsum.photos/seed/alfy$it/1080/1920") }
    }

    private fun installedSet(): MutableSet<String> = HashSet(Repo.prefs().getStringSet("themeInstalledIds", emptySet()) ?: emptySet())
    fun isInstalled(id: String) = Repo.prefs().getString("themeCurrentId", "") == id
    private fun saveFrom(tmp: File, id: String): Boolean {
        if (tmp.length() <= 1024) { tmp.delete(); return false }
        val old = dir().listFiles { f -> f.name.startsWith("wallpaper_") && f.name.endsWith(".jpg") }
        val nf = File(dir(), "wallpaper_${System.currentTimeMillis()}.jpg")
        if (!tmp.renameTo(nf)) return false
        old?.forEach { it.delete() }
        Repo.prefs().edit().putString("themeCurrentId", id).remove("themeCurrentFile").apply()
        saveColor(nf)
        AppPreferences.wallpaperLastDate = today()
        return true
    }
    private fun themesDir(): File = File(Repo.app.filesDir, "themes").apply { mkdirs() }
    private fun safeId(id: String) = id.replace(Regex("[^A-Za-z0-9_-]"), "_").take(80)
    private fun localTheme(id: String): File? = themesDir().listFiles { f -> f.name.startsWith(safeId(id) + ".") && !f.name.endsWith(".part") }?.firstOrNull()
    private fun themeFile(): File? {
        val n = Repo.prefs().getString("themeCurrentFile", "") ?: ""
        if (n.isEmpty()) return null
        return File(themesDir(), n).takeIf { it.exists() }
    }
    private fun isImage(f: File): Boolean = try {
        val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(f.absolutePath, o); o.outWidth > 0
    } catch (e: Throwable) { false }
    private fun activate(id: String, f: File) {
        if (f.name.endsWith(".css")) {
            val m = Regex("--(?:ui|alfy)-color\\s*:\\s*#([0-9a-fA-F]{6})").find(try { f.readText() } catch (e: Throwable) { "" })
            Repo.prefs().edit().putInt("palVibrant", 0).putInt("palMuted", 0).putInt("palDarkMuted", 0).apply()
            if (m != null) { Repo.prefs().edit().putInt("themeColor", (0xFF000000L or m.groupValues[1].toLong(16)).toInt()).apply() }
            colorTick.value = colorTick.value + 1
        } else saveColor(f)
        Repo.prefs().edit().putString("themeCurrentId", id).putString("themeCurrentFile", f.name).apply()
        AppPreferences.wallpaperLastDate = today()
    }
    /** Pasang tema dari URL (thread latar); file disimpan di filesDir/themes/ dan tidak diunduh ulang bila sudah ada. cb(ok) di thread latar. */
    fun applyUrl(id: String, url: String, cb: (Boolean) -> Unit) {
        Thread {
            var ok = false
            try {
                var f = localTheme(id)
                if (f == null) {
                    val tmp = File(themesDir(), safeId(id) + ".part")
                    AlfyHttp.client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                        if (r.isSuccessful) r.body?.byteStream()?.use { ins -> tmp.outputStream().use { ins.copyTo(it) } }
                    }
                    if (tmp.length() > 0) {
                        val nf = File(themesDir(), safeId(id) + if (isImage(tmp)) ".jpg" else ".css")
                        if (tmp.renameTo(nf)) f = nf
                    } else tmp.delete()
                }
                if (f != null) { activate(id, f); setSource("online", url); ok = true }
            } catch (e: Throwable) { }
            cb(ok)
        }.start()
    }
    /** Pasang gambar dari Galeri HP (Uri hasil ACTION_PICK): disalin permanen ke filesDir/themes/. */
    fun applyUri(uri: android.net.Uri, cb: (Boolean) -> Unit) {
        Thread {
            var ok = false
            try {
                val tmp = File(themesDir(), "gallery.part")
                Repo.app.contentResolver.openInputStream(uri)?.use { ins -> tmp.outputStream().use { ins.copyTo(it) } }
                if (tmp.length() > 1024 && isImage(tmp)) {
                    themesDir().listFiles { f -> f.name.startsWith("gallery_") }?.forEach { it.delete() }
                    val nf = File(themesDir(), "gallery_${System.currentTimeMillis()}.jpg")
                    if (tmp.renameTo(nf)) { activate("file:$uri", nf); setSource("gallery", uri.toString()); ok = true }
                } else tmp.delete()
            } catch (e: Throwable) { }
            cb(ok)
        }.start()
    }

    fun needsDaily() = AppPreferences.wallpaperAuto && AppPreferences.wallpaperLastDate != today()

    fun html(): String {
        val tf = themeFile()
        val css = if (tf != null && tf.name.endsWith(".css")) try { tf.readText().replace("</style", "<\\/style", true) } catch (e: Throwable) { "" } else ""
        val f = if (tf != null && !tf.name.endsWith(".css")) tf else current()
        val bg = if (f != null && css.isEmpty()) try {
            "url(data:image/jpeg;base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP) + ")"
        } catch (e: Throwable) { "none" } else "none"
        return "<!DOCTYPE html><html><head><meta name=viewport content='width=device-width,initial-scale=1'><title>Tab baru</title><style>" +
            "html,body{height:100%;margin:0}body{background:#1b2a41 $bg center/cover no-repeat fixed;display:flex;align-items:center;justify-content:center}" +
            "form{width:86%;max-width:480px}input{width:100%;box-sizing:border-box;padding:14px 18px;border:0;border-radius:28px;font-size:16px;background:rgba(255,255,255,.88);outline:0}" +
            css + "</style></head><body><form action='https://www.google.com/search'><input name=q placeholder='Cari di Google' autocomplete=off></form></body></html>"
    }

    /** Muat ulang semua tab New Tab (panggil di main thread). */
    fun reloadTabs() {
        for (t in BrowserTabs.tabs) try {
            if (isNewTab(t.url) || isNewTab(t.wv.url)) t.wv.loadDataWithBaseURL(BASE, html(), "text/html", "utf-8", null)
        } catch (e: Throwable) { }
    }

    fun load(w: android.webkit.WebView) {
        if (current() == null) refresh { android.os.Handler(android.os.Looper.getMainLooper()).post { reloadTabs() } }
        w.loadDataWithBaseURL(BASE, html(), "text/html", "utf-8", null)
    }
}
