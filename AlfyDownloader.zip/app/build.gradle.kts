plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Optional release signing (set by the GitHub workflow when KEYSTORE_BASE64 secret exists).
val keystoreFile: String? = System.getenv("KEYSTORE_FILE")
val hasReleaseKey = keystoreFile != null && file(keystoreFile).exists()

android {
    namespace = "com.alfy.downloader"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.alfy.downloader"
        minSdk = 24
        targetSdk = 34
        // Each CI run gets a higher versionCode so new builds can update older installs.
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "1.0.0"

        ndk {
            // arm64 only keeps the APK light (FFmpeg native libs are the bulk of the size).
            abiFilters += listOf("arm64-v8a")
        }
    }

    signingConfigs {
        if (hasReleaseKey) {
            create("release") {
                storeFile = file(keystoreFile!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Falls back to the auto-generated debug key so the APK is always installable.
            signingConfig = if (hasReleaseKey) signingConfigs.getByName("release")
            else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    // AndroidX & UI
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.google.android.material:material:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // AndroidX Media3 (preview player: progressive + HLS)
    val media3 = "1.4.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-ui:$media3")

    // FFmpegKit (community build; original com.arthenica artifacts were removed from Maven Central)
    implementation("com.moizhassan.ffmpeg:ffmpeg-kit-16kb:6.1.1")
    implementation("com.arthenica:smart-exception-java:0.2.1")

    // Networking
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // On-device OCR for Screen Scan (bundled Latin model, works offline)
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
