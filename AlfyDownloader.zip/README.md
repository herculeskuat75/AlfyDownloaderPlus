# AlfyDownloader+

Android downloader (Kotlin, minSdk 24, targetSdk 34, APK arm64-v8a) — gabungan Part 1 + 2 + 3.

## Struktur (package `com.alfy.downloader`)
- `permissions/`, `ui/MainActivity`, `ui/SettingsActivity` — Part 1: izin wajib (Root, Penyimpanan, Overlay, Baterai), tanda seru merah di ikon gear.
- `overlay/`, `scan/`, `data/`, `ui/DownloadAdapter` — Part 2: tombol mengambang (geser, snap ke tepi, badge), panel kaca (resize 4 sisi + 4 sudut), Screen Scan (OCR), Paste, Clear All.
- `part3/` — Part 3: `CaptureHub` (deteksi link), `DownloadEngine`/`DownloadService` (unduh, jeda/lanjut, HLS), `AutoScanService` (VPN lokal / iptables), `DownloadManagerActivity`, `PreviewPlayerActivity`, `FfmpegConverter`.

## Alur terpadu
- Paste / Screen Scan / Auto-Scan → `CaptureHub` (probe FFmpeg, filter 240p–1080p) → muncul di panel mengambang → **Unduh** / **⬇ Semua** → `DownloadService`.
- ☰ Manager membuka Download Manager (progres, jeda, lanjut, ganti nama, pratinjau, konversi, Auto-Scan 📡).
- Hasil: `Download/DownloadAlfy47/video` dan `/music`.

## Build & Release (GitHub Actions)
Push ke `main`/`master` → workflow `.github/workflows/build.yaml` membuat APK release dan mengunggahnya ke **Releases**.

Opsional (agar APK baru bisa menimpa instalasi lama): tambahkan secrets `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. Tanpa secrets, APK ditandatangani dengan debug key.

Lokal: `gradle assembleRelease` (Gradle 8.7, JDK 17, Android SDK 34).
