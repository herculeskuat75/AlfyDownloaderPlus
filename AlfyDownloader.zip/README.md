# AlfyDownloader+

Android downloader (Kotlin, minSdk 24, targetSdk 34, APK arm64-v8a) — gabungan Part 1 + 2 + 3.

## Struktur (package `com.alfy.downloader`)
- `permissions/`, `ui/MainActivity`, `ui/SettingsActivity` — Part 1: izin wajib (Root, Penyimpanan, Overlay, Baterai), tanda seru merah di ikon gear.
- `overlay/`, `scan/`, `data/`, `ui/DownloadAdapter` — Part 2: tombol mengambang (geser, snap ke tepi, badge), panel kaca (resize 4 sisi + 4 sudut), Screen Scan (OCR), Paste, Clear All.
- `part3/` — Part 3: `CaptureHub` (deteksi link), `DownloadEngine`/`DownloadService` (unduh, jeda/lanjut, HLS), `AutoScanService` (VPN lokal / iptables), `DownloadManagerActivity`, `PreviewPlayerActivity`, `FfmpegConverter`.

## Alur terpadu
- Paste / Screen Scan / Auto-Scan → `CaptureHub` (probe FFmpeg, filter 240p–1080p) → muncul di panel mengambang → **Unduh** / **⬇ Semua** → `DownloadService`.
- ☰ Manager membuka Download Manager (progres, jeda, lanjut, ganti nama, pratinjau, konversi, Auto-Scan 📡).
- Hasil: `Download/DownloadAlfy47/video` dan `/music`.

## Build & Release (GitHub Actions)
Push ke `main`/`master` → workflow `.github/workflows/build.yml` membuat APK release dan mengunggahnya ke **Releases**.

Opsional (agar APK baru bisa menimpa instalasi lama): tambahkan secrets `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. Tanpa secrets, APK ditandatangani dengan debug key.

Lokal: `gradle assembleRelease` (Gradle 8.7, JDK 17, Android SDK 34).

## Fitur lengkap
- 4 izin awal (Root, Penyimpanan, Overlay, Baterai) + tanda seru merah di gear. Accessibility Service bersifat opsional (lihat v2.1.0).
- Bubble download draggable dengan badge merah; panel kaca resizable; Screen Scan / Paste / Clear All.
- Dialog unduh gaya IDM (nama, ekstensi, ukuran/durasi, salin URL, pratinjau video/audio) dan dialog konflik file (Timpa / Ganti nama otomatis / Lewati / Batal).
- Auto-Scan hybrid: VPN lokal (DNS) + root iptables transparent proxy (HTTP URL + SNI HTTPS), dedup global (cache LRU + debounce), heuristik per aplikasi (deteksi app foreground via root), throttle baterai saat layar mati.
- Filter kualitas 240p-1080p, filter mute (ffprobe), format MP4/MKV/TS/M3U8 + M4A/MP3.
- Pratinjau Media3 dengan header User-Agent/Referer, kontrol ala YouTube, mode Video/Audio.
- Manager: tab Mengunduh/Dijeda/Selesai, kecepatan/ETA/URL, Jeda/Lanjut/Unduh ulang/Hapus, auto-cleanup, FFmpegKit remux, gabung TS/M3U8 ke MP4.

Catatan: URL video di dalam HTTPS (mis. YouTube googlevideo) tidak bisa dibaca tanpa dekripsi; DPI hanya membaca SNI untuk mendeteksi stream, link diambil lewat Paste / Screen Scan.

## v2.0.0
- Universal extraction: yt-dlp (youtubedl-android) resolves any pasted / shared / scanned link; separate video+audio streams are merged in the background by FFmpegKit.
- Dual-mode sniffing (Settings): Root (real-time, iptables + SNI, no VpnService) or Non-root (Paste / Share > AlfyD+ / Screen Scan).
- VPN-safe: root rules skip the app and every installed VPN app (HTTP Custom, Dark Tunnel, ...); IPv4-first DNS; local DNS VPN is opt-in.
- Encrypted HTTPS streams (YouTube): root mode identifies the playing media through the media session + yt-dlp; paste / screen-scan fallback is always offered.
- Floating bubble badge: green = active downloads (live), red = links ready.

## v2.1.0 — Deteksi YouTube otomatis (Accessibility Service)
- `accessibility/YouTubeAccessibilityService` (hanya baca): memantau HANYA YouTube, YouTube Music, dan bilah alamat browser populer. Tidak ada gestur, tidak membaca ketikan/key event -> tidak mengganggu keyboard.
- Alur: node UI -> ID video 11 karakter (URL/`youtu.be`/`shorts`/`live`/`embed`) -> URL standar `https://www.youtube.com/watch?v=ID` -> `CaptureHub` -> yt-dlp -> daftar mengambang (bubble berdenyut).
- Aplikasi YouTube tidak menampilkan ID di layar pemutar, jadi bila ID tidak terlihat, judul + channel dibaca dari pemutar lalu dicocokkan lewat pencarian cepat yt-dlp (`ytsearch`, hanya diterima bila kemiripan judul >= 0,6).
- Aktifkan: Pengaturan (ikon gear) > Deteksi YouTube Otomatis > Buka pengaturan Aksesibilitas. View-ID YouTube bisa berubah antar versi: nyalakan "Log debug" lalu `adb logcat -s AlfyA11y` dan sesuaikan regex di `YouTubeAccessibilityService.companion`.
