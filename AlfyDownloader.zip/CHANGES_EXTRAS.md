# CHANGES_EXTRAS — hanya alat pendukung scan link video

## File lama yang disentuh: HANYA app/build.gradle.kts (baris ditambah/versi naik)
- youtubedl-android library & ffmpeg 0.17.2 -> 0.17.4 (mesin yt-dlp)
- +6 dependency: libsu (pemantau root), okhttp + okhttp-dnsoverhttps (ambil halaman/API, DNS VPN), kotlinx-serialization-json (JSON API), jsoup (HTML), media3-exoplayer-dash (uji link .mpd)
Semua file lain identik dengan aslinya. Pembatalan: kembalikan 0.17.4 -> 0.17.2 dan hapus blok "TAMBAHAN AlfyExtras".

## File baru (belum dipanggil kode lama)
- extras/RootShell.kt  : pembungkus libsu
- extras/AlfyHttp.kt   : OkHttp + DoH
- extras/LinkExtract.kt: cari kandidat link media dari HTML/JSON

## Tambahan: pemantau pemutar di dalam halaman (androidx.webkit 1.11.0)
- Dependency baru: `androidx.webkit:webkit:1.11.0`
- File baru: extras/DocStartHook.kt (suntik skrip kecil sebelum halaman jalan; melapor URL media + currentSrc video yang sedang diputar; tidak mengubah halaman)
- SUDAH TERSAMBUNG di satu tempat: MoreTools.kt `webPro()` (1 blok 2 baris sebelum `w.loadUrl(page)`), hasil masuk antrean `q` yang sama dan lewat uji `addMediaChecked`. Tools.kt tidak disentuh.
  Pembatalan: hapus 2 baris yang diawali komentar "AlfyExtras: pemantau pemutar" di MoreTools.kt. Bila WebView tidak mendukung, `install` mengembalikan false dan jalur lama jalan seperti biasa.

## v1.49 — Batas waktu scan & saklar semua tools
- Tools.kt: `ScanLimit` + `Chain.runLimited` (scan YouTube & situs): tiap alat di thread sendiri, gagal tidak dinyatakan sebelum 5 dtk, dibatalkan paksa (thread di-interrupt, proses yt-dlp dimatikan) di 10 dtk -> status "✗ timeout 10 dtk".
- Loop tunggu WebView/AutoScan dibatasi `ScanLimit.cap` (<=9,5 dtk); timeout NewPipe 8/9 dtk; yt-dlp memakai processId agar bisa dimatikan.
- Util.kt: `Tool.setAll/allOn`; FloatingService (⚙): saklar "Aktifkan semua tools" mengikuti status tool.

## v1.41 - Blokir & Filter (satu layar)
- BARU: BlockHub.kt (BlockHubActivity): 4 bagian urut tetap: 1 Link yang di-scan (LinkBlock), 2 Blokir iklan (AdBlock + sakelar), 3 Blokir elemen (ElementBlock), 4 Blokir situs (Block). Pola sama: judul, keterangan, isian + TAMBAH, daftar dengan hapus per item, status kosong.
- Pintu masuk dialihkan: tombol di MainActivity, tombol 🚫 FloatingService, 3 menu blokir di browser (MiniActivities) + item baru "Blokir & Filter". Activity lama (BlockActivity, BrowserDataActivity) tetap ada, tidak diubah.
