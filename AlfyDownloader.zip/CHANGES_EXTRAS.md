# CHANGES_EXTRAS — hanya alat pendukung scan link video

## File lama yang disentuh: HANYA app/build.gradle.kts (baris ditambah/versi naik)
- youtubedl-android library & ffmpeg 0.17.2 -> 0.17.4 (mesin yt-dlp)
- +6 dependency: libsu (pemantau root), okhttp + okhttp-dnsoverhttps (ambil halaman/API, DNS VPN), kotlinx-serialization-json (JSON API), jsoup (HTML), media3-exoplayer-dash (uji link .mpd)
Semua file lain identik dengan aslinya. Pembatalan: kembalikan 0.17.4 -> 0.17.2 dan hapus blok "TAMBAHAN AlfyExtras".

## File baru (belum dipanggil kode lama)
- extras/RootShell.kt  : pembungkus libsu
- extras/AlfyHttp.kt   : OkHttp + DoH
- extras/LinkExtract.kt: cari kandidat link media dari HTML/JSON

## Tambahan: pemantau pemutar di dalam halaman (androidx.webkit 1.11.0)
- Dependency baru: `androidx.webkit:webkit:1.11.0`
- File baru: extras/DocStartHook.kt (suntik skrip kecil sebelum halaman jalan; melapor URL media + currentSrc video yang sedang diputar; tidak mengubah halaman)
- SUDAH TERSAMBUNG di satu tempat: MoreTools.kt `webPro()` (1 blok 2 baris sebelum `w.loadUrl(page)`), hasil masuk antrean `q` yang sama dan lewat uji `addMediaChecked`. Tools.kt tidak disentuh.
  Pembatalan: hapus 2 baris yang diawali komentar "AlfyExtras: pemantau pemutar" di MoreTools.kt. Bila WebView tidak mendukung, `install` mengembalikan false dan jalur lama jalan seperti biasa.
