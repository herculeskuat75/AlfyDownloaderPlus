# CHANGES_LONGPRESS — tekan lama tombol mengambang + ubah ukuran 2 jari

- `FloatingService.kt`: tekan lama tombol (tanpa digeser) -> popup di tengah layar berisi kotak centang "Ubah ukuran dengan 2 jari".
  Bila aktif: renggangkan 2 jari (tarik dua arah) = tombol membesar, cubit (dorong dua arah) = mengecil (skala 0.5x-3x, sama dengan slider ukuran).
- `MainActivity.kt` (dialog pengaturan): saklar yang sama + slider "Lama tekan" 1-5 detik (langkah 0.5 detik, default 1.5). Ikut RESET SEMUA.
- Pref baru: `pinchOn` (default mati), `longPressSec` (default 1.5).
BELUM dikompilasi/diuji di perangkat.
