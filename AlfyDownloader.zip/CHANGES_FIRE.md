# CHANGES_FIRE — hanya animasi api & percikan tombol mengambang

File yang disentuh:
- `Ring.kt` — mesin api & percikan ditulis ulang (cincin warna-warni tidak berubah).
- `FloatingService.kt` — meneruskan opsi percikan ke RingView, ruang gambar lebih luas bila percikan aktif, `FLAG_HARDWARE_ACCELERATED` pada jendela tombol.
- `MainActivity.kt` — hanya menambah 3 kontrol percikan di dialog pengaturan + ikut di RESET SEMUA.

Api: sprite gradien lembut 96px + blending aditif (inti putih-panas -> kuning -> oranye -> merah / sesuai warna pilihan), daya apung, turbulensi noise, angin, menyempit ke ujung, lidah api memanjang searah gerak, nyala "bernapas" + halo cahaya.
Mode "Api ikut berputar": api terlempar menyinggung arah putaran lalu melengkung tertinggal sambil naik.
Percikan (opsi sendiri): `sparkOn` (hidup/mati), `sparkAmount` 0..3 (default 1 = ±3x lebih banyak dari sebelumnya), `sparkFollow` (ikut warna api / oranye asli). Percikan terlempar (butuh cincin berputar) + bara melayang (tetap ada walau cincin diam).
Kualitas adaptif: jumlah partikel turun otomatis bila frame lambat.
BELUM dikompilasi/diuji di perangkat (lingkungan penulis tanpa Gradle/Android SDK).
