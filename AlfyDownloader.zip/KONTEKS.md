# KONTEKS PROYEK — AlfyDownloader+ (baca ini dulu di sesi baru)

## Tujuan
Aplikasi Android (Kotlin, Compose) pengunduh video/musik. Tombol mengambang yang bisa digeser, mendeteksi link video/musik otomatis di semua aplikasi di latar belakang, lalu mengunduh. APK ringan, build lewat GitHub Actions (`.github/workflows/build.yaml`), hasil masuk tab Releases.

## Pengguna
HP Android root, memakai ReVanced YouTube (app.revanced.android.youtube), sering memakai VPN (DarkTunnel, HTTP Custom). Prioritas utama: scan otomatis di belakang layar harus berhasil jadi link yang bisa diunduh. Tool berat boleh. Log per tool harus tampil di panel menu mengambang. Instruksi untuk pengguna ditulis di dalam aplikasi (tombol 📖), bukan di chat.

## Fakta penting dari uji lapangan (build v2)
- Pengguna HANYA bisa online lewat VPN (tidak ada kuota di luar VPN): fitur 'Lepas VPN' tidak berguna baginya. Semua alat harus bisa jalan di IP VPN + root.
- Hasil uji v2: semua alat gagal 'bot check' / LOGIN_REQUIRED (IP VPN ditandai YouTube). Deteksi video lewat Akses Notifikasi BERHASIL (judul + channel terbaca).
- v3: jalur yang tidak bergantung IP VPN / memakai login: yt-dlp+cookies (WebView login UA Firefox + cookies root dari Firefox/Chromium), Piped/Invidious dinamis (link diproksikan server), WebView memakai login yang sama.

## Arsitektur dua tahap
1. Deteksi video: Accessibility (AlfyAccessibilityService), media_session + logcat + clipboard (NetSniffer, root), Notifikasi MediaSession tanpa root (AlfyNotifService), menu Share.
2. Ubah video jadi link unduhan: `Chain.run()` di `Tools.kt` menjalankan 7 alat bersamaan secara bertahap:
   - ytFast (API pemutar iOS/Android VR) — `Resolver.ytFast`
   - NewPipe (NewPipeExtractor v0.26.5 via JitPack, refleksi) — `NP.fetch`
   - yt-dlp (6 klien, --force-ipv4) — `Resolver.ytdlpTool`
   - yt-dlp+cookies — `Cookies.file()` (WebView login + cookies root Firefox/Chromium), langsung jalan
   - Piped/Invidious dinamis — `Inst.fetch` (daftar server diambil otomatis, paralel)
   - HLS iOS/VR — `Resolver.youtubeFallback` (tunda 3 dtk, lewati bila sudah ada hasil)
   - WebView tersembunyi — `WebTool.grab` menangkap googlevideo/videoplayback, tunda 5 dtk
   Jeda coba ulang 60 detik per video, lalu satu kali coba ulang otomatis. Status tiap alat di `ToolLog` (tampil di panel + dialog 📖). Setiap link diberi label sumber `[alat]` (`Candidate.source`, diisi via `ToolLog.tl` ThreadLocal di `Repo.addCandidates`).
3. Lepas VPN: `VpnTool` (bind ke jaringan non-VPN tanpa root; bila root, `ip rule add uidrange`). Pengaturan di 📖.

## Yang sengaja tidak dipasang
tcpdump (HTTPS tidak terbaca), sniffer VPN lokal (bentrok dengan VPN pengguna), MITM (certificate pinning), PO token/bgutil (butuh Node), LSPosed (proyek terpisah).

## Status
- Kode baru (Tools.kt, AlfyNotifService.kt, perubahan Resolver/Models/Util/FloatingService/MainActivity/NetSniffer/AlfyApp, build.gradle.kts, proguard, manifest) BELUM dibangun/diuji: lingkungan penulis tidak punya Android SDK/Maven. Kemungkinan ada 1-2 error kompilasi di build pertama; perbaiki dari log GitHub Actions.
- Dugaan penyebab kegagalan sebelumnya: YouTube menolak "Sign in to confirm you're not a bot" karena IP VPN/seluler; versi klien iOS/VR di `Resolver` ditulis tetap dan bisa usang.
- Shorts: pencarian sekarang mengenali `shortsLockupViewModel`.

## Ide berikutnya (putaran kedua)
Perbarui versi klien iOS/Android VR, modul LSPosed untuk ReVanced, PO token via Termux, cookies Chrome (terenkripsi, sulit).

## Putaran v1.1 (versionCode 2) — perbaikan HTTP 403 pratinjau + Mini Preview Player modern
- Penyebab 403: pratinjau (`PreviewActivity`) memakai SATU User-Agent untuk semua link, diambil dari `formatSel`; link dari NewPipe/Piped/yt-dlp (formatSel kosong) jatuh ke UA Chrome, padahal link googlevideo terikat ke klien pembuatnya (parameter `c=IOS/ANDROID_VR/ANDROID/WEB`). Header Origin/Referer YouTube juga tidak dikirim untuk klien web.
- Perbaikan: `PreviewActivity.pickFactory()` memilih UA per alamat dari parameter `c=` (`Resolver.uaForGv`), lalu bila tetap 403 otomatis berputar IOS -> ANDROID_VR -> ANDROID -> Chrome (maks 4 kali), baru pindah ke sumber cadangan. `ChunkedDataSource` kini menerima `pick` agar pabrik HTTP dipilih saat link dibuka.
- UI: bilah atas (judul), kontrol kapsul, sembunyi otomatis, ketuk layar untuk tampil/sembunyi, kotak galat + tombol "Coba lagi".
- BELUM diuji di perangkat/CI (lingkungan penulis tanpa Gradle/Android SDK). Bila masih 403 pada link tertentu, kemungkinan link terikat IP/kedaluwarsa (parameter ip= dan expire= di link) -> pindai ulang videonya.

## Putaran v1.2 (versionCode 3) — log dua kolom + alat untuk semua situs + scan otomatis lebih luas
- Panel menu mengambang: log alat kini 2 kolom, huruf 9sp, panel default menempel di atas layar (`FloatingService.updateLog()`); ikon header diperkecil agar daftar unduhan tidak tertutup.
- Situs NON-YouTube (TikTok, Instagram, Facebook, X, Vimeo, dll) kini juga memakai rantai alat bersamaan: `Chain.runGeneric()` = yt-dlp, NewPipe (`NP.fetchAny`), WebView (`WebTool.grabPage`, tangkap request media), HTML (`Resolver.sniffSync`). Log memakai `ToolLog.siteNames`. Alat khusus YouTube (ytFast, Piped, HLS iOS/VR, cookies) tetap hanya untuk YouTube karena memang bergantung pada ID video YouTube.
- Aksesibilitas (semua aplikasi): alamat tanpa "https://" (mis. `tiktok.com/@x/video/1`) ikut dikenali; interval pindai layar penuh 1200 -> 800 ms; `thumbScan()` mencari video YouTube dari judul thumbnail yang hanya DILIHAT (pref `autoThumb`, default aktif, maks 8 per 10 menit, jeda 4 dtk) agar IP VPN tidak cepat ditandai bot.
- BELUM dikompilasi/diuji (tanpa Gradle/Android SDK di lingkungan penulis).
- Batasan jujur: aplikasi selain YouTube umumnya TIDAK menampilkan URL di thumbnail; deteksinya bergantung pada URL/teks di layar, clipboard, Share, notifikasi media, dan pemantau root (logcat/media_session).

## Putaran v1.3 (versionCode 4) — log bernomor, alat jwplyr/overfetch, X-API, uji link ytFast
- Pengguna melapor (uji lapangan v1.2): `jwplyr.com/d/ID` (halaman unduh dengan CAPTCHA Cloudflare/Turnstile) → log "WebView ✓ berhasil" tetapi `Tautan (0)`; ytFast cepat tetapi link tidak bisa diputar; log terlalu kecil.
- Penyebab "✓ tapi 0 link": `WebTool.grabPage` menaikkan penghitung untuk SETIAP request yang tampak media, padahal `Resolver.submit()` berjalan asinkron dan diam-diam membuang hasil (HEAD text/*, duplikat, m3u8 gagal). Kini request dimasukkan antrian lalu diperiksa sinkron lewat `Resolver.addMediaChecked()`; ✓ hanya bila link benar-benar masuk daftar.
- Halaman CAPTCHA tidak bisa diselesaikan WebView tersembunyi: alat melapor "butuh CAPTCHA", `Resolver.captchaPage` diisi, dan tombol 🌐 di panel membuka `BrowserActivity` (terlihat) di halaman itu. Di sana request media (ekstensi media, host overfetch, atau request ber-header Range/Accept video — `WebTool.looksMedia`) dan unduhan file (`setDownloadListener`) ditangkap lewat `Resolver.submitMedia`. Cookies WebView (cf_clearance dll) ikut dikirim oleh `Resolver.open()` dan `SiteTool.fetch()`.
- Alat baru `SiteTool.kt`: `JWPlayer` (jwplyr.com, *.overfetch.video: baca HTML + iframe /e/ID /v/ID, buka kemasan JS p,a,c,k,e,d, base64 atob, uji tiap kandidat) dan `X-API` (cdn.syndication.twimg.com, jauh lebih cepat dari yt-dlp). Keduanya otomatis menjadi alat nomor 1 di `Chain.runGeneric` untuk host terkait; alat umum tetap jalan.
- Host `*.overfetch.video`: URL sering tanpa ekstensi → `Resolver.isMedia()` mengenalinya; Referer bawaan `https://jwplyr.com/` (`Resolver.defaultRef`).
- ytFast: tiap link googlevideo kini diuji seperti pemutar (`Resolver.probePlay`: GET Range, UA sesuai `c=`, byte terbaca) dan hanya yang lolos yang masuk daftar; bila 0 lolos, klien berikutnya dicoba. Akar masalah "tidak bisa diputar" BELUM terkonfirmasi (tanpa log perangkat).
- Panel log: daftar bernomor 12sp berwarna (hijau ✓ / merah ✗ / kuning ⏳), status sistem 11sp di bawahnya, area log bisa digulir; `ToolLog.lines()/text()` bernomor (juga di dialog 📖).
- Aksesibilitas: bar alamat browser mana pun (id berisi url/address/omnibox) dibaca; `jwplyr.com` masuk `pageRe` sehingga dipindai otomatis.
- BELUM dikompilasi/diuji: lingkungan penulis tanpa Gradle/Android SDK/jaringan. Situs jwplyr/overfetch tidak bisa dibuka dari lingkungan penulis, jadi `SiteTool.jw` memakai pola umum JW Player/host file video dan masih berupa dugaan.
