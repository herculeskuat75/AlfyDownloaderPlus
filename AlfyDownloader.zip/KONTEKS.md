# AUDIT 28 TOOLS (v64) — hanya baca kode, TIDAK ada yang diperbaiki
Metode: baca statis Tools.kt, Resolver.kt, MoreTools.kt, SiteTool.kt, MusicMap.kt, NetSniffer.kt, AlfyNotifService.kt, HookEntry.java, build.gradle.kts. Tidak dijalankan di HP (tanpa SDK/jaringan) -> status = penilaian kode, bukan hasil uji lapangan.

## Temuan utama
1. TIDAK ADA tool "pajangan": tidak ada yang langsung `return null`/`throw`; semua punya isi nyata. (5x `return null` di Resolver.kt itu guard normal.)
2. Semua library yang dipakai ada di build.gradle.kts (yt-dlp, ffmpeg, NewPipeExtractor via JitPack, okhttp, jsoup, libsu, webkit). Kecuali: biner tcpdump (eksternal) dan modul LSPosed (eksternal).
3. PENYEBAB STATUS TIDAK JELAS (Tools.kt `chainStatus`): tool yang tidak ikut rantai saat ini tampil "⏳ memindai otomatis (siaga)" padahal TIDAK berjalan. Rantai berbeda per situs, jadi banyak tool terlihat "menunggu" selamanya:
   - YouTube hanya menjalankan: ytFast, NewPipe, yt-dlp, yt-dlp+cookies, Piped/Invidious, HLS iOS/VR, WebView (+HTML bila mode agresif).
   - X/Twitter: fxtwitter, Syndication, NewPipe, WebView, HTML, yt-dlp+cookies (perlu login X), yt-dlp (hanya mode agresif).
   - Situs lain: yt-dlp, NewPipe, WebView, HTML, Situs API, OpenGraph, Iframe, JS Deep, Manifest, Redirect, Host Pack, WebView Pro; Spotify Match HANYA host musik (spotify dll); JWPlayer HANYA host jwplyr/overfetch/vidoy/vidlyx atau mode agresif; yt-dlp+cookies HANYA instagram.
4. Versi klien YouTube ditulis tetap (iOS 20.10.4, ANDROID_VR 1.62.27/1.60.19): kemungkinan usang -> ytFast & HLS iOS/VR.

## DAFTAR [Tool] -> [Status]
### 20 tool pemindai (chainAll)
1. fxtwitter -> Berfungsi (hanya x.com status/profil; bergantung server api.fxtwitter.com/vxtwitter)
2. Syndication -> Berfungsi (hanya x.com status; endpoint publik X bisa dibatasi sewaktu-waktu)
3. yt-dlp -> Berfungsi (library ada; butuh Engine siap + jaringan)
4. yt-dlp+cookies -> Berfungsi (butuh login YouTube/X/Instagram; tanpa login melapor "belum login")
5. ytFast -> Butuh Perbaikan (versi klien IOS/ANDROID_VR tetap, kemungkinan usang; IP VPN kena bot check)
6. NewPipe -> Berfungsi (refleksi ke NewPipeExtractor v0.26.5, ada di gradle+proguard; YouTube sering diblokir bot check)
7. Piped/Invidious -> Butuh Perbaikan (bergantung server publik; banyak yang mati/diblokir, daftar statis cadangan kemungkinan usang)
8. HLS iOS/VR -> Butuh Perbaikan (klien tetap sama dengan ytFast; kemungkinan usang)
9. WebView -> Berfungsi (WebView tersembunyi; halaman CAPTCHA tidak bisa diselesaikan)
10. HTML -> Berfungsi (sniffSync regex media; hanya menemukan link yang tertulis di HTML)
11. Spotify Match -> Berfungsi (hanya host musik; cari judul di YouTube/SoundCloud lalu jalankan rantai YouTube, jadi ikut kena kendala #5-#8)
12. JWPlayer -> Berfungsi (hanya jwplyr/overfetch/vidoy/vidlyx; CAPTCHA butuh 🌐; masih dugaan pola, belum terkonfirmasi di perangkat)
13. OpenGraph -> Berfungsi (og:video/JSON-LD, 4 UA; situs tanpa og:video -> gagal wajar)
14. Situs API -> Berfungsi (Vimeo, Dailymotion, Reddit, Streamable, TikTok via tikwm, Facebook, Imgur gifv; situs lain -> "tidak punya API khusus"; TikTok bergantung layanan pihak ketiga tikwm.com)
15. JS Deep -> Berfungsi (baca maks 10 file JS)
16. Iframe -> Berfungsi (kedalaman 2)
17. Manifest -> Berfungsi (cari .m3u8/.mpd + config JSON)
18. Redirect -> Berfungsi (ikuti redirect; media langsung atau pindai halaman baru)
19. WebView Pro -> Berfungsi (hook fetch/XHR, auto-play; blacklist bkcdn.net/nereserv.com)
20. Host Pack -> Berfungsi (Rumble, OK.ru, VK, Bilibili, Instagram embed, Telegram, Streamtape, Doodstream, Mixdrop; polanya bisa berubah)

### 8 pemantau (monAll)
21. Logcat root -> Berfungsi (butuh root; libsu ada)
22. tcpdump -> Butuh Perbaikan (butuh biner tcpdump eksternal yang tidak ada di project/HP; hanya HTTP polos port 80/8080, HTTPS tidak terbaca)
23. Media session -> Berfungsi (butuh root)
24. Clipboard root -> Berfungsi (butuh root; status "tidak mendukung" bila HP menolak)
25. Notifikasi -> Berfungsi (butuh izin Akses Notifikasi)
26. Aksesibilitas -> Berfungsi (butuh layanan diaktifkan di Pengaturan)
27. ffmpeg -> Berfungsi (library ada; hanya status init, bukan pemindai link)
28. Hook pemutar -> Butuh Perbaikan (kode HookEntry nyata, tapi butuh modul LSPosed diaktifkan + app target di-restart; tanpa itu 0 link)

Ringkasan: Berfungsi 23 | Butuh Perbaikan 5 (ytFast, Piped/Invidious, HLS iOS/VR, tcpdump, Hook pemutar) | Rusak 0. Plus 1 masalah label status (#3).

---
# ATURAN TETAP (baca dulu): versionCode dinaikkan manual atas permintaan pengguna (kini 64). JANGAN ubah/hapus app/alfy-debug.keystore (kunci tanda tangan tetap; tanpa ini APK tidak bisa menimpa). Pengguna memakai Titanium Backup, login X/Instagram tidak boleh hilang. Perbaiki hanya bug yang dilaporkan; catat di KONTEKS.md.

# v63: optimasi RAM (pause WebView browser, Chain.cancelAll saat bubble ditutup, proses ffmpeg di-destroy, largeHeap).

# KONTEKS PROYEK — AlfyDownloader+ (baca ini dulu di sesi baru)

## Tujuan
Aplikasi Android (Kotlin, Compose) pengunduh video/musik. Tombol mengambang yang bisa digeser, mendeteksi link video/musik otomatis di semua aplikasi di latar belakang, lalu mengunduh. APK ringan, build lewat GitHub Actions (`.github/workflows/build.yaml`), hasil masuk tab Releases.

## Pengguna
HP Android root, memakai ReVanced YouTube (app.revanced.android.youtube), sering memakai VPN (DarkTunnel, HTTP Custom). Prioritas utama: scan otomatis di belakang layar harus berhasil jadi link yang bisa diunduh. Tool berat boleh. Log per tool harus tampil di panel menu mengambang. Instruksi untuk pengguna ditulis di dalam aplikasi (tombol 📖), bukan di chat.

## Fakta penting dari uji lapangan (build v2)
- Pengguna HANYA bisa online lewat VPN (tidak ada kuota di luar VPN): fitur 'Lepas VPN' tidak berguna baginya. Semua alat harus bisa jalan di IP VPN + root.
- Hasil uji v2: semua alat gagal 'bot check' / LOGIN_REQUIRED (IP VPN ditandai YouTube). Deteksi video lewat Akses Notifikasi BERHASIL (judul + channel terbaca).
- v3: jalur yang tidak bergantung IP VPN / memakai login: yt-dlp+cookies (WebView login UA Firefox + cookies root dari Firefox/Chromium), Piped/Invidious dinamis (link diproksikan server), WebView memakai login yang sama.

## Arsitektur dua tahap
1. Deteksi video: Accessibility (AlfyAccessibilityService), media_session + logcat + clipboard (NetSniffer, root), Notifikasi MediaSession tanpa root (AlfyNotifService), menu Share.
2. Ubah video jadi link unduhan: `Chain.run()` di `Tools.kt` menjalankan 7 alat bersamaan secara bertahap:
   - ytFast (API pemutar iOS/Android VR) — `Resolver.ytFast`
   - NewPipe (NewPipeExtractor v0.26.5 via JitPack, refleksi) — `NP.fetch`
   - yt-dlp (6 klien, --force-ipv4) — `Resolver.ytdlpTool`
   - yt-dlp+cookies — `Cookies.file()` (WebView login + cookies root Firefox/Chromium), langsung jalan
   - Piped/Invidious dinamis — `Inst.fetch` (daftar server diambil otomatis, paralel)
   - HLS iOS/VR — `Resolver.youtubeFallback` (tunda 3 dtk, lewati bila sudah ada hasil)
   - WebView tersembunyi — `WebTool.grab` menangkap googlevideo/videoplayback, tunda 5 dtk
   Jeda coba ulang 60 detik per video, lalu satu kali coba ulang otomatis. Status tiap alat di `ToolLog` (tampil di panel + dialog 📖). Setiap link diberi label sumber `[alat]` (`Candidate.source`, diisi via `ToolLog.tl` ThreadLocal di `Repo.addCandidates`).
3. Lepas VPN: `VpnTool` (bind ke jaringan non-VPN tanpa root; bila root, `ip rule add uidrange`). Pengaturan di 📖.

## Yang sengaja tidak dipasang
tcpdump (HTTPS tidak terbaca), sniffer VPN lokal (bentrok dengan VPN pengguna), MITM (certificate pinning), PO token/bgutil (butuh Node), LSPosed (proyek terpisah).

## Status
- Kode baru (Tools.kt, AlfyNotifService.kt, perubahan Resolver/Models/Util/FloatingService/MainActivity/NetSniffer/AlfyApp, build.gradle.kts, proguard, manifest) BELUM dibangun/diuji: lingkungan penulis tidak punya Android SDK/Maven. Kemungkinan ada 1-2 error kompilasi di build pertama; perbaiki dari log GitHub Actions.
- Dugaan penyebab kegagalan sebelumnya: YouTube menolak "Sign in to confirm you're not a bot" karena IP VPN/seluler; versi klien iOS/VR di `Resolver` ditulis tetap dan bisa usang.
- Shorts: pencarian sekarang mengenali `shortsLockupViewModel`.

## Ide berikutnya (putaran kedua)
Perbarui versi klien iOS/Android VR, modul LSPosed untuk ReVanced, PO token via Termux, cookies Chrome (terenkripsi, sulit).

## Putaran v1.1 (versionCode 2) — perbaikan HTTP 403 pratinjau + Mini Preview Player modern
- Penyebab 403: pratinjau (`PreviewActivity`) memakai SATU User-Agent untuk semua link, diambil dari `formatSel`; link dari NewPipe/Piped/yt-dlp (formatSel kosong) jatuh ke UA Chrome, padahal link googlevideo terikat ke klien pembuatnya (parameter `c=IOS/ANDROID_VR/ANDROID/WEB`). Header Origin/Referer YouTube juga tidak dikirim untuk klien web.
- Perbaikan: `PreviewActivity.pickFactory()` memilih UA per alamat dari parameter `c=` (`Resolver.uaForGv`), lalu bila tetap 403 otomatis berputar IOS -> ANDROID_VR -> ANDROID -> Chrome (maks 4 kali), baru pindah ke sumber cadangan. `ChunkedDataSource` kini menerima `pick` agar pabrik HTTP dipilih saat link dibuka.
- UI: bilah atas (judul), kontrol kapsul, sembunyi otomatis, ketuk layar untuk tampil/sembunyi, kotak galat + tombol "Coba lagi".
- BELUM diuji di perangkat/CI (lingkungan penulis tanpa Gradle/Android SDK). Bila masih 403 pada link tertentu, kemungkinan link terikat IP/kedaluwarsa (parameter ip= dan expire= di link) -> pindai ulang videonya.

## Putaran v1.2 (versionCode 3) — log dua kolom + alat untuk semua situs + scan otomatis lebih luas
- Panel menu mengambang: log alat kini 2 kolom, huruf 9sp, panel default menempel di atas layar (`FloatingService.updateLog()`); ikon header diperkecil agar daftar unduhan tidak tertutup.
- Situs NON-YouTube (TikTok, Instagram, Facebook, X, Vimeo, dll) kini juga memakai rantai alat bersamaan: `Chain.runGeneric()` = yt-dlp, NewPipe (`NP.fetchAny`), WebView (`WebTool.grabPage`, tangkap request media), HTML (`Resolver.sniffSync`). Log memakai `ToolLog.siteNames`. Alat khusus YouTube (ytFast, Piped, HLS iOS/VR, cookies) tetap hanya untuk YouTube karena memang bergantung pada ID video YouTube.
- Aksesibilitas (semua aplikasi): alamat tanpa "https://" (mis. `tiktok.com/@x/video/1`) ikut dikenali; interval pindai layar penuh 1200 -> 800 ms; `thumbScan()` mencari video YouTube dari judul thumbnail yang hanya DILIHAT (pref `autoThumb`, default aktif, maks 8 per 10 menit, jeda 4 dtk) agar IP VPN tidak cepat ditandai bot.
- BELUM dikompilasi/diuji (tanpa Gradle/Android SDK di lingkungan penulis).
- Batasan jujur: aplikasi selain YouTube umumnya TIDAK menampilkan URL di thumbnail; deteksinya bergantung pada URL/teks di layar, clipboard, Share, notifikasi media, dan pemantau root (logcat/media_session).

## Putaran v1.3 (versionCode 4) — log bernomor, alat jwplyr/overfetch, X-API, uji link ytFast
- Pengguna melapor (uji lapangan v1.2): `jwplyr.com/d/ID` (halaman unduh dengan CAPTCHA Cloudflare/Turnstile) → log "WebView ✓ berhasil" tetapi `Tautan (0)`; ytFast cepat tetapi link tidak bisa diputar; log terlalu kecil.
- Penyebab "✓ tapi 0 link": `WebTool.grabPage` menaikkan penghitung untuk SETIAP request yang tampak media, padahal `Resolver.submit()` berjalan asinkron dan diam-diam membuang hasil (HEAD text/*, duplikat, m3u8 gagal). Kini request dimasukkan antrian lalu diperiksa sinkron lewat `Resolver.addMediaChecked()`; ✓ hanya bila link benar-benar masuk daftar.
- Halaman CAPTCHA tidak bisa diselesaikan WebView tersembunyi: alat melapor "butuh CAPTCHA", `Resolver.captchaPage` diisi, dan tombol 🌐 di panel membuka `BrowserActivity` (terlihat) di halaman itu. Di sana request media (ekstensi media, host overfetch, atau request ber-header Range/Accept video — `WebTool.looksMedia`) dan unduhan file (`setDownloadListener`) ditangkap lewat `Resolver.submitMedia`. Cookies WebView (cf_clearance dll) ikut dikirim oleh `Resolver.open()` dan `SiteTool.fetch()`.
- Alat baru `SiteTool.kt`: `JWPlayer` (jwplyr.com, *.overfetch.video: baca HTML + iframe /e/ID /v/ID, buka kemasan JS p,a,c,k,e,d, base64 atob, uji tiap kandidat) dan `X-API` (cdn.syndication.twimg.com, jauh lebih cepat dari yt-dlp). Keduanya otomatis menjadi alat nomor 1 di `Chain.runGeneric` untuk host terkait; alat umum tetap jalan.
- Host `*.overfetch.video`: URL sering tanpa ekstensi → `Resolver.isMedia()` mengenalinya; Referer bawaan `https://jwplyr.com/` (`Resolver.defaultRef`).
- ytFast: tiap link googlevideo kini diuji seperti pemutar (`Resolver.probePlay`: GET Range, UA sesuai `c=`, byte terbaca) dan hanya yang lolos yang masuk daftar; bila 0 lolos, klien berikutnya dicoba. Akar masalah "tidak bisa diputar" BELUM terkonfirmasi (tanpa log perangkat).
- Panel log: daftar bernomor 12sp berwarna (hijau ✓ / merah ✗ / kuning ⏳), status sistem 11sp di bawahnya, area log bisa digulir; `ToolLog.lines()/text()` bernomor (juga di dialog 📖).
- Aksesibilitas: bar alamat browser mana pun (id berisi url/address/omnibox) dibaca; `jwplyr.com` masuk `pageRe` sehingga dipindai otomatis.
- BELUM dikompilasi/diuji: lingkungan penulis tanpa Gradle/Android SDK/jaringan. Situs jwplyr/overfetch tidak bisa dibuka dari lingkungan penulis, jadi `SiteTool.jw` memakai pola umum JW Player/host file video dan masih berupa dugaan.

## Putaran v1.4 (versionCode 5) — filter iklan jwplyr/vidoy, x.com via fxtwitter, ytFast diuji lebih dalam
- Laporan pengguna: jwplyr.com banyak iklan; link yang tertangkap hanya video judol (nama UUID, host lain). Video asli ada di `mp4-NN.overfetch.video` (angka berubah-ubah), situs asli `vidoy.asia`. v1.1 menampilkan link x.com/jwplyr tetapi lambat (berasal dari pemantau root logcat, `NetSniffer`, yang tidak diubah).
- Penyebab link iklan (dugaan kuat): `WebTool.grabPage` v1.3 menerima SETIAP request ber-header Range/Accept video dari host mana pun, termasuk video iklan.
- Perbaikan: `Resolver.isJwPage()/jwMediaOk()` (host milik situs: overfetch.video, vidoy.asia/com, jwplyr.com, backblazeb2.com). Di halaman jw: `WebTool.grabPage` memblokir video/skrip iklan dari host lain, menahan perpindahan halaman & popup, memuat dengan Referer vidoy.asia, menanyakan alamat video langsung ke pemutar (`jwplayer().getPlaylist()`, `<video>`, `<source>`) tiap 1,5 dtk, batas waktu 30 dtk. `SiteTool.jw` membuang kandidat non-host-situs dan memakai Referer vidoy.asia untuk halaman embed. `Resolver.addMediaChecked` mencoba Referer lain (vidoy.asia / jwplyr.com) bila host overfetch menolak (403). `BrowserActivity` ikut mengabaikan video iklan di halaman jw. `vidoy.asia` masuk `pageRe` dan `runGeneric`.
- Log alat kini memuat alasan penolakan (kode HTTP, host, tipe) dan jumlah iklan yang diabaikan: pakai ini untuk putaran berikutnya bila masih gagal.
- x.com: `SiteTool.xFx` memakai api.fxtwitter.com (cadangan api.vxtwitter.com) sebelum syndication; hasil `media.videos[].url`.
- ytFast: `Resolver.probePlay` kini menguji juga potongan Range di kedalaman ~6MB (atau tengah file); link klien iOS/Android yang butuh PO Token lolos di potongan pertama tetapi 403 setelahnya (gejala "loading lalu 403"). Urutan klien: ANDROID_VR (tanpa PO Token) lalu IOS; versi ANDROID_VR 1.60.19 -> 1.62.27. Bila semua link gagal uji, ytFast melapor ✗ (alat lain tetap jalan).
- BELUM dikompilasi/diuji di perangkat (lingkungan penulis tanpa Android SDK dan tanpa akses ke situs jwplyr/overfetch). Perilaku halaman jwplyr/vidoy masih dugaan dari pola umum JW Player.

## Putaran v1.5 (versionCode 6) — format link overfetch bertanda tangan
- Contoh link asli dari pengguna: `https://mp4-01.overfetch.video/s/<TOKEN>/<EXPIRE unix>/i/<ID>` (kadang tanpa ekstensi, kadang `.mp4`); host mp4-NN berbeda = load balancing/kualitas berbeda. Link bertanda tangan + kedaluwarsa, kemungkinan diminta lewat API setelah pemutar dibuka.
- `WebTool.grabPage` (halaman jw): pengait JS fetch/XHR (`window.__alfy`) menangkap URL overfetch dari respons API; dibaca bersama playlist JW Player tiap 1,5 dtk.
- `Resolver.addMediaChecked`: link overfetch dari pemutar diterima (trust) walau tanpa ekstensi dan uji HEAD/Range gagal, selama bukan halaman HTML.
- BELUM diuji di perangkat.

## Putaran v1.6 (versionCode 7) — kembali ke cara v1.1 untuk jwplyr/vidoy/overfetch/x.com, tombol 🌐 dihapus
- Uji lapangan v1.5: jwplyr.com/e/ID -> semua alat gagal (JWPlayer hanya menemukan gambar jpeg dan HTML; halaman berisi iklan "Confirm you're not a robot"), Tautan (0). Pemindaian aktif tidak berguna; di v1.1 link asli datang tanpa label dari pemantau root (logcat) saat video diputar di browser (mis. 1DM+).
- Perubahan: `jwplyr.com`/`vidoy` dikeluarkan dari `pageRe` dan `Resolver.ytdlp()` tidak memindai host jw (hanya diag "putar videonya di browser"). Link media asli tetap masuk lewat `NetSniffer` (host overfetch tanpa ekstensi dikenali `isMedia`, Referer bawaan). Selama `lastPage` (bar alamat browser) adalah halaman jw, media dari host lain (bukan googlevideo) diabaikan 60 dtk (filter iklan, `Resolver.submit`).
- X/Twitter: `Resolver.ytdlp()` mencoba fxtwitter dulu (`SiteTool.xApi`), lalu yt-dlp polos seperti v1.1 (bukan rantai alat).
- Tombol 🌐 dihapus dari panel mengambang (crash; `BrowserActivity` tetap ada di Manifest dan di MainActivity). Alat jw/WebView lama di `Tools.kt`/`SiteTool.kt` masih ada tetapi tidak lagi dipanggil untuk situs-situs itu.
- BELUM diuji di perangkat.

## Putaran v1.7 (versionCode 8) — panel bisa digeser dari tengah, suara ytFast, x.com serentak, AutoScan, crash Browser
- Panel mengambang: pil di TENGAH garis atas/bawah/kiri/kanan = geser panel ke mana saja (`FloatingService.handle()`, moveMode); bagian garis lain & sudut tetap ubah ukuran.
- ytFast tanpa suara: penyebab `urls.take(14)` memotong daftar sebelum format audio (audio ada di akhir adaptiveFormats). Kini hanya audio m4a (maks 3) + video H.264/muxed yang diuji (`Resolver.ytFast`). Pratinjau memberi toast bila jatuh ke video tanpa suara.
- X/Twitter: `Chain.runGeneric` jalur X = fxtwitter, Syndication, yt-dlp, WebView SERENTAK (sebelumnya berurutan, log basi). Timeout API 4,5 dtk. `SiteTool.xApi(page, part)`.
- `AutoScan` (Tools.kt): saat media apa pun mulai diputar (root: `dumpsys media_session` state=3 tiap 1 dtk; non-root: AlfyNotifService), otomatis jalankan pindai layar, pindai ulang halaman terakhir, baca clipboard, pantau logcat; log "Auto <app>" tampil di panel. Halaman jwplyr/vidoy juga memicu log ini.
- Alat cadangan dipercepat: WebView/HLS YouTube tunda 3 dtk/1,5 dtk; generic WebView 1–1,5 dtk.
- Crash menu Browser: `WebView.getUrl()` dipanggil dari thread jaringan di `shouldInterceptRequest` (targetSdk 28 -> RuntimeException); kini memakai `curUrl` yang diisi di `onPageStarted`.
- BELUM dikompilasi/diuji di perangkat.

## Putaran v1.8 (versionCode 9) — panel kembali ke v1.1, log semua alat 2 kolom, root sekali, fxtwitter+NetSniffer, ffmpeg
- Panel daftar download: header (🔍📋🗑✕ 18sp), posisi awal 20% tinggi layar, gagang tarik, dan perilaku seret dikembalikan persis v1.1 (v1.7 membuat ✕ sulit ditekan: ikon 14sp + panel muncul di bawah status bar + mode geser dari pil tengah).
- Log panel: `ToolLog.allLines()` menampilkan SEMUA alat bernomor (pemindai: fxtwitter, Syndication, yt-dlp, yt-dlp+cookies, ytFast, NewPipe, Piped/Invidious, HLS iOS/VR, WebView, HTML, JWPlayer; pemantau: Logcat root, tcpdump, Media session, Clipboard root, Notifikasi, Aksesibilitas, ffmpeg) dalam 2 kolom 13sp (separuh pertama kiri, sisanya kanan) + status sistem di bawah. AutoScan tidak lagi menimpa log rantai.
- `RootGate` (NetSniffer.kt): izin root diminta SEKALI saat aplikasi mulai (`su -c id`), semua pemantau root (logcat, tcpdump, media_session, clipboard), cookies root, dan rute VPN root menunggu gerbang ini. tcpdump kini selalu dijalankan bila binary ada (tidak lagi hanya saat "pantau semua").
- NetSniffer: ID/URL tweet di logcat -> `Resolver.submitTweet` -> fxtwitter/vxtwitter/syndication langsung (maks 6 ID baru/menit); media `twimg.com` dari logcat -> `Resolver.submitFast` (masuk daftar tanpa HEAD). Penghitung baris/link/permintaan HTTP tampil di panel.
- Semua alat pemindai kini mulai SERENTAK (tunda HLS/WebView YouTube dan WebView situs dihapus); X: fxtwitter, Syndication, yt-dlp polos (cara v1.1), NewPipe, WebView, HTML.
- ffmpeg: `io.github.junkfood02.youtubedl-android:ffmpeg:0.17.2` + `FFmpeg.getInstance().init()` di `AlfyApp` (status di panel).
- BELUM dikompilasi/diuji di perangkat (lingkungan penulis tanpa Android SDK/Maven).

## Putaran v1.9 (versionCode 10) — panel geser/cubit, root cek ulang otomatis, X tanpa yt-dlp, play otomatis situs stream
- Panel: `FloatingService.PanelFrame` — geser dari mana saja (header + area log langsung; daftar download: tahan sebentar lalu geser), pinggir/sudut tetap ubah ukuran, cubit/renggang 2 jari = kecil/besar (ScaleGestureDetector).
- Root: `RootGate.watch()` cek ulang tiap 3 dtk (lalu 30 dtk) sampai root diizinkan, lalu `NetSniffer.enable()` menyalakan semua pemantau sendiri; MainActivity meminta root PERTAMA (`rootFirst()`), izin lain ikut diberikan lewat root. Penyebab lama: status "ditolak" tersangkut (state=3) walau sudah diizinkan di Magisk.
- YouTube: `thumbScan` (pencarian video dari judul thumbnail) dimatikan (penyebab video acak); update yt-dlp dicoba ulang sampai 8x (30 dtk).
- X/Twitter: yt-dlp dihapus dari `Chain.runGeneric` jalur X.
- jwplyr/vidoy: dipindai aktif otomatis tanpa paste (`Resolver.ytdlp` → `Chain.runGeneric`; halaman utama vidoy.asia diingat di `Resolver.mainPage`); `AlfyAccessibilityService.autoPlay()` menekan tombol play yang terlihat di situs stream (`canPerformGestures` ditambah ke accessibility_config.xml); pref `autoPlay` (default aktif).
- BELUM diuji di perangkat/CI.

## Putaran v1.10 (versionCode 11)
- Panel: geser dari mana saja hanya setelah ditahan 2 dtk (getar); usapan biasa menggulir log. Header tetap langsung bisa digeser.
- X: halaman profil/subdomain dipindai (fxtwitter `/2/profile/{handle}/statuses`, `SiteTool.xProfile`), `pageRe` mencakup semua halaman x.com, rescan tiap ~10 dtk saat scroll (`AlfyAccessibilityService.xTick`), cooldown X 8 dtk.
- HLS/m3u8: setelah unduh, bila bukan MP4 valid (tanpa ftyp) dikonversi otomatis `ffmpeg -c copy` (`DownloadService.remuxMp4`, binary dicari di noBackupFilesDir).
- BELUM diuji di perangkat.

## Putaran v1.11 (versionCode 12) — tombol ⚙ scan, sumber link jelas, suara asli NewPipe, YouTube fokus video terbuka
- Panel: tombol ⚙ di header (`FloatingService.showOptions`) = 2 kotak centang: (1) aktifkan semua tools scan di semua aplikasi & web (bawaan aktif), (2) scan sangat agresif (bawaan mati). Pref `scanAll` / `scanAggr`, dibaca lewat objek `Scan` (Util.kt). Scan mati = semua pemindaian otomatis berhenti; aksi manual (🔍, 📋, Bagikan, tambah tautan; src diawali "Manual"/"Share") tetap jalan.
- Mode agresif: logcat/tcpdump memproses semua URL, halaman web apa pun di layar ikut dipindai (maks 4 rantai bersamaan), thumbScan YouTube hidup, jeda coba ulang 20 dtk, HTML + JWPlayer + yt-dlp ikut di rantai YouTube/X/situs.
- Log panel: semua alat selalu tampil "⏳ memindai otomatis (siaga)" saat scan aktif; baris "Scan otomatis: AKTIF • normal/AGRESIF" di bawah log.
- Sumber link: `Resolver.submit/rescan/submitMedia` menerima `src`, dibawa ke thread latar (`ToolLog.tl`); semua pemanggil memberi label (Aksesibilitas (…), Logcat root, tcpdump, Clipboard…, Share, Browser Alfy, Manual…). Tanpa label = "Tidak diketahui". `direct()` kini memakai `probe()` agar ukuran terisi.
- NewPipe/Piped/ytFast/gv(): trek audio dubbing/deskripsi/DRC dibuang (`Resolver.isOrigAudio`, `getAudioTrackType`) -> pratinjau memakai suara asli.
- ytFast: 3 klien (VR 1.62.27, VR 1.60.19, IOS) dicoba SERENTAK.
- Video acak setelah login: `WebTool.grab` kini hanya menerima link googlevideo yang `dur=`-nya cocok dengan durasi video yang dibuka (iklan/autoplay ditolak).
- YouTube mode normal: tautan YouTube lain di layar aplikasi YouTube tidak dipindai otomatis; hanya video yang dibuka/diputar.
- BELUM dikompilasi/diuji di perangkat.

## Putaran v1.12 (versionCode 13) — ⚙ 18 tool, tombol 🚫 blokir situs, YouTube otomatis hanya yang terlihat/diklik/diputar, channel di scan layar
- ⚙ (`FloatingService.showOptions`): scan otomatis, scan agresif/normal, dan 18 kotak centang tool (`Tool.all` = `ToolLog.chainAll` + `monAll`; pref `tool_<nama>`, bawaan aktif) + log status tiap tool di bawah namanya (`ToolLog.statusOf`, diperbarui tiap detik lewat `updateLog`). Tool dimatikan: dibuang dari `Chain.run/runGeneric` (`specs.removeAll`), pemantau root (`NetSniffer.feed/dump/media/clip`), `AlfyNotifService`, `AlfyAccessibilityService` (otomatis; tombol 🔍 tetap jalan), ffmpeg (`DownloadService` lewati remux), fxtwitter (`Resolver.submitTweet`).
- 🚫 (`BlockActivity`): daftar situs yang tidak discan (pref `blockList`, objek `Block` di Util.kt). Dicek di `Resolver.submit/rescan/submitMedia/submitFast/sniff/sniffSync`, `Chain.run/runGeneric`, `searchYoutube`. youtube.com juga mencakup youtu.be/googlevideo/ytimg; x.com ↔ twitter.com/twimg/t.co.
- YouTube mode otomatis (normal): `onPlayer` kini butuh tombol Bagikan DAN Suka/Simpan/Remix yang TERLIHAT dan teksnya diawali kata tombol (judul feed berisi "like/save/suka" tidak lagi dianggap pemutar); `ytQuery(root, true)` hanya node `isVisibleToUser`, mengabaikan keterangan thumbnail rekomendasi & teks di bawah 65% tinggi layar; `scan()` tidak memindai tautan apa pun di aplikasi YouTube; `thumbScan` (agresif) hanya thumbnail terlihat; `Scan.ytLock()` (mode normal + YouTube di depan, `AlfyAccessibilityService.fgPkg`) membuat logcat/tcpdump tidak memasukkan link.
- Scan layar (🔍) & klik: nama channel dibaca ("Buka saluran X", "X • N subscriber") lalu dipakai di pencarian dan penilaian hasil (`Resolver.quickSearch(q, shorts, chan)`, `searchYoutube(..., chan)`, fallback yt-dlp memilih uploader yang cocok).
- BELUM dikompilasi/diuji (tanpa Android SDK di lingkungan penulis).

## Pengaturan per situs (v+)
`SiteSettings.kt`: key = host tanpa "www.", JSON di prefs "siteSettings", hanya menyimpan override (null = ikuti global). Opsi: desktop/mobile, JavaScript, blokir pop-up & redirect, scan otomatis (hanya bisa dimatikan), blokir iklan. Menu browser: "Pengaturan situs ini". Hook: MiniActivities (BrowserTabs.create), AdBlock.isAd/cosmetic (param opsional), AlfyAccessibilityService (AutoScan web).

## v1.50 (versionCode 51) — laporan kegagalan tool disusun sebagai prompt lengkap untuk AI
- `ScanReport.build(all, only)` ditulis ulang: [0] instruksi untuk AI (peran, 6 tugas, batasan, format jawaban), [1] profil app, [2] lingkungan (versi app, perangkat, root, VPN, mode scan), [3] target scan (halaman, jenis situs, tautan per sumber, pemenang, diagnosa), [4] daftar SEMUA tool + status + tugas, [5] penolakan link, [6] detail tool (golongan, status mentah, cakupan, implementasi file/fungsi, pemicu, tanda sukses, risiko umum, riwayat langkah, indikasi penyebab), [7] permintaan akhir.
- Data teknis per tool ada di `ScanReport.INFO` (tambahkan entri bila menambah tool baru; `ROLE` untuk tugas).
- Tiga pintu salin memakai generator yang sama: 📖 (hanya tool GAGAL), ⚡ SCAN MAKSIMAL + LAPORAN → SALIN SEMUA LOG (semua tool), 📋 per tool di ⚙ (`ToolStatus.detail` → `build(false, nama)`).
- Klasifikasi memakai `ToolStatus.state()`: tool 'siaga/menunggu/dilewati/dimatikan' tidak lagi dianggap gagal. `ToolStatus.history(n)` publik.
- BELUM dikompilasi (tanpa Android SDK di lingkungan penulis).

## v1.51 (versionCode 52) — laporan AI: sebab gagal PASTI + perintah memperbarui zip
- `ScanReport.diagnose(n)`: sebab gagal dibaca dari kondisi nyata (RootGate.state 0/1/3, tool dimatikan ⚙, scan otomatis mati, layanan Aksesibilitas/Akses Notifikasi belum diaktifkan vs aktif tapi tidak berjalan lewat Settings.Secure, binary tcpdump tidak ada, logcat putus, Scan.ytLock, mesin yt-dlp/ffmpeg belum siap, tool tidak berlaku untuk jenis situs, jaringan/VPN tidak tervalidasi, timeout). Label PASTI/SENGAJA/BUKAN KEGAGALAN = bukan bug kode.
- Laporan [2] kini memuat status jaringan/VPN, Aksesibilitas, Akses Notifikasi, root; [4] menampilkan 'Sebab' per tool; [6] 'Sebab terdeteksi' + 'Dugaan tambahan'.
- Instruksi [0] meminta AI langsung memperbarui AlfyDownloader.zip (kode, versi, KONTEKS.md) dan menyerahkannya sebagai unduhan.
- BELUM dikompilasi.

## v1.52 (versionCode 53) — laporan AI diringkas (hemat token, untuk Claude gratis)
- `ScanReport.build()` dipangkas: [0] perintah keras (jangan ubah yang ada, patch minimal, fokus zip, saran 1 baris, langsung kirim zip), [1] kondisi 3-4 baris, [2] daftar semua tool 1 baris (all=true: + status mentah), [3] tool gagal: kode (file/fungsi), status, sebab PASTI, 3 langkah terakhir (risiko/dugaan hanya bila sebab tidak pasti). Profil panjang & katalog tugas dihapus.
- BELUM dikompilasi.

## v1.53 (versionCode 54) — aturan keputusan di prompt laporan AI
- `ScanReport.instruksi()`: AI menilai tiap perbaikan SANGAT DISARANKAN (langsung diganti di zip, tanpa tanya) / RAGU (tanya 1 baris, jangan ubah) / TIDAK DISARANKAN (jangan diubah). Di luar yang sangat disarankan tidak boleh mengubah apa pun. Penekanan hemat token di awal & akhir. Balasan: 'Tool: DIGANTI/TANYA/SKIP — alasan' + zip.
- BELUM dikompilasi.

## v1.54 (versionCode 55) — scan alamat yang dibuka (non-root), Instagram video+suara, log alamat
- `Resolver.submit`: alamat dari bar alamat browser (src "Aksesibilitas (bar alamat)") kini SELALU dipindai (situs apa pun, bukan hanya daftar `pageRe`), kecuali mesin pencari/beranda umum (`barSkipRe`). Jalan tanpa root. `AutoScan` ikut memindai ulang halaman terakhir mana pun.
- Log: `Resolver.shortAddr()` -> "Sedang scan: host/path" (diag) dan judul rantai "Situs host/path". ID bar alamat ditambah (location_bar dll).
- Instagram/Facebook CDN: `Resolver.igDirect` membuang bytestart/byteend, membaca `efg` (audio/video DASH), memasangkan video+suara lewat MERGE (`igMerge`, judul "(+suara)").
- NewPipeExtractor v0.26.5 sudah rilis terbaru; yt-dlp/FFmpegKit tidak disentuh. BELUM dikompilasi/diuji.

## v1.55 (versionCode 56) — X tanpa suara, cookies Instagram/X, thumbnail YouTube otomatis
- X: `SiteTool.audioOk` cek jalur suara mp4 (moov tanpa "soun"); bila tanpa suara, kandidat ditandai "tanpa suara" dan HLS bersuara dari syndication ditambah (`xFixAudio`, `xHls`). Dipakai di fxtwitter dan syndication.
- `Cookies.fileFor(page)`: cookies login Instagram (sessionid) / X (auth_token) dari Browser Alfy atau browser root -> tool "yt-dlp+cookies" di `Chain.runGeneric` untuk instagram.com dan x.com. `Cookies.file()` (YouTube) kini hanya memuat cookies google/youtube.
- YouTube: `thumbScan` kini aktif di mode normal (pref autoThumb, default aktif), tidak hanya mode agresif. Risiko: IP VPN lebih cepat ditandai bot.
- Instagram app tanpa root: URL reel tidak tampil di layar, jadi tidak ada jalur pasif; butuh root (logcat) atau Share. BELUM dikompilasi/diuji.

## v1.56 (versionCode 57) — situs vldey.mom
- `vldey.mom` diperlakukan seperti vidoy/jwplyr (dugaan, situs tidak bisa dibuka dari lingkungan penulis): masuk `pageRe`, `jwPageRe`, `jwMediaOkRe`, `streamHostRe` (auto-play), `Chain.runGeneric` (isJw), `Resolver.ytdlp` (halaman utama). Referer asal lewat `Resolver.jwRef()`; `jwRefs` ikut mencoba vldey.mom. BELUM diuji.

## v1.57 (versionCode TETAP 57) — perbaikan X.com: auto-scan status + filter iklan
- `Resolver.isXAd(u)`: URL host x.com/twitter.com/twimg.com/t.co yang memuat `/ads/`, `/promoted/`, `?promoted` atau host `ads.x.com` diabaikan di `submit`, `submitMedia`, `submitFast`, `WebTool.looksMedia`.
- `Resolver.xStatusId(u)` + `submit`: URL `x.com/.../status/ID` dinormalkan ke `https://x.com/i/status/ID` dan SELALU dipindai (force) -> `Chain.runGeneric` menjalankan fxtwitter + Syndication otomatis.
- `BrowserActivity` WebViewClient: `doUpdateVisitedHistory` memicu scan saat X (SPA) pindah ke halaman status tanpa reload (onPageStarted tidak terpanggil). BELUM dikompilasi/diuji.

## Laporan jujur & ringkas (versionCode TETAP 57)
- `ScanReport`: prompt/instruksi AI dihapus. `translate/honest` = penerjemah error (403 -> "Situs menolak akses (403)", timeout -> "Koneksi lambat"). `build()` singkat = hanya tool GAGAL, 1 baris "Nama: alasan"; `build(true)` = tabel Nama Tool | Status | Alasan Jujur. `DlRow`/`DownloadService` menampilkan "Gagal: [alasan]" 1 baris. BELUM dikompilasi.
- 2026-11-04: Swipe-to-delete (SwipeToDismissBox) di tab SEMUA, MainActivity.kt: SwipeDlRow

## v1.58 (versionCode TETAP 57) — Musik universal (Spotify/Apple Music/Joox dll)
- `MusicMap.parse()`: Metadata Matching judul+artis dari JSON-LD MusicRecording, og:title/og:description ("Artis · Lagu · Tahun"), `<title>` ("X - song by Y", "X by Y on Apple Music", "Artis - Judul").
- `MusicMap.run()` (tool "Spotify Match"): cari "Artis Judul audio" via yt-dlp `ytsearch1` (cadangan HTML YouTube) -> `Chain.run`; bila gagal -> yt-dlp `scsearch1` (SoundCloud). Audio hasilnya ditandai `toMp3` (`MusicMap.wants` di `Repo.addCandidates`) dan otomatis masuk antrean unduh (`autoDownload`, nama "Artis - Judul.mp3").
- `DownloadService.finishAudio/convertMp3`: bila `toMp3`, file hasil dikonversi ke .mp3 lewat ffmpeg (libmp3lame, cadangan `-c:a mp3`; lewati bila sudah MP3), lalu cover dipasang. Gagal = file asli dibiarkan. BELUM dikompilasi/diuji.

## v1.57 (versionCode 58) — YouTube auto-scan thumbnail
- `YtThumbScan.kt`: MutationObserver + IntersectionObserver (hanya thumbnail terlihat di viewport) + debounce scroll 600 ms; ID dikirim via JavascriptInterface `AlfyYT` ke `BrowserTab`; antrian 1 video/4 dtk, maks 20/10 menit, lewat `Resolver.submit` ("Browser Alfy (auto-scan)"). Mengikuti pref `autoThumb`, `Scan.enabled()`, `SiteSettings.scan`. Versi dinaikkan atas permintaan pengguna (menggantikan aturan tetap di atas untuk putaran ini). Belum dikompilasi.

## v1.58 (versionCode 62)
- m3u8 selalu lewat ffmpeg langsung (bukan yt-dlp/direct): UA Chrome Mobile, Referer, Origin, Cookie WebView per-referer, -bsf:a aac_adtstoasc; sisa .ts/.part dibersihkan; gagal = error jelas, tanpa fallback yt-dlp.

## Putaran v1.63 — fix 403 Vidlyx: force refresh m3u8 + header lengkap + log ffmpeg mentah
- Penyebab: server Vidlyx (api.tvid.app) menolak token m3u8 kedaluwarsa; unduhan memakai link lama dari cache.
- `Resolver.noteHls()` mencatat setiap request .m3u8 dari intercept (BrowserTab, WebTool.grabPage). `Resolver.forceFreshHls()` dipanggil di awal `DownloadService.ffmpegHls()`: reload tab browser (`window.location.reload()` + klik play) atau WebView tersembunyi bila tab tidak ada, lalu memakai m3u8 TERBARU (host+path sama > host sama), tunggu maks 14-18 dtk; gagal = pakai link lama (dicatat di log).
- FFmpeg: `-user_agent` (UA tab WebView bila ada), `-headers "Referer: [halaman]\r\nOrigin: https://vldey.mom\r\nCookie: [cookie WebView]"` dicoba PERTAMA; lalu kombinasi Referer/Origin lain.
- UI: error HLS kini mentah (`ScanReport.RAW`): baris daftar menampilkan 3 baris stderr terakhir; Detail menampilkan log penuh (refresh, header, exit code, stderr) + tombol SALIN LOG. Belum dikompilasi/diuji.


# v77: 🔍 Visual Scan — (1) hasil ekstrak (URL/teks judul) langsung masuk antrean yt-dlp/NewPipe tanpa aksi tambahan; (2) Force Re-scan: scan manual mengabaikan cache seen/sniffed/lastRescan, jeda gagal & penanda running (Resolver.forgetForManual + Chain.resetForManual; submit() manual selalu lolos seen). YouTube & Toggle tidak diubah.

# v84: Hook pemutar YouTube: googlevideo video-only (mute) -> videoId (dari hook/lastPage) dikirim ke Chain (NewPipe/yt-dlp + ffmpeg merge) agar bersuara.

# v87: wallpaper New Tab (Wallpaper.kt, harian via AppPreferences, tombol Ganti Tema di Pengaturan browser).
- v88: katalog tema halaman baru (ThemeCatalogActivity, grid 2 kolom, menu 'Tema')
